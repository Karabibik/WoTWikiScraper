---
tags: [Women, Altara_people, Rulers, Queens, Deceased, TheBlood, HighSeats, Royalty]
---


*"That woman has more hands than any six women I ever met."*
   —[[Mat Cauthon]] 
**Tylin Quintara Mitsobar**, by the Grace of the Light, was the [[Queen]] of [[Altara]], [[Mistress of the Four Winds]], [[Guardian of the Sea of Storms]], and [[High Seat]] of [[House Mitsobar]]. She is survived only by her one remaining son, [[Beslan Mitsobar]], the rest of her children having died in duels.

## Appearance
She had long glossy black hair with gray at the temples, and a very handsome face with two faint scars on either cheek. She was around 5'3" tall.

## Activities
She was a very smart ruler, taking care to listen to all delegations presented before her, including controversial delegations such as the [[Children of the Light]] and the [[White Tower]]. Despite their shaky status, she listened to what [[Elayne Trakand]] and [[Nynaeve al'Meara]] had to say from the [[Rebel Aes Sedai|Salidar Aes Sedai]]. She did all in her power to help the two young women obtain the [[Bowl of the Winds]], hidden in the Rahad quarter of [[Ebou Dar]], a very poor and dangerous community.
Tylin was delighted when [[Matrim Cauthon]] moved into the palace as a favor to Nynaeve and Elayne. There, Tylin forced him to become her lover at dagger point. She called Mat her pretty and was overly possessive of the young man to the point that for the first time in his life Mat felt like he was the hunted one instead of the other way around. When he broke his leg during the [[Seanchan]] invasion she took the opportunity to switch out his wardrobe for something she preferred seeing a man wear, to his great embarrassment.
After the Seanchan landed in Altara, Tylin swore the requisite Seanchan oath of fealty and was raised to [[The Blood|the High Blood]]. In return, the Seanchan promised her complete control over all of Altara. To bolster their promise, [[Suroth]] took Tylin away for a week on a *raken* to show her the lands she would eventually control once more territory had been reclaimed.
Both women returned early because Suroth was informed of a military emergency, Tylin to find that Mat had made and was executing plans to escape his gilded captivity. After a tempestuous farewell during which Mat found that he really did have feelings for this pushy queen, she volunteered to be tied up and shoved under her bed lest the Seanchan believe she helped Mat free some leashed [[Aes Sedai]], going so far as to coach Mat in how she should be tied and reassuring Mat that tomorrow she would play the part of an outraged monarch after learning of his perfidy, and making promises to [[Tuon]], the [[Daughter of the Nine Moons]], that she may buy him if he were ever caught.
Unfortunately the *gholam* who was tracking Mat in order to kill him, as the medallion he wears is the only thing that can kill the *gholam*, discovered and then killed and fed upon Tylin while she was tied up.

## Notes






https://wot.fandom.com/wiki/Tylin