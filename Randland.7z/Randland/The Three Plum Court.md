---
tags: [Inns, Tarabon]
---
**The Three Plum Court ** is an inn in [[Tanchico]]. The innkeeper's name is [[Rendra]].  Special dining rooms at Three Plum Court include the Chamber of Falling Blossoms.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Three_Plum_Court