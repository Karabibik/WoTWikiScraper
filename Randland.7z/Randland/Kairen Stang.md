---
tags: [Women, BlueAjah, Andor_people, RebelAesSedai, AesSedai, Deceased, CaemlynEmbassy, HighRankingAesSedai, Channelers]
---



*"Men say many things, Lady Dyelin, but you know I do not lie."*
   —Kairen Stang, Lord of Chaos 
**Kairen Stang** was an [[Aes Sedai]] of the [[Blue Ajah]].

## Contents

1 Appearance
2 Strength and Abilities
3 History
4 Activities
5 Notes


## Appearance
She was described as being beautiful, with an oval face and icy blue eyes. She is 5'4 tall.

## Strength and Abilities
Kairen's introduction in the main books made it seem that she was not in a high standing because she had to defer to many sisters in the Salidar Embassy to Rand.
Instead her strength level given in "The Wheel of Time Companion" is 18(6), meaning she was quite a high-ranking Aes Sedai, stronger than many Sitters. Also strong enough to use [[Traveling]] on her own. Indeed, she was only a little less strong in relation to most of the other members of the [[Salidar Embassy to the Dragon Reborn]], but in most groupings of Aes Sedai she would have stood quite high.
She was strong in [[Earth]]. She was one of the few [[Rebel Aes Sedai]] strong enough in earth to make  [[Cuendillar|cuendillar]]*,* and she was stronger than almost all of them except [[Egwene al'Vere|Egwene]], [[Leane Sharif|Leane]] and [[Bodewhin Cauthon|Bode]].

## History
Kairen was 63 years old when she died. She was born in 937 NE and became a [[Novice|novice]] in 952 NE, at age fifteen. She spent eight years as a novice and eight years as an [[Accepted]] before she was raised to the shawl in the year 968 NE.
She was one of the first to greet [[Moiraine Damodred]] and [[Siuan Sanche]] when they first come to the Blue Ajah living quarters. She is one of those who took note when Moiraine leaves the Tower, though she does not say anything.
She had one Warder, [[Llyw]].
She, [[Anaiya Carel]] and [[Cabriana Mecandes]] were nicknamed "The Three" because they did not share any of their activities with anyone else except each other. Anaiya's and Kairen's close association with Cabriana helped disclose the mystery around their murders.

## Activities
She was a part of the [[Salidar Embassy to the Dragon Reborn|embassy]] sent by the [[Salidar Aes Sedai]] to [[Rand al'Thor]] in [[Caemlyn]]. She approaches [[Dyelin Taravin]] with certain promises. According to Min, she worried that Rand ruled in her native Andor, and that he might have murdered [[Morgase Trakand|Morgase]].
When that embassy was dissolved, [[Bera Harkin]] and [[Kiruna Nachiman]] ordered Kairen, [[Demira Eriff]], [[Valinde Nathenos]] and [[Berenecia Morsad]] to take the novices from the [[Two Rivers]] to the rebel camp. Though Kairen had the same strength and 1 year shorter training time compared to Demira, Demira was the one put in charge; possibly because Demira had been attacked by fake [[Aiel]].
She was one of the few Aes Sedai among the rebels that has the ability to create *cuendillar*, and is the best after Egwene, Leane, and Bode, indicating her high strength in Earth*.* She finds her slow progress very frustrating. [[Janya Frende]] chastises her for acting sullen and not having as good an attitude about it as some of the novices.
[[Egwene al'Vere]] notes she has been spending a lot of time with [[Lelaine Akashi]] lately, and tended to favor Lelaine's positions. This was partly due to her frustration at the lack of success of the Salidar Embassy, and partly due to the shock of seeing former Accepted Egwene as the new [[Amyrlin Seat|Amyrlin]].
She was murdered by [[Aran'gar]], who broke her neck with *saidin, *wrenching her head around almost full circle. Kairen is survived by her [[Warder]], [[Llyw]], whose bond was passed to [[Myrelle Berengari]] (after [[Faiselle Darone]] twisted her arm into taking it). She was murdered for the same reason Anaiya was; unless incapacitated, they could have exposed "[[Halima]]'s" lie about having been Cabriana's secretary.
Her death meant that turning the [[Southharbor]] chain to *cuendillar* fell to the novice, [[Bodewhin Cauthon]], though Egwene 
decided to go herself instead.

## Notes






https://wot.fandom.com/wiki/Kairen