---
tags: [Towns, AradDoman]
---
**Kandelmar** is a town in [[Arad Doman]].
[[Rodel Ituralde]] won a victory at Kandelmar against the [[Dragonsworn]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Kandelmar