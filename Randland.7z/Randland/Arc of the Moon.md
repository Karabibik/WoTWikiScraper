---
tags: [Swordforms, ]
---


**Arc of the Moon** is a [[Sword form|sword form]]. Other than the name, nothing is known about it. [[Rand al'Thor]] used the form during his practice duel against five other men in [[Caemlyn]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Arc_of_the_Moon