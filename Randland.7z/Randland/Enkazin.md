---
tags: [Men, Saldaea_people, Soldier_Ashaman, LivingasofKOD, Channelers]
---


**Enkazin** is a [[Saldaean]] [[Asha'man]] [[Soldier]] at the Black Tower.

## Appearance
He is skinny and broad-nosed just short of his middle years. He looks like a clerk with a bit of a stoop as if from hunching for long hours over a writing table. He has tilted eyes.

## Activities
He watches the six [[Red Ajah]] members, when they come to the [[Black Tower]] to ask [[Mazrim Taim]] for permission to bond Asha'man as [[Warder|Warders]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Enkazin