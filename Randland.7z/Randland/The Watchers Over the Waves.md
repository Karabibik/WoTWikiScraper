---
tags: [Seanchanculture]
---



The **Watchers Over the Waves** or *Do Miere A'vron* were a group of people who believed that the armies [[Artur Hawkwing]] sent across the [[Aryth Ocean]] would someday return. They were located in the [[Almoth Plain]], along the coast of [[Toman Head]], primarily in the town of [[Falme]].
The Watchers built watchtowers along the coast. Their leader was called the First Watcher. The Do Meire A'vron were mentioned in the [[Karaethon Cycle]]. It was said that "above the Watchers shall he proclaim himself." [[Rand al'Thor]] first accepted the mantle of the Dragon Reborn above Falme when the [[Horn of Valere]] was sounded.
When the [[Seanchan]] appeared in Falme the *Do Meire A'vron* were punished. The First Watcher was placed in a cage, hung from one of their towers overlooking the harbor in Falme, and left to die. When the First Watcher died another was named and placed in the cage. The Seanchan claimed the Watchers over the Waves had "watched for the wrong thing, and forgot what they should have been remembering."

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Watchers_Over_the_Waves