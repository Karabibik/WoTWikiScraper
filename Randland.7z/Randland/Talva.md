---
tags: [Women, YellowAjah, BlackAjah, AesSedai, Deceased, Dreadlords, Channelers]
---


**Talva** was an [[Aes Sedai]] of the [[Yellow Ajah]]. She was also part of the [[Black Ajah]].

## Appearance
She is thin, and wears her golden hair in a bun.

## Activities
Talva is among the Black sisters who flee the [[White Tower]] before the Black Ajah hunters can question them.
While eavesdropping on [[Egwene al'Vere]], [[Nynaeve al'Meara]] and [[Elayne Trakand]] in *Tel'aran'rhiod*, Talva unknowingly sets off one of Egwene's [[Ward|wards]]. She begins to [[Weave|weave]] [[Five Powers|Fire]] at Egwene when the [[Amyrlin Seat|Amyrlin]] comes to investigate, but is too slow, and Egwene [[Shielding|shields]] her and binds her in flows of [[Five Powers|Air]] instead.
Talva is accidentally killed by [[Alviarin Freidhen]], who suddenly appears and throws a jet of Fire at Egwene. When Egwene disappears to avoid the flow, Talva is left in the path of the weave and is incinerated, screaming as her flesh burns. Because she dies in the [[World of Dreams]], she also dies in real life.
She was possibly using one of the dream *ter'angreal* stolen by [[Sheriam Bayanar]] one [[Mesaana|Mesaana's]] orders, so her soul may not have been obliterated from the [[Pattern]].






https://wot.fandom.com/wiki/Talva