---
tags: [Women, Cairhien_people, Ladies, LivingasofTOM, Nobility]
---


**Alaine Chuliandred** is a [[Cairhienin]] lady. 

## Appearance
She is a short, pretty lady and wears her hair in a tall array of curls.

## Activities
She makes certain advances on [[Rand al'Thor]] at [[Barthanes Damodred]]'s party even though she is still married.
She is seen walking through the corridors talking amicably with [[Fionnda Annariz]].
Queen [[Elayne Trakand]] brings Alaine and a small group of Cairhienin nobles to [[Caemlyn]] where she first demonstrates her newly created [[Dragon|Dragons]]. She then witnesses [[Arymilla Marne]], [[Elenia Sarand]] and [[Naean Arawn]] have their lands and titles stripped by Elayne. These lands are offered to [[Bertome Saighan]] and [[Lorstrum Aesnan]] on the condition that they support her ascension to the [[Sun Throne]].

## Notes






https://wot.fandom.com/wiki/Alaine_Chuliandred