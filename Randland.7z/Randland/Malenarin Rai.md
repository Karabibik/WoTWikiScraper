---
tags: [Men, Kandor_people, Soldiers, Deceased, POVcharacter]
---


**Malenarin Rai** is the commander of [[Heeth Tower]] in North [[Kandor]] near the [[Blight]].

## Activities
He is told by [[Jargen]] about a mirror flash from [[Rena Tower]]. When he goes to investigate why there was a flash, he sees the storm getting darker and moving towards him. He gives his son [[Keemlin Rai]] his sword, making him a man, and then prepares his men for battle. A huge force of [[Draghkar]] attack from the sky and a massive army of [[Trolloc|Trollocs]] march towards the Tower. It can be assumed he doesn't survive the conflict.

## Notes






https://wot.fandom.com/wiki/Malenarin_Rai