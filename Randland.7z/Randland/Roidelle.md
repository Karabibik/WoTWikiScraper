---
tags: [Men, BandoftheRedHand, Mapmakers, LivingasofTGS]
---


Master **Roidelle** is the mapmaker for the [[Band of the Red Hand]].

## Appearance
He is graying with a round face. His bulk strained the dark coat he was wearing.

## Activities
He joins the [[Band of the Red Hand]] and accompanies [[Talmanes Delovinde]] into [[Altara]]. While there they find [[Matrim Cauthon]], who uses Roidelle's maps to help plan a series of hit and runs against a number of larger [[Seanchan]] forces.
He claims that a road they find just off the border of [[Altara]] will lead them all the way into [[Andor]].

## Notes






https://wot.fandom.com/wiki/Master_Roidelle