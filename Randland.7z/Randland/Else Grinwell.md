---
tags: [Women, Andor_people, LivingasofTDR, Novices, Channelers]
---


**Else Grinwell** is the eldest daughter of nine children, living on a farm between [[Whitebridge]] and [[Arien]]. 
After meeting [[Rand al'Thor]] and [[Mat Cauthon]], Else seeks adventure and goes to the [[White Tower]] to enrol as a [[Novice|novice]], although she is a very weak channeler and is lazy as a novice, and is sent away from the Tower after a short amount of time. She is later impersonated by [[Lanfear]].

## Contents

1 Appearance
2 Activities
3 In the television series
4 Notes


## Appearance
She is dark-haired, big-eyed, pretty, and plump. Her dark hair is in braids.

## Activities
When Rand and Mat are traveling to [[Caemlyn]], they stop at her family's farm. She flirts with Rand while he stays there.
Else ran away from home to go to the [[White Tower]] to train as a [[Novice|novice]] after meeting Rand and Mat, but was sent home when she shirked her works and studies. She would spend almost all her time at the Warder practice yards. She didn't want to work at learning; but her potential was very low, so the White Tower was willing to let her go in under a year.
[[Lanfear]] used Else as a disguise twice while in the White Tower—once, after Else had been sent away.

## In the television series
Else has not been cast in the [[The Wheel of Time (TV series)|television series]].  
## Notes






https://wot.fandom.com/wiki/Else_Grinwell