---
tags: [Women, Aiel_people, Shaido, FarDareisMai, Deceased]
---


**Marthea** was a [[Shaido]] [[Maiden of the Spear]].

## Activities
She became [[Arrela Shiego]]'s protector while Arrela was a *gai'shain* in the town of [[Malden]]. They become lovers. She hated what the Shaido did but stayed with them out of loyalty. Ultimately this cost her her life and she died in the [[Battle of Malden]].

## Notes






https://wot.fandom.com/wiki/Marthea