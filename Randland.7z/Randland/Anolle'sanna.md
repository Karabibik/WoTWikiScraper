---
tags: [, Towns, Aramaelle, Historicalsettlements]
---
**Anolle'sanna** was a town in the nation of [[Aramaelle]], which was part of the [[Ten Nations]]. Aside from the name, nothing else is known about it.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Anolle%27sanna