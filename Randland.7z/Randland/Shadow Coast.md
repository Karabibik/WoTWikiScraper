---
tags: [Otherfeatures, Geographicalregions]
---



The **Shadow Coast** is the name given to the southwestern-most coastline of the [[Westlands]], where the [[Aryth Ocean]] meets the [[Sea of Storms]]. The Shadow Coast was once part of the kingdoms of [[Aelgar]] (during the time of the [[Ten Nations]]) and later [[Balasun]] and [[Kharendor]] during the Free Years, but is today unclaimed by any nation, although it is bordered by both [[Tarabon]] and [[Amadicia]], neither of which seem inclined to try to resettle it.
The Shadow Coast is known for its dangerous reefs and broken coastline, with numerous offshore islands. Sailing close to the coast is hazardous. A semi-submerged peninsula, [[Windbiter's Finger]], extends for several hundred miles out to sea from the Shadow Coast, forcing ships to give it a wide berth. Good harborages on the coast are almost impossible to find, with the next viable harbors being [[Tanchico]] to the west or [[Ebou Dar]] to the east. The [[River Sharia]] rises in the eastern part of the Shadow Coast.
Tall, dark hills and mountains dominate the interior, and wild and dangerous animals are said to live in the countryside. Mostly, it is a region to be avoided.






https://wot.fandom.com/wiki/Shadow_Coast