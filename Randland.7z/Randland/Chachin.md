---
tags: [Capitals, Kandor, Borderlands]
---

**Chachin** is the capital city of [[Kandor]], in the [[Borderlands]]. It is located on the junction of several trade routes, including the cross-Borderland route running from [[Bandar Eban]] to [[Fal Moran]] and another running south to [[Tar Valon]]. It is located just south of the [[Blight]] and as a result is extremely heavily defended, although it is large enough and far enough south that vigilance is not quite as severe as in smaller settlements such as [[Canluum]]. Chachin is not usually counted as one of the great cities of the [[Westlands]], but it rivals [[Tear]] in size. Despite being neither built by Ogier nor founded on the site of a city built by Ogier, Chachin holds its fair share of ancient relics; foremostly the documents named *the Strike at Shayol Ghul* were found inside the mountain city. It is unknown exactly how old the city is; it is known that it, and its neighbor capital [[Shol Arbela]], lay within the borders of [[Elsalam]], but it is neither said of what importance they were nor if either of them was capital.
The city is built around several hills with three tall mountains rising out of the center. The [[Aesdaishar Palace]], the seat of the ruler of Kandor, currently Queen [[Ethenielle Cosaru Noramaga]], is located atop the highest mountain, which rises over 5,000 feet over the city below. Three tall ringwalls encircle the city with a 100-foot-wide drymoat located beyond that. Twenty-four bridges cross the moat, each overlooked by a small fortress where the bridge meets the city. The Bridge of Sunrise is located on the eastern side of the city, where the road from Canluum enters the city.
As with many Borderland cities, Chachin is mostly made of stone buildings with glazed tile roofs that are more difficult to burn in a sneak attack. The poorest districts are nearest the edge of the city, within the first ringwall, with the districts becoming richer and more prosperous the closer a traveler comes to the central mountains.
The city is also the home of the Merchants' Guild of Kandor. These merchants can easily be recognized by the chains going across the front of their coats.
Inns within Chachin include the [[Silver Penny]], [[Ruffled Goose]], [[Evening Star]] and [[Blind Pig]].

## In the books
Chachin was visited by [[Moiraine Damodred]] and [[Al'Lan Mandragoran|al'Lan Mandragoran]] in early 979 NE, during the events of *New Spring*. Moiraine was searching for evidence of the [[Dragon Reborn]] and Lan was attempting to halt an attempt by his former lover [[Edeyn Arrel]] to have him claim the throne of ruined [[Malkier]] against his wishes. During their visit several important people died, including Prince-Consort [[Brys]] and his son [[Diryk]], as a result of the machinations of the [[Black Ajah]]. After these events Lan agreed to become Moiraine's [[Warder]] and aid her in her search for the Dragon Reborn, a quest that would eventually be fulfilled twenty years later in the [[Two Rivers]].






https://wot.fandom.com/wiki/Chachin