---
tags: [Women, Entertainers, LivingasofKOD]
---


**Miyora** is a leopard trainer in [[Valan Luca]]'s [[Valan Luca's Traveling Show|traveling show]]. 

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Miyora