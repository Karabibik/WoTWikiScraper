---
tags: [Women, Aiel_people, WiseOnes, Shaido, LivingasofKOD, Channelers]
---


**Belinde** is a [[Wise One]] of the [[Shaido]] [[Aiel]]. 

## Appearance
She is skinny and has a narrow and fox-like face. She is slender with pale blue eyes and hair almost bleached white.

## Strength and Abilities
Belinde can [[Channel|channel]] quite strongly. In TWoTC her strength level is described as 18(6), the same level of [[Coiren]] and [[Corele]], which is a high ranking level among [[Aes Sedai]].
This strength is more than enough to open alone a gateway for [[Travel|Traveling]]. 

## Activities
She participated in the murder of [[Desaine]] and fights in the [[Battle of Dumai's Wells]]. She was "Chosen from the strongest of the Shaido Wise Ones who could wield the One Power". She helps to activate the call box and is present when both "[[Sammael|Cadder]]" and "[[Graendal|Maisia]]" arrive.
She ends up Traveling to [[Ghealdan]]. She carries out severe punishments on [[Galina Casban]] for slapping her.
She is present when [[Therava]] and the [[Shaido]] decide to abandon the quest to conquer the [[Westlands]] and return to the [[Three-Fold Land]].






https://wot.fandom.com/wiki/Belinde