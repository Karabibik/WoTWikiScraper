---
tags: [Men, Aiel_people, Clanchiefs, Reyn, LivingasofLOC, DuadheMahdiin]
---


**Dhearic** is the [[Clan chief|clan chief]] of the [[Reyn]] [[Aiel]]. 

## Appearance
He is a thick set Aiel with a prominent nose and white streaks through his golden hair.

## History
Before becoming chief, he was a [[Duadhe Mahdi'in|Water Seeker]]. 

## Activities
Dhearic's Reyn clan join up with [[Rand al'Thor]] just before he reaches the [[Jangai Pass]].
He leads his Aiel clan when he is sent to the [[Plains of Maredo]] when Rand gathers a massive army in preparation for the attack on [[Illian]].






https://wot.fandom.com/wiki/Dhearic