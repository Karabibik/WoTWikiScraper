---
tags: [Women, Novices, LivingasofTGS, ElaidaaRoihansWhiteTower]
---


**Lucain** is a [[Novice|novice]] in the White Tower. 

## Appearance
She is a brunette.

## Activities
She is one of the novices who are part of [[Egwene al'Vere]]'s resistance against the invading [[Seanchan]] in the [[Battle of Tar Valon]].






https://wot.fandom.com/wiki/Lucain