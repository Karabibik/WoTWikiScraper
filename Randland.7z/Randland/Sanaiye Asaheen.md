---
tags: [Women, GreenAjah, AradDoman_people, AesSedai, Living, DorlanGroup, ElaidaaRoihansWhiteTower, Characternotmentionedinbooks]
---


**Sanaiye** is a [[Domani]] [[Aes Sedai]] of the [[Green Ajah]] who remanied loyal during the [[Tower]] split.

## Contents

1 Strength
2 Activities
3 Particularity of this character
4 Notes


## Strength
[[Covarla Baldene]] obtained command in [[Dorlan]] because she was the strongest in that group of Aes Sedai. Sanaiye's strength must therefore be below that of Covarla (21(9)).

## Activities
She was one of the Aes Sedai sent to kidnap [[Rand]] in [[Cairhien]]. She escaped with [[Covarla Baldene]] after [[Dumai's Wells]] battle and took refuge in the village of Dorlan.

## Particularity of this character
This Aes Sedai is described only in "The Wheel of Time Companion", she is never mentioned in the main books of the Wheel of Time.

## Notes






https://wot.fandom.com/wiki/Sanaiye_Asaheen