---
tags: [Terangreal, ItemsofPower, EbouDariStash]
---
The **sapphire ring** is a *ter'angreal* in the possession of [[Nynaeve al'Meara]]. It was recovered from the [[Kin's Storeroom]] in the [[Rahad]] district of [[Ebou Dar]].

## Appearance
The ring is average-sized and contains a flawless blue sapphire.

## Use
When in the presence of someone feeling anger or hostility, the ring will turn cold against the wearer's finger.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Sapphire_ring