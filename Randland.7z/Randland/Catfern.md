---
tags: [, HerbsandMedicines]
---
**Catfern** is an [[Herbs|herb]] that can be found in the [[Two Rivers]] region. A village [[Wisdom]] such as [[Nynaeve]] can boil the catfern and mix with powdered [[Mavinsleaf|mavinsleaf]] to form a viscous sickly green liquid with an atrociously acrid tang. The concoction is harmless, but the highly unpleasant taste makes drinking it a punishment administered for someone who lies.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Catfern