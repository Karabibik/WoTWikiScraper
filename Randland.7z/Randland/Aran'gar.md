---
tags: [Women, Borderlands_people, Forsaken, Deceased, POVcharacter, Antagonists, Balefired, Reincarnated, Maids, Secretaries]
---




**Aran'gar** ([[Old Tongue]]: *one of a twin set of daggers, along with* [[Osan'gar|osan'gar]]), was the reincarnation of [[Balthamel]], whose soul was retrieved by the [[Dark One]] at the moment of his death and placed in the body of a woman from the [[Borderlands]].
Aran'gar's primary motivation was to infiltrate and undermine the [[Rebel Aes Sedai]] and keep the [[White Tower]] fragmented and divided, posing as **Halima Saranov**, the maid to the rebel [[Amyrlin Seat]], [[Egwene al'Vere]]. After her true nature came close to being exposed, Aran'gar retreated to [[Natrin's Barrow]] with [[Graendal]], where she was killed with [[Balefire|balefire]] when the building was attacked by [[Rand al'Thor]], with it being impossible for even the Dark One to reincarnate her again.

## Contents

1 Appearance
2 Activities

2.1 Hiding in Salidar
2.2 Hiding spot revealed
2.3 Graendal's Guest


3 Notes


## Appearance
Showing a sense of humor, the Dark One reincarnated the soul of this womanizer Forsaken into the body of an alluring Borderlander woman.
Aran'gar's new body is strikingly beautiful; her perfect face has big green eyes and glossy black hair. She has a thin waist and large hips. She often showed a large amount of her full, firm bosom. She is about 5'4 or 5'5 tall. She has an earthy, outspoken manner. Women would describe her as the sort of woman who had been dreamed up by a lascivious man.
Curiously, she was still channeling *saidin*, which seems to show that it is the soul that determines which part of the [[True Source]] that is channeled, at least in the case of resurrection by the Dark One. That the soul has gender is a curious feature of Jordan's metaphysics, and is a concept not found in reincarnationist religions such as  and  from which Jordan drew many of his ideas.
Her training as a historian (as Balthamel) gave her the ability to deduce things about the present time with a greater ability than the other Forsaken.
Though initially angered at her new body, she soon adapts to it. She would smile temptingly at anyone, though Egwene at least thought it was just the shape of her mouth. Formerly a womanizer, she now took pleasure in pursuing men, yet still retained her love of women, making her bisexual. She wanted any pretty man or woman she saw.

## Activities

Using the knowledge [[Semirhage]] gained from torturing [[Cabriana Mecandes]], Aran'gar posed as a friend of Cabriana's. Her goal was to influence the rebellion and keep it going so the White Tower would remain divided and distracted. She revealed many things she supposedly learned from Cabriana about Elaida's plans; few believed her at first, but she soon gained some measure of credibility when some of Elaida's true plans leaked out, as there was some congruence. However, she was careful about what she revealed. As, Egwene, Siuan, and Leane could disprove some of her more outrageous planned claims, leading to a lessening of her overall credibility. She initially claimed that Cabriana had found evidence proving Elaida as Black Ajah, but backed off once others questioned her.
Aran'gar hides with the [[Rebel Aes Sedai|Salidar Aes Sedai]] marching on [[Tar Valon]], using the alias **Halima Saranov** and working as secretary to [[Delana Mosalaine]] (a [[Black Ajah|Black]] sister posing as [[Gray Ajah|Gray]]). She ingratiates herself with the rebel [[Amyrlin Seat]] [[Egwene al'Vere]] by giving Egwene massages to ease the frequent painful headaches (e.g., a migraine headache) which often left the Amyrlin "whimpering." While, unbeknownst to Egwene, Aran'gar was *causing* her headaches and not *only* treating them. During this time Egwene also frequently experienced troubled dreams that she couldn't remember on waking, an odd occurrence for a Dreamer. Aran'gar was likely causing these as well; this is confirmed later by [[Mesaana]] asking if she was too busy "playing your little dream-games with her that you forgot to find out what she was thinking?" during the Forsakens' meeting in Tel'aran'rhiod.
She kills Egwene's other maids [[Meri]] and [[Selame]], who were spying for [[Romanda Cassin|Romanda]] and [[Lelaine Akashi|Lelaine]]. She didn't want her own position to be endangered. Egwene's last maid [[Chesa]] survived simply because she wasn't a spy, and was completely loyal to Egwene.
Balthamel's fondness for physical pleasures has expanded since the resurrection, and as Halima, wears quite revealing dresses which cause quite a bit of comment.
Halima danced with [[Matrim Cauthon]] while he was in Salidar. After Mat decides that Halima is too forward and leaves her, Halima channels at Mat as he's walking away. The [[Foxhead medallion]] he wears goes cold, stopping *saidin* this time. Mat turns around, and sees Halima looking at him with a very surprised expression on her face, but only for a very brief moment.


Halima rescues [[Moghedien]] from the *a'dam* in which she is being held, which she accidentally touches. [[Egwene al'Vere]] who was wearing the bracelet at the time feels this.
She travels with the Salidar delegation to meet with various nobles along the border of [[Andor]] and [[Murandy]]. Though her abilities in Tel'aran'rhiod were not particularly great, she would spy on Egwene, and eavesdropped on Egwene's meeting with Nynaeve and Elayne. She clumsily opened a door too loudly and alerted them to her presence though, and had to escape before learning more.


She participated in the [[Battle near Shadar Logoth]]. She is forced to retreat when she is attacked by [[Nesune Bihara]], [[Daigian Moseneillin]], [[Beldeine Nyram]] and [[Eben Hopwil]]. Hopwil is killed during the exchange when he detects her channeling *saidin* but, as he is not controlling a *circle*, he must attack her just physically.
While in the camp she murders [[Anaiya]] and her [[Warder]], and [[Kairen Stang]] with *saidin*.
She attends the meeting with the other Chosen in *Tel'aran'rhiod*, which is made to look like the [[Ansaline Gardens]]. There she is told that Rand is not to be harmed and that Mat and [[Perrin Aybara]] are to be killed if found. She flirts with [[Graendal]] and entertains the notion of entering an alliance with her. When Moridin reveals that Sammael, or another Chosen disguised as him, had given orders to Myrdraal and Shadowspawn which sent them into the Ways, Aran'gar thinks to herself that she wishes she knew who was playing her own game. This suggests that she had begun posing as [[Sammael]] but still was not the one to have ordered the assault on Rand at Lord Algarin's manor. She was likely plotting to kill Rand in some other scheme, though, as she thinks to herself that Moridin was going to be "terribly disappointed" about not harming Al'Thor.
When [[Jahar Narishma]] came with a proposal from the [[Dragon Reborn]] [[Rand al'Thor]] to the Salidar rebel Aes Sedai about bonding forty-seven [[Asha'man]], Narishma detects someone channeling *saidin* and warns them of a female Forsaken able to channel *saidin*. Romanda realizes that a female Forsaken channeling saidin could explain the deaths of [[Anaiya Carel]] and [[Kairen Stang]], who had been close to Cabriana; and connects this with Halima's presence and claims of being a friend of Cabriana's. However, despite ordering the arrests of Delana and Halima, the two had already fled to prevent detection.
It is finally revealed that Halima was [[Sheriam Bayanar]]'s tormentor.


Aran'gar and Delana end up hiding out with Graendal. When al'Thor sends Lord [[Ramshalan]] to [[Natrin's Barrow]], Graendal, sensing a trap, orders Delana and Aran'gar to place compulsion on him. As Aran'gar announces that she senses a huge amount of the One Power nearby, Graendal realizes it's a trap and shields Aran'gar and Delana so they cannot escape with her. Aran'gar and Delana are burned out of existence along with Graendal's hideout, making the compulsion disappear.

## Notes






https://wot.fandom.com/wiki/Aran%27gar