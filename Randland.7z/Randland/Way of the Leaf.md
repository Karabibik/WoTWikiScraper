---
tags: [Tuathaan, Aielculture]
---

*"The leaf lives its appointed time, and does not struggle against the wind that carries it away. The leaf does no harm, and finally falls to nourish new leaves. So it should be with all men. And women."*
   —[[Aram]] 




The **Way of the Leaf** is a pacifistic code of honor practiced by the [[Da'shain Aiel]].  The *Tuatha'an*, who descended from the Da'shain Aiel, also follow it. The philosophy uses the leaf as a model for life; not using force or resisting its fall from the tree. It is similar to the [[Water Way]]. It is held in contempt by most of the people in the Aiel Waste and the Wetlands, probably due to the fact that the Tinkers follow it.
Under the Way of the Leaf, the *Tuatha'an* will not raise a hand even to defend themselves.

## Contents

1 Da'shain Aiel
2 Tuatha'an
3 Jenn Aiel
4 The Bleakness
5 Notes


## Da'shain Aiel

During the [[Age of Legends]] the Da'shain Aiel were a people that worked as servants for the [[Aes Sedai]]. These people were sworn to serve the Aes Sedai and uphold the Way of the Leaf.

## *Tuatha'an*

Following a split among the Da'shain Aiel a group decided to forsake the command of the Aes Sedai and instead seek out the Song of Growing. These people went on to become the *Tuatha'an*. They still held to the Way of the Leaf, and are today alone among the decendant of the Da'shain Aiel to do so. Members of the *Tuatha'an* that can not abide to live according to the Way of the Leaf leave the *Tuathan'an* society to go and live in the cities. They are called "the lost." There are also people who seek out the *Tuatha'an* and join their ranks because they find the Way of the Leaf appealing.

## Jenn Aiel

A second split among the remaining Da'shain Aiel occurred when a group of Aiel abandoned the Way of the Leaf, but still maintained that they were Aiel. The original group that still held on to the Way of the Leaf started to call themselves Jenn Aiel, the others simply Aiel. As time went by the Jenn Aiel dwindled to extinction.

## The Bleakness

At [[Alcair Dal]], Rand al'Thor revealed the secret that the Aiel had once been the Da'shain Aiel and followed the Way of the Leaf. The reaction to this revelation differed, but some forsook the spear and *cadin'sor* and attempted to live the Way of the Leaf in the wetlander cities, or among the *Tuatha'an*, as their ancestors would have.

## Notes






https://wot.fandom.com/wiki/The_Way_of_the_Leaf