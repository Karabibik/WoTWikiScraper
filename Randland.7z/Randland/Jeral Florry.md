---
tags: [Men, Andor_people, Innkeepers, LivingasofTDR]
---


**Jeral Florry** is the innkeeper of the [[The Good Queen]], in [[Aringill]].

## Activities
When [[Mat]] and [[Thom]] arrive in Aringill they find all of the inns full. They finally buy a place in the stable. Mat notices that the innkeeper likes to gamble and wins two horses at two rolls to one odds. Later as they are preparing to go to sleep, [[Aludra]] brings a wagon in to the stable and shortly after [[Tammuz]] and three men come in to murder her. Mat comes to the rescue and receives a bundle of fireworks as a reward.

## Notes






https://wot.fandom.com/wiki/Jeral_Florry