---
tags: [, Militaryunits]
---
**Cavalry** is a type of military unit consisting of mounted soldiers organized for scouting, flanking and/or shock assaults. 
Cavalry is most commonly equipped with [[Horse|horses]] and are organized into [[Troop|troops]] of fifty cavalrymen led by a [[Lieutenant|lieutenant]]. Ten troops are organized as a [[Squadron|squadron]] under the command of a [[Captain|captain]]. Three squadrons under the command of a [[Banner-General]] form a [[Banner|Banner of Horse]]. Generally, [[Legion|Legions]] combine cavalry (horse) and infantry (foot) Banners; "pure" cavalry legions (and higher formations) are almost unheard of.
Cavalrymen are often contemptuous of infantry or foot soldiers.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Cavalry