---
tags: [Mountains]
---




The **Spine of the World** is a vast mountain range that stretches from the [[Blight]] in the north to the [[Sea of Storms]] in the south, forming the eastern border of the [[Westlands]] and separating it from the [[Aiel Waste]] and the [[Termool]] to the east. The rivers [[River Erinin|Erinin]], [[River Iralell|Iralell]] and [[River Gaelin|Gaelin]] all flow out of the Spine. The Aiel refer to the Spine as the Dragonwall.


The range has two major spurs which extend into the Westlands: [[Kinslayer's Dagger]] and the [[Maraside Mountains]], which respectively form the northern and southern borders of the kingdom of [[Cairhien]].
There are several passes through the mountains. The [[Niamh Passes]] cross from the Aiel Waste to [[Shienar]]. The [[Jangai Pass]] crosses from the Aiel Waste into [[Cairhien]]. It is also possible to circumvent the Spine to the south through a narrow coastal strip between the mountains and the [[Bay of Remara]], but this route only leads into the hostile swampland known as the [[Drowned Lands]].
There are several Ogier *steddings* in the Spine. From north to south these are: [[Stedding Qichen|Qichen]], [[Stedding Sanshen|Sanshen]], [[Stedding Handu|Handu]], [[Stedding Chanti|Chanti]], [[Stedding Lantoine|Lantoine]], [[Stedding Yongen|Yongen]], [[Stedding Mashong|Mashong]], [[Stedding Sintiang|Sintiang]], [[Stedding Taijing|Taijing]], [[Stedding Kolomon|Kolomon]], [[Stedding Daiting|Daiting]] and [[Stedding Shangtai|Shangtai]].

## External links
  on  





https://wot.fandom.com/wiki/Dragonwall