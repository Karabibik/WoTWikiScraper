---
tags: [Women, FarMadding_people, CounselsofFarMadding, LivingasofWH, ]
---


**Cyprien** is one of the thirteen [[Counsel|Counsels]] of [[Far Madding]]. 

## Appearance
She has protruding teeth.

## Activities
She was in attendance as the Counsel discussed the fate of [[Rand al'Thor]] when [[Cadsuane Melaidhrin]] burst in and demanded the release of the [[Dragon Reborn]].






https://wot.fandom.com/wiki/Cyprien