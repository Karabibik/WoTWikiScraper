---
tags: [Altara, Thrones]
---
The **Throne of the Winds** is the seat of power in [[Altara]], located in [[Ebou Dar]]'s [[Tarasin Palace]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Throne_of_the_Winds