---
tags: [Men, ChildrenoftheLight, Soldiers, Unknownstatus, LivingasofACOS, ]
---


**Canvele** is an officer of the [[Children of the Light]].

## History
Canvele is one of the [[Lord Captains]] of the [[Council of the Anointed]] of the Children of the Light.
[[Rhadam Asunawa]] says Canvele believes the law should be obeyed.

## Activities
He becomes complicit in [[Eamon Valda]]'s plans for the Children, but only because Valda brought half a legion with him to the [[Fortress of the Light]].
It is unknown whether or not he survived the [[Battle of Jeramel]], although it is known that three Lord Captains died there.

## Notes






https://wot.fandom.com/wiki/Canvele