---
tags: [AgeofLegends]
---
A **hoverfly** was a flying vehicle used in the [[Age of Legends]]. One is described through the eyes of [[Coumin]] (whilst [[Rand al'Thor]] is in the [[Glass columns|glass columns]] in [[Rhuidean]]) as "a deadly black metal wasp containing two men." It was also said to have "buzzed overhead in its patrol". The Wheel of Time companion directly describes it as the equivalent of a helicopter.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Hoverfly