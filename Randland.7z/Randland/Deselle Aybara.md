---
tags: [Women, Andor_people, TwoRivers_people, Deceased, ]
---




**Deselle Aybara** was [[Perrin]]'s sister. 

## History
Her father and mother were [[Con Aybara]] and [[Joslyn Aybara]]. She also had another brother, [[Paet]], and a sister, [[Adora]]. She was twelve.

## Activities
[[Padan Fain]] murders Perrin's entire family including Deselle. Their deaths are blamed on Trollocs.

## Notes






https://wot.fandom.com/wiki/Deselle