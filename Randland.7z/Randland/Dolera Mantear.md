---
tags: [Women, Andor_people, Rulers, Queens, Deceased, HighSeats, Characternotmentionedinbooks]
---


**Dolera Mantear ** was  former Queen of [[Andor]] and High Seat of [[House Mantear]].

## History
She succeeded her mother as Queen of Andor in 944 NE. Her mother died at aged 78.
She had one known daughter, [[Mordrellen Mantear]], and four elder sons.
[[Gareth Bryne]] became Captain-Commander of the [[Queen's Guards]] under her reign in 963 NE.
Her husband was [[First Prince of the Sword]] until his death in 963 NE. On his death, Gareth Bryne also became [[Captain-General (Andor)|Captain-General]] of Andor and First Prince of the Sword.
Dolera died in 964 NE, succeeded by her daughter Mordrellen.

## Notes






https://wot.fandom.com/wiki/Dolera_Mantear