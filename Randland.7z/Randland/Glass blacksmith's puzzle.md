---
tags: [Terangreal, ItemsofPower, EbouDariStash]
---
The **glass blacksmith's puzzle** is a *ter'angreal* found in the [[Kin's Store Room]] in [[Ebou Dar]].

## Appearance
The *ter'angreal* has an unspecified appearance of a blacksmith's puzzle made of glass. It is heavy, and when dropped broke a chip off the edge of a cistern cover.

## Use
The use of this *ter'angreal* is unknown. [[Elayne]] tried testing it with a touch of Spirit, but it left her extremely dizzy and kept her from sleeping for half the night.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Glass_blacksmith%27s_puzzle