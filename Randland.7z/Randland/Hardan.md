---
tags: [FormerNationsoftheNewEra, Historicalnations]
---
**Hardan** was a nation that came into existence after the [[Hundred Years War]]. It was located between [[Shienar]] and [[Cairhien]]. Its capital was [[Harad Dakar]].


[[Stedding|Stedding Nurshang]] was found within the borders of Hardan. 
Circa 700 NE, Hardan collapsed as its population declined to low levels and the city of Harad Dakar was abandoned. 

|**Westland Nations**|
|-|-|
|**New Era**|**Current:****Former:**|
|**Free Years**||
|**After the Breaking**||
|Places | Items | Timeline | Concepts|


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Hardan