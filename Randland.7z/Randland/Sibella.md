---
tags: [Women, Kinswomen, LivingasofTPOD, FarmGroup, Channelers, Accepted]
---


**Sibella** is part of the [[Knitting Circle]] in the [[Kin]] based in [[Ebou Dar]]. 

## Appearance
She is scrawny with yellow hair. She has no gray or white in her hair. She favored plunging necklines and appeared to be in her middle years. She wore the red belt of a Wise Woman.

## Activities
Her Saidar strength is revealed in the Wheel of Time Companion to be 22(10), strong enough to be tested for Aes Sedai. In fact, she is as strong as many Sitters, though the Wheel of Time Companion states she would not be strong enough to make a Gateway (which some Aes Sedai of her strength are able to do). However, she badly failed her test for Aes Sedai and was put out of the White Tower. She was born in 613 NE, went to the Tower in 627 NE, spent ten years as novice and six as Accepted, and was put out in 643 NE. 
She is one of Kin that accompanies [[Elayne Trakand]] and [[Nynaeve al'Meara]] to the [[Rahad]] to find the [[Bowl of the Winds]]. She narrowly survives the attack from the *gholam*.
She nearly faints when Merilille and others unmask her as a Kinswoman; and again when it was suggested she sit in the presence of the Aes Sedai and Queen Tylin. 
She [[Traveling|Travels]] with the the rest of the group led by Nynaeve and Elayne from Ebou Dar to the Kin's farm with the Bowl of the Winds.
As all the Kinswomen in the [[Farm|farm]] she later travelled to [[Andor]].






https://wot.fandom.com/wiki/Sibella