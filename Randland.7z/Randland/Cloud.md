---
tags: [Horses]
---


**Cloud** is a tall and gray [[Horse|horse]], with black mane and tail. [[Rand al'Thor]] rode him when he fled the [[Two Rivers]].
Cloud is very spirited as well as very fast.  He was purchased from [[Jon Thane]], the miller, who would often race the horse against those belonging to merchants' guards.  Rand had never known the horse to lose. 
Cloud was ridden out of Two Rivers, into [[Baerlon]], out of Baerlon, into [[Shadar Logoth]], and out of Shadar Logoth by Rand. After Rand rode Cloud out of Shadar Logoth, he, [[Thomdril Merrilin]], and [[Matrim Cauthon]] escaped incoming [[Trollocs]] by boat, abandoning their horses, including Cloud.

## Notes






https://wot.fandom.com/wiki/Cloud