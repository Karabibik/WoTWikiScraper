---
tags: [Men, Kandor_people, Soldiers, Deceased, ]
---


**Caniedrin** (pronounced: cah-NIE-drihn) was a [[Kandori]] archer in [[Lan]]'s army during the [[Aiel War]]. 

## Appearance and Skills
He was an efficient, experienced, young beardless soldier who enjoyed fighting. He usually laughed when he was fighting.
Some months later, he is dressed scruffily, making him look older.
Caniedrin is an archer of rare skill.

## Activities
He brought Lan's horse, [[Cat Dancer]], to him before the battle at the Hook. 
Later, Lan was shot with an arrow by Caniedrin while traveling with a young [[Moiraine Damodred]] when she is searching for the [[Dragon Reborn]]. Moiraine binds him with the One Power to prevent him escaping. While still bound, he is shot by [[Bukama Marenellin]] and [[Ryne Venamar]], being killed almost instantly. This comes dangerously close breaking the Oath against using the One Power as a weapon in Moiraine's mind as it allowed him to be executed.
While dying he revealed to Lan that he was paid by a man to assassinate Moiraine and her party, with Moiraine to be killed first. He was in the possession of ten Cairhienin gold crowns, one face showing the portrait of Moiraine's uncle [[Laman Damodred]]. Moiraine reflects that her life was worth as much as a dress in Tar Valon.

## Notes






https://wot.fandom.com/wiki/Caniedrin