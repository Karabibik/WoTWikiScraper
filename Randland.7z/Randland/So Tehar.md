---
tags: [Altara, Villages]
---
**So Tehar** is a small village in [[Altara]]. It is a scruffy collection of white-plastered bricks and flies.
[[Matrim Cauthon]], [[Elayne Trakand]], [[Nynaeve al'Meara]] and others stayed at [[The Southern Hoop]], an inn in So Tehar, on their way to [[Ebou Dar]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/So_Tehar