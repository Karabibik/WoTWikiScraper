---
tags: [Towns, Andor]
---



**Kore Springs** is a town in the northern part of Andor, and is the site of [[Gareth Bryne]]'s family home.

## Activities
It is the place where Bryne retired after being dismissed from the Queen's service in [[Andor]]. It is the town where [[Siuan Sanche]], [[Leane Sharif]] and [[Min Farshaw]] were tried and found guilty of burning [[Admer Nem]]'s barn. During Bryne's current absence, the town is currently under the oversee of Bryne's retainer, [[Caralin]].

## Notes






https://wot.fandom.com/wiki/Kore_Springs