---
tags: [Men, BandoftheRedHand, Soldiers, Redarms, Deceased]
---


**Lawtin** was a [[Redarm]] in [[Matrim Cauthon]]'s [[Band of the Red Hand]].

## Activities
He went to [[Ebou Dar]] with Mat and a few other Redarms to search for the [[Bowl of the Winds]]. He was killed, along with [[Belvyn]], when [[Moghedien]] used [[Balefire|balefire]] on the boat in which they were riding.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Lawtin