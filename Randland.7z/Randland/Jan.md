---
tags: [Women, Andor_people, Seamstresses, LivingasofLOC]
---


**Jan** is one of [[Min]]'s three aunts. She lives in [[Baerlon]], [[Andor]] and is a Seamstress. She is gentle and kind, but has very strong notions of proper behaviour.

## Activities
She, [[Miren]] and [[Rana]] have raised Min to be fair; the young woman lives by it, although she sometimes thinks her life would have been easier if she had not had this education .
They also admonished her not to behave like a fluff-brained girl and Min still thinks of her aunts when she hears that word . Jan always said that what could not be mended must be lived with. Another piece of advise that Jan and Rana always gave Min was to never kiss a man if she did not intend to marry him, which is why Min does not want to know what her aunts might think of her relationship with Rand .

## Notes






https://wot.fandom.com/wiki/Jan