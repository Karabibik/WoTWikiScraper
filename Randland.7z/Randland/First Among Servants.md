In the Age of Legends, the First Among the Servants was the equivalent of what the Aes Sedai (Servants of All) called the Amyrlin Seat in the Third Age. Lews Therin Telamon was the First Among the Servants.






https://wot.fandom.com/wiki/First_Among_Servants