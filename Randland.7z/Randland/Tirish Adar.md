---
tags: [Holidays]
---
**Tirish Adar** starts from the rise of the first full moon in [[Adar]], and ends at the rise of the next moon. In most northern countries, no one sleeps more than an hour or two a night during this period.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Tirish_Adar