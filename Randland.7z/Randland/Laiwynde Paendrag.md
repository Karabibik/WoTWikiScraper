---
tags: [Women, Shandalle_people, Deceased, Historicalpeople, Royalty, PeopleoftheFreeYears]
---


**Laiwynde Paendrag** (c. [[FY 964]] - [[FY 994|994]]) was a daughter of [[Artur Paendrag Tanreall]], the High King, and his second wife [[Tamika]]. 

## History
She was born in the late FY 960s or some time in the 970s, and was one of four or five children the couple had. Of the others, the only name that has survived was that of her elder brother, [[Luthair Paendrag Mondwin]].
For a figure of historical importance, we know virtually nothing of Laiwynde. All records relating to her, as with almost everything related to [[Artur Hawkwing's Empire]], was destroyed in the [[War of the Hundred Years]].
It is known that Laiwynde and her young son, [[Tyrn sur Paendrag Mashera]], were the last of Hawkwing's heirs left alive in the [[Westlands]] after the despatch of Luthair to [[Seanchan]] in [[FY 992]] and her sister (name unknown) to [[Shara]] the following year. Laiwynde died under murky and uninvestigated circumstances just days before her father's death in FY 994.
It was claimed at the time that her son died with her, but ten years later a young man emerged in the city of [[Mayene]] claiming to be Tyrn. His claim was accepted by the ruling council of that city and he was made First Lord of the city, but was not acknowledged outside of Mayene.
As such, the current First of Mayene, [[Berelain sur Paendrag Paeron]], claims descent from Laiwynde and Hawkwing via Tyrn.






https://wot.fandom.com/wiki/Laiwynde_Paendrag