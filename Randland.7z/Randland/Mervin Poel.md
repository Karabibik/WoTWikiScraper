---
tags: [Men, Inventors, LivingasofKOD, CairhienAcademy]
---


**Mervin Poel** is an inventor and a faculty member of the [[School of Cairhien]].

## Appearance
Master Poel has a beard and is bald

## Activities
Mervin shows [[Rand al'Thor]] the invention he is working on, which appears to be a steam engine.
When Rand is back at the school to retrieve some books from [[Herid Fel]]'s quarters, he witnesses Mervin's steam-wagon roar to life and move about twenty paces before breaking down again.
When Rand returns to [[Tear]], he sees Poel's steamwagon, which can now travel a hundred miles a day and can also pull wagons.

## Notes






https://wot.fandom.com/wiki/Mervin_Poel