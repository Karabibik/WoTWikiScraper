---
tags: [Men, Aridhol_people, Rulers, Kings, Deceased, Historicalpeople]
---


**Balwen Mayel**, also known as **Balwen Ironhand**, was the last king of [[Aridhol]].  He ruled circa [[1150 AB]]. 

## Appearance
Histories relate that Balwen presented a regal appearance.  His hair coloring was dark and he was of middle age at the time of his death.

## History
Records do not exist to relate the early years of King Balwen's life or how he came to the throne of Aridhol.  He ruled his nation during the height of the [[Trolloc Wars]] and formed a strong alliance with his greatest ally - King [[Thorin al Toren al Ban]] of [[Manetheren]].  Even with his allies close, King Balwen found his nation at the forefront of the fight against the [[Shadow]] and years of protracted attrition warfare began to take their toll on his people.  Thus King Balwen began to despair that victory could never be achieved for the forces of [[Light]].
It was during this time of trouble that a man named [[Mordeth]] came to Balwen's court.  Mordeth quickly became a trusted councilor to Balwen and advised that Aridhol break its commitments provided in the [[Compact of the Ten Nations]] and proceed to fight the shadow alone.  Over time it is said that King Balwen began to change.  He grew cruel and started issuing evil commands to his subjects.  The people of Aridhol also changed during this time and history records that former allies of Aridhol began to fear Balwen's solders more than the [[Shadowspawn]] they fought.
Fearing that his former ally was abandoning the light, King Thorin sent his son Prince [[Caar al Thorin al Toren|Caar]] on a diplomatic mission to Aridhol to convince Balwen to rejoin the Compact of the Ten Nations.  History relates that when Prince Caar arrived he and his embassy were arrested and brought before Balwen as [[Darkfriends]].  Balwen - his eyes filled with madness and Mordeth by his side - ordered Caar and his men to be imprisoned, tortured, and executed.  Caar suffered greatly in the dungeons of Aridhol but eventually escaped Balwen's clutches and fled north.
Shortly after these events King Balwen, and all the people of Aridhol, mysteriously disappeared.  Soldiers of Manetheren arrived at Aridhol to exact vengeance for the mistreatment of their prince only to find the gates of the capital city torn down and nobody living within.  King Balwen's final fate is unknown, though scholars believe that he and all of his people were consumed by the [[Mashadar]] entity.  The soldiers of Manetheren left and later the cursed place became known as [[Shadar Logoth]].       

## Notes






https://wot.fandom.com/wiki/Balwen_Mayel