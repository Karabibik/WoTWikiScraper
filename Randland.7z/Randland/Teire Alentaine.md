---
tags: [Women, GrayAjah, AesSedai, LivingasofCOT, ElaidaaRoihansWhiteTower, DorlanGroup, MiddleRankingAesSedai, Cairhienexpedition, Channelers, Characternotmentionedinbooks]
---


**Teire Alentaine** is an [[Aes Sedai]] of the [[Gray Ajah]]. 

## Contents

1 Abilities
2 Activities
3 Particularity of this character
4 Notes


## Abilities
Teire is not very strong in the [[One Power]]. Her level of strength is described by "The Wheel of Time Companion" as 32(20) which is a middle/low level in Aes Sedai hierarchy. With this level of strength she is unable to open alone a suitable [[Gateway|gateway]] to [[Travel]]. 

## Activities
Teire was part of [[Elaida do Avriny a'Roihan]]'s secret expedition to kidnap [[Rand al'Thor]] in [[Cairhien]].
After kidnapping Rand and escaping capture during the [[Battle of Dumai's Wells]] she flees to [[Dorlan]] along with other sisters under the leadership of [[Covarla Baldene]].
After Elaida learned of the failure from Dumai's Wells, she ordered the sisters to remain in Dorlan and sent [[Narenwin Barda]] to take command of the group.

## Particularity of this character
Teire Alentaine is described only in *The Wheel of Time Companion*, she is never mentioned in the main books of *The Wheel of Time*. Taking inference from the *Companion*, she is the third Gray mentioned in the party sent to kidnap Rand in Cairhien.
But this is in contradiction to the description given by [[Galina Casban]] about this group in *Lord of Chaos*. There, we know the number of sisters involved and the Ajahs involved in this kidnapping group, and no more Gray sisters than one ([[Coiren Saeldain]]) were ever counted in that party.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Teire_Alentaine