---
tags: [Wotwikifeaturedarticles, Women, Saldaea_people, Ladies, LivingasofAMOL, Rulers, Queens, HuntersoftheHorn, Nobility, POVcharacter, Notesneeded, Gaishain]
---





*"I'll not have you bleeding to death on me. That would be just like you, to die and leave me the work of burying you. You have no consideration."*
   —Faile to [[Perrin]] 




**Zarine ni Bashere t'Aybara**, commonly known as **Faile** ([[Old Tongue]]: *Falcon*, pronounced "fa-YEEL") is the wife of [[Perrin Aybara]], the Lady of the [[Two Rivers]], and the present Queen of [[Saldaea]].
Faile begins as an adventurous Saldaean noblewoman who travels to [[Illian]] in order to pledge herself as a [[Hunter of the Horn]]. While adventuring in [[Remen]], Faile chooses to join the party of Perrin Aybara in search of the Horn. Faile journeys through the [[Ways]] to the [[Two Rivers]] with Perrin and several [[Aiel]] after learning of attacks by [[Trolloc|Trollocs]] and [[Children of the Light|Whitecloaks]]. Faile provides constant support to Perrin, and the pair are married after they defeat the Trolloc invasion.
Perrin is declared the Lord of the Two Rivers by its people, and Faile rules as his lady, advising him on matters of state. Faile also journeys to [[Caemlyn]] and [[Cairhien (city)|Cairhien]] when they are held under the direct rule of the [[Dragon Reborn]], and aids in the overthrow of the usurper [[Colavaere Saighan]], and forms an elite personal guard known as *Cha Faile*. While journeying to [[Ghealdan]] in order to put down [[Masema Dagar]], Faile is taken as *gai'shain* by the [[Shaido]] Aiel until she is liberated in the [[Battle of Malden]], where she personally kills the [[Prophet]].
Faile helped negotiate an official agreement between Perrin and Queen [[Elayne Trakand|Elayne]] of [[Andor]] regarding his lordship of the Two Rivers, before organizing their forces to grow ready for the [[Last Battle]]. Faile proved crucial to the victory of the light by giving the [[Horn of Valere]] to [[Olver]] to call forth the [[Heroes of the Horn]]; despite her grievous injuries, she survives the last battle and becomes Saldaea's queen following the deaths of her father and Queen [[Tenobia si Bashere Kazadi|Tenobia]].

## Contents

1 Appearance and Personality
2 Skills and Abilities
3 History
4 Activities

4.1 Finding Perrin
4.2 To Tear and Emond's Field
4.3 To Caemlyn and Cairhien
4.4 To Ghealdan and capture by the Aiel
4.5 After rescue
4.6 Confrontation with the Whitecloaks
4.7 Meeting with Elayne
4.8 The Last Battle


5 External links
6 Notes


## Appearance and Personality
Faile hails from [[Saldaea]] and like most Saldaean women her hair coloring is black which she wears just past her shoulders. Her other obvious Saldaean features include a bold, hooked nose, high cheekbones, prominent slightly tilted dark eyes, and a wide mouth which some might have found too wide. Faile is tall and slim with a high voice and a flat way of speaking. She is beautiful in an exotic way; and it took Perrin several weeks to decide if he found her attractive or not. To Perrin's highly sensitive olfactory senses, she frequently smells of herbal soap.
Faile's personality is somewhat aggressive and she is occasionally prone to emotions of anger or jealousy. She harbors a keen intellect which she frequently uses to manipulate people or circumstances to benefit her husband. Emotionally, Faile is the product of Saldaean cultural values where women - be they noble ladies or common farmgirls - express a territorial nature when it comes to husbands and property. Though Faile has a short temper which can lead to fights with Perrin, her passion can express itself just as equally as a fierce love towards him.

## Skills and Abilities

Faile's talents are many and varied. As a result of her upbringing within Saldaean nobility she was well-educated; being exposed to various subjects at a young age. Faile was taught history, accounting, geography, and she gained a passing familiarity with the [[Old Tongue]] though she does not understand it with fluency. Like all Saldaean nobles, she is an expert in the knowledge of horsemanship and can easily guide a horse without the use of reins. Though she hates it and it rankles her, she is highly skilled at sewing and has a deft touch with a needle. In battle Faile is quite skilled at fighting with hands and feet along with the use of combat knives in close quarters. In the summer of 999NE she began training in the Two Rivers style of archery.
For all her skills though, Faile's greatest talent lies in the field of public administration. She is a natural politician, easily able to manipulate others and build political coalitions between various groups and factions. These are skills she put to good use in consolidating political power over citizens in [[Taren Ferry]] to guide them towards deference towards her husband. She understands well the skills needed to govern people and how to apply the precepts of justice.

## History
In the year 981NE, Zarine ni Bashere t'Aybara was born the third child and only daughter of [[Davram t'Ghaline Bashere]] and [[Deira ni Ghaline t'Bashere]]. Her father was the Lord of Bashere Tyr and Sidona, Guardian of the [[Blightborder]], Defender of the Heartland, Marshal-General to Queen [[Tenobia si Bashere Kazadi|Tenobia]] of Saldaea, and the queen's uncle. Thus Zarine was born a cousin to a monarch. During her childhood she was expected to learn the skills and refinements of any Saldaean noblewoman such as needlework, hawking, poetic recitation, playing the cittern, and communication via the Language of Fans. She chafed under these restrictions, envious of her older brothers who rode to the blightborder with their father in order to make war upon [[Shadowspawn]]. So as a teenager Zarine approached an old soldier in her fathers service who had been assigned as her footman, a man named Eran, and insisted that he teach her the ways of combat. Though amused at the request, Eran taught her how to fight with knives as well as in hand-to-hand martial arts.
In the spring of 998NE the Bashere family suffered a pair of tragedies when Zarine's eldest brother was killed in combat with shadowspawn and her next-eldest sibling fell from a horse while out riding and likewise perished. At the age of seventeen Zarine suddenly became the eldest living scion of House Bashere and by Saldaean custom it became her duty to manage the family estates. She was forced to study accounting books, the family ledgers, and learn the ways of commerce and trade. These subjects were a ponderous bore to her and when she noted that her father had begun to train her younger brother [[Maedin Bashere|Maedin]] in the ways of the warrior, she decided upon a drastic course of action. Word had reached Saldaea that the [[The Great Hunt of the Horn]] had been called by the [[Council of Nine]], so Zarine wrote a letter to her mother expressing her discontent in the family's expectations of her, and fled Saldaea to seek adventure in [[Illian]].


Zarine arrived in time to take the hunter's oath in the [[Square of Tammaz]] and become a [[Hunter of the Horn]]. She shed her prior identity to assume the name *Mandarb*; a word meaning *blade* in the [[Old Tongue]]. Soon afterwards she elected to travel with a pair of fellow hunters named [[Orban]] and [[Gann]] who had a theory that the [[Horn of Valere]] was hidden in the [[Forest of Shadows]] south of the [[Two Rivers]]. Since she had a similar notion that the Horn was somewhere in the fallen nation of [[Manetheren]], she felt they could help each other for a time since they would be traveling in the same direction. For several months she journeyed with the two men and their ten retainers until they reached the village of [[Remen]] in the early spring of 999NE. It was in a field near Remen that Orban, Gann, and their retainers unexpectedly encountered the [[Aiel|aielmen]] [[Sarien]] and [[Gaul]] who were searching for [[Car'a'carn|He Who Comes With The Dawn]]. The hunters attacked without cause and the Aiel responded by slaying six of their followers and seriously wounding Orban before Sarien was killed and Gaul was captured. Zarine suddenly found herself wasting a week in Remen as Orban recovered from his wounds. She also had to listen as he bragged and lied to villagers about the number of Aiel he had defeated. She had reached a point that she was ready to depart the village on her own when four interesting strangers rode into Remen from the west; [[Moiraine Damodred]], [[Al'Lan Mandragoran|Lan Mandragoran]], [[Perrin Aybara]], and an [[Ogier]] named [[Loial]].

## Activities
### Finding Perrin

She encountered Perrin Aybara in [[Remen]], [[Altara]]. After watching Perrin fight off a group of [[Whitecloaks]], she decided to follow him, hoping he would lead her to the Horn. When Perrin pointed out that **Mandarb** is the name of [[Lan]]'s horse, Zarine announced that she would call herself Faile instead. **Faile** was a name her father called her when she was young. Faile means falcon in the old tongue, and it instantly made Perrin wary, as in a vision his friend [[Min Farshaw]] told him that a hawk and a falcon would perch on his shoulders.

### To Tear and Emond's Field
Along the way to Tear she learns the reason for the group's travels, [[Rand al'Thor|Rand, The Dragon Reborn]]. Soon after reaching [[Tear]] she gets caught in a trap meant for [[Moiraine]] by picking up a [[Hedgehog|hedgehog]] shaped *ter'angreal* which traps her mind in *Tel'aran'rhiod*. She is rescued by Perrin who finds her with the help of [[Hopper]] through the [[Wolf Dream]].
While she is in Tear she meets [[Berelain sur Paendrag Paeron]], who has decided to lay claim on Perrin for herself. This begins a massive rivalry between the two for the right to Perrin. After the [[Stone of Tear]] falls to [[Rand al'Thor]], she is uneasy about being in Tear and wants to leave with [[Perrin]]. She doesn't let Perrin dissuade her from coming along to the Two Rivers and tricks Loial to get her way. They travel through the Ways and manage to escape [[Machin Shin]]. Upon reaching Emond's Field and learning of the fate of Perrin's family, the Aybaras, she is the one who helps Perrin grieve. She is instrumental in teaching Perrin how to be a great leader as well. Later, they marry, but before the Trolloc horde attacked [[Emond's Field]], Perrin sent Faile away, under the pretext of getting help from [[Queen Morgase]], in the hope she would remain free and not die with the rest of the village. Instead she rides to [[Watch Hill]] to pick up reinforcements and leads them back to [[Emond's Field]] where these men, along with men from [[Deven Ride]], help turn the tide and defeat the Shadowspawn army.


### To Caemlyn and Cairhien
Now known as the Lady Faile, she leaves the Two Rivers with Perrin when he is pulled back to Rand. They head to [[Caemlyn]], where her father and mother happen to be present. She takes an instant dislike to [[Min Farshaw]] upon meeting her, but is not hostile. Faile at first believes that Min is after Perrin, but soon learns that it is not Perrin, but Rand, who Min loves. After a confrontation with her mother, both her parents accept Perrin as her husband.
Faile goes with Perrin and Rand to [[Cairhien]], where Berelain happens to be steward. Berelain continues her pursuit of Perrin, which causes even greater friction between Faile and Perrin, with Faile not even acknowledging Perrin's existence anymore. When it is revealed that Rand is captured by Aes Sedai she opts to stay behind while Perrin goes to rescue him.
While Perrin is gone, she attaches herself as a lady-in-waiting to the newly made Queen of Cairhien [[Colavaere Saighan]]. She secretly gathers information about Colavaere ordering the murders of both [[Lord Maringil]] and [[Meilan Mendiana]], and confronts her with this when Rand arrives back in Cairhien, leading to Colavere having both her crown and lands stripped from her and being exiled to a farm.  Perrin, on his arrival, confronts Faile and after a heated argument (which pleases Faile) they make up.


### To Ghealdan and capture by the Aiel
After Perrin and Rand have a large and angry public argument, Faile joins Perrin on a secret mission to Ghealdan. They are under the pretense of being exiled from the presence of the Dragon Reborn, because of said argument. To her annoyance, Berelain also accompanies them. While traveling to meet the Queen of Ghealdan she chances on Maighdin, who is actually Morgase, and her party. After judging them worthy she takes them into her service. Upon reaching their destination, she is instrumental in binding the Queen of Ghealdan, [[Alliandre]], to Perrin. Later, she is captured by the [[Shaido]] [[Aiel]] and made *gai'shain*.
[[Therava]] and [[Someryn]] are part of a number of [[Wise Ones]] who make her spy on Sevanna and report back any information she finds back to them. She is nearly raped by a massive Aiel named [[Nadric]] but is saved by [[Rolan]], who has noticed her interest in the Aiel way then tries to court her.
A number of other *gai'shain* swear fealty in the hope of escaping with her. Two of these oath-bound *gai'shain*, [[Theril]] and [[Alvon]], steal the [[Oath Rod]] from Therava's tent and bring it to Faile.  She plots her escape in many ways but ultimately is betrayed by [[Galina Casban]] who traps her and her party under a collapsing house. However, she is rescued by Rolan and others, who dig her out. Perrin sees Rolan leading Faile and kills him.

### After rescue

She orders [[Cha Faile]] and a group of Two Rivers men to surround and ambush Masema and the last surviving [[Dragonsworn]]. She stabs Masema, killing him. She believes that as Perrin's wife, she has to do what he can't. Later she meets with Alliandre, Arrela and Lacile. The four women hold a funeral ceremony for the Aiel men and the Maiden that protected them while they were in the Shaido camp and were then ultimately murdered.
While traveling from Malden, she continues to try to support her husband and teach him how to be a leader. She is with Perrin when they find land that appears to have been affected by the [[Blight]].
She confronts [[Bavin Rockshaw]] over some of the shady deals he has been linked to as quartermaster of the camp and is warned to cut it out. She then celebrates a Two Rivers version of *Shanna'har* with Perrin and convinces him that he needs to remain lord of all the people he has assembled. She then explains all her exploits while captive of the Shaido.
She then confronts Berelain about the rumors of her bedding Perrin. At first Faile issues a challenge but on further discussion they decide to be seen around camp as friends to help dissuade rumors. 
She is present during [[Seonid Traighan]]'s report to Perrin on current events that are happening within the continent.

### Confrontation with the Whitecloaks
She rides out front with Perrin when his force is about engage the Whitecloaks and is intrigued with his plan of stalling the combat. She is present at the second parley between Perrin and [[Galadedrid Damodred]] where Maighdin is actually revealed to be [[Morgase Trakand]]. She is walking through the camp when a [[Bubble of evil]] erupts causing all the weapons to attack their owners. When Faile manages to leap out of the way, the dagger becomes inanimate again on contact with soil. She starts throwing dirt on the rest of the weapons which also become inanimate. During the scuffle she saves Berelain's life. This single event seems to have finally quelled all rumors of Perrin's alleged infidelity with Berelain; in the time after, many members of Perrin's army would come up to him and apologize for believing the rumors.
Faile sends Lacile and Selande into the Whitecloak camp to spy. She then charges Dannil to set up a rescue for Perrin just in case the trial goes wrong. She attends the trial and asks if other witnesses may speak for Perrin to contest the accusation that he is a darkfriend to which she is denied by Morgase.
She confronts Perrin after the trial on his decision to submit to Galad's judgement and not instigate battle with the Whitecloaks. He roars back at her that even the Whitecloaks swords will be needed at the [[Last Battle]] and that she is to take command of the armies withdrawal.
She is with Perrin when he wakes from his battle with [[Slayer]] and informs him of the armies withdrawal through a Gateway. She tries to comfort him over the death of [[Hopper]], witnesses him create *Mah'alleinir* and his declaration to the men on his acceptance at becoming their Lord and leader. Perrin then gives the command for his army to Travel back to where the Whitecloaks have set their camp up. Berelain is concerned that Perrin is planning to ambush the Whitecloaks and Faile reassures her that Perrin is not like that. She then realizes that Berelain is attracted to Galad. Perrin sends her, Alliandre and Berelain to the back of his army when his force starts attacking the Trollocs which were about to ambush the Whitecloaks. After the battle, the three ladies help make bandages for the injured.

### Meeting with Elayne
Faile attends Morgase and [[Martyn Tallanvor]]'s wedding ceremony, which is performed by Perrin. The entire camp Travels to Andor where Faile and Perrin eventually confront [[Elayne Trakand]] about their Lordship of the Two Rivers. Faile handles most of the talking, though Perrin does respond and contribute when necessary. They are able to convince Elayne that it is in her best interest to allow them to be nobles of the Two Rivers. Elayne declares that Perrin will be the [[Steward of the Dragon]] for the Two Rivers so they will have an excuse for the political advantage they will have.
She Travels through with Perrin and the rest of his huge force to the [[Field of Merrilor]] to prepare for the [[Last Battle]].

### The Last Battle
Faile is present during negotiations between all the monarchs of the world and Rand over the [[Dragon's Peace]]. With [[Moiraine Damodred]] finally arriving, Rand manages to convince the rulers to sign. Rand has Faile sign the document as well, just in case she raises to a position of leadership. When Elayne asks Perrin to transport the [[Horn of Valere]] to Mat, he refuses and instead puts forth Faile as the one who should carry out
the task. Faile, along with several members of Mat’s band and a few of her own
trusted companions, are transported to [[Tar Valon]] to pick up supplies and a
chest of what everyone else thinks is Two Rivers tabac, but is in fact, the
Horn. As she and the band are leaving Tar Valon via a gateway, a bubble of evil
erupts and injures [[Berisha]] Sedai, causing her to create gateway to the Blight,
instead of the Field of Merrilor.
[[Setalle]] suggests instead of trying to walk out of the
Blight, they head towards [[Shayol Ghul]], where Rand and other channelers are
fighting, and Faile agrees. While traveling she decides to ferret out
Darkfriends by setting a trap to see who might steal the Horn of Valere and she
removes the horn from the chest and buries it. She is surprised to see [[Vanin]]
and [[Harnan]], two trusted members of Mat’s band, have dug up the horn. Instead of
execution, she banishes them, but they continue to follow the caravan through
the Blight. 
They come across a supply camp while in the Blight and
Faile decides they must get through one of the gateways that are being created
to supply the Shadowspawn with weapons and supplies. They make it to the camp,
with [[Aravine]] posing as a merchant of their caravan. Aravine proves to be a
Darkfriend and she takes the Horn to give to [[Demandred]], but Faile ends up
killing her, with the help of Vanin and Harnan who came back to rescue the
group. She is chased by Trollocs, Fades and Darkfriends when they find out she
has the Horn, so she gives it to [[Olver]], instructing him to take it to Mat, and
she gallops off in the opposite direction.
Once the Last Battle is over, she is thought dead by
Perrin but he searches the wolf dreams for her and finds her lying under a
Trolloc, almost dead. He brings her to Merrilor where she is healed, and she becomes the new Queen of Saldaea, with her cousin Queen [[Tenobia si Bashere Kazadi|Tenobia]] as well as her father Davram Bashere having died in the Last Battle.

## External links
  on  
## Notes

|**Major Characters**|
|-|-|
|**Protagonists**|**Main:****Primary:**|
|**Antagonists**|**The Shadow:**|
|**Major Allies**|**Aes Sedai:****Asha'man:****Aiel:****Seanchan:****Westlands Rulers:****Other Allies:**|
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Zarine_ni_Bashere_t%27Aybara