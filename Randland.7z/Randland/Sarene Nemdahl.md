---
tags: [Women, WhiteAjah, Tarabon_people, AesSedai, Unknownstatus, LivingasofTOM, RandsAesSedai, ElaidaaRoihansWhiteTower, HighRankingAesSedai, POVcharacter, Cairhienexpedition, Channelers, LivingasofAMOL]
---


**Sarene Nemdahl** is an [[Aes Sedai]] of the [[White Ajah]].

## Contents

1 Appearance, Personality and Abilities
2 History
3 Activities

3.1 Fealty to Rand
3.2 The Last Battle


4 Speculation
5 Viewings
6 Notes


## Appearance, Personality and Abilities
She is from [[Tarabon]]. She has dark hair that she wears in beaded braids and is 5'4" or 163cm in height; Sarene is considered one of the most beautiful women in the Tower, but she seems totally unaware of her stunning beauty..
When Accepted together, Moiraine thinks Sarene has a sharp tongue that often gets her into hot water, and remarkably little tact, though she seems to be as unaware of what she says as she is of her beauty. Moiraine also thinks Sarene's mother must have been glad to see Sarene's sharp tongue go off to Tar Valon.
Sarene is a typical White. She insists on reasoning logically, and often does not understand matters of the heart. However, Egwene notes that she has a temper, and although she usually keeps it leashed, she can snap your nose off if you put a foot wrong. Sarene will listen to what other people have to say, and is not afraid to admit that she is wrong.
Being chosen by [[Elaida]] and the White Ajah to be among the six ambassadors to the [[Dragon Reborn]] indicates that Sarene is high in the Aes Sedai hierarchy; Sarene is at level 18(6) in saidar strength, which is enough to use the [[Traveling]] weaves proficiently and places her as relatively strong in the One Power compared to other sisters.

## History
Sarene was born in 955 NE and was a shopkeeper's daughter.
She went to the [[White Tower]] in 970 NE. After six years as [[Novice]] and five as [[Accepted]] she was raised to the shawl in the year 981 NE.
She was a novice and Accepted with [[Moiraine Damodred]] and [[Siuan Sanche]].
She has a single [[Warder]], [[Vitalien]]. She secretly writes poetry about him in which she compares him to a leopard, among other graceful, powerful, and dangerous animals.

## Activities
### Fealty to Rand
She remained loyal to the White Tower during the split. She is among the six ambassadors sent by Elaida to the Dragon Reborn in Cairhien and also, on the way, she was part of the White Tower embassy that makes an alliance with the [[Shaido]].
Sarene and the rest of the embassy ride into Cairhien , where she discusses Rand with [[Coiren Saeldain]], Galina, and [[Erian Boroleos]]. In the city she prepares herself to capture him when it is clear that he will not accept the invitation to follow them to Tar Valon.
Sarene was one of the Aes Sedai captured by the [[Asha'man]] at the Battle of [[Dumai's Wells]]. She was made *da'tsang* and held captive in the Aiel camp near Cairhien. There she is probably put under a mild form of compulsion by [[Verin]], planting in Sarene's mind the idea to serve the Dragon.
[[Sorilea]] brings [[Elza Penfell]], Nesune, Erian, [[Beldeine Nyram]], and Sarene to Rand after they beg to be allowed to swear fealty to him. Rand accepts. Some time afterwards Beldeine, Elza, Erian, Nesune and Sarene are in the Sunroom of the Sun Palace with [[Cadsuane Melaidhrin]]. Sorilea enters and gives them a lecture.
She [[Traveling|Travels]] with Cadsuane to [[Far Madding]] to track down Rand but she must leave her Warder behind. She acts as attendant to [[Harine din Togara Two Winds]] while in Far Madding. She participated in the [[Battle near Shadar Logoth]] where she linked with [[Damer Flinn]] and [[Corele Hovian]] against [[Demandred]] . Sarene was badly injured but was completely healed by Damer.
When Rand stays at [[Algarin Pendaloan]]'s house in [[Tear]] to recover after cleansing *saidin*, Sarene and the rest of the group go with him. 
She pushes past Elza Penfell to inform Rand that her Warder Vitalien is Traveling towards her.
She helps maintain [[Semirhage]]'s shield while [[Merise Haindehl]] interrogates the captive. Cadsuane also uses her to interrogate Semirhage.
She goes to Rand's room after finding out about Semirhage's escape and then death. After this episode Erian, Nesune, Sarene, and Beldeine are less welcome in Rand's presence .
With the Last Battle approaching, Sarene engaged in a tempestuous affair with Vitalien.
She informs [[Min Farshaw]] and [[Nynaeve al'Meara]] that [[Alanna Mosvani]] has disappeared mysteriously from the [[Stone of Tear]].

### The Last Battle
As with many of the others sworn to Rand, Sarene fights in [[Thakan'dar]] near [[Shayol Ghul]]. [[Aviendha]] thinks that she is a very good fighter; if Aiel, Sarene could have made an excellent [[Maiden of the Spear]]. The group is puzzled by a mysteriously strong female channeler, and Sarene states that she does not fit any Black Ajah or Forsaken description.
While in a circle with [[Kiruna Nachiman]], [[Faeldrin Harella]] and Aviendha, Sarene is attacked by [[Hessalam]]. Kiruna and Faeldrin are killed, Damer Flinn is gravely injured, and Sarene's Warder is killed. Sarene herself was placed under Hessalam's heavy [[Compulsion]] and kidnapped .
Later Sarene is forced by Hessalam to link to her in circle and to give her strength. While fighting Rand's forces, Sarene falls to her knees, staring vacantly ahead. Her current status is unknown, although she may have died from over-exhaustion from forced [[Channeling|channeling]].

## Speculation
Sarene was the only member of Aviendha's circle that was captured, but not killed or badly injured by [[Graendal]]/[[Hessalam]]. It is possible that, even at that time, Graendal could not force herself to damage such a beautiful specimen.

## Viewings
One of [[Min's viewings]] shows an aura of blue, yellow, and green around Sarene. It means she will serve Rand in her own fashion.
Min has a viewing that Sarene will have a tempestuous love affair. This was with her Warder, Vitalien.
## Notes






https://wot.fandom.com/wiki/Sarene