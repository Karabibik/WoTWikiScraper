---
tags: [Men, Seanchan_people, LivingasofTPOD, EverVictoriousArmy, Soldiers]
---


**Nadoc** is an officer and soldier in the [[Seanchan]] army under the command of [[Furyk Karede]].

## Appearance
He is a big man with a mild face.

## Activities
He is in a Seanchan unit that is on the way to attack [[Illian]]. The [[Asha'man]] attack the Seanchan army and they are forced to retreat back to [[Ebou Dar]].

## Notes






https://wot.fandom.com/wiki/Nadoc