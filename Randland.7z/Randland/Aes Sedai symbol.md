---
tags: [Symbols, AgeofLegends, AesSedai]
---

The **Aes Sedai symbol** is a round black-and white disc. The two colours are divided by a sinuous line in the middle. It has long been associated with the [[Aes Sedai (Age of Legends)|Aes Sedai]] of the [[Age of Legends]]. It's a graphical representation of the philosophical understanding of the duality of life; active-passive, male-female, material-immaterial which underpinned the culture of the Age of Legends.  In the [[Third Age]], it has been split into the white [[Flame of Tar Valon]]; some said it stood for the Light, and the black [[Dragon's Fang]] representing the evil.

## Contents

1 References in the books

1.1 The Eye of the World
1.2 The Fires of Heaven
1.3 Lord of Chaos
1.4 The Towers of Midnight
1.5 A Memory of Light


2 References and similarities
3 Side notes
4 Notes


## References in the books
### The Eye of the World
[[Lews Therin Telamon]] had this symbol sewn to his cloak.
It was carved to the keystone of the stone arch of the opening to the [[Eye of the World]]. 
The [[Seven Seals]] of the [[Dark One]]'s prison were made of [[Cuendillar|cuendillar]] and decorated with the symbol.

### The Fires of Heaven
When Rand was attacked by [[Darkhounds]] in [[Rhuidean]] he waited for them in a room where a mosaic of this symbol was centred on the floor. He stood right in on the sinuous line, one boot on the black teardrop and the other on the white one, thinking about the [[Prophecy of Rhuidean]] saying "*Under this sign, will he conquer."* Because of that prophecy he has chosen that symbol and carried together with the Dragon Banner. Later both were interchangeably named as [[Dragon Banner]]. 
[[Asmodean]], as [[Jasin Natael]] carried the banner with the Aes Sedai symbol for Rand at the [[Jangai Pass]]. It was described as *whiteandblack* symbol centred to a brilliant red banner which rippled behind him just as his gleeman's-cloak.  

### Lord of Chaos
Some Aiel decides to wear a crimson cloth knotted around their temples, with the ancient  Aes Sedai symbol a black-and-white disc above their brows. It was a new thing, first seen only a few months earlier. They called themselves *siswai'aman*; the Spears of the Dragon in the [[Old Tongue]]. The Spears Owned by the Dragon. 

### The Towers of Midnight
[[Egwene al'Vere|Egwene]] has seen the sign in [[Tel'aran'rhiod]], on the place of the rose window which was ruined by the [[Seanchan]] attack on the [[White Tower]]. 
*"A massive rose window dominated the far wall behind the the Amyrlin Seat itself. The Flame at the center sparkled, as if there were sunlight beyond, though Egwene knew those boiling black clouds covered  all the sky of the World of Dreams. *
*She turned from the window, then froze.*
*There, set into the glass below the Flame of Tar Valon, was a large segment in the shape of the Dragon's Fang. That wasn't part of the original window. Egwene stepped forward, inspecting the glass.*
*There is a third constant besides the Creator and the Dark One, Verin's meticulous voice said, a memory from another time. There is a world that lies within each of these others, inside all of them at the same time. Or perhaps surrounding them. Writes in the Age of Legends called it Tel'aran'rhiod.*
*Did this window represent one of those, another world where Dragon and Amyrlin ruled Tar Valon side by side?"*

### A Memory of Light
In the Last Battle white and black clouds swirled together above Shayol Ghul, forming the symbol of the Aes Sedai on the sky. Aviendha, seeing it, remembered the lines from the prophecy: *"Under this sign... shall he conquer."*  The sign was still there when Mat arrives with Olver on to'raken's back. Mat lost the Dragon Banner but Olver points to the sky, smiling *"It will be fine – were beneath his banner already."* and blew the Horn of Valere.

## References and similarities
There is a quite obvious similarity with Buddhism and the symbol of yin-yang.  

## Side notes
Spelling is inconsistent throughout the books. Black and white, blackandwhite, black-and-white are used interchangeably.

## Notes






https://wot.fandom.com/wiki/Aes_Sedai_symbol