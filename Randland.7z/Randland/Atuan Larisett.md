---
tags: [Women, YellowAjah, Tarabon_people, BlackAjah, AesSedai, Unknownstatus, LivingasofCOT, Dreadlords, Channelers]
---


**Atuan Larisett** is an [[Aes Sedai]] of the [[Yellow Ajah]], who is secretly a member of the [[Black Ajah]].

## Contents

1 Appearance and Personality
2 History
3 Activities
4 Trivia
5 Notes


## Appearance and Personality
She is quite striking with dark hair in thin beaded braids that fall to her waist. [[Yukiri Haruna]] thinks she is fairly modest, for a Yellow.

## History
She was born in 809 NE in Tarabon and was enrolled in the [[White Tower]] in 825 NE.
She is secretly a member of the Black Ajah and a member of a [[Heart]] along with [[Marris Thornhill]] and [[Karale Sanghir]]. She is [[Talene Minly]]'s extra contact outside of her Heart.
She has no [[Warder]].

## Activities
Elayne recalls that the [[Stone of Tear]] was created using the [[One Power]] and that Atuan says that such a feat was impossible for the White Tower today.
She was betrayed as being Black Ajah by [[Talene Minly]]. Yukiri spies on her spending time with [[Pritalle Nerbaijan]], also of the Yellow, and suspects the second sister of also being Black Ajah, although as far as we know she is not .
She was tortured using the [[Chair of Remorse]] by Yukiri and [[Pevara Tazanovni]]. After having her Black Ajah Oaths removed using the [[Oath Rod]] and sworn to obey Yukiri and the rest of the Black Ajah hunters, she betrays the members of her Heart and is adamant that she once again walks in the Light.
Her fate is undisclosed. It is possible that she was one of the sisters that managed to escape the Tower, though her Oaths to the Black Ajah hunters may have prevented her flight. If that is the case, she would have been executed with the rest of the Black sisters unable to escape.

## Trivia
There is an [[Accepted]] mentioned in [[New Spring]] called [[Atuan]], but the Companion birth date for Atuan Larisett puts her as being almost 200 years old. Since the surname of the Accepted is never given, and in order to avoid inconsistencies, it is assumed that these are two seperate people with the same first name.
Her name may be a reference to the classic 1971  fantasy novel .


## Notes






https://wot.fandom.com/wiki/Atuan_Larisett