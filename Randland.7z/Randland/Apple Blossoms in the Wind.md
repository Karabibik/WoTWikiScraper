---
tags: [Swordforms, ]
---






**Apple Blossoms in the Wind** is a [[Sword form|sword form]]. It is meant to be used against multiple opponents. It uses three quick strikes to push opponents back.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Apple_Blossoms_in_the_Wind