---
tags: [Swordforms]
---






**Whirlwind on the Mountain** is a [[Sword form|sword form]]. Other than the name, nothing is known about it. [[Rand al'Thor]] used this form with a *saidin*-wrought blade to defend against spears thrown by [[Couladin]] and two other [[Aiel]] after returning from [[Rhuidean]] with [[Matrim Cauthon]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Whirlwind_on_the_Mountain