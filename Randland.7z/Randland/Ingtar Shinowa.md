---
tags: [Men, Shienar_people, Lords, Deceased, Soldiers, Nobility]
---



*"It is every man's right, Rand, to choose when to Sheathe the Sword. Even one like me...One man holding fifty at a narrow passage. Not a bad way to die. Songs have been made about less"*
   —Ingtar 
Lord **Ingtar of House Shinowa** was a [[Shienar|Shienaran]] nobleman, who served under Lord [[Agelmar]] in [[Fal Dara]]. Ingtar was also a [[Darkfriend]] of considerable influence; however, he returned to the [[Light]] shortly before his death.

## Contents

1 Appearance
2 Activities
3 Return to the Light
4 Horn of Valere
5 In the television series
6 Notes


## Appearance
When introduced to [[Rand]] and his company when they arrived in [[Fal Dara]] he was described as a short, dark Shienaran warrior, head shaved except for the topknot, wearing armor and a yellow cloak. His clothes prominently displayed his personal sigil, the Gray Owl (on a yellow background), and the stooping black hawk of Shienar.
Ingtar's helmet was described as having a crescent moon crest positioned so that the points of the crescent moon pointed upward. While searching for the [[Horn of Valere]], before he is revealed as a Darkfriend, [[Perrin Aybara|Perrin]] notes that this helmet crest reminds him of [[Trolloc]] horns.

## Activities
Ingtar and a few other Shienaran soldiers were sent by [[Lord Agelmar]] to escort [[Moiraine]], [[Lan]] and the [[Two Rivers]] folk to the edge of the [[Blight]] when they were searching for the [[Eye of the World]]. He was greatly frustrated at this as it meant he was forced to miss the battle at [[Tarwin's Gap]] where he felt he would have been of more use.
Later, in [[The Great Hunt]], Ingtar was appointed leader of the group that went to chase the [[Horn of Valere]] after it was stolen by [[Padan Fain]]. The group also included [[Rand]], [[Mat]] and [[Perrin]] and was later joined by [[Verin Mathwin]]. The group tracked Fain south across the [[River Erinin]] and through several villages that had been all but destroyed by Fain's party, as well as what was left of the old city of [[Harad Dakar]]. During this time, Rand along with the [[Loial]] and the group's [[Sniffer|sniffer]] [[Hurin]] were separated from the rest because of a [[Portal Stone]] and when Rand managed to get back into the real world he was able to steal the Horn back from Fain. They were reunited with Ingtar in [[Cairhien]] but Fain took the Horn back once again and fled through the [[Ways]] to [[Toman Head]], forcing the group to follow them using a Portal Stone as the Ways were blocked by the [[Black Wind]]. Upon reaching Toman Head they discovered the [[Seanchan]] were in control of the peninsula and the Horn was in the possession of High Lord [[Turak Aladon]] in [[Falme]]. Ingtar's group snuck into the High Lord's residence where they took back the Horn and slew the High Lord, throwing Falme and the Seanchan into chaos. It is at this point while escaping the mansion that Ingtar confesses to Rand that he is a [[Darkfriend]] after appearing to be lost in his thoughts for a while, and his experiences living a myriad possible lives inside the Portal Stone after Rand misused it somewhat appear to have philosophically shaken him to his core and incited him to return to the [[Light]]. In particular, Ingtar confesses to having been the one who let an assassin (his description indicates that this was likely a [[Gray Man]]) into Fal Dara keep, leading to an attempt on the life of either Rand or the Amyrlin Seat. Upon Ingtar saying that 'It is every man's right to choose when to [[Sheathe the Sword]]', Rand then commends him to 'the last embrace of the mother' in the way of Shienaran funeral rites and he is presumed to have been killed defending a narrow alleyway against a large Seanchan patrol in order to allow the others to escape.

## Return to the Light
Like most Shienaran Lords, Ingtar was well educated in matters of history. He was pessimistic about mankind's chances in the long run, and the endless war with the [[Blight]] and the vast stretches of land unclaimed by any nation made him change his allegiance to the [[Shadow]], thinking it would be better for Shienar than 'useless oblivion, like [[Caralain]], or [[Hardan]].' He later regretted that choice and saw the pursuit of [[Padan Fain]], who he had freed, and the [[Horn of Valere]] as a way to redeem himself, and it seems the unfortunate journey through the Portal Stone made him see all the possible lives he might lead and the horrible things he might be forced to do in the service of the Shadow. He resolved his internal crisis by confessing all to Rand al'Thor and fully forsaking the Shadow, invoking the idea that 'no man can walk so long in the Shadow that he cannot come again to the Light'. The price he paid for his service to the [[Dark One]] was his own life, willingly sacrificing himself so that Rand and the others could escape. 
Ingtar is one of only two known examples in the series of Darkfriends who have returned to the Light, the other being [[Verin Mathwin]] (along with her [[Warder]] [[Tomas]]). However, where Verin joined the Shadow with the intent of serving as a double agent, Ingtar did not.


## Horn of Valere
Much of Ingtar's dialogue in the series has been identified as expressing a desire for the [[Horn of Valere]]. It can be speculated that at the [[Darkfriend Social]], a meeting of influential Darkfriends which he is known to have attended, he was given some sort of compulsion to obtain the Horn, similar to the yearning [[Padan Fain]] feels to find Rand, only of a much lesser strength. This would explain his passionate and at times desperate actions during the Great Hunt.

## In the television series
In the [[The Wheel of Time (TV series)|television series]],   is played by  .

## Notes






https://wot.fandom.com/wiki/Ingtar