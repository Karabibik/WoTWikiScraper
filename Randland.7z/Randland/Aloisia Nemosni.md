---
tags: [Women, Kinswomen, Merchants, LivingasofWH, Channelers, Novices]
---


**Aloisia Nemosni** is one of the [[Kin]]. She is only mentioned once in the series.

## Contents

1 Strength
2 History
3 Activities
4 Notes


## Strength
Aloisia's has a strength in the One Power of 17(5) or 18(6). This is quite high by Aes Sedai standards and strong enough to Travel if she was taught the weave.

## History
She was born shortly after the year 400 NE and therefore is the oldest known living person in the series.
As with all the Kin, she would have been born and gone to the White Tower as a novice during the reign of [[Nirelle Coidevwin]]. In her lifetime, she has seen 25 Amyrlins come and go and several nations that emerged after the [[War of the Hundred Years]] dwindle and die.
She is currently an oil merchant in [[Tear]], but would have followed many trades over the centuries.

## Activities
Aloisia is only mentioned in passing, but [[Elayne Trakand]] and [[Nynaeve al'Meara]] consider her as an extreme example of what might happen as a consquence of a much older woman swearing the [[Three Oaths]] were she to become Aes Sedai. She is almost double the life expectancy of the odest known Aes Sedai and they consider the possibility that she might fall over dead immediately.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Aloisia_Nemosni