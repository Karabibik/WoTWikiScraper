---
tags: [Women, Aiel_people, WiseOnes, Shaido, Living]
---


**Narendhra** is a [[Wise One]] of the [[Shaido]] [[Aiel]]. 

## Activities
She was part of [[Sevanna|Sevanna's]] inner circle and participated in the murder of [[Desaine]].
She was with [[Therava]] during the [[Battle of Dumai's Wells]]. It is unknown if she survived the battle. 
It is also not known whether she escaped the [[Seanchan]] in the [[Battle of Malden]] or if she was taken *damane*.






https://wot.fandom.com/wiki/Narendhra