---
tags: [Women, BlueAjah, Andor_people, BlackAjah, MistressesofNovices, AesSedai, Deceased, HighRankingAesSedai, Channelers]
---







**Merean Redhill** (pronounced: MEH-ree-an red-hill) was an [[Aes Sedai]] of the [[Blue Ajah]] publically, and secretly a member of the [[Black Ajah]].

## Appearance
She was plump and motherly with graying hair. She was 5'8 tall.

## History
She was Aes Sedai for nearly 200 years. She was born in 716 NE.
She was the [[Mistress of Novices]] under [[Noane Masadim]] and under [[Tamra Ospenya]]. She was very good at finding out what novices didn't want her to know, but nonetheless, she was kind and comforting to all novices, and generally warm and easygoing. Most initiates could not figure her out--she could soothe very well, but would go easy on an initiate for one offense only to be a harsh disciplinarian for another, lesser infraction. Still, she was very good to talk to and most initiates went to her on their own more often than for punishment.
Shortly after the [[Aiel War]], Merean summoned the [[Accepted]] [[Moiraine Damodred]] and [[Siuan Sanche]] to test for the shawl.
She was strong in the [[One Power]], only a little below [[Moiraine]]'s ultimate strength. The Wheel of Time Companion confirms this, giving her strength as 14(2) - one level below Moiraine.
After Tamra's death and the rise of [[Sierin Vayu]] as Amyrlin, Merean was replaced as Mistress of Novices. She became one of the Black Ajah's searchers for the [[Dragon Reborn]], after they found out that he had been born. Her search eventually led her to [[Kandor]], where she crossed paths with [[Lan Mandragoran]] and Moiraine. She tried to kill them, and did kill [[Diryk]], prince of Kandor, [[Brys]], the consort and Swordbearer of [[Queen]] [[Ethenielle Cosaru Noramaga]] of Kandor, and [[Iselle Arrel]], the daughter of [[Edeyn Arrel]], Lan's [[Carneira|carneira]]. When Merean grew overconfident and turned away, Moiraine managed to kill her with a knife in the back after a severe duel with the [[One Power]]. To keep the Black Ajah hidden Moiraine burnt Merean's body.
She bonded a Warder more than ten years after becoming Aes Sedai, and after he died never bonded another. People whispered that she was in love with him. The truth is, he was a Darkfriend; she did not want to deal with a non-Darkfriend Warder, and never found another she thought suitable. She also never felt the need for a Warder as she was not bound by the Three Oaths.

## Notes






https://wot.fandom.com/wiki/Merean