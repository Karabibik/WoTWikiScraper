---
tags: [Swordforms]
---



*"Every movement of his blade was an attempt to reach the High Lord; now all Turak can do was retreat and defend, down the length of the room, almost to the door."*
   —Rand's movements against Turak 



**The Boar Rushes Down the Mountain** is a [[Sword form|sword form]]. It is a series of aggressive strikes raining down from overhead.
[[Rand al'Thor]] used this sword form against [[Turak Aladon]], forcing the [[Seanchan]] into retreating.
Rand also used this form to break through his sparring partner's [[Parting the Silk]] and [[Lightning of Three Prongs]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Boar_Rushes_Down_the_Mountain