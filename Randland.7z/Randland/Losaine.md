---
tags: [Women, Aiel_people, WiseOnes, Unknownclan, LivingasofTPOD, Channelers]
---


**Losaine** is an [[Aiel]] [[Wise One]].

## Appearance
She is gray-eyed and dark-haired.

## Activities
She is one of the Wise Ones supervising the [[Aes Sedai]] held prisoner by the [[Aiel]] in [[Cairhien]]. She is a very weak [[Channeler|channeler]], in fact she needs to link to [[Daviena]] to maintain the shield on [[Turanna]] (but this is in contradiction to the strength levels described by "The Wheel of Time Companion" were Losaine strength is 22(10) while Turanna is quite weaker than her at level 26(14).
It can be assumed that during the [[Last Battle]] she fights in [[Thakan'dar]] Valley along the other Wise Ones.






https://wot.fandom.com/wiki/Losaine