---
tags: [Women, Andor_people, Novices, LivingasofTPOD, TwoRivers_people, RebelAesSedai, Sparkers, Channelers]
---




**Jancy Torfinn** (sometimes spelled Janacy) is a [[Novice|novice]] from the [[Two Rivers]] among the [[Rebel Aes Sedai]].

## Contents

1 Appearance
2 Abilities
3 History
4 Activities
5 Notes


## Appearance
She is about fourteen, small and has a high voice.

## Abilities
She is described as 'very strong' in the [[One Power]], likely on the same level as [[Lelaine Akashi]], [[Elaida do Avriny a'Roihan]], [[Romanda Cassin]], [[Zarya Alkaese]] and [[Rainyn]], and possibly even stronger.

## History
She is from [[Emond's Field]].
She is among the three girls born with the [[Spark|spark]] and found in the Two Rivers by [[Verin Mathwin]] and [[Alanna Mosvani]], and so is found suitable for training. 
It is possible that she is the sister of [[Jaim Torfinn]], an [[Asha'man]] Soldier in the [[Black Tower]]. 

## Activities
She accompanies several other [[Two Rivers]] girls with channeling abilities to [[Caemlyn]], where they are all terrorized by [[Rand]].
She eventually joins the rebel Aes Sedai in [[Murandy]], and becomes a novice. Later she follows the Aes Sedai to Tar Valon.

## Notes






https://wot.fandom.com/wiki/Jancy_Torfinn