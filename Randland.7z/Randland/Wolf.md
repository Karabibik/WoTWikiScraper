---
tags: [Wolves, Animals, Dreamwalkers]
---




While it is not widely known, **wolves** are sentient creatures who can communicate through  and form close social bonds with their pack, and occasionally with [[Wolfbrother|wolfbrothers]], humans who share the gift for communicating with them. When wolves and wolfbrothers communicate they don't talk so much as send sensations and images. Wolfbrothers can use the wolves to track over long distances.


Wolves remember every life they have lived. When a wolf dies, the soul of the wolf enters the "wolf dream," which is actually *Tel'aran'rhiod*. Each wolf is born again into the world in a cycle. If a wolf is killed by a [[Darkhound]], or in the wolf dream, the cycle is broken. They call Darkhounds "Shadowbrothers," creatures made from wolf stock by twisting the soul of a wolf.
The wolves are aware of [[Rand al'Thor]]. They call him "Shadowkiller" and are in awe of him. Wolves also know of [[Tarmon Gai'don]] and refer to it as the "last hunt." It is widely believed that [[Perrin Aybara]] will call the wolves to Tarmon Gai'don.
Wolf names are not simple. For example,  the name [[Two Moons]] is actually described as "a night shrouded pool, smooth as ice in the instant before a breeze stirred, with a tang of autumn in the air, and one moon hanging full in the sky and another reflected perfectly on the water so that it was difficult to tell which was real. And that is cutting it to the bone."
Wolves are generally feared, used often in [[Two Rivers]] phrases such as "whether the wolf beats the bear or the bear beats the wolf, the rabbit always loses" although this isn't a reference to wolves. People often suspect a link between the [[Shadow]] and wolves, unaware that in actuality wolves harbor deep hatred for the Shadow. [[Children of the Light|Whitecloaks]] frequently hunt wolves, claiming that [[Trolloc|Trollocs]] use wolf skin, muzzle, teeth, and claws to be created. Wolves hate Trollocs and [[Myrddraal]]; packs of wolves can overpower Trollocs in small numbers quite easily and will hunt them if possible, but their hatred for Myrddraal goes so deep that entire packs will sacrifice themselves to pull a single Fade down.

## Notes






https://wot.fandom.com/wiki/Wolves