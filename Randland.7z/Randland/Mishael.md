---
tags: [Men, AthaanMiere_people, LivingasofWH]
---


**Mishael** is an *Atha'an Miere* and husband to [[Shalon din Togara Morning Tide]].

## Activities
When Shalon and [[Ailil Riatin]] are caught together, Shalon desperately wishes to keep the relationship secret. If Mishael discovers it, he might divorce her.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Mishael