---
tags: [Men, Amadicia_people, Gaishain, LivingasofTOM, ]
---



**Aldin** is a bookkeeper from [[Amadicia]] who was made *gai'shain* by the [[Shaido]] [[Aiel]].

## Appearance
He is tall and square-shouldered.

## Activities
He is one of the many people who have been made *gai'shain* by the Shaido. He has pledged an oath of fealty to [[Faile Bashere]]. He has tried to court [[Arrela Shiego]], but she is not interested in men.
He comes to help rescue Faile when she is trapped in the burnt out old building. He is now part of [[Perrin Aybara]]'s camp and has turned his attention from Arrela to [[Aravine Carnel]].






https://wot.fandom.com/wiki/Aldin