---
tags: [Women, BrownAjah, Tear_people, Unalignedsisters, AesSedai, LivingasofCOT, MiddleRankingAesSedai, Channelers]
---


**Rosara Medrano** is a [[Tear|Tairen]] [[Aes Sedai]] of the [[Brown Ajah]].

## Contents

1 Appearance
2 Abilities
3 Activities
4 Notes


## Appearance
She is tall, with brown skin and black hair.

## Abilities
Rosara is not very strong in the [[One Power]]. Her level of strength is described by "The Wheel of Time Companion" as 32(20) which is a middle/low level in Aes Sedai hierarchy. With this level of strength she is unable to open alone a suitable gateway to [[Travel]].

## Activities
Rosara was one of the sisters in Cadsuane's group in [[Cairhien]].
When Cadsuane went to [[Far Madding]] in search of Rand, she left Rosara and other sisters to keep an eye to the situation there, under the leadership of [[Samitsu Tamagowa]].
Some time later Rosara warned Samitsu and [[Sashalle Anderly]] of a party of [[Asha'man]], including [[Logain Ablar]], and Aes Sedai approaching the [[Sun Palace]].

## Notes






https://wot.fandom.com/wiki/Rosara