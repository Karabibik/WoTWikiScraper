---
tags: [Women, Andor_people, TwoRivers_people, LivingasofAMOL, WomensCircle]
---




**Natti Cauthon** is one of the village women of [[Emond's Field]]. She is married to [[Abell Cauthon]] and has three children: [[Matrim Cauthon|Matrim]], [[Bodewhin Cauthon|Bodewhin]] and [[Eldrin Cauthon|Eldrin]]. Matrim, better known as *Mat* is [[Ta'veren|ta'veren]] and a friend of [[Rand al'Thor]], the [[Dragon Reborn]].
She was usually a cool, collected woman. Mat could not understand how she always knew what he was doing, and did not realize that it was his sisters who kept their mother informed.

## Activities
She is rescued from the Whitecloak camp by [[Perrin]].
She makes bandages in the Winespring Inn after the first large Trolloc attack. She helps tend to the wounded Tinkers. She also participates in the defense of Emond's Field.

## Trivia
In the [[The Wheel of Time (TV series)|TV series]],  
## Notes






https://wot.fandom.com/wiki/Natti_Cauthon