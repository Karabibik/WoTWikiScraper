---
tags: [Angreal, ItemsofPower]
---
The **Little Gold Ring** was a quite powerful *angreal* aligned to *saidar*. It was a very little plain ring of gold that entered only in the small finger of [[Graendal]]; she found it searching in [[Sammael]]'s quarters in [[Illian]] while the [[Forsaken]] was fighting against [[Rand]] in [[Shadar Logoth]], or just a little time after. Previously the ring was probably stolen from the [[Kin's Storeroom]] in [[Ebou Dar]] by a group of [[Darkfriend|Darkfriends]] and given to Sammael.
Graendal used it against [[Moghedien]] and [[Cyndane]] when they come to give her orders from the [[Nae'blis]]. She probably used it also in the [[Battle near Shadar Logoth]] against the circle led by [[Verin]].
The ring was destroyed by Rand's [[Balefire|balefire]] assault on Graendal's fortress of [[Natrin's Barrow]].






https://wot.fandom.com/wiki/Little_Gold_Ring