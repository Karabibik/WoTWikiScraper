---
tags: [Men, Forsaken, Deceased, LivingasofAMOL, Blademasters, POVcharacter, Antagonists, AesSedai_AgeofLegends, Channelers, Shara_people, Charactersnamedafterfans]
---


**Demandred** (DEE-man-drehd; /ˈdiːˌmæn.dɹɛd/), previously known as **Barid Bel Medar** and known in [[Shara]] as **Bao the Wyld**, was one of the thirteen [[Forsaken]] trapped at [[Shayol Ghul]] due to the Dragon's sealing at the end of the [[Age of Legends]], and released back into the world in the summer of 998 NE.

## Contents

1 Appearance and personality
2 Strength and Abilities
3 History
4 Activities

4.1 Release
4.2 The Wyld
4.3 The Last Battle


5 Identity
6 Trivia
7 Notes


## Appearance and personality
He was described as being handsome but hook-nosed, and was tall with jet black hair. He was an exceedingly humorless individual, and those who knew him were known to remark that he never smiled. Even those who sparsely interacted with him tended to come to similar conclusions. Like virtually all of the Forsaken, he was exceedingly arrogant, and was also phenomenally petty. His sole motivation for defecting from the Light was jealousy towards Lews Therin, and he committed numerous atrocities out of sheer spite. He believed himself incapable of feeling affection, and openly treated those around him like tools to be used. Demandred was often described as being the most angry of all the Forsaken, though this wrath was tightly controlled and he rarely betrayed his calm stoic demeanor in public.
However, before and during The Last Battle, he appeared to have a very, very slight change of disposition. He fell in love with the leader of the Sharan Ayyad, though he still prioritized killing Lews Therin above all else. His lover hoped that after his revenge on the Dragon Reborn, he could finally let go and love her. It is also revealed that Demandred, seeing no hope for defeating the Dark One, had intended to use his favor with the Dark One to protect the Sharans and all those he cared for after the Dark One's victory. 


## Strength and Abilities
In "The Wheel of Time Companion" his level of strength in the [[One Power]] is described as ++2, making him one of the most powerful channelers ever, but still below [[Rahvin]], [[Moridin]], and [[Rand al'Thor]].

## History

Barid Bel Medar lived his life in the shadow of [[Lews Therin Telamon]]. Born one day after Lews Therin, he was almost as strong in the [[One Power]] as him and almost as honored and influential. [[Graendal]] states that had it not been for Lews Therin he would have been the most acclaimed man of his Age. He held numerous high offices, authored critically acclaimed books, but could never quite match the success and glory of Lews Therin. He also once desired Lews Therin's wife [[Ilyena]], but evidently was out-done by Lews Therin in that regard as well. Being consistently beaten by Lews Therin in virtually every aspect of his life caused Barid to become filled with petty, spiteful jealousy and bitterness, and he came to hate Lews Therin with every ounce of his being - more so even than [[Sammael]] - thinking him a lucky fool. Millennia later, [[Rand al'Thor]] reflects Barid turning to the [[Shadow]] was the most tragic. Had Lews Therin been less arrogant and competitive against Barid and more complimentary, then perhaps he could have been one of the Age's greatest heroes.
During the [[War of Power]], he developed an extraordinary amount of skill as a military commander, finally matching his hated rival at something. Demandred was the first to discover warfare in ancient scripts, before warfare was even understood. However, when Lews Therin was appointed commander of the forces of Light, Demandred was furious. Believing himself the superior general, he calculated that with Lews Therin at the command of the Light, the Shadow would triumph.

Filled with jealousy and contempt, Demandred decided to proclaim for the Shadow, and he sided with the other Chosen in the third year of the War. Later during the War, Demandred fed the entire populations of two captured cities to [[Trollocs]]; he felt that the people within them had slighted him when he was still fighting for the Light.
Demandred believed himself superior to the other Forsaken. He was at odds with Sammael in particular, since both men wanted to be the one to personally defeat Lews Therin (despite, apparently, having had far less reason to hate Lews Therin than Sammael). Despite his belief in his own superiority however, he was always slightly perturbed by [[Ishamael]]. During an unknown battle during the war, after Demandred founded the [[Eighty and One]], he confronted Lews Therin's forces. A clerk named [[Tellindal Tirraso]] was present and was struck by lightning called down by the enemy, which was apparently a noteworthy enough event for mention of it to cause Rand al'Thor (with Lews Therin's memories) emotional distress.
At the tail-end of the war, forces under his and [[Be'lal]]'s command threatened the construction sites of the [[Choedan Kal]] *sa'angreal*. Barely holding the forces of Shadow at bay, Lews Therin decided to strike at [[Shayol Ghul]] itself together with the [[Hundred Companions]]. Sealing the [[Bore]], the Companions also by happenstance managed to trap the thirteen most powerful of the Forsaken, among them Demandred, in a deep sleep for three thousand years.

## Activities
### Release

Shortly after his release, Demandred traveled to [[Shara]] searching for D'jedt, also known as [[Sakarnen]], an incredibly powerful *sa'angreal*. Taking the name Bao and posing as a slave, Demandred unwittingly began to fulfill the Sharan prophesies of [[The Wyld]]. He led a slave rebellion and was adopted by [[Mintel]], an elderly abrishi man. To sow chaos, he freed the Male [[Ayyad]], who took the name "The Freed" and taught them to channel. He met [[Shendla]], who became one of his strongest supporters and his lover.
In 999 NE Demandred traveled to [[Shayol Ghul]] and spoke with the [[Great Lord of the Dark|Dark One]] about him becoming *nae'blis*. The Dark One told him of things to come, of who would live and who would die. Seventeen days later Demandred met with [[Mesaana]] and [[Semirhage]] and formed an alliance with them. It is likely that at this time Demandred recruited [[Mazrim Taim]] to the Shadow and ordered him to attach himself to [[Rand al'Thor]]. Other than ordering the death of [[Rand al'Thor]] at least once, his plans and identity remained unrevealed until the beginning of [[The Last Battle]].
Sammael once thought to himself that "events to the south" were almost certainly the work of Demandred; Sammael was in [[Arad Doman]] at the time. He probably refers to Mazrim Taim's orders to join Rand and help build the Asha'man. Sammael mentions another man involved in these events and it is later revealed that Demandred was the one to recruit Taim shortly before Sammael's meeting with Graendal. During the Last Battle, Demandred indicates that he has been giving to him all along. 
At a meeting with the other Forsaken , Aran'gar comments that Demandred and Osan'gar had been charged with watching Rand. Again Demandred was not in Randland, so perhaps Demandred was keeping an eye on Rand through Taim.


The only open action Demandred undertook prior to [[The Last Battle]] was to appear at the [[Battle near Shadar Logoth]] when al'Thor cleansed *saidin*, nearly getting himself killed by some of Rand's guards.
He attends the meeting with the other Chosen in *Tel'aran'rhiod*, which is made to look like the [[Ansaline Gardens]]. There he is told that Rand is not to be harmed and that [[Matrim Cauthon]] and [[Perrin Aybara]] are to be killed if found.

### The Wyld
It was at this time that Demandred, as Bao, came to walk the path of *Angarai'la*, The River of Souls. The prophecies of the Wyld stated that the Wyld would walk the path, enter the Hearttomb and retrieve the piece of Sakarnen that was hidden there. When Demandred entered Rai'lair, he battled one of the ancient guardians of the tomb, an adult Jumara, and killed one [[Green Man]]. He returned to his people at sunset on the third day.
He is summoned to the [[Blight]] to meet with [[Moridin]] and Mesaana and is forbidden by Moridin to rescue Semirhage from Rand. During the meeting he also stated that his rule is secure and he gathers his troops for war.


### The Last Battle
Moridin gathers the last of the Chosen within one of his [[Dreamshard|dreamshards]]. Moridin reveals two unfamiliar looking Chosen, the male who is [[Mazrim Taim]] is renamed M'Hael. Demandred and M'Hael already knew each other before the meeting and it is revealed that it was Demandred who brought M'Hael to the Shadow. The unfamiliar female Chosen present is named Hessalam, who is actually Graendal in a new body. Moghedien is placed under Demandred's command. Moridin then demands that all other plots and plans by the Chosen are to be concluded and that they are to unite for [[The Last Battle]] against the forces of the Light.
Demandred appears leading the [[Shara|Sharan]] forces against the [[White Tower]] army on the [[Kandor|Kandori]] battlefront. As the forces of the Tower appear to be routing the [[Trolloc]] army, a massive [[Gateway|gateway]] opens and an army of Sharans pour out and overrun the [[White Tower]] camp, executing all captives in a brutal fashion.
Demandred discovers [[Leane]] as the Sharans are still securing the Aes Sedai camp and easily captures her. He then tells her to relay a message to the [[Dragon Reborn]]. He challenges [[Rand al'Thor]] to combat, revealing himself as someone he once knew as Barid, confirming his identity. As Rand was already at the Bore, this message was never delivered.


When the battle resumes at Merrilor, he is eventually pitted in tactics against [[Matrim Cauthon|Mat]]. The numerical superiority of Demandred's forces, combined with his tactical acumen and the Sakarnen, gave him what appeared to be a decisive advantage. However, Mat managed at every turn to keep from being overrun, which confused Demandred. Mat's abilities were unknown to Demandred, and as he assumed that nobody from the current Age had the experience to be such a capable general, he concluded that the one commanding the Light's forces was Lews Therin/Rand himself. This caused him to make the critical mistake of not making a direct, personal attack on Mat's command post, as he believed that Rand was attempting to bait him into making just such an assault, and also believed that he had the battle under control. Even after learning that Mat was the one leading the forces of the Light, he assumed that Mat was either Rand in disguise, or that Rand was feeding Mat information.
Besides commanding troops, he acted during the battle as a piece of human artillery, cutting swaths through Mat's forces while leading a full [[Link|circle]] of seventy two and wielding a powerful *sa'angreal*: [[Sakarnen]]. Demandred repeatedly called out for Rand to face him directly in single combat during his attacks.
He participated in single combat on four occasions in the battle. The first attacker was [[Gawyn Trakand|Gawyn]], enhanced by three Seanchan [[Bloodknife ring|Bloodknife rings]]. Demandred noticed his assassination attempt, and despite Gawyn's rings he defeated him fairly handily and without injury.
[[Galadedrid Damodred|Galad]] attacked second, calling out Demandred to face the brother of the Dragon Reborn, while protected by a copy of Mat's [[Foxhead medallion]]. He managed to injure Demandred, but lost his sword-arm in the encounter.


[[Logain Ablar|Logain]] then attacked Demandred as the fight with Galad was concluding, enabling the latter to escape. Demandred, armed with Sakarnen, managed to shield Logain and nearly killed him. However, Logain threw a rock at Demandred, which struck him and surprised him long enough for Logain to flee through a gateway.
Finally, [[Al'Lan Mandragoran|Lan]] retrieved the foxhead medallion from the wounded Galad and challenged Demandred. His skill, determination, and single-mindedness initially caught Demandred completely off guard. Astounded by his foe's prowess, Demandred quickly gave over to fighting with all his focus instead of trying to use the Power to throw objects at Lan. Unfortunately, Lan, having been engaged in pitched fighting all day, had been tired even before the duel began while Demandred had been relatively fresh. Pressing his advantage and assured of victory, Demandred underestimated Lan's resolve, and Lan impaled himself on Demandred's sword in accordance with the [[Sheathing the Sword]] technique. The wound in Lan's side, though it would have been mortal, was not immediately fatal. With his sword stuck in Lan, Demandred was unable to block Lan's subsequent attack, and was fatally stabbed through the throat. His death, announced with his severed head by Lan, threw the Shadow's armies into disarray, and they never managed to recover. Mat pressed home the advantage caused by Demandred's death and, with the help of the Seanchan armies' re-entry into the battle and the un-damming of a river straight into the Trolloc forces, the forces of the Light managed to win the Last Battle. His body was burned away with the [[True Power]] by [[Moghedien]] in disgust.

## Identity
Before he revealed himself in [[Kandor]], there was much speculation as to Demandred's identity.
It was once widely suspected that [[Mazrim Taim]] was Demandred, but [[Robert Jordan]] has stated to the contrary. Additionally, Jordan stated that Demandred had not appeared "on screen" as any other character before *Knife of Dreams*. Also, during the [[Cleansing of saidin|cleansing of saidin]], Demandred saw [[Damer Flinn]], one of Taim's first [[Black Tower]] recruits, and didn't recognize him. He also orders [[Raefar Kisman]], [[Manel Rochaid]], [[Charl Gedwyn]] and [[Peral Torval]] to kill Rand. It is also stated by Kisman that Taim orders the four to kill Rand as well, as if the two didn't know each others' orders.
Another popular theory was that Demandred was [[Charlz Guybon]], partially due to his physical similarities to Demandred (tall and handsome), but also because Guybon is described by Elayne as: "... his face seemed suited to smiling. He looked as if he had not smiled in too long." This, coupled with the description of Demandred as a man who "never smiles," seemed to provide a good fit. Others theorized that he could be impersonating King [[Roedran Almaric do Arreloa a'Naloy|Roedran]] of [[Murandy]], who was also unseen on the page until the final book and had recently consolidated his power and formed a standing army for the first time. He reported to Moridin that his "rule is secure and his armies march for war."

## Trivia
His Sharan alias, Bao the Wyld, comes from reader Bao Pham.
## Notes






https://wot.fandom.com/wiki/Bao_the_Wyld