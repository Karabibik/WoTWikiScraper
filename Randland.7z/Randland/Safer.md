---
tags: [TenNations, Safer, AftertheBreaking, Historicalnations]
---

**EWoT:** 


**Safer** was one of the [[Ten Nations]] that arose in the aftermath of the [[Breaking of the World]]. It fell in the aftermath of the [[Trolloc Wars]].

## Contents

1 Geography
2 History
3 Ogier cities
4 Rulers


## Geography

Safer was located along the west coast of the continent, stretching from the [[Aryth Ocean]] to the foothills of the [[Mountains of Mist]] and from the [[River Akuum]] in the north to the upper [[Andahar]] in the south. Maps are unclear but seem to suggest that Safer also held some land east of the mountains, up to the [[Arinelle]]. It was bordered by [[Jaramide]], [[Aridhol]], [[Manetheren]] and [[Aelgar]]. It's capital was [[Iman]], located on the site of the modern [[Arad Doman|Domani]] city of [[Katar]].
Safer consisted of all of [[Almoth Plain]] and [[Toman Head]], as well as the southern parts of [[Arad Doman]] and the northern parts of [[Tarabon]].

## History
Safer arose in the aftermath of the Breaking. There are records of it engaging in border clashes with Manetheren to the east. King [[Eawynd]] brought Safer into the [[Compact of the Ten Nations]] in 209 AB. Safer fought in the [[Trolloc Wars]] and suffered tremendous losses. However, it survived the wars only to collapse in their aftermath, reconstituting as the kingdoms of [[Oman Dashar]], [[Elan Dapor]] and [[Darmovan]].

## Ogier cities
[[Iman]] (capital city, now [[Katar]])
[[Miereallen]] (now [[Falme]])
[[Shainrahien]]
## Rulers
[[Aedomon]]
||
|-|-|



https://wot.fandom.com/wiki/Safer