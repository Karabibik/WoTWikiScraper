---
tags: [Women, GreenAjah, Cairhien_people, AmyrlinSeats, AesSedai, Deceased, Historicalpeople, HighRankingAesSedai, Channelers, Characternotmentionedinbooks]
---


**Nirelle Coidevwin** was an [[Aes Sedai]] of the [[Green Ajah]] who was raised to the [[Amyrlin Seat]] in the year 396 NE.

## History
Her name indicates that she was from [[Cairhien]], given the common Cairhienin ending *-in* preceded by a distinct consonant combination.
[[Aloisia Nemosni]], one of the oldest people alive and one of the [[Kin]], may have been born during Nirelle's time on the Seat.
Nirelle held the position for twenty-three years until her death in 419 NE. She was [[Suilin Escanda]]'s successor and [[Ishara Nawan]]'s predecessor.
Nirelle was a strong Amyrlin, forceful and dynamic. Chosen in the belief that she would extricate the [[White Tower]] from her predecessor's foreign intrigues, she instead continued them, involving the Aes Sedai in a number of wars.
She personally led the Tower contingents in battle, a fact not seen in centuries.
Had it not been for the war and the laws related to it, she might have been removed, but the Tower reaction to external threads was always to gather in and to do nothing that might even hint at any crack in the supposedly unbreakable facade.
During her reign, [[Stedding Tsofu]] was relocated and repopulated.

## Notes






https://wot.fandom.com/wiki/Nirelle_Coidevwin