---
tags: [Men, Darkfriends, Ashaman_rank, LivingasofAMOL, Taimscronies, TheTurned, Channelers]
---


**Dobser** is an [[Asha'man]] who is often drunk. 

## Activities
He was turned to the Shadow by a circle of 13 channelers and 13 fades. Dobser maintained his alcohol addiction after turning. He was captured by [[Androl]], [[Pevara]] and [[Emarin]] in the cellar of the Black Tower pub, where he was looking to steal some wine and spirit. They were able to force him to reveal the location of [[Logain]]'s prison. Dobser is given a sedative that knocks him unconscious. His final status is unknown.






https://wot.fandom.com/wiki/Dobser