---
tags: [Women, AthaanMiere_people, MistressesoftheShips, LivingasofAMOL, Wavemistresses]
---


**Zaida din Parede Blackwing** was an *Atha'an Miere* [[Wavemistress]] of [[Clan Catelar]] who has been chosen as the new [[Mistress of the Ships]].  She previously captained the *Blue Gull*. Her husband is [[Amel]].

## Contents

1 Appearance
2 Activities

2.1 Seeking the Coramoor
2.2 Summons
2.3 The Last Battle


3 Notes


## Appearance
She has dark skin and has gray flecks among her close cut black curly hair. She is short, about 5'2" to 5'3" tall. She has six fat golden earrings in each ear.

## Activities
### Seeking the Coramoor
She sends a letter to [[Rand al'Thor]] in [[Caemlyn]] hoping to meet him as a *Coramoor*. She is staying in the royal palace in Caemlyn and interrupts Elayne having a meeting with [[Dyelin Taravin]]. She points out that they only have one [[Aes Sedai]] teacher and seals a bargain with Elayne promising the other Aes Sedai present in Caemlyn to teach the [[Sea Folk]] [[Windfinder|Windfinders]] a few hours a day. She is then interrupted by the arrival of [[Mazrim Taim]].
She watches all the lesson's between the Aes Sedai and the Windfinders and threatens [[Nynaeve al'Meara]] when she is shielded by [[Talaan din Gelyn]], to try her best at breaking the shield, which Nynaeve couldn't do.

### Summons
When the [[Mistress of the Ships]] [[Nesta din Reas Two Moons]] is killed, Zaida is summoned along with the other [[First Twelve]] of the *Atha'an Miere* to meet in [[Illian]] where a new Mistress of the Ships will be chosen. Clearly Zaida believes that she is foremost for the top Sea Folk position. She makes a new bargain with Elayne to leave behind nine Windfinders for Elayne to use. [[Merilille Ceandevin]] runs away with [[Talaan din Gelyn]] before she can be taken away with the Sea Folk as their part of the bargain.
At the meeting of the First Twelve, she is made Mistress of the Ships. One of her first commands is to have [[Harine din Togara Two Winds]] punished due to her bargain with Rand found wanting. She sets up another meeting of the First Twelve, where they are to meet with Rand's ambassador [[Logain Ablar]]. He refuses to disclose Rand's location to her, but is willing to take Harine again as the Sea Folk ambassador to Rand. Rand calls upon the bargain Harine made and to gather as many ships as possible, to bring food and supplies for over a million people to [[Arad Doman]]. At the end of the meeting [[Cemeille din Selaan Long Eyes]] enters with the news of the [[Amayar]] mass suicide.

### The Last Battle
Zaida and all her capable channelers go with Rand to [[Shayol Ghul]]. There they channel into the [[Bowl of the Winds]], in order to hold the raging storms that threaten to tear apart the forces that [[Rodel]] commands there.
Because [[Min]] has observed in [[Harine]] aura that she is destined to became Mistress of the Ships it can be guessed that Zaida died during the Last Battle or in a short time after it.

## Notes






https://wot.fandom.com/wiki/Zaida_din_Parede_Blackwing