---
tags: [RandsAesSedai, AesSedai, AesSedaifactions]
---
In recent times [[Aes Sedai]] divided themselves in many factions. Among these factions was formed a group of sisters that allied themselves directly or indirectly to the [[Dragon Reborn|Dragon Reborn,]] under many different circumstances. It can be calculated that the sisters allied to the Dragon were more than eighty, but many of them were [[Turned|turned]] to the shadow before the [[Last Battle]].

## Contents

1 Friends
2 Dumai's Wells sisters
3 Cairhien sisters
4 Asha'man bonded
5 Cadsuane's Aes Sedai
6 Other female channellers


## Friends

## Dumai's Wells sisters
Group of 9 [[Rebel Aes Sedai]] (5 Greens, 2 Browns, 1 Gray, 1 Blue) that were forced to swear loyalty to the Dragon after the battle of [[Dumai's Wells]]:


## Cairhien sisters
This is the group of 22 loyalist sisters (5 Reds, 5 Greens, 5 Whites, 3 Browns, 2 Yellows, 2 Greys) that were captured during the battle of [[Dumai's Wells]] and later, when they were captives in [[Cairhien]] Aiel Camp, they were persuaded to swear loyalty to the Dragon by Verin utilizing her mild kind of [[Compulsion]]:


## Asha'man bonded
This is the group of around 50 sisters that were [[Bond|bonded]] by the [[Asha'man]] led by [[Logain]], so they were indirectly allied to the Dragon. The majority of them were probably later [[Turned|turned]] to the shadow. We know the name of 10 of them:


## Cadsuane's Aes Sedai
[[Cadsuane]] was leading a group of [[Unaligned Sisters]] when she accepted to be Rand's advisor, so indirectly all of them allied to the Dragon. We know the name of 10 of them:


## Other female channellers






https://wot.fandom.com/wiki/Rand%27s_Aes_Sedai