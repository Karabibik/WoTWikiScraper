---
tags: [Seanchananimals, Animals]
---

*Grolm* are a species of animal used by the [[Seanchan]]. 

## Contents

1 Description
2 Background
3 Gallery
4 Notes


## Description
Grolm  are the size of large , only with the gray green coloration and skin texture of very tough . Like the *torm*, they have three eyes. Their diet consists of whatever is at hand, including their own dead.
When walking, *grolm* appear almost awkward, moving with a waddling motion. All traces of awkwardness vanish when they run, as they can cover great leaps of ground in a hurry. Grolm communicate using a sharp, short barking call. With this call, they alert others of the species nearby that food has been located. Grolm travel in small packs of only a handful of individuals. When a victim has been located, they communicate over large distances using a short, gutteral barking call. With this call they alert other packs to join the chase. This behavior was first seen in[[The Great Hunt]] when [[Rand al'Thor]], [[Loial]] the [[Ogier]] and [[Hurin]] became accidentally trapped in a [[Mirror World]].
*Grolm* are used in battle, though normally only against lightly armored opponents to break holes in an enemy line which will then be quickly exploited by human soldiers. They are very useful against cavalry, as horses often panic in their presence unless specifically trained to tolerate the *grolm*.
Grolm are difficult to kill because to be killed quickly, an arrow must be driven through their eye. Another significant factor is the sheer number of Grolm who will answer the call of their kin. In the [[Mirror World]] which was mentioned above, food was scarce as to the [[Trolloc]] clans apparent victory over [[Artur Hawkwing's Empire]] (This is known because of the [[Trolloc]] spire erected in the place which in the real world, the spire made to commemorate [[Artur Hawkwing]]'s victory once stood.) Henceforth, the [[Trolloc|Trollocs]] had pillaged every other reliable source of food since they were largely unopposed after their victory. Grolm also have very good vision, a keen sense of smell, and are extremely territorial. 

## Background
*Grolm* were first seen in the *The Great Hunt* by [[Rand al'Thor]], in a [[Mirror World]]. It is confirmed in [[The World of Robert Jordan's The Wheel of Time]] that all the exotic creatures used by the [[Seanchan]] were brought to the real world using [[Portal Stones]] sometime after the [[Breaking|Breaking of the World]] to use against [[Shadowspawn]].
Grolm riders in Seanchan are called *morat'grolm* with masters or leaders in the animal are called *der'morat'grolm*.

## Gallery
A *grolm*Painting by Todd Cameron HamiltonSize comparison with 5'10" (or 178cm) man.Grolm attacking in a Mirror World
## Notes






https://wot.fandom.com/wiki/Grolm