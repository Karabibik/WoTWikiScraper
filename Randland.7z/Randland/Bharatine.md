---
tags: [Women, GreenAjah, AesSedai, LivingasofLOC, RebelAesSedai, MiddleRankingAesSedai, Channelers]
---


**Bharatine** is an [[Aes Sedai]] of the [[Green Ajah]]. She allied herself with the [[Salidar Aes Sedai]] during the split.

## Appearance and Abilities
Bharatine is thin, yet graceful, with a long nose. Though thin as a rail, she manages to look elegant.
Bharatine is not very strong in the [[One Power]]. Her level of strength is described by "The Wheel of Time Companion" as 33(21) which is a middle/low level in Aes Sedai hierarchy. With this level of strength she is unable to open alone a suitable gateway to [[Travel]].

## Activities
She was born in 921 NE and went to the [[White Tower]] in 936 NE. She spent nine years as a [[Novice|novice]] and seven years as [[Accepted]], then was raised to the shawl in 952 NE.
She is one of the Aes Sedai who joined in the [[Link]] with [[Anaiya]] when the [[Bubble of evil]] erupted in [[Salidar]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Bharatine