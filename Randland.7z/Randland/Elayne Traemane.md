---
tags: [Women, Andor_people, Ladies, HighSeats, Deceased, Nobility]
---


**Elayne Traemane** was an [[Andoran]] noblewoman who was the grandmother of Lady [[Ellorien Traemane]].

## Activities
Queen [[Morgase Trakand]] named her daughter and heir [[Elayne Trakand|Elayne]] in honor of Lady Elayne Traemane. However, despite this honor, Lady Ellorien is disgusted at House Trakand after Morgase orders her flogged when she is held under [[Compulsion]] by [[Rahvin]] as "Lord Gaebril."

## Notes






https://wot.fandom.com/wiki/Elayne_Traemane