---
tags: [Saldaea, Andor, Rivers]
---

The **River Arinelle** is one of the largest and most important rivers of the [[Westlands]]. It rises in the [[Mountains of Dhoom]] and flows south through the [[Blight]] and into [[Saldaea]]. By the time the river reaches the capital at [[Maradon]] it is already navigable by fairly large merchant and trade craft.
The river flows south and west, for a time serving as Saldaea's southern border, before turning into the unclaimed and heavily forested lands between the [[Mountains of Mist]] and the [[River Haevin]]. The river is joined by several tributaries, including the [[Ivo]], before turning sharply eastwards to form the northern border of [[Andor]]. Here, where the river is joined by a smaller trbiutary flowing out of the Mountains of Mist, the river passes the fog-shrouded and cursed city of [[Shadar Logoth]]. Traders and merchantment plighing the river give the ancient city a wide berth. After being joined by the Haevin, the Arinelle turns south and passes through the Andoran town of [[Whitebridge]] before it flows into the [[Manetherendrelle]].
The Manetherendrelle-Arinelle river netwrok is the largest and most extensive on the continent, and is navigable for roughly three thousand miles from Maradon to the city of [[Illian]]. The only bridges over the river are located in Maradon and Whitebridge. All other crossings must be achieved by either ferry or swimming.
The river passes within extreme viewing distance of a [[Tower of Ghenjei|silver tower]], a relic from the [[Age of Legends]] located between Shadar Logoth and Whitebridge. The purpose and origins of this tower are not known to the river traders, who avoid it.






https://wot.fandom.com/wiki/Arinelle