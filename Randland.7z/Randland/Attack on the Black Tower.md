---
tags: [ElaidaaRoihansWhiteTower]
---



The **Attack on the Black Tower** was a failed attempt by [[Elaida do Avriny a'Roihan]] to vanquish [[Rand al'Thor]]'s growing [[Asha'man]] army at the source.

## Contents

1 The plan
2 Arrival
3 The aftermath
4 List of known sisters involved


## The plan
After receiving news that the Dragon had begun gathering men who could channel at the location known as the [[Black Tower]], the Aes Sedai in the [[White Tower]] knew that action had to be taken. Despite the amount of reports about the Asha'man training ground, the number of male channelers was largely underestimated as the number that the White Tower found every year was growing notably small.
Under the belief that Rand al'Thor couldn't have been able to gather more than a handful of male channelers, let alone train them quickly enough to be of a threat in any near future, Elaida do Avriny a'Roihan dispatched a party of fifty sisters; more than enough, as was assumed. The group was led by [[Toveine Gazal]] of the [[Red Ajah]], and they set out under orders to capture and [[Gentle|gentle]] every man at the Black Tower on the spot.

## Arrival
The group of Aes Sedai held complete confidence for their mission to the very last moment. However, the Asha'man discovered their presence long before their arrival and stood ready for an ambush. The Asha'man stayed hidden, for the most part, and shielded each Aes Sedai before the sisters knew what had occurred. After the countless black cloaked men revealed themselves from the woods, the Aes Sedai realized that they had already failed their attack before it even began, having already succeeded in the capture of the Aes Sedai attackers.

## The aftermath
Each of the Aes Sedai that were captured became [[Bonding|bonded]] to an Asha'man, but with the bond altered to force the sisters into absolute obedience. Otherwise, the Aes Sedai were free to roam the grounds under the forbearance of [[Channeling|channeling]] or making any act of deceit or treason.
At the White Tower, news of the failure of the Aes Sedai party and the number of channeling men reached Elaida. As news of this failure would risk Elaida's power over the Tower, the faulty attack became a piece of leverage in [[Alviarin Freidhen]]'s blackmail towards her, and the rest of the Tower remained in the dark concerning the entire affair.

## List of known sisters involved

Of all the sisters sent in the expedition, none was of the [[Black Ajah]]. Seeing Alviarin's concern with the fate of the Aes Sedai involved, [[Mesaana]] made sure no Black sister was sent.






https://wot.fandom.com/wiki/Attack_on_the_Black_Tower