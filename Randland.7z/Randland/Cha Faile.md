---
tags: [, OldTongue, Organizations, ChaFaile, Eyes-and-ears]
---
*Cha Faile* is a phrase from the [[Old Tongue]] meaning "Falcon's Talon" or "Falcon's Claw."
This name has been adopted by the cadre of men and women, previously nobles, who follow [[Faile]] and function unofficially as her spies. The members of *Cha Faile* are fanatically loyal to her, and also seek to emulate the [[Aiel]] way of life. Many of them were used by Faile and later by [[Sebban Balwer]] as spies and agents.

## History
Many women of Cha Faile started as [[Maidens of the Sword]], which offended many of the Aiel stationed in Cairhien. As a result, some of the Aiel tried to give them a taste of being true *gai'shain*, although the result was not what they hoped for, as many of the women considered this to be a point of honor; they told others that they couldn't know true *ji'e'toh* until they served as *gai'shain*. 
The group was reorganized by Lady Faile Bashere to keep them out of trouble, with them becoming personally devoted to her. They numbered some two dozen young men and women, mostly nobles from Tear and Cairhien, when she departed to [[Ghealdan]] with Perirn.

## Customs
All members of Cha Faile dress in men's clothing, and wear a sword at the hip. Men and women alike wear their hair to their shoulders, but gather it back with a ribbon in imitation of the Aiel "tail."
They are considered arrogant in everything, even in the way that they walk, with the women being considered far more arrogant than the men.

### Members
[[Arrela Shiego]]
[[Barmanes Nolaisen]]
[[Camaille Nolaisen]]
[[Carlon Belcelona]]
[[Haviar Agora]]
[[Lacile Aldorwin]]
[[Medore Damara]]
[[Meralda]]
[[Nerion]]
[[Parelean]]
[[Selande Darengil]] (unofficial leader during Faile's absence)

This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Cha_Faile