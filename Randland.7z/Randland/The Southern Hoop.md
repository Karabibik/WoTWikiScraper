---
tags: [Inns, Altara]
---
**The Southern Hoop** is an inn in [[So Tehar]], [[Altara]]. 

## Appearance
It is a "a scruffy two stories of white-plastered bricks." The inkeeper is a "lanky woman" who served brandy "which tasted as if it might remove rust."

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Southern_Hoop