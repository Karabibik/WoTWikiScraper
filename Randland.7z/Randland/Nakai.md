---
tags: [Aielclans, Nakai]
---

The **Nakai** are one of the twelve [[Aiel]] clans. Their clan hold is [[Shiagi Hold]]. They were one of the four clans to cross the [[Dragonwall]] during the [[Aiel War]].

## Notable Members
[[Bruan]] ([[Clan chief]])
[[Aeron]] ([[Wise One]])
[[Alsera]] (Wise One)
[[Seana]] (Wise One)
[[Roidan]]
[[Jolien]]
## Septs
[[Black Cliffs]]
[[Black Water]]
[[Salt Flat]]
## Holds
[[Shiagi Hold]]
*This page is a stub. You can help A Wheel of Time Wiki by expanding it. *





https://wot.fandom.com/wiki/Nakai