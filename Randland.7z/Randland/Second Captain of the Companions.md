---
tags: [Military]
---
**Second Captain of the Companions** is the rank given to the second-in-command of the [[Illianer Companions]]. This rank is directly subordinate to the First Captain of the Companions.
This rank is unusual in the fact that it is able to be achieved by a foreigner, of whom no noble birth is needed.

### Former Second Captains
[[Tam al'Thor]]


*This page is a stub. You can help A Wheel of Time Wiki by expanding it. *





https://wot.fandom.com/wiki/Second_Captain_of_the_Companions