---
tags: [Horses]
---


**Rosebud** is the name of [[Selucia]]'s horse.

## Appearance
Rosebud is a dun colored mare.

## Activities
After [[Matrim Cauthon]] bought [[Tuon Athaem Kore Paendrag]] [[Akein]], Selucia buys Rosebud. Rosebud carries Selucia during her travels across [[Altara]] and back to [[Ebou Dar]].

## Notes






https://wot.fandom.com/wiki/Rosebud