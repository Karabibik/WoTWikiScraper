---
tags: [Arafel]
---
The **Arafellin** people hail from [[Arafel]] in the [[Borderlands]]. The women are known to wear bells in their hair.






https://wot.fandom.com/wiki/Arafellin