---
tags: [Women, Andor_people, Tavernkeepers, LivingasofTOM, Charactersnamedafterfans]
---


**Melli Craeb** is the tavernkeeper of [[The Seven-Striped Lass]] in [[Caemlyn]].

## Appearance
She is a short woman, pretty, she has round face with curly auburn hair, nicely exposed bosom and pretty lips.

## Activities
She raised the area behind the bar to appear taller. [[Mat]] considers her pretty lips, her nice bosom, that she is not afraid to show, would be good for a kiss and cuddle. But as he is married it would be wrong, and decides she would be suitable for [[Talmanes]]. Mat asked Melli for advice concerning [[Verin]]'s letter; she snatched it and offered to open it for him. She always fancied going to [[Tar Valon]] and becoming an [[Aes Sedai]].

## Notes






https://wot.fandom.com/wiki/Melli_Craeb