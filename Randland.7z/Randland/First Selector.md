---
tags: [BlueAjah, Titles, AjahHeads]
---

**First Selector** is the title of the [[Ajah Heads|Head]] of the [[Blue Ajah]].  The First Selector could be more or less autocratic, depending on the woman holding the post. She always has an advisory council with a variable number of members. Beyond that, there is no constant organizational structure.

## Title holders
In [[New Spring]], the title of First Selector was held by a woman called [[Eadyth]], who was also a [[Sitter]] for the Blue Ajah at the time.  [[Lelaine Akashi]] is the current Head of the Blues, and a Sitter, but it is not clear when she became First Selector. 
There had long been speculation that perhaps [[Maigan]] or [[Anaiya]], who, like [[Rebel Aes Sedai|Rebel]] [[Captain-General (Green Ajah)|Captain-General]] [[Myrelle Berengari]] sat on [[Salidar Six|the council that helped organize the Salidar rebellion]], was First Selector. The revelation that Lelaine is the First Selector would tend to rule out Maigan as the previous one, but it is possible Anaiya served in the role before her death or that someone else did before [[Siuan Sanche]] was deposed. In [[Knife of Dreams]], [[Siuan Sanche|Siuan]] said to Lelaine that she was faithful to her *as a Sitter*, not as Ajah Head. This would seem to indicate either that the First Selector at that time was still in office, or that Lelaine had not yet taken the position after the previous Head's death.
It is not known when Eadyth died or stepped down from the position, and not who replaced her. Moiraine's cryptic "I will leave the [[Hall of the Tower]] to you [Anaiya]" could suggest that Anaiya was indeed the First Selector of the time, and that Moiraine due to [[Liandrin]]'s presence did not want to be more specific.  It is also most likely that the Head of the Blue Ajah be on the [[Salidar Six]], and since it is known Sheriam was not the Ajah Head, it increases Anaiya's likelihood to be. It would seem most likely that Anaiya has been the First Selector throughout the main series.

## Notes






https://wot.fandom.com/wiki/First_Selector