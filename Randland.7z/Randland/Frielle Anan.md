---
tags: [Women, Altara_people, Maids, LivingasofWH]
---


**Frielle Anan** is an [[Ebou Dar|Ebou Dari]] woman, the daughter of [[Jasfer Anan|Jasfer]] and [[Setalle Anan]]. Her siblings are [[Marah Anan|Marah]], [[Ross Anan|Ross]], and [[Leral Anan|Leral]].

## Appearance
Frielle is pretty, just like her mother.

## Activities
Frielle works at [[The Wandering Woman]] with her mother. When [[Matrim Cauthon]] and his party are in Ebou Dar and staying at the Wandering Woman, Frielle takes care of [[Olver]]. While she often said that she wanted to have six sons, Mat thinks that after taken care of the boy, she may wish to have a few daughters. A short time before Mat's party left Ebou Dar, Frielle got married. It is not known who she married. This is a great annoyance and source of jealousy for her older sister, Marah.

## Notes






https://wot.fandom.com/wiki/Frielle