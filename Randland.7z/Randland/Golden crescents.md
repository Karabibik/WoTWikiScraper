---
tags: [Terangreal, ItemsofPower]
---



The **golden crescents** are a *ter'angreal* in the possession of [[Cadsuane Melaidhrin]] as part of her [[Paralis-net|paralis-net]].

## Appearance
The *ter'angreal* is made of intertwining golden crescents which look like moons.

## Use
When *saidar* is channeled in proximity to the crescents, they will detect it and turn cool, much like [[Mat Cauthon]]'s [[Foxhead medallion|foxhead medallion]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Golden_crescents