---
tags: [, Titles, Military, Andor, Generals]
---
**Captain-General** is the military rank of the leader of the [[Queen's Guard]] in [[Andor]].

## Title Holders
Both [[Gareth Bryne]] and [[Aranvor Naldwinn]] held the title simultaneously during the [[Aiel War]]. The current Captain-General of Andor is [[Birgitte Silverbow]].

*This page is a stub. You can help A Wheel of Time Wiki by expanding it. *





https://wot.fandom.com/wiki/Captain-General_(Andor)