---
tags: [CrownsandRegalia]
---




The **Dragon Scepter** is a scepter that [[Rand al'Thor]] uses as a symbol of the [[Dragon Reborn]].

## Appearance
The scepter is made from a piece of a [[Seanchan]] spear. About two feet in length, it sports a green and white tassel beneath the spearhead, and has dragons carved into the remaining haft by Maidens of the Spear.

## History
Rand acquired the Seanchan spear when it was cut off not far behind its head by a closing [[Gateway|gateway]] while he and [[Aviendha]] escaped from the Seanchan continent they had accidentally found themselves on. Instead of disposing of the spear, Rand kept it as a constant reminder of the Seanchan threat. The *Far Dareis Mai* were the ones who carved the dragons into it, and it eventually became informally known as the Dragon Scepter.
Rand carried the scepter with him nearly everywhere he went, using it as a symbol and reminder for himself of the Seanchan and all of the other problems he had to deal with, figuratively keeping his hands full.
Most recently, during a trap laid by [[Semirhage]] to pose as the [[Daughter of the Nine Moons]] to lure in Rand, Semirhage sent a burst of power-wrought fire at him, which burnt the scepter to a crisp.






https://wot.fandom.com/wiki/Dragon_Scepter