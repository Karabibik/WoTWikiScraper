---
tags: [OldTongue, Listpages]
---
This page consists of a list of numbers in the [[Old Tongue]] that is expanded from and using the rules described in [[The Wheel of Time Companion]]. The key features are as follows:

**Numerical stem**: Every number has a core part that reresents a value.
**Concrete vs abstract**: For numbers under 20, the suffix "-*yat*" is appended to the numerical stem to represent objects that are concrete/material (*e.g.*, apples, oranges), while the suffix "-*ye*" is appended to represent abstract/immaterial objects (*e.g.*, ideas, arguments, propositions).
**Teen suffix**: For the numbers from 11 to 19, the suffix "-*pi*" is appended to the stem. Note that this includes 11 and 12, which are not considered "teens" in English.
**Tens, hundreds, and thousands suffixes**: Suffixes can be added to describe larger quantities. The suffixes for ten, hundreds and thousands are "-*shi*," "-*deshi*," and "-*tuhat*," respectively. Note that the word for one hundred, "*deshi*," is a compound of the stem for ten, "*des*," and the suffix for tens, "-*shi*".
**Ordinal numbers**: Ordinal numbers (*e.g.*, "first," "second," "third," etc.) are formed by appending the suffix "-*yn*" to the numerical stem.
The following tables give a selection of numbers. There are no canon versions of the larger numbers, as, though the above rules are enumerated in the Companion, the order in which to apply said rules is not described. The following conventions have been applied to the numbers in the tables below:

Numbers read from left to right in descending order (*i.e*., they're written as "forty-one," not "one-and-forty"- in the Old Tongue, "*min'shi'ko,"* not "*ko'min'shi*").
Ordinal number suffixes are added to the integer of the smallest order of magnitude (*i.e*., "forty-first," not "fortieth-one" - in the Old Tongue, "*min'shi'koyn,"* not "*min'shiyn'ko*").
We use apostrophes to seperate the suffix(es) from the numerical stem and, if applicable, from each other (*i.e.*, "*min'shi'ko*," not "*minshiko/min'shiko/minsh'ko*"); ordinal numbers are an exception (see below).
We also use an apostrophe with the "-*pi*" suffix used for the numbers from 11 to 19.
Using the canon spelling of *koyn,* "first", as an exemplar, we do not use an apostrophe to seperate the "-*yn*" suffix for ordinal numbers, with the exception of "-*shi'yn*" in order to seperate the phonemes ("*-shyn*" might be an alternative). For the first 19 numbers, we have the two suffixes to be applied for concrete/abstract distinctions.
|**Number**|**Concrete**|**Abstract**|**Ordinal**|
|-|-|
|1|koyat|koye|koyn|
|2|dvoyat|dvoye|dvoyn|
|3|treyat|treye|treyn|
|4|minyat|minye|minyn|
|5|choryet|chorye|choryn|
|6|panyet|panye|panyn|
|7|sukyat|sukye|sukyn|
|8|otyat|otye|otyn|
|9|navyat|navye|navyn|
|10|desyat|desye|desyn|
|11|koyat'pi|koye'pi|koyn'pi|
|12|dvoyat'pi|dvoye'pi|dvoyn'pi|
|13|treyat'pi|treye'pi|treyn'pi|
|14|minyat'pi|minye'pi|minyn'pi|
|15|choryet'pi|chorye'pi|choryn'pi|
|16|panyet'pi|panye'pi|panyn'pi|
|17|sukyat'pi|sukye'pi|sukyn'pi|
|18|otyat'pi|otye'pi|otyn'pi|
|19|navyat'pi|navye'pi|navyn'pi|
|20|dvo'shi|dvo'shi|dvoyn'shi|
For higher numbers:
|Number|Old Tongue|Ordinal|
|-|-|
|21|dvo'shi'ko|dvo'shi'koyn|
|22|dvo'shi'dvo|dvo'shi'dvoyn|
|23|dvo'shi'tre|dvo'shi'treyn|
|24|dvo'shi'min|dvo'shi'minyn|
|25|dvo'shi'chor|dvo'shi'choryn|
|26|dvo'shi'pan|dvo'shi'panyn|
|27|dvo'shi'suk|dvo'shi'sukyn|
|28|dvo'shi'ot|dvo'shi'otyn|
|29|dvo'shi'nav|dvo'shi'navyn|
|30|tre'shi|tre'shi'yn|
|31|tre'shi'ko|tre'shi'koyn|
|32|tre'shi'dvo|tre'shi'dvoyn|
|33|tre'shi'tre|tre'shi'treyn|
|34|tre'shi'min|tre'shi'minyn|
|35|tre'shi'chor|tre'shi'choryn|
|36|tre'shi'pan|tre'shi'panyn|
|37|tre'shi'suk|tre'shi'sukyn|
|38|tre'shi'ot|tre'shi'otyn|
|39|tre'shi'nav|tre'shi'navyn|
|40|min'shi|min'shi'yn|
|50|chor'shi|chor'shi'yn|
|60|pan'shi|pan'shi'yn|
|70|suk'shi|suk'shi'yn|
|80|ot'shi|ot'shi'yn|
|90|nav'shi|nav'shi'yn|
|100|deshi|deshi'yn|
|110|deshi'des|deshi'desyn|
|120|deshi'dvo'shi|deshi'dvo'shi'yn|
|130|deshi'tre'shi|deshi'tre'shi'yn|
|140|deshi'min'shi|deshi'min'shi'yn|
|150|deshi'chor'shi|deshi'chor'shi'yn|
|160|deshi'pan'shi|deshi'pan'shi'yn|
|170|deshi'suk'shi|deshi'suk'shi'yn|
|180|deshi'ot'shi|deshi'ot'shi'yn|
|190|deshi'nav'shi|deshi'nav'shi'yn|
|200|dvo'deshi|dvo'deshi'yn|
|300|tre'deshi|tre'deshi'yn|
|400|min'deshi|min'deshi'yn|
|500|chor'deshi|chor'deshi'yn|
|1000|tuhat|tuhatyn|
|2000|dvo'tuhat|dvo'tuhatyn|
|3000|tre'tuhat|tre'tuhatyn|
|10000|des'tuhat|des'tuhatyn|
|20000|dvo'shi'tuhat|dvo'shi'tuhatyn|
|50000|chor'shi'tuhat|chor'shi'tuhatyn|
|100000|deshi'tuhat|deshi'tuhatyn|
|200000|dvo'deshi'tuhat|dvo'deshi'tuhatyn|
|500000|chor'deshi'tuhat|chor'deshi'tuhatyn|
|1000000|?|?|
These rules can be combined to create any number whatsoever.
## Notes






https://wot.fandom.com/wiki/Old_Tongue_numbers