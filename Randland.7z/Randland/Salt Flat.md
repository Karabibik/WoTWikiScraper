---
tags: [Nakai, SaltFlat, Aielsepts]
---



The **Salt Flat** is a sept of the [[Nakai]] [[Aiel]]. The sept hold is unknown.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Salt_Flat