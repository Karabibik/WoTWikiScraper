---
tags: [Battles]
---
The **Battle of Malden** was fought in early 1000 NE, in and around the town of [[Malden]] in central-western [[Altara]]. It was a major conflict involving tens of thousands of troops from nine different nations fighting against the [[Shaido]] [[Aiel]] who were massing in the region, posing a significant danger to both the inhabitants and the [[Seanchan]], who had taken most of the territory to the south. It is highly significant as the first major engagement where the Seanchan had to fight alongside native [[Westlands|Westland]] forces against a common foe, and where *damane* were employed alongside non-leashed channelers, including Aiel [[Wise Ones]], [[Aes Sedai]] and [[Asha'man]], a state of affairs that previously would have been considered unthinkable.

## Contents

1 Background
2 Battle plans
3 The Battle of Malden

3.1 Shaido forces
3.2 Allied forces
3.3 Casualties


4 Aftermath
5 Notes


## Background
After being defeated at the [[Battle of Dumai's Wells]], the Shaido retreated into [[Kinslayer's Dagger]]. [[Sevanna]], acting for the clan chief, accepted aid from two local nobles (in reality the [[Forsaken]] [[Graendal]] and [[Sammael]]) in the form of *ter'angreal* called "Traveling Boxes," which would supposedly carry the Shaido to new, rich lands to conquer. In reality, the devices did nothing; Sammael used *saidin* to create [[Gateway|gateways]] which scattered the Shaido across much of the south and west of the continent, some bands ending up as far west as [[Tarabon]] or as far south as [[Illian]].
Sevanna's group, which included all 400-odd of the clan's Wise Ones, found itself in northern [[Amadicia]]. Sevanna had perverted much of *ji'e'toh* and now found herself with a taste for taking wetlanders as *gai'shain* in defiance of all tradition. With the Seanchan invasion troops advancing from [[Amador]] in the south and with the forces of the [[Dragonsworn]] under the [[Prophet of the Dragon]] to the north, plus the [[Children of the Light]] also in the area, Sevanna elected to withdraw across the [[River Eldar]] into Altara. After some days or weeks of travel, the Shaido found and took the small city of Malden. With fresh water being brought into the city by an aqueduct and food plentiful in the region, Sevanna elected to wait out the rest of winter in Malden and gather as many other Shaido septs to her as possible.
By the time spring arrived, the Shaido had amassed over 100,000 people in and around Malden, presenting a significant threat to the Seanchan who had seized [[Ebou Dar]] to the south and were now attempting to secure the rest of Altara. The senior Seanchan officers in Ebou Dar - presumably either [[High Lady]] [[Suroth Sabelle Meldarath]] or Captain General [[Lunal Galgan]] - ordered Banner-General [[Tylee Khirgan]] to locate and destroy the Shaido forces at any cost.
At the same time, [[Perrin Aybara]] had been sent to [[Ghealdan]] by [[Rand al'Thor]], the [[Dragon Reborn]], to neutralize the Prophet of the Dragon, [[Masema Dagar]]. Perrin tracked Masema to the Amadician town of [[Abila]], but whilst negotiating with him there the Shaido swept past Perrin's camp and took his wife [[Faile]] prisoner. Perrin pursued the Shaido across the Eldar and into Altara, but found Malden far too heavily defended for his small force to have a chance of winning the battle, forcing a rethink of strategy.

## Battle plans
With both Perrin and the Seanchan seeking the destruction of the Shaido, he decided to put aside misgivings and suggest an alliance with Tylee's forces. Although the prospect of working alongside *marath'damane* was highly troubling to the Seanchan, the opportunity presented to destroy the Shaido and take their Wise Ones as *damane* was deemed worth the danger. The deal struck between the two sides was that the Seanchan would be able to take any and all Shaido Wise Ones as *damane* and destroy their *algai'd'siswai* who refused to surrender, while their *gai'shain* prisoners would be released. Channelers among the *gai'shain* would be allowed to go free, and the Seanchan would also promise not to leash the channelers with Perrin's forces.

## The Battle of Malden
The Seanchan poured large quantities of [[Forkroot|forkroot]], a drug that inhibited channeling, into the aqueduct at Malden. This incapacitated most of the Shaido Wise Ones. A wall of fog was created to cover Perrin's forces on the ridge above Malden, and his troops drew the Shaido spear-carriers out of the city. The Shaido also sent a flanking force to try and surround Perrin's troops. Using sustained missile fire from their bowmen, Perrin's forces inflicted terrible damage upon the Shaido, whilst his channelers were able to affect even more destruction on the Shaido ranks. The Seanchan then took the Shaido flanking force in the rear and side, and enveloped their forces, destroying some of them and forcing them to surrender. Perrin led a personal sortie into Malden and was able to rescue his wife and several other prisoners.

### Shaido forces
100,000 Shaido led by [[Sevanna]] of the Jumai sept.
400+ Wise Ones capable of channeling, led by [[Therava]].
25-30,000 other Aiel forces (presumed to be Shaido) to the west of Malden.
40,000 other Aiel forces (presumed to be Shaido) to the east of Malden.
### Allied forces
15,000 Seanchan led by Banner-General Tylee Khirgan and Captain [[Bakayar Mishima]].
12 Seanchan *damane*.
20,000 [[Dragonsworn]] under Masema Dagar.
900 [[Winged Guards]] of [[Mayene]] under Lord-Captain [[Bertain Gallenne]].
1,000 [[Legion of the Wall]] of [[Ghealdan]] under First Captain [[Gerard Arganda]].
3,000-4,000 [[Two Rivers]] bowmen under First Captain [[Tam al'Thor]].
20+ *Cha Faile*, mostly [[Cairhienin]], under [[Selande Darengil]].
20 Aiel [[Maidens of the Spear]] under [[Sulin]].
Gaul, a Stone Dog of the Shaarad Aiel
6 Wise Ones under [[Edarra]] of the [[Shiande]] [[Aiel]].
3 [[Aes Sedai]].
2 [[Asha'man]].
### Casualties
400 Shaido Wise Ones taken as *damane*.
Other Shaido casualties unknown but likely tens of thousands killed or captured.
Approximately 19,800 Dragonsworn killed.
Total casualties among the other Allies: approximately 100 killed.

## Aftermath
Approximately 15-20 of the Shaido Wise Ones and an unknown number of other combatants (likely several hundred) and non-combatants escaped the battle. Unified under the command of Therava, these Shaido decided to return to the [[Aiel Waste]] as soon as possible. They freed their remaining *gai'shain* with the sole exception of [[Galina Casban]], whom Therava chose to make her personal slave for life following her botched escape attempt.
Tylee Khirgan was commended on her initiative in the field and raised to the rank of Lieutenant-General and to the Low Blood.

## Notes






https://wot.fandom.com/wiki/Battle_of_Malden