---
tags: [Disambiguation, Chapterdisambiguations]
---
**Mountain** can refer to the following:

## [[Aiel]]
*Hama N'dore* - an [[Aiel warrior society]].
[[Iron Mountain]] - a [[Sept|sept]] of the [[Taardad]] Aiel.
[[White Mountain]] - a sept of the [[Chareen]] Aiel.
[[Mountain king]] - a snake from the [[Aiel Waste]].
## [[Sword forms]]
[[The Boar Rushes Down the Mountain]]
[[Stone Falls From the Mountain]]
[[Whirlwind on the Mountain]]
## [[Old Tongue]]
[[Manetheren]] - one of the [[Ten Nations]] whose name means "Mountain Home" in the Old Tongue.
*hama* - mountain in the Old Tongue.
## Others
*The Way Out of the Mountains* - the seventh chapter of *The Dragon Reborn*.
Mountains - a category listing of mountains in *The Wheel of Time* world.
*Duty is heavier than a mountain, death lighter than a feather.* - a saying often quoted by [[Rand al'Thor]] and [[Al'Lan Mandragoran|al'Lan Mandragoran]].


https://wot.fandom.com/wiki/Mountain