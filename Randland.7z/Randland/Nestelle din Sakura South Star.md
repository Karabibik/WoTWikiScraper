---
tags: [Women, AthaanMiere_people, Windfinders, LivingasofCOT, Channelers]
---


**Nestelle din Sakura South Star** is an *Atha'an Miere* [[Windfinder]] and former [[Damane]].

## Activities
She was captured during the [[Seanchan]] attack on [[Ebou Dar]] and made *damane*. 
[[Matrim Cauthon]] stole into her sleeping room where she was held in the *damane* kennels and freed her from her *a'dam*. In return he taught her how to unlock more *a'dam* by herself. Mat instructed her to wait three hours and then release as many of the captive Sea Folk *damane* as she could before fighting her way to freedom. 
It is unknown whether she was killed, recaptured, or managed to escape in the uprising that ensued. 

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Nestelle_din_Sakura_South_Star