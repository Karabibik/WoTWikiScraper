---
tags: [Historical, Diseases]
---



The **Black Fever** was a plague that devastated the [[Westlands]] over the course of several years, culminating in [[FY 939]]. The plague moved across the continent from east to west and killed over ten percent of the population, including the King and Queen of a small kingdom named [[Shandalle]]. Their deaths allowed their son, [[Artur Paendrag Tanreall]], to assume the throne. The plague left much of the continent weak and divided, and the [[False Dragon|false Dragon]] [[Guaire Amalasan]] was able to take advantage of this to conquer vast stretches of territory before opposition could assemble against him.
The Black Fever was the prelude to the [[War of the Second Dragon]] and the rise of [[Artur Hawkwing]].






https://wot.fandom.com/wiki/Black_Fever