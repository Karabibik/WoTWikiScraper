---
tags: [Men, Aiel_people, Nakai, SaltFlat, ShamadConde, LivingasofLOC]
---


**Roidan** is a man of the [[Salt Flat]] [[Sept]] of the [[Nakai]] [[Aiel]].  He is the leader of the [[Thunder Walkers]] society.

## Appearance
He is thick shouldered with gray hair and icy blue eyes.

## Activities
He helps to teach [[Rand al'Thor]] the Aiel way of fighting.
He is present when the Aiel begin their attack on the [[Shaido]] who are laying siege to [[Cairhien]].
He is later sent with most of the other Aiel to the [[Plains of Maredo]] where Rand plans to attack [[Sammael]] in [[Illian]].

## Notes






https://wot.fandom.com/wiki/Roidan