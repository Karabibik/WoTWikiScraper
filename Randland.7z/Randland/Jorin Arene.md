---
tags: [Men, Amadicia_people, Darkfriends, Merchants, LivingasofTFOH]
---






**Jorin Arene** is a merchant in [[Amador]]. He is a [[Darkfriend]]. He has a wife named [[Amellia Arene]], who is also a Darkfriend.

## Activities
He objected to [[Liandrin]] and the rest of her [[Black Ajah]] group taking over his house, so Liandrin allowed [[Temaile Kinderode]] to torture him into submission.

## Notes






https://wot.fandom.com/wiki/Jorin_Arene