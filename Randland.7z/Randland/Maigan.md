---
tags: [Women, BlueAjah, AesSedai, LivingasofCOT, RebelAesSedai, HighRankingAesSedai, Channelers]
---







**Maigan** is an [[Aes Sedai]] of the [[Blue Ajah]].

## Contents

1 History
2 Appearance
3 Strength
4 Activities
5 In the television series
6 Notes


## History
Her name suggests an [[Andoran]] origin, as there reportedly are other Andoran women with this first name.

## Appearance
She is beautiful with a long face, large eyes, and full lips, and is "elongated" somehow but not very tall.

## Strength
Maigan seems to be a very influential sister, chosen by the Blue Ajah as a substitute to [[Anaiya]], killed by [[Aran'gar]], as a member of [[Egwene]]'s advisory council.
This is confirmed by the "Wheel of Time Companion" where her strength in *saidar* is described at the level 15(3), which is the same level of three others in Egwene's council: [[Myrelle]], [[Morvrin]], and [[Carlinya]].

## Activities
She was one of two Blue sisters, the other being [[Anaiya]], who accompanied [[Siuan Sanche]], as part of the [[Amyrlin Seat|Amyrlin]]'s retinue, to [[Fal Dara]]. Several [[Sitter|Sitters]] objected to the fact that there were really four representives of the Blue in the retinue, since Siuan and [[Leane Sharif]] were also raised from the Blue.
Maigan had been a strong supporter of Siuan when she was [[Amyrlin]], but after the Tower split she was one of many who blamed Siuan for the loss and the breaking of the Tower. After Siuan was [[Healed]] by [[Nynaeve]] and reconfirmed Aes Sedai, she had to beg to be accepted back into the Blue Ajah: rumour had it that Maigan had been the most insistent on the begging.
After the death of [[Anaiya]], Maigan took her position as a representative of the Blue Ajah in [[Egwene's Council]] of advisors. Maigan is somewhat of a wild card in her role as advisor because she is the only one of the council who has not sworn loyalty to Egwene. Maigan is also an ally to Lelaine and usually supports her goals so she usually clashed with Egwene and the other five members of the Council.
She is present when Egwene reveals her plan to [[Romanda Cassin]] about Aes Sedai retiring by being released from the [[Three Oaths]] and joining the [[Kin]]. When Romanda then leaves and [[Lelaine Akashi]] enters, Maigan appears to be loyal to Lelaine. Maigan subtly offers up the idea of using [[Compulsion]] through the bond when the [[Asha'man]] from the [[Black Tower]] are made [[Warder|Warders]], so the men had to obey. At Lelaine's behest Maigan also proposed that the bond be modified to eliminate the sharing and thus protect sisters from bonding a man fated to go mad. Egwene is disgusted, and states in no uncertain terms that Compulsion is not to be used.

## In the television series
In the [[The Wheel of Time (TV series)|television series]],  
## Notes






https://wot.fandom.com/wiki/Maigan