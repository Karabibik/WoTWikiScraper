---
tags: [Men, Aiel_people, LivingasofAMOL, Charactersnamedafterfans]
---


**Shaen** is an [[Aiel]] *Shae'en M'taal*.

## Contents

1 Appearance
2 Activities
3 Trivia
4 Notes


## Appearance
Shaen has begun wearing the red headband of the *Siswai'aman*.

## Activities
Shaen helps scout [[Thakan'dar]] with [[Rhuarc]] and [[Aviendha]].

## Trivia
Shaen is named for Shane Spears, a fan of *The Wheel of Time*.
## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Shaen