---
tags: [Aielwarriorsocieties, FarAldazarDin]
---
The *Far Aldazar Din* is an [[Aiel]] [[Aiel warrior society|warrior society]]. The name means "Brothers of the Eagle" in the [[Old Tongue]].

## Role
The Brothers to the Eagle are scouts, much like Far Dareis Mai, except that they excel at scouting areas that are more rigid.  Often they are used to scout areas along the Dragonwall, and other mountainous regions in the Three-fold Land.

## Activities
Members of the *Far Aldazar Din*, along with members of the *Aethan Dor*, *Duadhe Mahdi'in*, *Far Dareis Mai*, *Seia Doon*, and *Sha'mad Conde* helped [[Rand al'Thor]] find a [[Portal Stone]] outside [[Tear]]. All of the societies, including the *Far Aldazar Din*, accompanied [[Rand al'Thor]] from the [[Sun Palace]] in [[Cairhien]] to [[Caemlyn]] in [[Andor]] to battle [[Rahvin]] and his forces. *Far Aldazar Din* have guarded the halls of the Sun Palace. 

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Brothers_of_the_Eagle