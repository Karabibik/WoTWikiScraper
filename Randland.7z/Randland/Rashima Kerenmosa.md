---
tags: [Women, GreenAjah, AmyrlinSeats, AesSedai, Deceased, Historicalpeople, HighRankingAesSedai, Channelers, AesSedaiaftertheBreaking]
---


**Rashima Kerenmosa** (c. [[1150 AB|1150]] - [[1301 AB]]) is one of the most decorated and famous [[Aes Sedai]] since the [[Breaking of the World]]. She is considered a hero by the [[Green Ajah]], one of their greatest and, alongside [[Caraighan Maconar]], the symbol of all it means to be a Green sister.
In the records of the White Tower Rashima was the fourth strongest Aes Sedai ever, after [[Caraighan Maconar]], [[Eldrene]] and [[Tetsuan]], a record unsurpassed till the arrival of [[Nynaeve]]. Because in TWoTC Caraighan is described at level 3(+10) it can be guessed that Eldrene was at 4(+9), Tetsuan at 5(+8) and Rashima at 6(+7).

## History
Rashima was born circa 1150 AB, during the [[Trolloc Wars]]. She went to the [[White Tower]] around 1165 AB and spent five years as a [[Novice|novice]] and five years as [[Accepted]]. She was raised to the Green Ajah around 1175 AB. In [[1251 AB]], she became the [[Amyrlin Seat]], the most powerful position on the continent. While all Amyrlins during the [[Trolloc Wars]] had been more martial than their peacetime counterparts, Rashima took this to new extremes. She served directly as a general and battle leader, rather than relying on advice from a [[Warder]] or general. She fought in person rather than relying on others. Rashima is credited with restoring morale to the faltering [[Ten Nations]] after the destruction of [[Aridhol]] and [[Manetheren]], with [[Trolloc]] armies ranging as far south as [[Barashta]] on the [[Sea of Storms]].
Rashima led the defense of [[Tar Valon]] when the Trollocs broke into the city and partially razed it circa [[1290 AB]]. She began diplomatic and military overtures that led to a string of major victories for the Ten Nations over the next ten years, most notably at [[Kaisin Pass]], the [[Sorelle Step]], [[Larapelle]], and [[Tel Norwin]]. Rashima's efforts culminated at the [[Battle of Maighande]] in 1301 AB, where the nations achieved a decisive victory over the Trollocs. Although not the final victory—tracking down and destroying all the remaining Trolloc bands would take another fifty years—it broke the back of the [[Shadowspawn]] invasion.
Rashima died during the battle, along with her five Warders. Around their bodies a wall of Trolloc and [[Myrddraal]] corpses was found, along with the bodies of no fewer than nine [[Dreadlords]]. This proves that she must have been very strong in the [[One Power]].






https://wot.fandom.com/wiki/Rashima_Kerenmosa