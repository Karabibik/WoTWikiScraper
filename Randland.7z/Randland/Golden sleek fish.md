---
tags: [Terangreal, ItemsofPower]
---
The **golden** **sleek fish** ornament is a *ter'angreal* in the possession of [[Cadsuane Melaidhrin]] as a part of her [[Paralis-net|paralis-net]].

## Appearance
A sleek fish shaped trinket, pending from a golden hair needle. The fish is with sharp fins.

## Use
It enables the wearer to pull someone else into an involuntary [[Circle|circle]] under her/his control guiding the flows. It works only if the other person has already seized *saidin* or embraced *saidar*.

## Notes







https://wot.fandom.com/wiki/Golden_sleek_fish