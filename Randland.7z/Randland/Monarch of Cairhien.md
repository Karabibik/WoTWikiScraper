---
tags: [Cairhien, Rulers, Listpages]
---
The **monarch of Cairhien** is the ruler of all of [[Cairhien]], who governs from the [[Sun Throne]]. Unlike some titles in the [[Westlands]], this position can be held by both men and women.
Royal succession in Cairhien is more complicated than simply passing to the late monarch's eldest child or their closest blood relative. A rather stable monarch will often be succeeded by a relative, but if no potential successors are supported by the nobility, the throne may pass to another noble house. The lack of clear strictures around succession has led to *Daes Dae'mar* frequently being played in the nation, with lords and ladies manoeuvring to gain the throne. There have been five [[Wars of Cairhienin Succession]] since the [[War of the Hundred Years]], although the Cairhienin prefer not to discuss them with foreigners.
Candidates are barred from the throne by law if they are married to a foreign monarch, as [[Taringail Damodred]] could not claim the throne during his marriage to Queen [[Morgase Trakand]] of Andor. However, this was nullified with the personal union of Andor and Cairhien after Queen [[Elayne Trakand]] of Andor was also acknowledged as Queen of Cairhien at the end of the Fifth War of Cairhienin Succession.

## Known monarchs
King [[Matraine Colmcille]]
Queen [[Carewin Damodred]]
King [[Laman Damodred]]
King [[Galldrian Riatin]]
Queen [[Colavaere Saighan]]
Queen [[Elayne Trakand]]





https://wot.fandom.com/wiki/Monarch_of_Cairhien