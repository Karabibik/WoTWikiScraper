---
tags: [Men, Seanchan_people, EverVictoriousArmy, Soldiers, Unknownstatus, LivingasofTPOD]
---


**Tiras** is First Lieutenant to [[Assid Bakuun]] in the [[Seanchan]] army. 

## Appearance
He is a bony man with a very thin beard.

## Activities
He is in a Seanchan unit that is marching on [[Illian]]. One of [[Rand al'Thor]]'s armies, along with a group of [[Asha'man]], attack his unit. It is unknown whether or not he survived that battle.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Tiras