---
tags: [Shaido, Aielsepts]
---
The **Jonine** is a sept of the [[Shaido]] [[Aiel]]. The sept hold is unknown. The Jonine are the fifth sept to join with [[Sevanna]] in [[Amadicia]] during the [[Shaido War]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Jonine