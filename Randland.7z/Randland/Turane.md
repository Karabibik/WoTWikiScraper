---
tags: [Women, AthaanMiere_people, Sailmistresses, LivingasofKOD]
---


**Turane** is an *Atha'an Miere* [[Sailmistress]].

## Appearance
She is very stocky.

## Activities
She lost her vessel in [[Ebou Dar]] and now captains a [[Seanchan]] ship. Her craft is used by the *Atha'an Miere* [[First Twelve]] for their meeting with [[Rand al'Thor]]'s ambassador [[Logain Ablar]].






https://wot.fandom.com/wiki/Turane