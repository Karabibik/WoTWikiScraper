---
tags: [Women, Aiel_people, WiseOnes, Miagoma, SpineRidge, LivingasofACOS, Channelers]
---


**Cosain** is an [[Aiel]] [[Wise One]]. She is from the [[Spine Ridge]] [[Miagoma]] clan.

## Appearance
She is lean and yellow haired.

## Strength and Abilities
Cosain can [[Channel|channel]] strongly. In TWoTC her strength level is described as 14(2), the same level of [[Sheriam]] and [[Yukiri]], that are among the strongest [[Aes Sedai]] until the arrive of [[Nynaeve]], [[Egwene]] and [[Elayne]].
This strength is more than enough to open alone a gateway for [[Travel|Traveling]].

## Activities
She is one of the Wise Ones camped outside [[Cairhien]]. She is irritated with the appearance of the [[Shaido]] Wise Ones.
She does not participate in beating [[Egwene al'Vere]] over her lie.
She participated in the [[Battle of Dumai's Wells]].
It can be assumed that during the [[Last Battle]] she fights in [[Thakan'dar]] Valley along the other Wise Ones.






https://wot.fandom.com/wiki/Cosain