---
tags: [Women, GrayAjah, AmyrlinSeats, AesSedai, Deceased, Historicalpeople, HighRankingAesSedai, Channelers, Characternotmentionedinbooks]
---


**Dalaine Ndaye** was an [[Aes Sedai]] of the [[Gray Ajah]] who was raised to the [[Amyrlin Seat]] in the year 36 NE.
She was the first Amyrlin not of the [[Green Ajah|Green]]-[[Blue Ajah|Blue]]-[[White Ajah|White]] axis since [[Bonwhin Meraighdin]].

## History
Dalaine held the position for twenty-eight years until her death in 64 NE. She was [[Rabayn Marushta]]'s successor and [[Edarna Noregovna]]'s predecessor.
She was a weak Amyrlin.

## Notes






https://wot.fandom.com/wiki/Dalaine_Ndaye