---
tags: [AielWaste]
---



**Imre Stand** is a location in the [[Aiel Waste]]. It is a small watering hole in the lands held by the [[Taardad]] [[Aiel]]. Imre Stand is about a day's travel from [[Rhuidean]] and [[Chaendaer]] and twelve days travel to [[Cold Rocks Hold]].

## Activities
After leaving Chaendaer, [[Rhuarc]] intends to stop at Imre Stand for the night. Upon arriving there, the group finds that there had been a slaughter. While camping at the Stand, the group of Aiel, along with [[Rand al'Thor]], [[Matrim Cauthon]], [[Egwene al'Vere]], [[Moiraine Damodred]], and [[Lan Mandragoran]] are attacked by [[Trolloc|Trollocs]] and [[Myrddraal]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Imre_Stand