---
tags: [Disambiguation, Chapterdisambiguations]
---
**Sword** can refer to the following:

## Weapons
*Ashandarei* - pole-arm weapons with a short blade at the end, whose name in the Old Tongue means "sword spear."
[[Practice sword]] - a bundle of wood lathes used for training.
[[Sword-breaker]] - a weapon ment to catch an opponent's sword and turn it away.
[[Sword of Kirukan]] - an ancient blade of [[Kandor]].
[[Tamlin al'Thor's sword]] - a [[Power-wrought blade]] with herons on the hilt and blade.
## Book and chapter titles
*The Tinker's Sword* - the forty-fifth chapter of *The Shadow Rising*.
*A Crown of Swords* - the forty-first chapter of *A Crown of Swords.*
*A Crown of Swords* - the seventh book in the *Wheel of Time*.
## Titles
[[Bearer of the Sword of the Thousand Lakes]] - a title claimed by [[Al'Lan Mandragoran|al'Lan Mandragoran]].
[[First Prince of the Sword]] - the title given to the eldest brother of the queen of [[Andor]].
[[Sword of the Blightborder]] - a title of the [[Saldaea|Saldaean]] monarch.
[[Swordbearer]] - a title given to the commander of the armies of [[Kandor]], often the husband of the [[Queen]], but not necessarily so.
[[Blademaster]] - a title promising elite skill with a sword.
## Others
[[Arad Doman]] - which features a sword on its sigil and banner.
*Callandor* - a male *sa'angreal* in the form of a crystal sword.
[[Crown of Swords]] - the [[Crown|crown]] of [[Illian]].
[[Maidens of the Sword]] - a [[Westlands]] offshoot of the *Far Dareis Mai*, the Maidens of the Spear.
*manshima* - which means "sword" in the Old Tongue.
[[Sword forms]] - techniques for fighting with a blade.
[[Sheathing the Sword]] - a concept related to sword forms.
## See also
[[Blade]]
[[Dagger]]
[[Knife]]
[[Spear]]


https://wot.fandom.com/wiki/Sword