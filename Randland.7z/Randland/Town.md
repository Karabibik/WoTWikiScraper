---
tags: [Borderlands, Towns, TheShadow]
---
The **Town** is an urban centre in the [[Great Blight]], located not far from the valley of [[Thakan'dar]] at the foot of [[Shayol Ghul]]. It is a sprawling, ramshackle settlement that has existed for over two thousand years and was constructed by forced labor.
The Town is inhabited mainly by [[Darkfriend|Darkfriends]] and the numerous people enslaved by them. From the description it seems a very dangerous place where the laws of force, fear, and crime are rule. At the top of the hierarchy, it seems that there are the people able to impose their will through force and intrigue.
Nevertheless the hierarchy and the rules of the Darkfriends are applied and it appears also to follow some of the same rules as Shayol Ghul itself; for example, [[Channeling|channeling]] can be restricted to those with the [[Great Lord]]'s favor.
[[Isam]] was raised in the Town from a very young age, and still uses it as a "base camp" when he is in the waking world. The Town also contains a great percentage of *Samma N'Sei* and their relatives.
Because the [[Turning]] process greatly altered the face expressions of its victims, it can be easily guessed that also all the [[Aes Sedai]] that have been Turned along the millennia have then been kept hidden in places as the Town.
The [[Forsaken]] are known to visit the Town from time to time as needed.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Town