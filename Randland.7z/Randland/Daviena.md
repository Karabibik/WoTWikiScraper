---
tags: [Women, Aiel_people, WiseOnes, Unknownclan, LivingasofTPOD, Channelers]
---


**Daviena** is an [[Aiel]] [[Wise One]]. Her clan and sept are unknown.

## Contents

1 Appearance
2 Strength and Abilities
3 Activities
4 Notes


## Appearance
She is green-eyed with yellow-red hair.

## Strength and Abilities
Daviena is not particularly strong in *saidar*. In TWoTC her strength level is described as 30(18), which is a middle ranking level among [[Aes Sedai]].
This strength is not enough to open alone a gateway for [[Travel|Traveling]].

## Activities
She is one of the Wise Ones who are supervising the [[Aes Sedai]] held prisoner by the Aiel in [[Cairhien]]. She can channel and she links with [[Losaine]] to maintain a [[Shield|shield]] on [[Turanna]].
It can be assumed that during the [[Last Battle]] she fights in [[Thakan'dar]] Valley along the other Wise Ones.

## Notes






https://wot.fandom.com/wiki/Daviena