---
tags: [Men, Shienar_people, Lords, Deceased, Nobility, Soldiers]
---



*"I am Kayen Yokata, Lord of Fal Eisen, and may Peace abandon me and the Blight consume my soul if harm befalls you or anyone with you in our camp."*
   — Yokata to Elayne when they arrive 
**Kayen Yokata** is the Lord of [[Fal Eisen]], [[Shienar]].

## Contents

1 Appearance
2 Activities
3 Notes
4 In the television series


## Appearance
He has a sharp face and a harsh voice.

## Activities
He is among the [[Borderlands]] army that rides to [[Braem Wood]] in [[Andor]]. He directed [[Elayne Trakand]], [[Aviendha]] and [[Birgitte Silverbow|Birgitte]] to the place in camp when she is riding to meet with the Borderland Rulers.
During the [[Last Battle]] Badhere talks to [[Lan]] about how Yokata had lead his two cavalry squadrons, which were blindsided by [[Trolloc|Trollocs]]. The squad was killed to the last man except the [[Asha'man]]. 

## Notes

## In the television series
In the television series,  





https://wot.fandom.com/wiki/Kayen_Yokata