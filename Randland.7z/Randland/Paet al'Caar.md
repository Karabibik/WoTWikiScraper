---
tags: [Men, Andor_people, TwoRivers_people, LivingasofTSR]
---






**Paet al'Caar** is a [[Two Rivers]] resident. His son is [[Wil al'Caar]].

## Appearance
He has a lantern jaw.

## Activities
After the [[Trolloc|Trollocs]] first attack [[Emond's Field]], he is part of the crowd that confronts [[Moiraine Damodred]] demanding she leave at once, even though she [[Heal|Healed]] his son's leg after the attack. He is the first to apologize to her.
He helps defend [[Emond's Field]] against the invading Trolloc army.

## Notes






https://wot.fandom.com/wiki/Paet_al%27Caar