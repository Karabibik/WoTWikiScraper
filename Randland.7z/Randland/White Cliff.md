---
tags: [Shaido, WhiteCliff, Aielsepts]
---



The **White Cliff** is a [[Sept|sept]] of the [[Shaido]] [[Aiel]].

## Activities
When [[Perrin Aybara]] is planning his siege on [[Malden]] he hears of two large groups of Aiel on their way to the city. Those groups are the White Cliff and the [[Morai]] septs. [[Gueye Arabah]] later reports that the two septs will arrive at Malden at noon. After the [[Battle of Malden]], the two septs are still a few hours from the city.

## Notes






https://wot.fandom.com/wiki/White_Cliff