---
tags: [Women, Andor_people, TwoRivers_people, LivingasofLOC, ]
---


**Cilia Cole** is a resident of the [[Two Rivers]]. 

## Appearance
She is pleasingly plump, pink-cheeked and big-eyed.

## Activities
She was the first girl that Perrin kissed.
She insisted on being tested by [[Verin Mathwin]] and [[Alanna Mosvani]] and could [[Channel]], but was too old to become a [[Novice|novice]]. However, she did become a novice when the [[Novice book]] was opened to all.

## Notes






https://wot.fandom.com/wiki/Cilia_Cole