---
tags: [Men, Deceased, Generals, Historicalpeople, Charactersnamedafterfans]
---


Villiam Bloodletter was an ancient leader who fought a battle against the [[Banath people]].

## History
[[Thom Merrilin]] knows a couple of fine songs about the Banath people and one particular one, [[The Song of a Hundred Days]] is about the first and last battle Villiam Bloodletter fought with them on the location which is called [[Almoth Plain]] in the [[Third Age]]. Thom calls his maneuver brilliant and expresses his surprise, assuming that Mat has heard the song, because the battle happened so long ago, even history books don't remember to it. Having that mentioned [[Perrin Aybara]] notices that Mat smells nervous listening to that. Whether [[Matrim Cauthon]] has any memory about Villiam Bloodletter or the Banath people is left unclear. 

## Trivia
Villiam Bloodletter is named for William Klock, a fan of *The Wheel of Time*.
## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Villiam_Bloodletter