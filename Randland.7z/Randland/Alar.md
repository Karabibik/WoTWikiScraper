---
tags: [Ogier, Women, LivingasofLOC, ]
---




**Alar** is an [[Ogier]] [[Elder]] of [[Stedding Tsofu]]. She is the Eldest of the Elders. She is very old. She is the grandmother of [[Erith]] and mother of [[Iva]].

## Activities
She lets [[Rand al'Thor]] and his group use the [[Waygate]] outside *Stedding* Tsofu, although very reluctantly.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Alar