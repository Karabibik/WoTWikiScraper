---
tags: [Men, Altara_people, Kings, Deceased, Historicalpeople, PeopleoftheFreeYears]
---


**Maddin Todande** was the first king of [[Altara]].

## History
In c. [[FY 1112]], Lord Maddin Todande founded the nation of Altara. He claimed descent from the last queen of [[Shiota]], the nation that had ruled in the same location prior to the formation of [[Artur Hawkwing]]'s [[Artur Hawkwing's Empire|Empire]], and this claim is considered somewhat credible. Numerous attempts to reestablish Shiota had been undertaken during the end of the [[War of the Hundred Years]], with one lasting for fifty years under three rulers. Maddin saw that the old nations were finished and made a claim to a new nation; his success was aided by the war ending only five years later.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Maddin_Todande