---
tags: [Cities_AgeofLegends, Historicalsettlements]
---
**Paaran Disen** was the greatest city in the [[Age of Legends]], considered to be the "crown jewel" of all the cities, and the location of the [[Hall of Servants]]. It was also the capital city and seat of government. [[Lews Therin]] defeated [[Ishamael]] at the Gates of Paaran Disen. Like its slightly smaller companion city, M'Jinn, Paaran Disen was technologically advanced, with skyscrapers glittering like precious jewels in the sky. [[Nym]] and [[Ogier]] were known to have sung trees into being throughout the city. The most striking building in Paaran Disen is said to have been the Hall of Servants, the home for the governing Aes Sedai, which comprised both male and female channelers in that Age.
This beautiful city was presumably destroyed in the [[Breaking of the World]], leaving little to nothing of its one-time grandeur.
It is explained through the Seventh vision of [[Rand al'Thor]] in the Glass ter'angreal of Rhuidean, how [[Jonai]], a Da'shain Aiel was given orders to lead the [[Aiel]] to safety by [[Solinda]] Sedai, in the [[Hall of Servants]]. She says *"I want you far from Paaren Disen by tomorrow." *So Aiel start their wandering from Paaran Disen.

### Spelling differences
TEOTW prologue: spelled Paaran Disen, once. 
TSR: spelled  Paaran Disen once, then Paaren Disen (twice)
TFOH: spelled Paaran Disen, once.

## Etymology
The name Paaren Disen is believed to have come from the word "paradise."
Paaren is a German infinitive meaning "to mate" or "to pair," possibly a reference to Paaren Disen's conjoined sister city M'Jinn. The Disen were a group of goddesses of fate and fertility in old-Scandinavian mythology.

## Notes






https://wot.fandom.com/wiki/Paaran_Disen