---
tags: [, Talents]
---



**Earth Singing** is a [[Talent]] of the [[One Power]]. It involved controlling movements of the earth. Examples of this include preventing or causing earthquakes or avalanches. People with this Talent have a far greater control and ability with flows of [[Five Powers|Earth]], needing to put less strength in the weaves.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Earth_Singing