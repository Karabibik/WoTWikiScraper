---
tags: [Men, Aiel_people, Deceased, Historicalpeople, Clanchiefs]
---


**Mandein** was an [[Aiel]] sept chief who lived during the construction of [[Rhuidean]]. His story is learned from Rand's [[Visions of Rhuidean|visions]] in the ter'angreal of Rhuidean.

## Ancestry of Rand al'Thor
[[Charn]] ↠ unknown ↠ unknown ↠ [[Coumin]] ↠ [[Jonai]] ↠ [[Adan]] ↠ [[Marind]] ↠ [[Lewin]] ↠ [[Jeordam]] ↠ unknown ↠ [[Rhodric]] ↠ unknown ↠ [[Comran]] ↠ unknown ↠  ↠ ... ↠ [[Janduin (father)|Janduin]] ↠ [[Rand al'Thor]]

## History
Mandein was married to [[Sealdre]] and was the grandchild of [[Comran]], who was the grandchild of [[Rhodric]]. He lived in the early days of the Aiel’s settlement of the [[Three Fold Land]].
He was the first to go to [[Rhuidean]]. At the time he was forty years of age, considered young for a sept chief at the time. Mandein was an ancestor of [[Rand]].

## Notes






https://wot.fandom.com/wiki/Mandein