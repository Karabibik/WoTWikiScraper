---
tags: [Women, UnknownAjah, AesSedai, LivingasofLOC, RebelAesSedai, Channelers]
---


**Carenna** is an [[Aes Sedai]] of an unknown [[Ajah]]. She allied herself with the [[Rebel Aes Sedai|rebels]] in [[Salidar]]. Therefore, she is not [[Red Ajah]].

## Activities
She went to the [[White Tower]] at age seventeen; spent thirteen years as a [[Novice|novice]] and eleven as [[Accepted]]; and was raised Aes Sedai at forty one. It can be said that twenty four years of training mean that Carenna is not particularly strong, in fact usually the period in training reflects the strength of an Aes Sedai (if other factors are not involved, such as stubbornness, periods of rebellion, immaturity, [[Block|blocks]]) and twenty four years is the period of training of sisters at a low level in the hierarchy.
When [[Nynaeve]] passes off a trick for [[Eavesdropping|eavesdropping]] using the [[One Power]] learned from [[Moghedien]] as her own discovery, Carenna picks it up with suspicious quickness. Nynaeave thinks that she, as an [[Accepted]], can hardly accuse Carenna of having used such a trick before her 'discovery'.
Carenna says that she thinks the [[Weave|weave]] can be used to communicate with other sisters over long distances (two or more miles away). This adaptation of the eavesdropping weave has not yet been seen, if it was successful. Though, the Wheel of Time Companion says that with inverted weaves, this communication would have been very secure.






https://wot.fandom.com/wiki/Carenna