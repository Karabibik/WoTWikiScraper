---
tags: [HerbsandMedicines]
---
**Rannel** is an [[Herbs|herb]] that can be found in the [[Two Rivers]] region. A mixture of rannel and [[Sheepstongue root|sheepstongue root]] will perk a person up somewhat, but the significant property is its horrible and lasting taste. A village [[Wisdom]] such as [[Nynaeve]] may administer the concoction to someone who is claiming they are sick, moping, behaving "like a goose" and generally acting the fool.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Rannel