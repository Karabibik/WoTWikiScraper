---
tags: [Terangreal, ItemsofPower, EbouDariStash]
---




The **Bowl of the Winds** is a *ter'angreal* recovered from the [[Kin's Storeroom]] in [[Ebou Dar]].
It is a powerful bowl-shaped *ter'angreal* which allows its users to control the weather. It draws both *saidin* and *saidar*, no matter which is being channeled at it.

## Contents

1 History
2 Use
3 Discovery
4 Bargain

4.1 The Aes Sedai received:
4.2 The Atha'an Miere received:


5 Use to fix the weather

5.1 The full circle

5.1.1 Atha'an Miere
5.1.2 Aes Sedai
5.1.3 Kin
5.1.4 Aiel




6 Effects
7 Last Battle
8 Trivia
9 Notes


## History
During the [[Age of Legends]], the weather was carefully regulated by [[Aes Sedai (Age of Legends)|Aes Sedai]] using various weather *ter'angreal*. None of the *ter'angreal* were strong enough on their own to affect the weather of the entire planet, yet through the use of several, the Aes Sedai of the Age of Legends were able to keep close control over the weather.
One of these *ter'angreal* was held by the ancestors of the [[Atha'an Miere]]. They used the bowl to survive the seas during the [[Breaking of the World]]. It was somehow lost 2000 years ago. It's whereabouts since becoming lost are unknown, except that it turned up in a storeroom of the Kin in [[Ebou Dar]] where it had lain undiscovered for an undetermined length of time. The bowl became a legend among the Atha'an Miere and was thought lost or destroyed. During this time the Atha'an Miere learned to control the weather to a degree that according to [[Ishamael]] should have required a weather *ter'angreal*.

## Use
The bowl is activated by channeling a complex weave of all [[Five Powers|five powers]] to form a four-pointed star, which turns the bowl blue as a summer sky with clouds floating through it. Then the number of points on the star is increased to five, six, seven, eight, and nine. At each stage the bowl changes colors and reflects a different part of the sky or the sea. After the nine-point star is channeled the bowl begins to draw *saidar* and *saidin* on its own in far greater quantities than what was originally channeled into it.
The bowl then shoots a column of power into the sky, a complex mix of *saidar* and *saidin*. A new weave is then laid on the bowl to alter the column of power. Eventually the column branches at the top, fanning spiderwebs of power out in all directions. When finished the column evaporates and the bowl turns clear.
Controlling the weather with the bowl is like using the rudder of a ship. The weather is not changed instantly, rather the course of the weather is nudged in the desired direction to produce lasting effects.

## Discovery
The bowl was located again by [[Elayne Trakand]] and [[Nynaeve al'Meara]] in *Tel'aran'rhiod* using Need. They were sent by the [[Salidar]] [[Amyrlin]], [[Egwene al'Vere]], with [[Matrim Cauthon]] and several more experienced [[Aes Sedai]] to retrieve the bowl. However because the streets of Ebou Dar, particularly in the [[Rahad]], all look the same, they could not easily return to the same spot. Through the use of Mat's *ta'veren* qualities they were led to the Kin by [[Setalle Anan]], roughly the same time Mat discovered the bowl's location independently. They retrieved the bowl through a confrontation with the [[Black Ajah]], [[Darkfriend|Darkfriends]], and a *gholam* sent by [[Moghedien]] and [[Sammael]]. During this confrontation, about a quarter of the relics from the Kin's hoard were stolen, and [[Ispan Shefar]] was captured.

## Bargain
Because the Sea Folk had the knowledge to use the bowl that the Aes Sedai lacked, Elayne and Nynaeve [[Bargains of the Atha'an Miere|bargained]] with [[Renaile din Calon Blue Star]] of the Atha'an Miere for their help in using the bowl. This was a spectacularly bad bargain for the Aes Sedai, and would have been even worse if Mat had not bullied the Atha'an Miere into agreeing to the final details, including the location of the Kin's [[Farm|farm]].

### The Aes Sedai received:
Sea Folk knowledge to use the bowl and control the circle.
[[Windfinder|Windfinders]] of strength to be part of the circle.
Use of the most powerful Windfinders instead of the Windfinders with the highest rank.
### The Atha'an Miere received:
Windfinders could learn anything that Aes Sedai could teach, including [[Traveling]] and forming a [[Link|link]].
The bowl itself, after the weather was fixed.
Twenty sisters going to the Atha'an Miere subject to their laws, required to teach anything the Windfinders wanted to learn and unable to leave until others came to replace them.
Windfinders allowed to enter the [[White Tower]] as guests, allowed to learn whatever they wished and leave whenever they wished.
## Use to fix the weather
After fleeing Ebou Dar to the Kin's farm, [[Aviendha]] unwove the [[Gateway|gateway]] after seeing the *gholam* watching her so that no one could follow. They chose the top of a hill as the best place to form the [[Link|circle]]. The circle was led by [[Caire din Gelyn Running Wave]] who knew more of the Bowl of Winds than anyone else. She led the circle like the captain of a ship, expecting full obedience.
The circle involved women who could channel from all major societies in the [[Westlands]], and was probably the most powerful circle since the [[Breaking of the World]].

### The full circle

[[Caire din Gelyn Running Wave]] — In command (level of strength 17-5)
[[Tebreille din Gelyn South Wind]] (level of strength 17-5)
[[Naime]] (level of strength 16-4 or 14-2, depending on sources)
[[Rysael]] (level of strength 16-4 or 14-2, depending on sources)
[[Rainyn]] (level of strength 13-1)
[[Metarra din Junalle]] (potential level of strength 8+5, probably not reached)
[[Talaan din Gelyn]] (potential level of strength 2+11, actual around 4+9) — Using the amber turtle *angreal*

[[Elayne Trakand]] (potential level of strength 8+5, not reached yet)
[[Nynaeve al'Meara]] (potential level of strength 3+10, actual around 4+9) — Using the gold bracelet and rings *angreal*

[[Kirstian Chalwin]] (level of strength 14-2)
[[Garenia Rosoinde]] (level of strength 13-1)
[[Reanne Corly]] (level of strength 14-2)

[[Aviendha]] (potential level of strength 8+5, not reached yet, probably now she is around level 11+2) — Using the ivory carving of a woman covered by her hair *angreal*
## Effects
The effects of the Bowl of the Winds took effect within days, the prolonged heat of [[The Fires of Heaven]] through to [[A Crown of Swords]] being quickly dispelled and bringing about a delayed winter at an accelerated pace. As part of [[The Bargain]] between [[Elayne Trakand]] and [[Nynaeve al'Meara]], acting on behalf of the [[Rebel Aes Sedai]], and the [[Atha'an Miere]], the Bowl of the Winds entered the possession of the [[Windfinder|Windfinders]] in return for their expertise in manipulating the weather.
The aftereffects of using the *ter'angreal* caused both *saidin* and *saidar* to exhibit unusual behaviour that manifested in weaves of both halves becoming distorted and jumpy. In Rand's campaign against the [[Seanchan]] west of Illian, he and various [[Asha'man]], including [[Damer Flinn]], complain of a "strangeness" in *saidin*. Rand in particular notes that the [[Taint]] seemed more overwhelming than usual, although this may not be related. The effect was most noticeable near Ebou Dar where the Bowl of Winds was used. [[Furyk Karede]] notes how it affected the *damane*, calling it a "sickness" and lamenting that the *damane* were not able to channel in Ebou Dar, not even to create the sky lights that are normal in celebration of a victory. [[The Wheel of Time Companion]] confirms that these side-effects radiated outwards from Ebou Dar as far as the Altara-Illian border.
The cause of these aftereffects was an overcharging and overextension of the Bowl of the Winds beyond what it was designed for. Originally, the Bowl was only applied over a much more local area, rather than the whole of the Westlands, perhaps the whole world. This ended up causing an instability in True Source that would not have occured when it was being used properly. It was the advanced ability of the Windfinders that enabled the Bowl to be used over such a large area. Note that it is not the large amount of Power that is the cause of the instability, as there were no corresponding strange aftereffects that resulted from the [[Cleansing of saidin]], but rather a result of the Bowl of the Winds itself, which draws upon both halves of the source directly to "generate" weaves that affect the weather. The amount of saidar used by the Bowl was much more than the considerable amount held by the circle itself, whose entire strength was bent towards controlling and directing the weaves broadcasted by the *ter'angreal*. The Bowl cam only be triggered by weaves of *saidar*.
It is stated by [[Moridin]] that weather *ter'angreal*  in the Age of Legends did not need to be channeled into directly. He also states that the ability to work the weather with the Power was something discovered by women of the [[Third Age]]. It therefore stands to reason that the Bowl is an artifact of the Breaking or afterwards, something corroborated by the fact that could only be actvated using female half of the One Power and could draw saidin without the need of a male channeler. A male channeler may have been needed to create the *ter'angreal* in the first place.
The considerable quantity of the One Power wielded by the controlling circle immediately alerted the [[Seanchan]], who dispatched *Sul'dam* and their *damane* by [[Raken|raken]] to [[The Farm]] in order to collar any women who were channeling there. The Seanchan sent were all destroyed, however, when Elayne Trakand failed to unweave her gateway properly, causing the weave to blow up on of both sides of the gateway and releasing a huge amount of energy. The Farm itself was destroyed and this began rumour among the Seanchan of an "Aes Sedai weapon" that was the cause of their damane's inability to channel.

## Last Battle
The Bowl of the Winds is frequently used during the [[Last Battle]]. The Sea Folk Windfinders use it to fight the sudden and constant changes of the weather, namely the darkening of the sky to favor the [[Shadowspawn]].

## Trivia
At [[JordanCon]] 8, [[Harriet McDougal]] was given a large glass 'Bowl of the Winds' as a gift by members of the [[Waygate Foundation]].

## Notes






https://wot.fandom.com/wiki/Bowl_of_the_Winds