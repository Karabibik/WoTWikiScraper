---
tags: [Wotwikifeaturedarticles, AesSedai, Organizations]
---


*"An Aes Sedai never lies, but the truth she speaks may not be the truth you think you hear."*
   —[[Tam al'Thor]] 

The **Aes Sedai** ([[Old Tongue]]: *Servant of All*) are women who can channel the [[One Power]], and have been trained in the [[White Tower]] of [[Tar Valon]]. They have passed the tests for earning both the ring and the shawl and are bound by the [[Three Oaths]]. They are the only organization of female channelers in the [[Westlands]] (and until recently, they believed themselves to be the only legitimate channeling organization in the known world), giving them a vast amount of power and influence over the nations of the world, providing advisors to kings and queens.
Each Aes Sedai belongs to one of the seven [[Ajah|Ajahs]], with the exception of their leader, the [[Amyrlin Seat]], who is "of all Ajahs and none." 

## Contents

1 History

1.1 Age of Legends
1.2 The Collapse and War of Power
1.3 The Breaking


2 White Tower

2.1 Establishment
2.2 Hierarchy

2.2.1 The Amyrlin Seat
2.2.2 The Keeper of the Chronicles
2.2.3 The Hall of the Tower
2.2.4 Ajah Heads
2.2.5 Other Aes Sedai
2.2.6 Strength levels




3 Becoming an Aes Sedai

3.1 Novices
3.2 Accepted


4 Activities

4.1 White Tower Schism
4.2 Tower Reunification


5 Aes Sedai numbers and distribution

5.1 After the Schism
5.2 After reunification


6 Aes Sedai limitations
7 Other female groups of channelers

7.1 Seanchan Damane and Sul'dam
7.2 Aiel Wise Ones
7.3 Sea Folk Windfinders
7.4 Sharan Female Ayyad
7.5 Kin's Women


8 Parallels
9 See also
10 External links
11 Notes


## History

### Age of Legends

In the [[Old Tongue]], **Aes Sedai** (pronounced: /ˈaɪz sɛˈdaɪ/) means "servants of all," and the Aes Sedai of the [[Age of Legends]] lived up to this definition. They aided mankind as scientists, healers, and philosophers. Women used *saidar* and men *saidin*, although it is believed that channelers in the Age of Legends were much stronger, or at least more knowledgeable, in the Power than their modern equivalents; it is believed that they could fly, and things that would seem miraculous today were supposedly commonplace to them. Some of their lost [[Talent|Talents]], such as [[Traveling]] and [[Dreaming]], have only just been rediscovered. One thing is clear, however; the greatest works were wrought by male and female channelers working together. Additionally, due to the social structure of the Age of Legends being based on how well one served society, the Aes Sedai as an organization were held in extremely high regard and were very well respected due to the fact that, with the advantage of being able to channel, the Aes Sedai contributed extraordinarily to the betterment of humankind. 

### The Collapse and War of Power

It was an Aes Sedai research team at the [[Collam Daan]] that ripped open the [[Dark One]]'s prison.  The researchers, headed by [[Mierin Eronaile]], thought they had found a power that both men and women could wield. They were not entirely mistaken (see the [[True Power]]), but it allowed the Dark One to manipulate the darkest desires of those that lived in the Age of Legends. What followed was a general collapse of civilization over the course of 100-110 years, concluding in the [[War of Power]]. It is said that, during this time, almost half of all Aes Sedai went over to the Shadow. 
In the end, the [[Dragon]], with the help of the [[Hundred Companions]], sealed the Dark One and the [[Forsaken]] in his prison at [[Shayol Ghul]], and the Dark One's final counterattack [[Taint|tainted]] *saidin* itself, eventually driving all male channelers mad.  

### The Breaking

With the female Aes Sedai unable to control them, the men rampaged across the known world, boiling oceans, raising mountains where there were none, killing countless innocents. This was the [[Breaking of the World]]. While some of the men managed to find refuge in [[Ogier]] *stedding* (where they could not touch the Power, and therefore could harm no one and were protected from the effects of the taint), after a time they left the *stedding* hoping that the taint on *saidin* had disappeared. It had not, and they went insane, prolonging the breaking of the world according to some. Others hold to the view that this was not as disastrous as if all the men had gone insane all at once.

## White Tower

Current Aes Sedai differ greatly from those from before the Breaking, most notably in their organization and their level of knowledge. Present day Aes Sedai are organized into what is known as the White Tower. Only those women accepted by the White Tower can be called Aes Sedai, and all other channelers are known as [[Wilder|wilders]]. Additionally, their overall philosophy has changed drastically, and not for the better. Modern Aes Sedai, by and large, are trained not only in the Power, but are taught how to manipulate those around them. As observed by Nynaeve and numerous others, most Aes Sedai tend to place the White Tower's status, authority, and well-being above all other considerations. As such, they are seen as being very self-interested and self-serving. Many Aes Sedai excuse their behavior with the justification that whatever is best for the Tower is best for the world, but needless to say, this outlook is not shared by others. Additionally, the implementation of the Three Oaths, which make Aes Sedai incapable of telling an outright lie, have backfired with regard to their effectiveness. This is due to the fact that Aes Sedai simply use metaphorical doublespeak to circumvent the Oaths, and people are well aware of it. 
Most people in the Third Age trust neither the intentions nor the words of an Aes Sedai, and many others outright hate and fear them. Due to their tendency to meddle in the affairs of others, and their poor reputation, the Aes Sedai have many enemies and few allies. They are still very respected in the [[Borderlands]] and a Sister is usually chosen as advisor by the rulers of [[Andor]] and [[Cairhien]], due their historical links to the Tower, but in most places especially in the south they are unwelcome but tolerated, and in other places, they are even openly deterred or outright banned. For instance, they cannot openly travel in the country of [[Tear]], and the organization known as the [[Children of the Light]] (the true rulers of the country [[Amadicia]]) wishes to kill them all. 
Worst of all, the powerful [[Seanchan]] Empire wishes to enslave all women who can channel, and the White Tower is easily their most prominent target (though this is due to the cultural views of the Seanchan rather than being a consequence of the White Tower's policies).

### Establishment
The White Tower was established in [[98 AB]], over one hundred years before the [[White Tower|building of the same name]] was completed in [[202 AB]]. [[Elisane Tishar]] was raised at this time as the first [[Amyrlin Seat]], the supreme head of the Tower. The city of [[Tar Valon]] was likewise established at this time and is presently ruled by a governing body selected by the [[Hall of the Tower]]. It is said that the White Tower's reign in Tar Valon is the longest of any kingdom save for the [[Ogier]].
After consolidating their power, they began punishing those "pretending" to be Aes Sedai. It is suggested that many of those punished in the beginning may actually have been Aes Sedai who did not submit to the authority of the Tower. Eventually, the current hierarchy and seven [[Ajah|Ajahs]] developed.
Though still "servants of all," the present day Aes Sedai keep their own agenda. They still provide aid to any who ask, but it is said that any gift from an Aes Sedai has a price, and often one you never see coming. The Amyrlin Seat, the woman chosen to govern the Aes Sedai, has become as powerful as any king, queen, or legislative body - and often more so.

### Hierarchy
Aes Sedai rank themselves according to a strict hierarchy based on the levels of powers in *saidar* and also the ruling positions established by elections (as the [[Amyrlin Seat]], the [[Ajah Heads]], the [[Sitters]] in the Hall) or directly chosen and appointed by this women to another ruling position (as the [[Keeper of the Chronicles]], the [[Mistress of Novices]], the Head of a delegation, etc.). Usually the women chosen in such ruling offices stand already in a high hierarchical position being among the strongest in the levels of power.  Despite the strict hierarchy based on strength in the One Power, a Sister's strength or standing compared to other Sisters is not usually openly discussed, and it is considered rude to do so.  Rather, Aes Sedai naturally expect weaker Sisters to submit to the authority of stronger Sisters which younger initiates learn on their own without explicit instruction.
This means that a Sister's social or economic status prior to joining the White Tower has little to no influence on her standing within the establishment. A quite strong Sister born a commoner can easily outrank a sister born into a great noble family and holders of certain positions of power rank at the top. Morgase Trakand who is recognized as being given the right to wear the Ring was more a formality as a link to the Andoran Royal Family and her position as Queen, but her ability to channel was so little that she was seen as being below even the newest of Novices in the Tower. 
This was later confirmed as true after the [[Stilling]] and [[Healing]] of [[Leane]] and [[Siuan]], that before they were among the strongest of current Aes Sedai, but after their Healing (with their level of power reduced by 2/3) were considered among the weakest and lowest in Aes Sedai social standing.



The Amyrlin Seat is the leader of the Aes Sedai, along with the Hall of the Tower. She, as the public leader of the White Tower, is considered more powerful than any monarch in the land. The Amyrlin Seat does not always act as ambassador to other nations, but has been known to do so.
[[Tower law]] does not explicitly state that  the Amyrlin Seat needs to be full Aes Sedai before being raised, as revealed when [[Egwene al'Vere]] is raised to the Amyrlin Seat. The law does refer to the raised Amyrlin as Aes Sedai, though. This loophole was used to raise Egwene even though she was still [[Accepted]], and her raising was used to grant her the status of Aes Sedai without having taken the test for the shawl.



The Amyrlin's second-in-command, the duties of the Keeper of the Chronicles include being secretary to the Amyrlin and overseeing the official business of the Tower ([[Leane Sharif]] maintained an eyes-and-ears network in [[Tar Valon]] to help her with that task). The Amyrlin chooses her upon being raised. Unlike the Amyrlin, the Keeper does not officially shed her Ajah affiliation; the Keeper wears a stole in the color of the Ajah she was raised from.
Traditionally, the Keeper comes from the same Ajah as the Amyrlin, but there have been exceptions, including two relatively recent Amyrlins, [[Sierin Vayu]] and [[Elaida a'Roihan]]. Sierin, a [[Gray Ajah|Gray]] "with a touch of Red", chose a [[Red Ajah|Red]] Keeper. Elaida, a Red, had little choice but to raise a [[White Ajah|White]], [[Alviarin Freidhen]], because of her help in deposing [[Siuan Sanche]].
[[Egwene al'Vere]], though without an Ajah, also picked a surprising Keeper in [[Silviana Brehon]], choosing a Red both because she respected her choices and in an attempt to heal the rift between the Red Ajah and the rest of the Tower.



The [[Hall of the Tower]] is the deliberative body of the White Tower. It comprises twenty-one [[Sitters]] , three from each Ajah. The Amyrlin Seat presides over meetings of the Hall. The Hall authorizes all official policy for Tar Valon and the Aes Sedai, although some actions originate with the Amyrlin Seat. This functions as a system of  for the White Tower. The Hall is also responsible for selecting a new Amyrlin when the office falls vacant, and can remove an Amyrlin or Keeper. In that function, they are similar to the  in the Vatican, which elects the new Pope.
Sitters are highly esteemed sisters who have been chosen by their Ajahs to represent their interests in the Hall of the Tower. Each Ajah has its own method for selecting new Sitters, but the [[Ajah Heads]] generally have a significant role. The Sitters also vote to raise a new Amyrlin Seat.



Each Ajah has its own hierarchy and internal positions of authority, and the women in charge of each Ajah are collectively known as Ajah heads, though the nature of the position differs from Ajah to Ajah. It is unusual for an Ajah head to also be a Sitter, but not unheard of. Sitters are answerable to their Ajah heads for their actions in the Hall, and for the most part all Aes Sedai must obey the authority of their Ajah heads in general, especially regarding Ajah matters. Though the names of Sitters are public knowledge, the identities of the Ajah Heads are a closely guarded secret of each Ajah and as such they have no extra authority outside their Ajahs.


Although Aes Sedai enjoy almost unrestricted power among the wider world, they have their own strict hierarchy that allows little room for deviation. The hierarchy is a custom as strong as law, and failure to defer to a higher ranking can lead to the offended sister setting the other a penance. The hierarchy is based on four factors:



Following the hierarchy based only on the strength, the Aes Sedai can be divided in three main groups. The first is that of the High Ranking Aes Sedai, the most influential sisters, roughly between the levels 13(1) and 23(11) [using the 72(60) scale)] and the very few sisters even above this levels (as [[Cadsuane]], [[Egwene]], [[Elayne]] and [[Nynaeve]]). The Middle Ranking Aes Sedai are between the levels 24(12) and 34(22). The Low Ranking Aes Sedai between the levels 35(23) and 45(33). 
Obviously [[Sitters]] on the level 13(1) as [[Romanda]] and [[Lelaine]], or level 14(2) as [[Yukiri]], [[Saerin]] and [[Pevara]] are more influential in the Hall than Sitters on lower levels [not considering some at level 23(11), as [[Duhara]], [[Escaralde]] and [[Takima]] (but the level of strength given for the last three is probably a mistake, because it seems too low)].
Scheme of Aes Sedai hierarchy and levels of strength:

**13(1)** This was the top level in the Aes Sedai hierarchy during the last 20 years. Sisters on this level (or more), are considered very strong (this is also the minimum level to use the [[Choedan Kal]] safely) (example: [[Elaida]], Romanda, Lelaine, and Siuan and [[Moiraine]] before their power was reduced. [[Cadsuane]] was far away from the Tower during this period and considered dead by most)
**14(2)** Sisters on this level are considered strong and very influential (example: [[Sheriam]], Yukiri, [[Galina]], [[Merean]], Saerin, Pevara, [[Liandrin]])
**15(3) <> 18(6)** Sisters between this levels are considered among the most influential (example: [[Myrelle]], [[Beonin]], [[Silviana]], [[Morvrin]], [[Verin]], [[Carlinya Sorevin|Carlinya]], [[Katerine]], [[Seaine]], [[Alviarin]])
**19(7)** This can be considered the minimum level to be elected as a Sitter with a minimum of authority and influence in the Hall; it can also be considered the minimum level to be elected to the [[Amyrlin Seat]]. But there are Sitters with a lesser strength as [[Suana]] at level 22(10) that can compensate their relative weakness with some exceptional [[Talent]] (Siuan and Egwene also mentioned that there have been Amyrlin Seats who could barely channel, but this has to be related to the circumstances because they are barely allowed to channel).
**20(8) <>  22(10)** between this two levels there is the minimum strength needed for female channelers to open alone a suitable gateway to [[Travel]] (the descriptions of the strength needed is quite contradictory, depending on books and situation). Sisters on this levels are still quite influential but they have to defer or even obey to the many in the levels above them (example: [[Merilille]], [[Ashmanaille]])
**23(11)** At this level [[Kinswomen]] are described unable to open a suitable gateway to travel. Some Sitters in "The Wheel of Time Companion" are described at this level (or even lower), but it seems very unlikely if they can't compensate their lack of strength with some remarkable talent as it is clearly stated for Suana (example of sisters at this level: [[Adeleas]], [[Serafelle]])
**24(12) <> 34(22)** average strength: Middle Ranking Aes Sedai (example: [[Careane]], [[Sareitha]], [[Edesina]], [[Elza]])
**35(23) <> 45(33)** Low Ranking Aes Sedai (example: [[Bennae Nalsad]], [[Elin Warrel]]; also [[Siuan]] and [[Leane]] after being [[Heal|healed]] from the [[Stilling|stilling]])
**45(33)** minimum level an [[Accepted]] needs to be tested for the shawl (the level of the weakest Aes Sedai, example: [[Daigian]])
**46(34)<> 49(37)** between this levels a novice is considered barely strong enough to be tested for [[Accepted]] (example [[Sarainya Vostovan]])
**49(37) <> 72(60)** all the [[Novices]] between this levels are considered too weak for a further training and when they are able to use safely their power, they are sent away from the White Tower; most of [[Kinswomen]] come from this group (example: [[Alise]], [[Asra]])
**72(60)** Minimum known level of strength (example: [[Morgase]] who obtained the serpent ring only for political reasons)
## Becoming an Aes Sedai
Though Aes Sedai do not openly recruit, all women found by Aes Sedai who were born with the [[Spark|spark]] and all other women of appropriate age who can channel and wish to learn how are entered in the novice book to begin training. 
The laziness of this policy in recruitment during the last century caused a dramatic drop in the total number of living Aes Sedai, in fact the White Tower was built to host 3000 sisters but when the Dragon manifested his return announcing the coming of the Last Battle there were only a little less than 1000 Aes Sedai. 
In reality the potential number of channellers that can be trained to become Aes Sedai is elevated, as it was clearly demonstrated by the Amyrlin [[Egwene]] who opened the book of recruitment to all the women that desired to be tested and just in her expedition from Salidar to the border between Murandy and Andor was able to recruit almost 1000 new novices, many of them with a very great potential as [[Sharina Melloy]] showed.
The [[Mistress of Novices]] is in charge of the training, care, and punishment of all trainees, and she has the last word regarding them. 


There are two levels of training: novice and Accepted.

### Novices


Novices attend classes taught by full sisters and by Accepted concerning the [[One Power]]. They are treated as children because they could easily harm themselves with the Power and lack the knowledge to protect themselves. They have hardly any time for themselves, because when they are not training they are usually doing chores.
Novices who have little potential in the Power or who are otherwise unsuitable to eventually become Aes Sedai are taught just enough to keep them from hurting themselves. For the others, when the Mistress of Novices determines that a candidate is ready, the novice is summoned to a ceremony to be raised to Accepted. She has the right to refuse the ceremony twice, but on the third time if she refuses she will be put out of the Tower. Once she starts she cannot stop, or she will be put out of the Tower.
The ceremony consists of the novice stepping unclothed through a [[Accepted Testing|special three-arched]] *ter'angreal* that forces her to face her fears to test her dedication to the White Tower.

### Accepted


Once Accepted, the women have more privileges and are not usually forced to do chores. They can also wear the [[Great Serpent]] ring of the Aes Sedai, but only on the ring finger of their left hand. They train harder and also teach courses to novices. They usually spend several years more as Accepted, and when they are deemed ready to become full Aes Sedai they are summoned for another testing ceremony.
The Accepted is brought to a chamber with a specialized *ter'angreal*. The Accepted steps in, seeks out a symbol on the ground, and weaves one hundred very complex weaves while retaining perfect composure, seeking the symbol after each one. Sisters use the *ter'angreal* to attempt to distract; some of the distractions can be rather personal.
If an Accepted passes the test, she spends one last night in the Accepted quarters in quiet contemplation. The next day, she is brought to another ceremony with the Amyrlin and representatives of all seven Ajahs present. The Accepted then swears the [[Three Oaths]] on the [[Oath Rod]]. Once she has sworn the oaths, the Accepted is now an Aes Sedai and asks the sisters of a particular Ajah if she may join. Once an Accepted is raised to Aes Sedai, she has generally all but chosen her Ajah already.
The period of training usually depends on the strength in [[Saidar|saidar]] of the single channeler, for instance high ranking , and so strong Aes Sedai as [[Elaida]], [[Moiraine]] or [[Siuan]] have spent only 3 years as Novices and 3 as Accepted in the training to learn the necessary weaves, medium ranking Aes Sedai usually take a dozen years (6+6), instead the most weak Aes Sedai as [[Elin Warrel]] have remained in training for more than twenty five years before they were able to gain the shawl.

## Activities
### [[White Tower Schism]]

While the Aes Sedai overcame great crises such as the [[Trolloc Wars]], the [[War of the Hundred Years]], the [[Aiel War]], and even a few corrupt Amyrlins, an event in 999 NE broke the Tower's unity. [[Elaida do Avriny a'Roihan]], a Sitter of the Red Ajah, overthrew the Amyrlin [[Siuan Sanche]], formerly of the Blue Ajah, and was elected to the Amyrlin Seat herself.
Those sisters who did not support Elaida fled to [[Salidar]] and [[Rebel Aes Sedai|reorganized]]. They elected an opposing Amyrlin, [[Egwene al'Vere]], and declared open war against Elaida. This group also, for the first time since the Breaking, [[Black Tower Alliance|allied]] itself with [[Asha'man|male channelers]].

### Tower Reunification
The two factions eventually reached a compromise and have since been [[Hall of the Tower under Egwene al'Vere|reunified under Egwene al'Vere]].

## Aes Sedai numbers and distribution
The [[White Tower]] was built to house around 3000 Aes Sedai, but at the time of the [[Aiel War]] there were only 1250 living sisters, and among them only 1/3 resided at Tar Valon (these numbers are described in the *prequel* [[New Spring]]).
Twenty years later, at the time of the [[White Tower Schism]], the number of sisters was even more reduced, to only around 1000 living Aes Sedai.  
Some Aes Sedai speculated that this reduction of numbers was a consequence of the systematic [[Gentling|gentling]] of male channelers, which reduce the genetic pool of channelers overall, including female channelers. But this reduction is more due to the Aes Sedai reluctance to actively search for new novices, instead waiting for candidates to come to the Tower on their own. When this practice was changed, the [[Rebel Aes Sedai|rebel sisters]] were able to find almost a thousand potential female channelers, of every age, in their journey from [[Salidar]] to the border of Andor alone. 
The Black Ajah also killed, either directly or indirectly, thirty to fifty senior Aes Sedai during the [[The Vileness|Vileness]], which also reduced the candidate pool for choosing a new Amyrlin Seat. 
The size of every [[Ajah]] at the moment of the schism can be approximated, because: 


So the [[Red Ajah]] was held little more than 195 sisters, the [[Green Ajah]] around 190, the [[Grey Ajah]] around 135-130, the [[Brown Ajah]] around 130-125, the [[Yellow Ajah]] around 125-120, the [[Blue Ajah]] around 120-115, and the [[White Ajah]] around 115-110.

### After the Schism
After the Schism 294 sisters remained in the White Tower under the leadership of [[Elaida]]. Among them there were almost all the Reds, 33 White sisters and around 1/3 of each of the remaining Ajah sisters (obviously not including the Blue Ajah). But in a very short time Elaida lost more than 75 sisters in the unfortunate expeditions that tried to capture the Dragon Reborn or to destroy the Black Tower; 39 sisters were sent to the first expedition and 50 to the second: some of them were killed, the majority captured and only a dozen were able to return and take a secret refuge in the village of [[Dorlan]], near Tar Valon.
The group of the [[Rebel Aes Sedai]] was able to collect around 330 sisters in [[Salidar]]; among them there were almost all the living Blue Ajah sisters, no Reds and around 1/3 from each of the other Ajah.
The remaining Aes Sedai, who choose to not take a position between the Rebels and the loyalist to Elaida were called [[Unaligned sisters]], and [[Elayne]] suspected that somehow the majority of them were coordinate by someone, in particular she suspected [[Cadsuane]] (for instance we know that Cadsuane left for a while an *a'dam*, the [[Sad bracelets|sad bracelets]] copies and *Callandor* to some retired Aes Sedai she trusted so they can study their functioning). They were among the remaining third of the total of the living sisters, but among this third probably there were also many of the older sisters which were in retirement in some remote place and so they were cut apart from the main events 

### After reunification
After the [[Battle of Tar Valon|Seanchan Raid]], the discovery and purge or escape of more than 210 [[Black Ajah]] Sisters, only 650-700 living Aes Sedai remained under the leadership of the [[Amyrlin]] [[Egwene]] in a White Tower reunited. 
Meanwhile 28 sisters (9 from the rebels, the others from the Tower) sworn fealty to the Dragon Reborn and 50 were bonded as [[Warder|Warders]] by [[Asha'man]]. Many among this last group were later [[Turned|turned]] to the Shadow in the Black Tower along half a dozen of Red sisters, sent there to bond Warders.
Prior to the [[Last Battle]] almost the totality of the [[Yellow Ajah]] took refuge in Mayene with all the Novices and Accepted to organize there a huge hospital for the wounded from the battlefronts.
The White Tower loss during the Last Battle was heavy, because more than 250 sisters were killed, but recently a new policy of recruitment was introduced by Egwene, granting admission to the Book of Novices to older women, and it has raised the total number of new novices to almost 1500.

## Aes Sedai limitations
During the last three millenniums Aes Sedai developed a very specific method of training to teach how to form weaves using *saidar*. Their first goal was to ensure no danger in the trainees, the second to teach the most effective kind of weaves in every matter; despite it this method showed some limitations if confronted to the methods followed by other groups of female channelers.
In weaving the threads Aes Sedai developed unnecessary  gestures, so particular and specific that you could trace who taught the weave originally based on minor quirks.  
On the contrary Aiel [[Wise One|Wise Ones]] do not use a lot of gestures, their weaves can seem rough and in some cases less effective, but this avoided some problems linked to gesturing. The first problem is that if you have the hands occupied or bonded you can't form a weave properly. The second problem is that a specific gesture, repeated many and many time to form the same weave, imprints itself in the mind of the channeller, so she can't easily learn a new manner to form it. For example, when new effective healing weaves were invented or rediscovered, many Aes Sedai imprinted by the traditional healing weaves were not able to learn easily the new ones.
Another limitation demonstrated by Aes Sedai is their behaviour in experimenting with the One Power, they are very conservative, they are inclined to use only the weaves that they knew well, discarding innovation and originality as dangerous.
The hierarchical system based only on the strength in the One Power (See also: One Power#Strength for more information about the qualities linked to the strength in *saidar*) is another kind of limitation among Aes Sedai, because also weak sisters can have a lot of quality in other matters that are not very well capitalized.

## Other female groups of channelers
### Seanchan Damane and Sul'dam
Before the arrival of [[Luthair Paendrag Mondwin]], the [[Seanchan (continent)|Seanchan]] continent was a place ruled by constantly shifting alliances of dictators, and the worst among them were the women who called themselves Aes Sedai. They bore little resemblance to the Aes Sedai of the [[White Tower]]; they used the [[One Power]] in battle, enslaved the people of the continent, and killed each other for power.
One of these Aes Sedai, [[Deain]], sought an alliance with Luthair, and gave him information on how to recreate a *ter'angreal* she had invented, the *a'dam*. She was to eventually become chained by the device herself after Luthair used the invention to create a fighting force of female channelers. Eventually, all Seanchan Aes Sedai were captured and turned into *damane*.

### Aiel Wise Ones
Unknown until recently, but long suspected by various Aes Sedai, some [[Aiel]] [[Wise One|Wise Ones]] are able to channel. The ability to channel is not required to become a Wise One, but all who can learn or have the spark must become one. This is one of the reasons the Wise Ones have kept away from the Aes Sedai for more than 3,000 years.
Some of the Wise Ones that are able to channel are also [[Dreamwalker|dreamwalkers]]. This Talent has not died out with them. It also reveals that not only channelers can become dreamwalkers, as [[Seana]] is unable to channel. [[Egwene al'Vere]] has been thinking that some Aes Sedai could be sent to train under the Wise Ones, not only to learn how to channel, but also to learn how to harden themselves and to control themselves better.

### Sea Folk Windfinders
The [[Atha'an Miere]] [[Windfinder|Windfinders]] are another group of women that can channel, although not all of them can. This was until recently also unknown to the White Tower. The Sea Folk usually send one of their weakest channelers to the Tower, to fool the Aes Sedai about the strength of their channelers. This is considered a great sacrifice by the Atha'an Miere, because it means they are separated from the ocean for the rest of their life if they are just strong enough to become Aes Sedai. The Windfinders are very strong in [[Air]] and [[Water]], but are weaker than most female channelers in [[Earth]] and [[Fire]], due to their way of life.
The truth is discovered by [[Elayne Trakand]] and [[Nynaeve al'Meara]] when they were traveling from [[Tear]] to [[Tanchico]]. They are amazed by how thick the weaves of the Windfinders are in comparison with their own. No Aes Sedai would ever dare to weave such thick strands. Elayne has had private tutelage from [[Jorin din Jubai White Wing|Jorin]] and a bargain between the Sea Folk and the White Tower states that the Aes Sedai will dispatch twenty of their members to teach the Windfinders about the One Power. This has been considered a bad deal, as no counter effort was negotiated.

### Sharan Female Ayyad
Not much is known about this foreign country in the east, but what is known is troubling. They are advisers to the monarch. It is, however, suspected that the [[Ayyad]] really hold control over the monarchs. They kill the ruling monarch every seven years and let his/her consort take the throne. To the people of [[Shara]], this is known as the Will of the Pattern and believed to happen naturally.
The name "Ayyad" refers to both the male and female channelers of Shara, although only the female Ayyad rule the country. They have tattoos on their face to make their identity known. They live in secluded villages where no non-Ayyad is allowed - anyone who enters is killed. The Ayyad are very rarely allowed to leave the villages. They also use the male Ayyad to breed so the channeling gene is kept active.

### Kin's Women
The [[Kin]] is a group of female [[Channel|channelers]] who help pull in runaways or those who were put out from the [[White Tower]]. None of these women were Aes Sedai, but having trained in the Tower they have some similar rules and are not exactly [[Wilder|wilders]]. Rank among the Kin is determined by age, not strength in the Power. The thirteen oldest members in [[Ebou Dar]] comprise the [[Knitting Circle]] and are the ruling body of the Kin. Some Kinswomen as [[Sumeko Karistovan]] far from the control of the Tower were able to develop new and very effective [[Healing]] Weaves which were similar to those of the Age of Legends.
Just before the Last Battle, the Amyrlin Egwene, the Wise Ones and the Windfinders made the bargain to exchange for a time some of their young trainees, so each group can learn the ways of each other.

## Parallels
The name Aes Sedai and their magical nature comes from Irish myth, specifically from the , a magical people of immense power, who commanded abilities that rivaled the gods. Jordan also used this source as part of his inspiration for the [[Aelfinn]] and [[Eelfinn]].
Additionally, in Norse mythology seidr was a form of woven magic, primarily used by women. These women, called seidr-kona, were given a special place in society. 
There is also a very strong similarity between them and the . Like the Aes Sedai, the all-female Bene Gesserit are a key social, religious, and political force in 's science fiction . The group is described as an exclusive sisterhood whose members train their bodies and minds through years of physical and  to obtain  powers and abilities that can seem magical to outsiders. Sometimes called "witches" due to their secretive nature and misunderstood powers, the Bene Gesserit, like the Aes Sedai, are loyal only to themselves. However, to attain their goals and avoid outside interference, they often screen themselves with the illusion of being loyal to other groups or individuals. As their skills and knowledge are as desirable as an alliance with the Sisterhood itself, they are able to charge a fee to school the females from Great Houses, and install some of their initiates as leaders, wives, and prominent figures to their advantage.

## See also
[[Ajahs]]
[[White Tower]]
[[Aes Sedai factions]]
## External links
  on  
## Notes






https://wot.fandom.com/wiki/Aes_Sedai