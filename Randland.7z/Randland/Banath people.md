---
tags: [, People, Historicalpeople]
---
The Banath people were a group of savages roaming on a location known as [[Almoth Plain]] in the [[Third Age]]. 

## Culture and Customs
They had various tribes and a tradition of painting their leader's skin red to make him stand out, making it a challenge for their enemies to test their skills against the leader.

## History
Their history lived on mostly in a couple of songs. One particular one [[The Song of a Hundred Days]] is about a battle between the Banath people and a military leader called [[Villiam Bloodletter]] who used decoys painted red for distraction while archers took out the red painted leaders of the Banath people. This happened so long ago, most history books don't even remember it.
[[Thom Merrilin]] mentions he knows the songs and when he describes the tradition of the Banath people, [[Matrim Cauthon]] immediately points out the possible exploitation of the exposed leaders. Thom assumes Mat knows the song about the battle, and [[Perrin Aybara]] notices that Mat smells nervous. Whether Mat has any memory about Villiam Bloodletter or the Banath people is left unclear. 

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Banath_people