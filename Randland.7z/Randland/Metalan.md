---
tags: [Men, Aiel_people, Unknownoccupation, Unknownclan, Unknownstatus, Foreseenpeople]
---


**Metalan** is one of the Aiel [[Aviendha]] sees in her visions of the future in the [[Glass columns]] *ter'angreal* in [[Rhuidean]]. 
He is [[Norlesh]]'s husband, their infant son is [[Garlvan]] and her daughter [[Meise]]. He tries to talk outlanders into buying rocks he has worked hard to obtain that have ore in them. The outlanders will not buy or trade for them because the Raven Empress forbids trade with the Aiel and will punish them. 
Metalan tells Norlesh he will trap food in the morning but she points out that he hasn't caught anything in a long time. He then lays down.






https://wot.fandom.com/wiki/Metalan