---
tags: [Women, Servants, LivingasofKOD, ]
---


**Aelmara** is a serving lady in the employ of [[Romanda Cassin]].

## History
Aelmara began working for Romanda during the [[Aes Sedai]]'s first stint as a [[Hall of the Tower|Sitter]]. Sometime after, Aelmara helps Romanda escape from [[Far Madding]] after a "slight misunderstanding."

## Activities
Aelmara comes with Romanda when she joins the [[Rebel Aes Sedai]] in [[Salidar]] after the [[White Tower Schism]]. She takes care of Romanda's part of the tent in the rebels camp, near [[Tar Valon]].






https://wot.fandom.com/wiki/Aelmara