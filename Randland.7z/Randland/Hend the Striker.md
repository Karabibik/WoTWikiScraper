---
tags: [Men, HeroesoftheHorn, BoundtotheWheel, Historicalpeople]
---


**Hend the Striker** is a Hero of the Horn.

## Contents

1 Appearance
2 History
3 Activities
4 Parallels
5 Notes


## Appearance
He is a large, dark-skinned man. He carries a hammer in one hand and a spike in the other.

## History
He rides a big bay horse and laughs a lot, even in battle.

## Activities
He is one of the Heroes of the Horn who are called back to fight in the [[Last Battle]]. He is also the one to explain to [[Mat Cauthon]] that he is no Hero of the Horn.

## Parallels
Based on the American folk hero of African descent  who drove railroad spikes with a hammer.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.


## Notes






https://wot.fandom.com/wiki/Hend_the_Striker