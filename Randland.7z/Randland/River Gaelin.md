---
tags: [Rivers, Cairhien]
---

The **River Gaelin** is a major river that courses through the land of [[Cairhien]]. It rises in the [[Spine of the World]], just north of the [[Jangai Pass]], and flows westwards along the feet of [[Kinslayer's Dagger]]. It flows into the [[Alguenya]] just north of the city of [[Cairhien (city)|Cairhien]].
It is presumed that the Gaelin may assist in the transportation of minerals from mines such as the [[Dragon's Dagger]] to the capital, but this is not confirmed.






https://wot.fandom.com/wiki/Gaelin