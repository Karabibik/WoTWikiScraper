---
tags: [Battles]
---


The **Battle of Talidar** was a major battle fought between the people of the [[Westlands]], led by the High King [[Artur Hawkwing]], and an invading army of [[Shadowspawn]]. It is the largest and most significant victory of the [[Light]] over the [[Shadow]] since the [[Battle of Maighande]] during the [[Trolloc Wars]].

## Background
The Battle of Maighande, circa [[1301 AB]], shattered the back of the Shadowspawn armies during the Trolloc Wars, and over the next fifty years the remnants of the [[Ten Nations]] destroyed any remaining straggling bands of Shadowspawn operating in the Westlands. The victory was so complete that the Shadowspawn did not come south again in significant numbers for nearly a thousand years. During the period known as the Free Years the military arts reached their apex and the then-[[Borderlands]] of [[Basharande]], [[Elsalam]] and [[Rhamdashar]] did an excellent job of preventing Shadowspawn from entering the Westlands.
Artur Hawkwing conquered all three of the Borderlands during the [[Consolidation]] ([[FY 943]] - [[FY 963|963]]) and ruled peacefully for a decade afterwards, until he came into conflict with the [[Aes Sedai]] and besieged [[Tar Valon]]. In [[FY 986]], perhaps believing that Hawkwing, now of advanced age, would not be able to move with his customary vigor, the Shadow launched a major invasion of the Westlands, striking south into the heart of the Empire.

## The campaign and the battle
While the Battle of Talidar is cited as a single engagement, it was actually an ongoing conflict beginning in late FY 986 and continuing through into the summer of [[FY 987]]. The Shadow invaded across the [[Blightborder]] in three locations, overrunning the frontier and moving south, looting and destroying as they went. The 74-year-old Hawkwing moved with his established speed and had the frontier garrisons fight a series of delaying tactics and engagements whilst he assembled a new army to the south. Seven major battles were fought against the Shadowspawn which had the effect of funneling them south and east, into what had once been the kingdom of [[Hamarea]]. Here Hawkwing met the Shadowspawn on the field of Talidar and in a massive battle lasting a substantial amount of time utterly crushed them. The Shadowspawn army was destroyed in such depth that activity along the Blight was diminished for the next half-century, which with the outbreak of the [[War of the Hundred Years]] proved fortuitous.

## The monument
After the battle Hawkwing erected a monument, a huge spire inscribed with the names of every soldier who had fallen defending humanity from the Shadow. His own name was not mentioned on it, although the sigil of the Empire surmounted it. After Hawkwing's death the great monument was torn down and destroyed by those seeking to remove all trace of Hawkwing's existence. The battlefield was later claimed by the kingdom of [[Hardan]], but after Hardan's fall it became empty wilderness. Today the battlefield lies roughly halfway between the [[River Erinin]] in [[Shienar]] and [[Kinslayer's Dagger]] in [[Cairhien]].
In one of the "mirror worlds" reached by [[Portal Stone]], the [[Dragon Reborn]], [[Rand al'Thor]], discovered a parallel history where the Shadowspawn had been triumphant at the Battle of Talidar and gone on to wipe out humanity entirely. However, the Shadowspawn in turn seem to have decimated one another and then been wiped by other animals, such as *grolm*. In this reality, the Shadow had raised their own massive, ugly monument covered in Trolloc script and sigils on the site of the battle.






https://wot.fandom.com/wiki/Battle_of_Talidar