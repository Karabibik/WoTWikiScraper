---
tags: [Imagesbyartist]
---
Images created by Michael Whelan, a book cover artist for the series.






https://wot.fandom.com/wiki/Michael_Whelan