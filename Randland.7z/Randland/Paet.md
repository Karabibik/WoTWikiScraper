---
tags: [Disambiguation]
---
**Paet** can refer to two different people:

[[Paetram Aybara|Paetram "Paet" Aybara]] - [[Perrin Aybara]]'s brother, now deceased.
[[Paet al'Caar]] - a resident of the [[Two Rivers]].


https://wot.fandom.com/wiki/Paet