---
tags: [Battles, Otherfeatures, Manetheren, AftertheBreaking]
---

The **Field of Bekkar** - which some historical records have refered to as the **Field of Blood** - was the site of a battle between the army of [[Manetheren]] and forces of the [[Shadow]] during the middle years of the [[Trolloc Wars]]. It occurred circa [[1200 AB]] and resulted in a victory for the forces of [[Light]]. 

## History
Little to nothing is known of the Battle at Bekkar. The only reference to the confrontation appears in historical accounts of the [[Battle of the Tarendrelle River]] which was fought a week later. Research conducted by [[Moiraine Damodred]] indicates that the Shadow feinted a campaign towards Bekkar in order to lure the soldiers of Manetheren into an overextended tactical position which could allow for a direct assault upon the Manetheren heartland by a concealed army of [[Shadowspawn]]. When these plans were revealed, King [[Aemon al Caar al Thorin]] marched his army day and night from Bekkar to the [[River Taren|Tarendrelle River]] in order to repulse the pending invasion. 

The actual location of the Bekkar Battlefield is lost to time and legend. Scraps of history indicate only that Aemon force-marched his army "*day and night*" on an extended multiple-day journey to the Tarendrelle River in eastern Manetheren. 
Based upon these accounts, likely modern areas for the site of Bekkar are [[Ghealdan]], [[Altara]], [[Murandy]], [[Andor]], or the [[Caralain Grass]]. Since fewer battles during the Trolloc Wars were fought in southern areas, the Caralain Grass is the most likely candidate for containing the battlefield. If true, the battle would have taken place somewhere in the nation of [[Coremanda]].

## Notes






https://wot.fandom.com/wiki/Field_of_Bekkar