---
tags: [Women, WhiteAjah, Arafel_people, AesSedai, LivingasofKOD, ElaidaaRoihansWhiteTower, Channelers]
---


**Ramesa** is an [[Aes Sedai]] of the [[White Ajah]].

## Appearance
She is tall and slender. She is seen wearing silver bells embroidered onto her white dress, perhaps suggesting she is [[Arafellin]].

## Activities
She has remained loyal to the [[White Tower]] during the split.
When [[Alviarin Freidhen]] was removed as [[Keeper of the Chronicles]], Alviarin heard [[Norine Dovarna]] address Ramesa with a scathing remark about Alviarin. Ramesa seemed to wonder why Norine was addressing her, since they were not friends.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Ramesa