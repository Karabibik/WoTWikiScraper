---
tags: [Men, Illian_people, Merchants, LivingasofKOD]
---


**Jeorg Damentanis** is a jewel merchant from [[Illian]].

## Appearance
Jeorg is an older man. He has dark eyes and a gray-streaked beard.

## Activities
Jeorg and [[Pavil Geraneos]] negotiate with [[Weilin Aldragoran]] to purchase gems. They were at an inn called [[The Queen's Lance]] in [[Kayacun]], a city in [[Saldaea]].







https://wot.fandom.com/wiki/Jeorg_Damentanis