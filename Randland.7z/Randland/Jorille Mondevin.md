---
tags: [Women, Historians, LivingasofTSASG]
---


**Jorille Mondevin** is the royal historian to the court of [[Ethenielle Kirukon Materasu]], queen of [[Kandor]].

## History
She is mentioned by name once, in the introduction of the pseudo-historical narrative [[The Strike at Shayol Ghul]], after locating ancient documents in [[Chachin]]. She is presented as the author of the piece.
Her name indicates a [[Cairhienin]] origin, something unconfirmed, however.







https://wot.fandom.com/wiki/Jorille_Mondevin