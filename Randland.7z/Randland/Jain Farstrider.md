---
tags: [Men, Malkier_people, HeroesoftheHorn, BoundtotheWheel, POVcharacter]
---



*"If you ever meet a Malkieri, you tell him Jain Farstrider died clean."*
   —Jain Farstrider 
**Jain Charin**, known as **Jain Farstrider**, was a legendary traveler and adventurer from [[Malkier]], one of the [[Borderlands]]. His adventures are well known throughout the [[Westlands]] because of the book *The Travels of Jain Farstrider*.

## Contents

1 Appearance
2 History

2.1 A new identity as Noal Charin


3 Activities

3.1 First encounters
3.2 Fleeing Ebou Dar
3.3 Travelling with the Band
3.4 To the Tower of Ghenjei
3.5 The Last Battle


4 Additional info
5 External links
6 Notes


## Appearance
He is a scrawny, white-haired man with gaps in his teeth, stooped shoulders, a hooked nose, and a sad weathered face that does not match the long gray coat he wears. He is described as "the very picture of hard times." Both his nose and gnarled fingers looked to have been broken several times so he could no longer handle the sword.

## History
Jain Farstrider was still young when he brought to justice [[Cowin Gemallan]] Fairheart, betrayer of [[Malkier]] and a [[Darkfriend]], before the Great Lords of the [[Seven Towers]]. Gemallan had been instrumental in arranging the downfall of Malkier.
Jain appeared at an Ogier stedding shortly after the Aiel War, near to death, conveying the message that the Dark One was going to blind the [[Eye of the World]]. He recovered in the stedding then left. [[Ishamael]] tells [[Rand al'Thor|Rand]] it was him who arranged this to lure Rand here.

### A new identity as Noal Charin
After his wife died, he realized that he was used by Ishamael, and from that time he started to use the name Noal Charin, claiming that he is Jain's cousin. He disappeared north of the Blasted Lands in 981 NE.
Graendal knew his real identity and picked him because of his fame, and later on she used a very subtle Compulsion on him and sent him to [[Ebou Dar]] to find a cache there and spy on [[Jaichim Carridin]], [[Falion Bhoda]] and [[Ispan Shefar]]. Jain met with [[Matrim Cauthon]] when the *gholam* attacked Mat and after that he stayed with Mat.
He knew that there were gaps in his memory; he hoped that the memories would return, he felt their importance in some way. 

## Activities
### First encounters
Mat first encounters Noal while tracking [[Mili Skane]], the Darkfriend woman assassin from the horse races then to the [[Chelsaine Palace]] leased by [[Jaichim Carridin]] in Ebou Dar. Noal's identity does not become clear until later; his reasons for being in Ebou Dar and near Darkfriends remains mysterious.
Noal later saves Mat's life during a fight with a *gholam* in an Ebou Dar alley. Noal keeps long knives hidden under his vest, and is deceptively agile. Mat then took Noal with him to the [[Tarasin Palace]] and had him stay with his men. Noal told [[Olver]] many stories about his travels and adventures. Noal's memories of more recent events in his life appeared to have been lost or tampered with somehow, as he was shown struggling to remember some important task that he needs to perform.

### Fleeing Ebou Dar
When Mat attempts to leave Ebou Dar with the captive [[Aes Sedai]] he is confronted by [[Tuon Athaem Kore Paendrag]]. Noal manages to sneak up behind her and capture her before she could raise an alarm. He decides to leave with Mat's party rather than stay behind in Ebou Dar.
Along with the remainder of Mat's party, he uses [[Valan Luca's Traveling Show]] as cover to escape Ebou Dar. Mat charges him to keep an eye on [[Amathera Aelfdene Casmir Lounault]] while she is strolling about. He remembered a verse about Mat from the [[Prophecies of the Dragon]].
Later, Noal volunteers to join Mat and [[Thom Merrilin]] in their attempt to rescue [[Moiraine Damodred]] from the [[Eelfinn]].

### Travelling with the Band
After a skirmish with Darkfriends in [[Maderin]], Mat and the rest of his group decided to leave Luca's show. While riding through [[Altara]] they met up with the [[Band of the Red Hand]] and began to travel with them.
He met with Mat, who was planning how to approach [[Trustair]], the next village along after [[Hinderstap]].
After the Band set up camp in [[Caemlyn]], the *gholam* attacked Mat. During the fight, the *gholam* threatened to kill Noal. After the attack, Mat insisted on Noal sleeping in the city in a different tavern each night.
He meets with Mat and Thom in [[Low Caemlyn]] to discuss their strategy on how to retrieve Moiraine from the [[Tower of Ghenjei]]. Noal provides a set of iron throwing knives for each of them for the "iron to bind" verse. Mat tells Noal that he doesn't have to come but Noal is insistent saying it is something he needs to do.

### To the Tower of Ghenjei
Noal travels with Mat and Thom into the [[Tower of Ghenjei]] in order to rescue Moiraine. Although Mat's bargain prevents the Eelfinn from harming them, he said nothing about the [[Aelfinn]]. The Aelfinn cut off the group's escape. Noal chooses to remain behind in the tower, and hold off the Aelfinn as long as he can, in hopes of giving Mat and Thom enough time to escape with Moiraine. He bought them enough time to escape, but died in the attempt. His last words to Mat were: "If you ever meet a Malkieri, you tell him Jain Farstrider died clean." 

### The Last Battle
During the battle at the [[Field of Merrilor]] it is revealed that Noal was bound as a hero to the [[Horn of Valere]] upon his death. Olver, trapped and prevented from delivering the Horn to Mat by a band of [[Trolloc|Trollocs]], blows the horn in desperation. Since Mat's death during the invasion of Andor broke his link with the horn, Olver becomes the new Horn Blower and Noal soon appears, saving him from the Trollocs. At [[Shayol Ghul]] Noal rides with the rest of the [[Heroes of the Horn]] against the remaining forces of the Shadow.

## Additional info
It is only revealed in *Towers of Midnight* that Noal was actually the famous explorer Jain Farstrider, after he died in the Tower of Ghenjei and was brought back by the Horn of Valere. When [[Sammael]] visited [[Graendal]], an old, white-haired man was seen disconsolately sitting, something as yet unexplained. It was most probably him. Additionally, during [[Rand al'Thor]]'s confrontation with [[Ishamael]] at the [[Eye of the World]], the Forsaken gloats that he let Jain go "thinking he was free of me."
In some of the books, his name is spelled "Jaim."

## External links
 
## Notes






https://wot.fandom.com/wiki/Noal