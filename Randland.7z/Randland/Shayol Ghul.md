---
tags: [Mountains, TheShadow]
---

**Shayol Ghul** (pronounced: SHAY-ol GHOOL) is a great black mountain, once an idyllic tropical island paradise and vacation spot, now the focal point of the [[Dark One]]'s power. It is located in the lifeless [[Blasted Lands]], a place which bore the brunt of the [[War of Power]]. 
Within the mountain is the Pit of Doom, accessible only by a narrow stone passage where reality is wet clay to the [[Dark One]]; teeth of stone may brush at an intruder's head or close on him entirely, or rise to give honor to a loyal servant of the [[Shadow]].
The Blasted Lands are inaccessible for the most part, for they are past the [[Great Blight]]. Entire armies have died fighting the Blight, and it is all the forces of the [[Borderlands]] can do to hold it back.


## Contents

1 The Pit of Doom
2 Thakan'dar
3 Parallel
4 Notes


## The Pit of Doom
The Pit of Doom itself is a great lake of lava, the only place where the [[Pattern]] is thin enough to make the [[Bore]] detectable. The sky seen here is not the sky seen from outside. Instead, the sky contains clouds of multiple colors that are seen to race across the sky with impossible speed. 
This is where the [[Dreadlords]] swore oaths to the [[Dark One]]. 
The [[True Power]] of the [[Dark One]] is most concentrated here; any who dared channel it would be instantly incinerated. This is the only place on Earth where the Dark One can directly communicate with those within the Pattern. The Dark One is also capable of altering time and reality in this place, and it appears that the Dragon, Rand al'Thor, can counteract this tampering. The Dark One's control of reality in this place makes certain things, like creating [[Mindtrap|Mindtraps]], possible, where they would be impossible anywhere else. During the Last Battle, the lake of lava was consumed by a tiny portion of the Dark One's essence that he managed to spawn into the Pattern, leaving it empty and dark. 

## Thakan'dar
Below the mountain is the great valley of Thakan'dar, where [[Forgers|shadow-forgers]] forge the tainted swords of [[Myrddraal]] at the cost of human souls. Lightning flashes *up* at the clouds in this place. There is no life, and it is as cold as the ice to the north, yet the place is dry as any desert. No man of the [[Light]] who has ever seen Shayol Ghul and bore witness to the fact, is mentioned in the series. Any who survived were turned or slain. [[Jain Farstrider]] was known to have tried, yet what he saw is unknown as he disappeared shortly after his return. It is discovered in "Towers of Midnight" that he became a [[Darkfriend|darkfriend]] while there, though he returned to the light shortly before dying.

*"I have seen Thakan'dar." Saying that hurt; the memories it brought were agony.  He refused to whimper, forced the words out.  "The great sea of fog, rolling and crashing against the black cliffs, the fires of the forges glowing red beneath, and lightning stabbing up into a sky fit to drive men mad." He did not want to go on, but he made himself.  "I have taken the path down to the belly of Shayol Ghul, down the long way with stones like fangs brushing my head, to the shore of a lake of fire and molten rock--" No, not again! "--that holds the Great Lord of the Dark in its endless depths.  The heavens above Shayol Ghul are black at noon with his breath."*
   — [[Padan Fain]] 

However, the [[Aiel]] seem to be aware of basic facts about Shayol Ghul. [[Aviendha]], when attacking Shayol Ghul during the [[Tarmon Gai'don|Last Battle]], knows some rumors about forgers and the environment in the valley, saying that *"few Aiel had ever actually danced the spears with a Shadow-forger"*.

## Parallel
Shayol Ghul may be a parallel to  from Hebrew religion. Sheol is often said to be the underworld or land of the dead, which coincides with the dark role that Shayol Ghul plays. Ghul is likely a reference to the supernatural creature ghoul.

## Notes








https://wot.fandom.com/wiki/Thakan%27dar_Valley