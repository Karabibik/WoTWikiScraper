---
tags: [Seanchancontinent]
---
**Kirendad** is the second largest city in [[Seanchan]].
The city lies just south of the equator at the point where two rivers meet.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Kirendad