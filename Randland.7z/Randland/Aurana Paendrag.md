---
tags: [Women, Seanchan_people, Ladies, Deceased, TheBlood]
---



High Lady **Aurana Paendrag** was one of Empress [[Radhanan]]'s children.

## Activities
She was murdered, along with with the rest of her family, by [[Semirhage]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Aurana_Paendrag