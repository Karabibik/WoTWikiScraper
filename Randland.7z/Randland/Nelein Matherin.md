---
tags: [Women, Andor_people, Ladies, Deceased, Nobility]
---



Lady **Nelein Matherin** was an [[Andor|Andoran]] [[Nobility|noblewoman]] of [[House Matherin]].

## History
She was [[Lord]] [[Aedmun Matherin]]'s grandmother.

## "Activities"
Due to the [[Dark One]]'s influence on the world, Lady Nelein appeared as a ghost to a maid, [[Elsie]], which frightened her.

## Notes






https://wot.fandom.com/wiki/Nelein_Matherin