---
tags: [Terangreal, ItemsofPower]
---
The **golden trout** ornament is a *ter'angreal* in the possession of [[Cadsuane Melaidhrin]] as a part of her [[Paralis-net|paralis-net]].

## Appearance
It has the shape of a fish trinket, pending from a golden hair needle. The fish looks like a trout.

## Use
The use of this Cadsuane's ornament and two others is unknown. But from the fight against [[Semirhage]] we know also that Cadsuane has an unknown *ter'angreal* that disrupts weaves at close proximity, so the golden trout can be the one among the three with this abilities.


## Notes







https://wot.fandom.com/wiki/Golden_trout