---
tags: [Disambiguation, Chapterdisambiguations]
---
**Wind** can refer the following:

## [[Sword forms]]
[[Apple Blossoms in the Wind]]
[[Dandelion in the Wind]]
[[Low Wind Rising]]
[[Thistledown Floats on the Whirlwind]]
[[Twisting the Wind]]
[[Rain in High Wind]]
[[Whirlwind on the Mountain]]
[[Wind and Rain]]
[[The Wind Blows Over the Wall]]
## *Atha'an Miere*
[[Tebreille din Gelyn South Wind]] - a [[Windfinder]].
[[Coine din Jubai Wild Winds]] - a [[Sailmistress]].
[[Harine din Togara Two Winds]] - a [[Wavemistress]].
[[Windfinder]] - a title among the *Atha'an Miere*.
*Wind Racer* - a ship of the *Atha'an Miere*.
*Windrunner* - another ship of the *Atha'an Miere*.
## Chapter titles
*Dust on the Wind* - the twentieth chapter of *The Eye of the World*.
*Listen to the Wind* - the twenty-first chapter of *The Eye of the World*.
*Winds Rising* - the twentieth chapter of *The Shadow Rising*.
*The Bowl of the Winds* - the thirteenth chapter of *A Crown of Swords*.
*Eastward the Wind Blew* - the first chapter of *A Memory of Light.*
## Animals
[[Aldieb]] - [[Moiraine Damodred]]'s horse, whose name means "Westwind" in the [[Old Tongue]].
[[Dawn Wind]] - a horse owned by [[Elenia Sarand]].
[[Wind (horse)|Wind]] - a horse owned by [[Olver]].
[[Wind (wolf)|Wind]] - a wolf in [[Dapple]]'s pack.
## Others
[[Black Wind]] - another name for *Machin Shin*.
[[Five Powers|Wind]] - a flow of the [[One Power]], also known as Air.
[[Bowl of the Winds]] - a weather-changing *ter'angreal*.
[[Windbiter's Finger]] - a peninsula on the [[Shadow Coast]].
## See also
[[Air (disambiguation)|Air]]


https://wot.fandom.com/wiki/Wind