---
tags: [Men, Safer_people, Rulers, Kings, Deceased, Historicalpeople]
---


**Aedomon** was a king of [[Safer]] sometime after the establishment of the [[Compact of the Ten Nations]] in [[209 AB]] and before the outbreak of the [[Trolloc Wars]] circa [[1000 AB]].

## Contents

1 Appearance
2 History

2.1 The Battle of Midean's Ford
2.2 Later Years


3 Legacy
4 Notes


## Appearance
Historians believe that King Aedomon was a tall and powerful looking man.  His hair coloring was dark complected and he had a long glossy black beard.  He was accounted as a warrior king of great renown who was often seen clad in chain mail and armed for battle.  

## History
The early years of Aedomon's life are lost to time and legend.  He ruled Safer during a period of general peace among the [[Ten Nations]].  During his reign however, he was in a territorial dispute with King [[Buiryn]] of [[Manetheren]] over sovereignty claims to certain stretches of the [[Mountains of Mist]].

### The Battle of Midean's Ford
During the middle years of Aedomon's reign. he decided to lead a small army into disputed territory to expand the bounds of his dominion.  He led his men through these lands, pillaging and burning, until King Buiryn confronted him at a river crossing known as Midean's Ford.
History relates that Aedomon's force was greater than Buiryn's but even so, the Manetheren force was able to forestall Safari efforts to invade further.  However, after three days of battle Buiryn knew his force was much diminished and so attempted a gambit by ordering a sortie across the river and into Adeomon's forces in an effort to break the Saferi will to fight.  The attack did not succeed but the tenacity of the Manetheren solders gave pause to Aedomon who ordered a halt to the fighting in order to parley with Buiryn.  
Aedomon agreed to allow Buiryn and his men to depart back across the ford in peace and that he would lead his forces home to Safer.  However, the agreement was a ruse, for when Buiryn was halfway across the ford Aedomon ordered concealed archers to open fire on his rival.  Once the solders of Manetheren were floundering in the river Aedomon ordered his heavy cavalry to charge them.  Aedomon won the battle of Midean's ford, scattered his foe, and killed the king of Manetheren.  

### Later Years
The later years of Aedomon's life are also lost to time and legend.  Historians know that he lived many years after the Battle of Midean's ford - long enough for his black hair to turn grey.  It is also known that he died as he lived - in battle.  During a skirmish with an unknown enemy he was killed while on horseback after having a spear thrust into his back by a young boy.

## Legacy
The struggle between Aedomon and Buiryn is recounted in [[Midean's Ford|The Ballad of the Battle at Midean's Ford]], a song that has survived for over two-thousand years and known to most [[Gleemen]].  In the classic telling of the yarn, storytellers unintentionally spin a false account that relates how King Aedomon was emotionally moved by the bravery of Buiryn's soldiers and allowed them to depart back across Midean's Ford in peace. When [[Asmodean|Jasin Natael]] sings the song of Midean's Ford to some assembled [[Aiel]] at [[Imre Stand]], [[Matrim Cauthon]] correctly remembers the last moments of the battle when the wounded Manetheren soldiers floundered in the river's current and perished with Buiryn while under fire from the treacherous Saferi.

## Notes






https://wot.fandom.com/wiki/Aedomon