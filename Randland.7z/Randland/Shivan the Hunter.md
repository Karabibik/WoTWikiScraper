---
tags: [Men, HeroesoftheHorn, BoundtotheWheel, Parallels, Historicalpeople]
---


**Shivan the Hunter** is one of the [[Heroes of the Horn]]. He is brother to [[Calian the Chooser]]; both of whom are only born at the end of an [[Age]]. It was suspected that [[Elayne Trakand]] was pregnant with Shivan and Calian, but [[The Wheel of Time Companion]] states in the entries for each that they were born before the beginning of the [[Last Battle]] and Elayne had not yet given birth.

## Contents

1 Appearance
2 Activities
3 Parallels
4 Notes


## Appearance
He rides with a black mask.

## Activities
He appears when [[Matrim Cauthon]] blows the [[Horn of Valere]] near [[Falme]]. Later, Mat remembers seeing him when he is talking with [[Birgitte Silverbow]].

## Parallels
Shivan the Hunter is a parallel to  in . Shiva is known as "the destroyer" or "transformer." the name also translating roughly as "auspicious one." This reflects the words that Jordan uses to describe Shivan, *the destruction of what had been and the birth of what was to be*. Some stories describe Shiva appearing as a tribal hunter to challenge and test protagonists as in the case with Arjuna. Shiva, like some other Hindu gods, appears in incarnations called  in which a being descends from a higher plane to a lower one for a specific purpose. This is remarkably similar to how the [[Pattern]] incorporates the [[Heroes of the Horn]] into its weaving.

## Notes






https://wot.fandom.com/wiki/Shivan_the_Hunter