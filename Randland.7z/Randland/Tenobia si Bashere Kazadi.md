---
tags: [Women, Saldaea_people, Rulers, Queens, Deceased]
---




Her Illumined Majesty, **Tenobia si Bashere Kazadi**, [[Shield of the North]] and [[Sword of the Blightborder]], [[High Seat]] of [[House Kazadi]], Lady of [[Shahayni]], [[Asnelle]], [[Kunwar]] and [[Ganai]] was Queen of [[Saldaea]].
She was niece to [[Davram Bashere]] and thus cousin to [[Faile]].

## Contents

1 Appearance
2 Activities

2.1 Finding the Dragon
2.2 The Last Battle


3 Notes


## Appearance
Tenobia was tall and pretty with the typical Saldaean bold nose, a wide mouth and tilted purple eyes. She was roughly 5'7" tall.

## Activities
Tenobia was born in 975 NE and came to the throne of Saldaea in 991 NE. Tenobia was touchy about anything that she perceived as a threat to her reign, and only trusted her council of soldiers.
The White Tower under [[Elaida]]'s leadership sends [[Memara]] Sedai to Saldaea to keep Tenobia under control. Queen Tenobia writes to the Amyrlin Seat asking that the White Tower stop meddling in her affairs. In her disapproval, Elaida ordered a kidnapping of Tenobia, but it never came to pass. 
Tenobia wished to marry a man who was a poet, philosopher, and warrior of the finest degree. Her subjects thought that her expectations were so high that she would never find someone suitable for her. Instead, she made a political match by marrying her uncle, Lord [[Kalyan Ramsin]], to Queen Ethenielle of [[Kandor]].

### Finding the Dragon
Tenobia met with the other [[Borderland]] rulers, [[Ethenielle Cosaru Noramaga]], [[Paitar Nachiman]] and [[Easar Togita]], and made a blood pact with them before setting out and leaving the Borderlands to look for [[Rand al'Thor]]. Tenobia has brought five Aes Sedai with her, while Paitar has brought seven of them.
The army travels to [[Braem Wood]] in [[Andor]] where it camps down for the winter. She and the rest of the rulers meet with [[Elayne Trakand]]. They agree with her to carry on moving south towards [[Murandy]] in exchange for Elayne not raising a hostile hand against them as they travel. She seems intent on finding her uncle again.
When Rand finally agrees to meet with the Borderlanders outside of [[Far Madding]], Tenobia and the other rulers of the Borderlands arrive there. One by one the rulers smack Rand in the face as part of an ancient [[Arafellin]] prophecy, however preceding the kingdom of [[Arafel]]. Tenobia used her left hand to hit Rand.
When talking about his past actions, Rand demands the monarchs swear loyalty to him. A matter Tenobia had great difficulty with, as she found her loyalty should lie with the people of her nation. She and the others are left to discuss the offer of Rand marching to [[Shayol Ghul]] to break the remaining [[Seal|Seals]] on the [[Dark One]]'s prison.
Tenobia and her force Travel to the [[Field of Merrilor]], where she is one of the rulers arguing in Rand's defense on why everyone should sign the [[Dragon's Peace]]. With the timely arrival of [[Moiraine Damodred]], she manages to finally convince everyone that this needs to be done quoting the *Karaethon Cycle*. To the Borderlander rulers she quotes:


All the rulers finally sign the document.

### The Last Battle
Tenobia is in attendance at [[Elayne Trakand]]'s initial war-council, where it is decided that the army will fight on four fronts led by the four Great Generals. The Borderlander rulers join the [[Last Battle]] at [[Tarwin's Gap]], where [[Agelmar Jagad]], as a [[Five Great Captains|Great Captain]], is the head of the command structure. Tenobia keeps arguing with Agelmar about not being aggressive enough and taking the fight into the Blight. During the Borderlander army retreat through [[Shienar]], Tenobia begins to ride with her men into battle.
On orders from the [[Dark One]], [[Hessalam]] manipulates the dreams and thoughts of [[Agelmar Jagad|Lord Jagad]], causing him to make decisions that benefit the Shadow instead of the Light. Tenobia's elite guard is surrounded by [[Trolloc|Trollocs]], and Tenobia is killed, effectively making her cousin Faile Queen of Saldaea, following her father, Bashere's death.

## Notes






https://wot.fandom.com/wiki/Tenobia_Kazadi