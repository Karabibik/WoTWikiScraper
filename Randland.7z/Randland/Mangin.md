---
tags: [Men, Aiel_people, Taardad, Jindo, ShaeenMtaal, Deceased]
---


**Mangin** of the [[Jindo]] [[Taardad]] [[Aiel]] was a [[Stone Dog]].

## Appearance and Personality
He was gray-eyed. He was younger and taller than [[Rand al'Thor]].  Rand noted that in more peaceful times he could see himself being friends with Mangin as he had a sense of humor and personality in some ways similar to [[Mat Cauthon]].

## Activities
He was one of those who first crossed the [[Dragonwall]] in search of [[He Who Comes With the Dawn]].  He was one of the Aiel present when the [[Stone of Tear]] falls. He was also one of the first to follow Rand when he declared himself the *Car'a'carn*. He helped teach Rand the Aiel way of fighting.
He was with [[Gaul]] outside Rand's chambers in Tear, and apparently won a bet with Gaul about how far Rand would throw Lord [[Torean]].
He was with [[Rhuarc]] when they brought in some Tairen Lords who reported that the [[Shaido]] were attacking Cairhien. Some time after the battle of [[Cairhien]], he killed a Cairhienin man for bearing a tattoo resembling those Rand and all Aiel clan chiefs have on their arms. Rand reluctantly ordered Mangin hanged the next day, and was angry with [[Berelain]] and [[Rhuarc]] for not carrying out this law on their own, instead leaving this painful decision to Rand.

## Notes






https://wot.fandom.com/wiki/Mangin