---
tags: [Andor, Inns, Ashaman]
---
**The Great Gathering** is an inn in the [[Black Tower]] run by [[Lind Taglien]] and her husband [[Frask]]. 
It has been transformed from a warehouse, though the process is still in progress and not all the tables and chairs match. It has an extensive library and an upper floor with guest rooms and dining chambers. Lind keeps a tight reign on it, and there is rarely any real trouble.






https://wot.fandom.com/wiki/The_Great_Gathering