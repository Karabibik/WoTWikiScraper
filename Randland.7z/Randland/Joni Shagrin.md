---
tags: [Men, Andor_people, Deceased, LivingasofTFOH]
---


**Joni Shagrin** was an old warhand under the command of [[Gareth Bryne]]. He was formerly a Senior Bannerman of the [[Queen's Guards]].

## Appearance
He was a big man with thinning gray hair.

## Activities
He was escorting [[Siuan Sanche]], [[Leane Sharif]] and [[Min Farshaw]] to Bryne's estates when he was ambushed by [[Logain Ablar]] and knocked unconscious. He set off with Gareth to track down Siuan when she broke her oath to Gareth. This led him all the way from [[Andor]] to [[Salidar]] where the [[Rebel Aes Sedai]] were.
He was sent to [[Ebou Dar]] to help recruit men for the Rebel Aes Sedai army.
Assumingly, Joni remained with the Salidar Aes Sedai all the way up to the reunification of the [[White Tower]]. Approaching the [[Last Battle]], he started training the cavalry of the White Tower Guard together with [[Uno Nomesta]].
After the [[Shara|Sharans]] arrived on the battlefield in [[Kandor]] and the forces of the White Tower had been pushed back to the border to [[Arafel]], Joni was killed while commanding a contingent of the White Tower Guard fighting for control over a river ford. He was mourned by his lord, who however stated that Joni had always wanted to die in battle.
Uno replaced him when he died.

## Notes






https://wot.fandom.com/wiki/Joni