---
tags: [Women, WhiteAjah, AmyrlinSeats, AesSedai, Deceased, Historicalpeople, HighRankingAesSedai, Channelers, Characternotmentionedinbooks]
---


**Beryl Marle** was an [[Aes Sedai]] of the [[White Ajah]] who was raised to the [[Amyrlin Seat]] in the year 520 NE.

## History
Beryl Marle held the position for thirteen years until her death in 533 NE. She was [[Igaine Luin]]'s successor and [[Eldaya Tolen]]'s predecessor.
Beryl is described as a weak Amyrlin, a compromise candidate chosen after the [[Hall of the Tower|Hall]] had deadlocked on others; she turned out to have little interest in the world at all, so the [[White Tower|Tower]]'s influence waned considerably during her rule.
During her reign, the Tower's last known [[Dreamer]] prior to [[Egwene al'Vere]], [[Corianin Nedeal]], died. 

## Notes






https://wot.fandom.com/wiki/Beryl_Marle