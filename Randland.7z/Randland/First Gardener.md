---
tags: [Ogier, Gardeners, EverVictoriousArmy, Military]
---
**First Gardener** is the [[Seanchan]] title given to the leader of the [[Gardener|Gardeners]], the [[Ogier]] branch of the [[Deathwatch Guard]]. The title is currently held by [[Hartha]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/First_Gardener