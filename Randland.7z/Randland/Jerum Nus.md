---
tags: [Men, ChildrenoftheLight, Soldiers, LivingasofTOM, Charactersnamedafterfans]
---


**Jerum Nus** is a member of the [[Children of the Light]].

## Contents

1 Appearance
2 Activities
3 Trivia
4 Notes


## Appearance
He is a boy, barely a young man. Perrin calls him "son".

## Activities
Jerum has been found under a pile of [[Trolloc]] bodies after the Children were attacked in [[Ghealdan]], thanks to Perrin's enhanced hearing abilities. Being seriously injured on his side, he was partially [[Heal|Healed]] by a [[Wise One]] to survive the day. [[Galadedrid Damodred]] gave her permission to Heal him, because he was *"far too gone to speak for himself"*.

## Trivia
Jerum Nus is named for Jeremy Naus, a fan of *The Wheel of Time*.

This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.


## Notes






https://wot.fandom.com/wiki/Jerum_Nus