---
tags: [Swordforms]
---


**Plucking the Low-Hanging Apple** is a [[Sword form|sword form]]. It is used to cut at the neck, the head being the "low-hanging apple." [[Eamon Valda]] used this form at the beginning of his duel with [[Galadedrid Damodred]]. [[Leopard's Caress]] is often used as a following form to take advantage of the traditional, trained responses to Plucking the Low-Hanging Apple.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Plucking_the_Low-Hanging_Apple