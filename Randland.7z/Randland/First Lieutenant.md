---
tags: [Military, EverVictoriousArmy, Seanchanculture]
---
**First Lieutenant** is a military rank in the [[Ever Victorious Army]] of the [[Seanchan]].
It is also a rank among the [[Winged Guards]] of [[Mayene]].






https://wot.fandom.com/wiki/First_Lieutenant