---
tags: [Women, Seanchan_people, Suldam, LivingasofTSR, Channelers, Learners]
---


**Surine** is a [[Seanchan]] *sul'dam*.

## Appearance
She is said to look like [[Nynaeve al'Meara]], but is taller.

## Activities
[[Egeanin Tamarath]] sets [[Floran Gelb]] to search for deserters, including Surine.

## Notes






https://wot.fandom.com/wiki/Surine