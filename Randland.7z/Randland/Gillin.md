---
tags: [Women, Entertainers, LivingasofWH]
---


**Gillin** is a performer in [[Valan Luca]]'s [[Valan Luca's Traveling Show|Traveling Show]].

## Appearance
[[Olver]], who is taken with Gillin, says that her lips are like ripe cherries.

## Activities
Gillin is one of several women who have taken an interest in Olver. When he leaves the show with [[Matrim Cauthon]], Olver spends time with Gillin, [[Adria]], [[Jameine]], [[Merici]] and [[Neilyn]].

## Notes






https://wot.fandom.com/wiki/Gillin