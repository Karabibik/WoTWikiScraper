---
tags: [ChildrenoftheLight, Titles]
---
The **High Inquisitor** is the highest ranking member of the [[Hand of the Light]], and the second-highest ranking member among the [[Children of the Light]], second only to the [[Lord Captain Commander]] himself. While the Children generally dislike the Hand of the Light, they hold the High Inquisitor in high regard.

## Contents

1 Duties
2 Dress
3 Known Title Holders
4 Notes


## Duties
The High Inquisitor alone is responsible for issuing the orders for the Hand of the Light. The Hand of the Light usually only answers to the High Inquisitor, but are still technically under the command of the Lord Captain Commander.
The High Inquisitor is also a member of the [[Council of the Anointed]], which is presided over by the Lord Captain Commander and is also comprised of approximately twelve [[Lord Captain|Lord Captains]]. The Council is responsible for determining policies for the Children.

## Dress
The High Inquisitor can be differentiated from the rest of the Children by the sigil of his station. All Children wear a golden sunburst over the left breast of their cloak and tabard, and the Hand of the Light have a blood-red shepherd's crook emblazoned behind the sunburst. The High Inquisitor wears only the shepherd's crook, suggesting that holders of this position believe themselves to stand apart from the Children.

## Known Title Holders

[[Rhadam Asunawa]]
## Notes






https://wot.fandom.com/wiki/High_Inquisitor