---
tags: [Swordforms]
---






**The Moon Rises Over Water** is a [[Sword form|sword form]]. The movement of the sword form is a slashing movement. [[Rand al'Thor]] used this form when battling his reflections from a [[Bubble of evil|bubble of evil]] in the [[Stone of Tear]]. Rand later used the form with a sword wrought from *saidin* in [[Rhuidean]] while escaping another bubble of evil with [[Matrim Cauthon]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Moon_Rises_Over_Water