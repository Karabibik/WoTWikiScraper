---
tags: [Shaido, GreenSalts, Aielsepts]
---



The **Green Salts** are a sept of the [[Shaido]] [[Aiel]]. The sept hold is unknown. The sept chief is [[Bendhuin]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Green_Salts