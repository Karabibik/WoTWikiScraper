---
tags: [Women, LivingasofAMOL, Charactersnamedafterfans]
---


**Leish** is married to [[Taril Canler]] and currently lives in the [[Black Tower]].

## Contents

1 Appearance
2 Activities
3 Trivia
4 Notes


## Appearance
Leish has white hair, is plump and pleasant.

## Activities
Canler has [[Bond|Bonded]] Leish. She helps set up the plan for [[Pevara Tazanovni]] and [[Androl Genhald]] to capture [[Dobser]].

## Trivia
Leish is named for Leisha Springer, a fan of *The Wheel of Time*.
## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Leish