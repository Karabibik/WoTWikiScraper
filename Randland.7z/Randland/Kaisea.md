---
tags: [Women, Seanchan_people, LivingasofTOM, Learners, Charactersnamedafterfans, TheBlood]
---


**Kaisea** is of the [[Seanchan]] Low Blood and a former *sul'dam*.

## Contents

1 Appearance
2 Activities
3 Trivia
4 Notes


## Appearance
She is a tall woman with long black hair tied back in a braid.

## Activities
She was a former *sul'dam* who was captured at some point and now resides in [[Caemlyn]]. [[Dimana]] brings her forward to answer questions from [[Gawyn Trakand]] about the [[Bloodknife]] he has in his possession. 
Dimana reports to Gawyn that she is unreliable and may be learning [[Weave|weaves]] only so she can create an "accident" and thereby have to be collared by an *a'dam*.
Gawyn promised to ask [[Elayne]] to collar her in return of the given informations.

## Trivia
Kaisea is named for Jennifer Kaiser, a fan of *The Wheel of Time*.
## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Kaisea