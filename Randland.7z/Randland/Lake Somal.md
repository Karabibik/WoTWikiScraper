---
tags: [Otherfeatures]
---

**Lake Somal** is the largest lake in the [[Westlands]]. It lies between [[Paerish Swar]] and the [[Mountains of Mist]], southeast of [[Arad Doman]] and east of [[Almoth Plain]]. Despite its size it is somewhat remote and relatively unknown, although a trading road links it to the city of [[Katar]] a hundred miles or so to the northwest. Some maps show the lake as being the source of one of the many tributaries of the [[River Andahar]].
The [[Dragonsworn]] used the area as a base of operations during their war against [[Arad Doman]]. They were defeated in a battle on the lakeshore by General [[Rodel Ituralde]], but orders from King [[Alsalam Saeed Almadar]] meant that the victory could not be completed.






https://wot.fandom.com/wiki/Lake_Somal