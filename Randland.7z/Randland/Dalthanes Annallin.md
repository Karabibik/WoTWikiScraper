---
tags: [Men, Cairhien_people, Lords, LivingasofTPOD, Nobility]
---


**Dalthanes Annallin** is a noble from [[Cairhien]]. He supported [[Colavaere Saighan]] assuming the [[Sun Throne]].

## Activities
He rides with [[Rand al'Thor]] when Rand's forces attack the invading [[Seanchan]] just outside [[Illian]]. He follows [[Gregorin den Lushenos]] into the final assault on the Seanchan.






https://wot.fandom.com/wiki/Dalthanes_Annallin