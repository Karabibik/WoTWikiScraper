---
tags: [Occupations]
---
This page gives a list of those people in the series who are merchants and traders.






https://wot.fandom.com/wiki/Merchant