---
tags: [Women, Ghealdan_people, QueensGuards, Soldiers, LivingasofKOD, HuntersoftheHorn]
---


**Tzigan Sokorin** is a [[Ghealdan|Ghealdanin]] [[Under-Lieutenant]] in the [[Queen's Guards]]. 

## Appearance
She is apple-cheeked with cold eyes.

## Activities
She is one of the Queens's Guards placed as a bodyguard when [[Elayne Trakand]] moves through [[Caemlyn]] to greet the people.
She admits [[Monaelle]] and [[Sumeko Karistovan]] into Elayne's meeting room.
She is part of Elayne's Bodyguards in the rescue attempt of Elayne from the [[Black Ajah]].






https://wot.fandom.com/wiki/Tzigan_Sokorin