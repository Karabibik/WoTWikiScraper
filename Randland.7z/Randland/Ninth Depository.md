---
tags: [WhiteTower]
---
The **Ninth Depository** is a chamber in the [[White Tower Library]]. Though the smallest of the twelve depositories that make up the Library, it is still a large chamber, oval in shape, with a flattened domed roof. Texts stored in this wing of the Library consist mostly of tomes discussing various forms of arithmetic, stored upon rows and rows of wooden shelves that stand on seven-colored floor tiles, each row separated by four paces. Tall, wheeled ladders allow access to the tops of tall bookshelves and to the walkways that can be found therein. The chamber is illuminated by tall, mirrored brass lamps so heavy that they take up to four men to move. The Ninth Depository is accessed through wide, arched doorways. It is not often used, standing mostly empty of patrons, and silent.
[[Alviarin]] uses the Ninth Depository as an entryway when she [[Traveling|Travels]], because it is so little used.

## Notes






https://wot.fandom.com/wiki/Ninth_Depository