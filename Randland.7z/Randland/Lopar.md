---
tags: [Seanchananimals, Animals]
---

*Lopar* are an exotic species from [[Seanchan]]. They resemble large hairless  with thick, reddish-brown skin instead of fur, and no muzzles. If a lopar rears onto its hind legs, it can stand as much as ten feet tall.
*Lopar* can sprint as fast or faster than horses, but they have low endurance and tire out at long distances. They are fierce fighters with sharp teeth and retractable claws, but only if commanded or agitated. Usually, they are placid and can be kept as pets by the [[The Blood|the Blood]].
Mating between lopar involves a dominance display, resembling a battle. Mating can result in mortality quite often, and as such is commonly monitored by *morat'lopar*.
[[High Lady]] [[Suroth]] owns a *lopar* named [[Almandaragal]].

## Gallery
Painting by Todd Cameron HamiltonSize comparison with 5'10" (178cm) manA *lopar*.10, 2021





https://wot.fandom.com/wiki/Lopar