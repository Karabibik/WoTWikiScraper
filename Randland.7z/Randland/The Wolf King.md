---
tags: [Prophecies, Wolfbrothers]
---





*"When the Wolf King carries the hammer, thus are the final days known."*
   —*The Karaethon Cycle* 

**The Wolf King** is a figure in the [[Karaethon Cycle]] that signals the end of the age.

## Origin
Spoken of briefly in *Knife of Dreams* by [[Tylee Khirgan|Banner General Tylee Khirgan]], it appears that sections of the Karaethon Cycle speak of a king of wolves, who will lead all wolves into battle on the Last Day at [[Tarmon Gai'don]]. It speaks also of the announcement of the final days when the wolf king carries a hammer.

## Possibilities
Very few people are known to speak to wolves, the two central to the plot at the moment are [[Elyas Machera]] and [[Perrin Aybara]]. Perrin, being the one of the two who leads an army and carries a hammer is almost certainly the Wolf King of the prophecies. The Wolf King prophecy seems to be taken as fulfilled, when Perrin forged Mah'Alleinir (meaning 'he who soars' in the Old Tongue, his "hammer fit for a King", which is emblazoned with a likeness of the wolf Hopper, for whom the hammer is named. Perrin later leads wolves into battle at Tarmon Gai'don's Last Battle in the valley of Thakan'dar. When The Horn of Valere is sounded the spirits of all heroe wolves are called forth from the wolf dream to destroy the darkhounds and fight the forces of the Shadow.
The Seanchan noblewoman spoke jokingly of the prophecy when she saw the Wolf Head Banner and Perrin carrying a hammer, as if suggesting that the Last Battle was nigh, though she dismissed this as a bad thought.

## Notes






https://wot.fandom.com/wiki/The_Wolf_King