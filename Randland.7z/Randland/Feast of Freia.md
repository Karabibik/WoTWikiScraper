---
tags: [Holidays]
---
**Feast of Freia** occurs on the twenty-first day of [[Adar]].
It is celebrated in [[Illian]], [[Arad Doman]], [[Ghealdan]], [[Tarabon]], and parts of [[Altara]] and [[Murandy]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Feast_of_Freia