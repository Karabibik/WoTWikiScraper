---
tags: [Creators]
---

Wikipedia has , who has been chosen to complete The Wheel of Time since Robert Jordan's passing. This page is for information not suited to a general encyclopedia, such as correspondence and other fan-related information.

## Contents

1 Searchable Database of ALL Plot-related WoT Quotes
2 Interviews, Signing Reports, Blog Posts, etc.

2.1 2007

2.1.1 September
2.1.2 December


2.2 2008

2.2.1 January
2.2.2 February
2.2.3 March
2.2.4 April
2.2.5 May
2.2.6 June
2.2.7 July
2.2.8 August
2.2.9 September
2.2.10 October
2.2.11 November
2.2.12 December


2.3 2009

2.3.1 January
2.3.2 February
2.3.3 March
2.3.4 April
2.3.5 May
2.3.6 June
2.3.7 July
2.3.8 July/August
2.3.9 August
2.3.10 September
2.3.11 October
2.3.12 November
2.3.13 December


2.4 2010

2.4.1 January
2.4.2 February
2.4.3 March
2.4.4 April
2.4.5 May
2.4.6 June
2.4.7 July
2.4.8 August
2.4.9 September
2.4.10 October
2.4.11 November
2.4.12 December


2.5 2011

2.5.1 January
2.5.2 February
2.5.3 March
2.5.4 April
2.5.5 May
2.5.6 June
2.5.7 July
2.5.8 August




3 Peter Ahlstrom
4 Notes
5 External links

5.1 Interviews




## Searchable Database of ALL Plot-related WoT Quotes
Organized by category and linked to original sources, including Brandon Sanderson quotes:


## Interviews, Signing Reports, Blog Posts, etc.
Only interviews etc. with WoT-related information are included. For up-to-date information, follow Brandon on ,  or . For the sake of keeping all post-RJ interviews in one place, some interviews with Team Jordan - [[Harriet Rigney|Harriet McDougal]], [[Maria Simons]], and [[Alan Romanczuk]] - will be included here because they are so often inseparable from Brandon's interviews (with some exceptions), just as Harriet quotes are often found in RJ interviews.

### 2007

EUOLogy: Goodbye Mr. Jordan 19 September 2007

Blog: Brandon to finish Wheel of Time 10 December 2007
Blog: Merry Christmas! New FAQ! 27 December 2007
### 2008

Blog: Insomnia 14 January 2008
Blog: Annotations + Facebook 16 January 2008
Blog: Warbreaker 4.0 DONE! 20 January 2008
Blog: New Warbreaker Download 22 January 2008
Blog: WoT Read-Through Notes: Introduction 24 January 2008
Blog: WoT Read-Through: THE EYE OF THE WORLD 26 January 2008
Blog: WoT Read-Through: THE GREAT HUNT 29 Jaunary 2008

Amazon.com Interview – Omnivoracious: Brandon Sanderson on Robert Jordan and the Wheel of Time 1 February 2008
Blog: The Great Hunt Part Two 2 February 2008
Blog: WoT Read-Through: THE DRAGON REBORN 5 February 2008
Blog: WoT Read-Through: THE SHADOW RISING 7 February 2008
Blog: LTUE + Warbreaker + Annotations 13 February 2008
Blog: Podcast, New Art, MB3 Preorder, WoT: THE FIRES OF HEAVEN 18 February 2008
Blog: WoT: LORD OF CHAOS 25 February 2008
Blog: Late Posts and School Visits 29 February 2008

Blog: Thoughts 3 March 2008
Blog: Posts + A CROWN OF SWORDS 6 March 2008
Blog: The Path of Daggers 12 March 2008
Blog:Reader Mail: AMoL Progress Bar 15 March 2008
Blog: WINTER'S HEART 17 March 2008
Blog: Annotation + Warbreaker html 21 March 2008
Blog: Crossroads of Twilight 25 March 2008
Blog; Defining Surreal 27 March 2008
Blog; Weekly Updates + New A Memory of Light Book Page 30 March 2008

Blog: NAME OF THE WIND Paperback out! + New Spring 3 April 2008
Blog: Updates 9 April 2008
Blog: Back! 14 April 2008
Blog: You guys are great 20 April 2008
Blog; Progress Bar 21 April 2008
Blog: Progress Bar Moving Again 28 April 2008

Blog: Knife of Dreams 2 May 2008
Blog: A great Reader Mail question 12 May 2008
Blog: Iron Man 17 May 2008

Blog: Robert Jordan Citadel Dedication Pictures 9 June 2008
Blog: Done! (With something that...well, I can't tell you much about.) 15 June 2008
Blog: Warbreaker and A Memory of Light General Updates 23 June 2008
Blog: Reader Mail + Annotation 26 June 2008
Blog: Wheel of Time Blog Posts Collected 30 June 2008

Blog: Reader Mail 8 July 2008
Blog: Back to AMoL! 11 July 2008
Blog: Update + Annotations 14 July 2008
Blog: Denver Followup and AMoL Update 17 July 2008
Blog: Various Updates 24 July 2008
Blog: A Gift 28 July 2008

Source:Rolling up the Wheel of Time Panel, WorldCon, Denver, CO 9 August 2008
Blog: Wheel of Time Movie Deal 13 August 2008
Blog: Warbreaker 6.1 PDF and Mobile (And more movie deal thoughts.) 14 August 2008
Blog: Half Way! 22 August 2008
Blog: Answers to Questions 25 August 2008

Blog: Back from Dragon*Con with Many Updates 2 September 2008
Blog: AMoL Update + Alcatraz Sample Chapter 3 September 2008
Blog: Annotations (Finally) Plus notes 9 September 2008
Blog: State of the Inbox (Plus Reader Mail.) 14 September 2008
Blog: One Year 22 September 2008
Blog: Annotation + Random Notes 23 September 2008
Blog: Alcatraz Revision Done! 30 September 2008

Blog: Release Week is here! 12 October 2008
Blog: Updates 25 October 2008
Blog: AMoL Update 29 October 2008

Blog; Several Updates 5 November 2008
Blog; Tour Notes 12 November 2008
Blog: 300k 26 November 2008

Source:LA Times: Completing a World Left Unfinished 3 December 2008
Blog: Reader Mail + Annotation 10 December 2008
Blog: Big Wheel of Time Interview Retrospective 17 December 2008
Blog: Happy Koloss Head-Munching Day! 19 December 2008
Blog: Happy Holidays and Merry Christmas! 24 December 2008
### 2009

Blog: Happy New Year 2 January 2009
Blog: Award + Annotation 6 January 2009
Blog: Do You Want to Appear in A Memory of Light? 13 January 2009
Blog: MB3 Proofreads Due... 19 January 2009
Blog: Signing + Mistborn Audible 22 January 2009
Blog: New Annotation + Reader Mail 23 January 2009
Blog: My Sword 26 January 2009

Blog: Annotation + Reader Mail 5 February 2009
Blog: New Computer + Signing 21 February 2009
Blog: Various Notes 24 February 2009

Blog: AMoL Update - kind of 3 March 2009
Blog: Various Notes 13 March 2009
Blog: Mistborn Two Audiobook 24 March 2009
Blog: What's Up with AMoL? 25 March 2009
Blog: More news on AMoL 26 March 2009
Blog: Splitting AMoL 30 March 2009
Source:Commentary on Splitting AMoL 30 March 2009
Blog: Mistborn Two Personalized Hardcovers 31 March 2009

Blog: Three Random Updates 4 April 2009
Blog: Last Week for the WoT Fundraiser 6 April 2009
Blog: JordanCon and Releases 13 April 2009
Blog: Reader Mail 15 April 2009
Blog: TGS Turned In! + Book SIgning News 22 April 2009

Blog: Reader Mail (Regarding TGS Release Date) 5 May 2009
Blog: Another Long-Winded Explanation of Various Things 7 May 2009
Blog: The Gathering Storm Cover Art 14 May 2009
Source:DaveBrendon's Fantasy & SciFi Weblog - An Interview with Brandon Sanderson 15 May 2009
Source:AMC Filmcritic.com - Novelist Brandon Sanderson Discusses the End of the Wheel of Time 18 May 2009
Blog: Two Interviews 19 May 2009

Blog: Roundup of Thoughts 1 June 2009
Blog: Reader Mail 12 June 2009
Blog: Garden Ninja Contest 23 June 2009

Blog: Done 7 July 2009
Blog: What have I been up to? 23 July 2009

Source:BarnesandNoble.com Book Club Q&A with Brandon Sanderson July/August 2009

Blog: The Gathering Storm coming sooner than expected 11 August 2009
Blog:To Longtime Wheel of Time Fans 20 August 2009

Blog: Summer is Over 2 September 2009
Blog: Tour, The Gathering Storm Chapter 1 + More, Parsec Award, Geekarati 8 September 2009
Blog: The Gathering Storm Tour, Release Events 10 September 2009
Blog: THE GATHERING STORM signed books by mail; Storm Leader application now available 14 September 2009
Blog: Storm Leaders, Book 13 Title, THE GATHERING STORM Prologue 18 September 2009
Blog: Updates, THE GATHERING STORM chapter two audio 28 September 2009

Source:Tor-Forge Interview with Harriet McDougal and Brandon Sanderson 1 October 2009
Blog: Release Parties, Giveaways, Annotations, and John Brown 5 October 2009
Blog: Alcatraz 3, Maze Runner, Names 8 October 2009
Blog: MileHiCon, Signing Deadline, Allomantic Table, Updates 12 October 2009
Source:Tor-Forge Interview with Team Jordan on The Gathering Storm 16 October 2009
Source:Tor-Forge Interview with Brandon Sanderson 20 October 2009
Blog: Sam Weller's signing and my MileHiCon schedule 20 October 2009
Blog: Release party NOW (and live feed) 26 October 2009
The Gathering Storm Book Tour, BYU Midnight Release 27 October 2009 - Jennifer McBride reporting
Source:The Gathering Storm Book Tour, Border's, Oak Brook, IL 28 October 2009 - Peter Binkowski reporting
Blog: Housekeeping, Sam Weller's shipping 30 October 2009
Blog: Tattered Cover Denver Signing Tickets 31 October 2009

Ending The Wheel of Time: The GeekDad Interview with Brandon Sanderson 2 November 2009
Source:The Gathering Storm Book Tour, Salt Lake City, UT 2 November 2009 - Tamyrlin reporting
Blog: Updates, Signed Hardbacks 3 November 2009
Source:The Gathering Storm Book Tour, Harvard Coop, Cambridge, MA 5 November 2009 - Shannon Berndston reporting
Source:The Gathering Storm Book Tour, Chester County Books, Philadelphia, PA 6 November 2009 - Paul Grow reporting
Source:The Gathering Storm Book Tour, Toadstool Book Store, Milford, NH 7 November 2009 - Meg Lurvey reporting
Blog: No. 1 7 November 2009
Source:The Gathering Storm Book Tour, Union Square, New York City 9 November 2009 - Old (Peter) Salt reporting
The Gathering Storm Book Tour, New York City 9 November 2009 - WinespringBrother reporting
Source:The Gathering Storm Book Tour, Lexington, KY 10 November 2009
Blog: Mistborn Minifigs Sale, Updates 10 November 2009
Source:The Gathering Storm Book Tour, Books and Co., Dayton, OH 11 November 2009 - Tim Kington reporting
Source:The Gathering Storm Book Tour, Atlanta, GA, 13 November 2009 - Yellowbeard reporting
The Gathering Storm Book Tour, Norcross, GA, Cultural Arts Center 13 November 2009 - Tiffany Franklin reporting
Source:The Gathering Storm Book Tour, Border's, Dallas, TX 14 November 2009 - Matoyak reporting
The Gathering Storm Book Tour, Border's, Dallas, TX 14 November 2009 - Aubree Pham reporting
Source:The Gathering Storm Book Tour, Mysterious Galaxy, San Diego, CA 15 November 2009 - Freelancer reporting
Source:The Gathering Storm Book Tour, Mysterious Galaxy, San Diego, CA 15 November 2009 - Katie Frey reporting
The Gathering Storm Book Tour, Scottsdale Public Library, Phoenix Arizona 16 November 2009 - kcf reporting
Source:The Gathering Storm Book Tour, Vroman's Bookstore, LA 17 November 2009 - Robert Moreau reporting
Blog: Hitting the West Coast 17 November 2009
Source:The Gathering Storm Book Tour, Powell's, Portland, OR 19 November 2009 - forkroot reporting
Source:The Gathering Storm Book Tour, Powell's, Portland, OR 19 November 2009 - Matrimony Cauthon reporting
Source:The Gathering Storm Book Tour, Powell's, Portland, OR 19 November 2009 - Samadai reporting
Blog: My magic duel against Jason 20 November 2009
Source:Driving Mr. Sanderson, 21 November 2009 - Matt Hatch reporting
Source:The Gathering Storm Book Tour, San Jose, CA 21 November 2009 - Frenzy reporting

Blog: Doctors Without Borders, Interviews, THE WAY OF KINGS 1 December 2009
Source:The Gathering Storm Book Tour, Sandy, UT 5 December 2009 - kavorka reporting
Blog: Upcoming SIgnings + Typical Rambing 11 December 2009
Blog: Happy Koloss Head-Munching Day! (Free Short Story) 18 December 2009
Source:The Gathering Storm Book Tour, Idaho Falls, 19 December 2009 - Stephanie Reese reporting
### 2010

Blog: Hugo nomination season, GoodReads Q&A, Pat Rothfuss's Worldbuilders charity drive, Updates 4 January 2010

Blog: Amazonfail 2010, Mythmaker Interview, Updates 1 February 2010
Blog: Photoshop Contest - Win a New Tor Book 2 February 2010
Blog: Photoshop Contest Winners, Wheel of Time Games, & Updates 15 February 2010
Blog: Updates, Audies, Vote for the David Gemmell Legend Award! 22 February 2010
Blog: Some Long-Awaited Updates 24 February 2010

MAFO Answers by Luckers 13 March 2010
Interview with Maria Simons by Luckers 19 March 2010
Blog: KINGS final draft, THE GATHERING STORM in Audible's tournament + Updates 29 March 2010

Blog: Gemmell Nominations, Audible Tournament, Suvudu Cage Match + Updates 5 April 2010
Blog: Suvudu Cage Match: How It REALLY Went Down 12 April 2010
Blog: Gemmell Voting, Wheel of Time Article, Audible Tournament Winner + Updates 14 April 2010
Charleston City Paper Interview with Harriet and Brandon 14 April 2010
Blog: Play Magic with Brandon at Jordancon! 20 April 2010
JordanCon 2010 Questions and Answers 23-25 April 2010 - Terez reporting
Tor.com Interview with Harriet McDougal by Richard Fife 30 April 2010

Source:Tor.com Interview with Maria Simons by Richard Fife 3 May 2010
Blog: Catching Up on Updates 3 May 2010
Source:Tor.com Interview with Wilson Grooms by Richard Fife 5 May 2010
Source:Tor.com Interview with Alan Romanczuk by Richard Fife 12 May 2010
Source:Pat's Fantasy Hotlist: Interview with Brandon Sanderson 25 May 2010
Blog: Last chance to vote for the David Gemmell Legend Award 28 May 2010

Tor.com Interview with Brandon Sanderson by Richard Fife 7 June 2010
Blog: Robert Jordan Memorial Scholarship applications, updates 7 June 2010
Plot Related Q&A With Maria Simons + New MAFO by Luckers 10 June 2010
Blog: Updates, THE WAY OF KINGS ARC Giveaway, Tour 28 June 2010
Interview With Harriet by Luckers 30 June 2010

Blog: Updates, Tightening Language, and Suvudu Interview 27 July 2010

Blog: Writing for Charity + Updates 10 August 2010
Blog: TOWERS OF MIDNIGHT Is Done 23 August 2010

Dragon*Con 2010 Q&A, 4 September 2010 - Marie Curie reporting
Blog: The Great Hunt Update 8 September 2010
The Way of Kings Book Tour, Border's, Oak Brook, IL 9 September 2010 - Marie Curie reporting
Source:Postmodernism in Fantasy: An Essay by Brandon Sanderson - 12 September 2010
Source:Pat's Fantasy Hotlist: New Brandon Sanderson Interview - 13 September 2010
Grasping for the Wind Interview: Brandon Sanderson on The Way of Kings - 16 September 2010
Source:Stomping on Yeti Interview - 16 September 2010
Blog: The Great Hunt Completed! 16 September 2010
Source:Mad Hatter's Bookshelf and Book Review Interview - 17 September 2010
Blog: Guest Blogging, Babel Clash, Interviews, Authorpalooza Tommorow, and TOWERS OF MIDNIGHT Tour 17 September 2010
Source:Book Signing, Orem Library, Orem, UT 21 September 2010 - Tamyrlin reporting
Blog: TOWERS OF MIDNIGHT Prologue ebook Released + Updates + Orem Library 21 September 2010
Blog: Registering for Worldcon, TOWERS OF MIDNIGHT News, Inkwing T-Shirt + Updates 28 September 2010
Blog: Tower Guard program + Signed & Numbered TOWERS OF MIDNIGHT 30 September 2010

Source:Chat with Brandon - 4 October 2010
Blog: Robert Jordan Memorial Scholarship Winner + Updates 4 October 2010
Source:New York ComicCon 9 October 2010 - WinespringBrother reporting
Blog: Another Long and Rambling Post on Future Books 12 October 2010
Blog: TOWERS OF MIDNIGHT Preorders, Tower Guard, Trailer 18 October 2010
Source:Grasping for the Wind Interview: Brandon Sanderson on Towers of Midnight 19 October 2010
Blog: Updates, Interview, & Superstars Writing Seminar 26 October 2010
Dragonmount Interview with Brandon by Luckers 26 October 2010

Source:Towers of Midnight Book Tour, BYU Bookstore, Provo, UT 2 November 2010 - jemron reporting
Towers of Midnight Book Tour, BYU Bookstore, Provo, UT 2 November 2010 - Tamyrlin reporting
Source:Towers of Midnight Book Tour, Barnes and Noble, Sacramento, CA 2 November 2010 - Frenzy reporting
Source:Towers of Midnight Book Tour, Barnes and Noble, Sacramento, CA 2 November 2010 - Tower Guards reporting
Source:Towers of Midnight Book Tour, Joseph-Beth Booksellers, Cincinnati, OH 3 November 2010 - Maji reporting
Source:Towers of Midnight Book Tour, Joseph-Beth Booksellers, Cincinnati, OH 3 November 2010 - Res_Ipsa reporting
Source:Towers of Midnight Book Tour, Joseph-Beth Booksellers, Cincinnati, OH 3 November 2010 - Tower Guards reporting
Source:Towers of Midnight Book Tour, Border's, Dallas, TX 4 November 2010 - Catherine Sedai reporting
Source:Towers of Midnight Book Tour, Border's, Dallas, TX 4 November 2010 - Chris Treco reporting
Towers of Midnight Book Tour, Books A Million, Hanover, MD 5 November 2010 - frenchie reporting
Source:Towers of Midnight Book Tour, Books A Million, Hanover, MD 5 November 2010 - Tower Guards reporting
Towers of Midnight Book Tour, Border's, Bailey's Crossroads, VA 6 November 2010 - InfamousOne reporting
Source:Towers of Midnight Book Tour, Border's, Bailey's Crossroads, VA 6 November 2010 - Tower Guards reporting
Source:Towers of Midnight Book Tour, Harvard Coop, Cambridge, MA 7 November 2010 - Hilwa Katir reporting
Source:Towers of Midnight Book Tour, Harvard Coop, Cambridge, MA 7 November 2010 - kamarile reporting
Source:Towers of Midnight Book Tour, Harvard Coop, Cambridge, MA 7 November 2010 - RDDK reporting
Source:Towers of Midnight Book Tour, Harvard Coop, Cambridge, MA 7 November 2010 - Zaela Sedai reporting
Source:Towers of Midnight Book Tour, Barnes and Noble, New York, NY 8 November 2010 - joe heron reporting
Source:Towers of Midnight Book Tour, Barnes and Noble, New York, NY 8 November 2010 - lord Mordeth reporting
Source:Towers of Midnight Book Tour, Barnes and Noble, New York, NY 8 November 2010 - Sarayne reporting
Towers of Midnight Book Tour, Barnes and Noble, New York, NY 8 November 2010 - WinespringBrother reporting
Source:Twitterfest Summary 9 November 2010
Utopiales interview, Nantes, France, 10-14 November 2010
Source:New Zealand Herald Interview, 13 November 2010
Source:Towers of Midnight Book Tour, WH Smith, Paris, France 16 November 2010 - Jonathan B reporting
Blog: Order a personalized THE GATHERING STORM + Holiday shipping deadlines 18 November 2010

Blog: Questions, 30% Off Sale, Signings, Awards & Updates 6 December 2010
Goodreads Fantasy Book Club Q&A with Brandon, 14 December 2010
Source:The Fringe Magazine Interview, 23 December 2010
Source:Stormblessed.com Interview, 25 December 2010
Blog: Interviews, Gemmell Award Nominations, Annotation 27 December 2010
### 2011

Brandon's Wheel of Time Reread - 3 January 2011
Brandon's Wheel of Time Reread - 4 January 2011
Brandon's Wheel of Time Reread - 5 January 2011
Source:Goodreads Fantasy Book Club Q&A with Brandon, 5 January 2011
Brandon's Wheel of Time Reread - 6 January 2011
Blog: Wrapping Up My Time Off 6 January 2011
Brandon's Wheel of Time Reread - 7/8 January 2011
Source:Tor.com Q&A - 10 January 2011
Brandon's Wheel of Time Reread - 10 January 2011
Brandon's Wheel of Time Reread - 11/12 January 2011
Brandon's Wheel of Time Reread - 17 January 2011
Brandon's Wheel of Time Reread - 18-21 January 2011
Blog: For Your Nomination Consideration + Worldcon Deadline 26 January 2011

Source:ConDFW, Dallas, TX - 17-21 February 2011
Source:Reddit Fantasy Bookclub Q&A with Brandon Sanderson 28 February 2011

Blog: Reader Poll + Updates 7 March 2011
Blog; Suvudu Cage Matches 8 March 2011
Q&A with Maria Simons about Verin 11 March 2011 - Matt Hatch reporting
Blog: Wheel of Time Shirts 16 March 2011
Source:Goodreads Fantasy Book Club Q&A with Brandon, 17 March 2011
Blog: Hugo Nomination Deadline Tomorrow 25 March 2011
Blog: Tsunami Relief Auctions, Writing & Illustrating for Young Readers + Updates 28 March 2011

Blog: Name Auction Coming, Music + Updates 4 April 2011
Blog: My JordanCon Schedule + Updates 13 April 2011
JordanCon 15-17 April 2011 - WinespringBrother reporting
AMOL Status Report, JordanCon 16 April 2011 - Marie Curie reporting
JordanCon Book Signing 17 April 2011 - Terez reporting
Driving Mr. Sanderson 17 April 2011 - Terez reporting

Blog: Gemmell Awards Nominations + Updates 9 May 2011
Pancakes and Fries Meet, Amsterdam 30 May 2011 - Isabel reporting
Pancakes and Fries Meet, Amsterdam 30 May 2011 - jarno87 reporting
Pancakes and Fries Meet, Amsterdam 30 May 2011 - yks reporting

Source:European Book Tour, Forbidden Planet, London, England 4 June 2011 - Thomas C reporting
Blog: THE WAY OF KINGS WIns the David Gemmell Legend Award 22 June 2011

Polaris, Toronto, Canada 16 July 2011 - herid reporting
Blog: Q&A Recording, T-Shirts & Updates 19 July 2011

Source:SciFi Bulgaria Interview with Brandon Sanderson 1 August 2011
Source:Book Signing, West Jordan, UT 4 August 2011 - Josh and Mi'chelle reporting
## Peter Ahlstrom
**Peter Ahlstrom** is Brandon's assistant, and handles much of the day-to-day maintenance of his website, answering communications, and posting prewritten blog posts when Brandon is on tour. He is on Twitter at @PeterAhlstrom.

## Notes


## External links

 
### Interviews

 Podcast from www.iscifi.tv





https://wot.fandom.com/wiki/Brandon_Sanderson