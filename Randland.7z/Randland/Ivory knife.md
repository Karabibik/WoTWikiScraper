---
tags: [Angreal, ItemsofPower]
---
The small, carved **Ivory knife** is an *angreal* aligned to *saidar*. After [[Graendal]] lost her [[Little Gold Ring]] *angreal* during the destruction of [[Natrin's Barrow]], she obtained this new *angreal* by [[Mesaana]] trading it with precious informations.
It is not known how strong this *angreal* could be, most probably not much, but still enough to step Graendal up over the top male level of strength.

## Speculation
After the [[Last Battle]] and the capture of Graendal/[[Hessalam]] it can be assumed that now the ivory knife is in [[Aviendha]]'s possession.






https://wot.fandom.com/wiki/Ivory_knife