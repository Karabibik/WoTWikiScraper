---
tags: [Altara, Illian, Gulfsandbays]
---

**Kabal Deep** is a large bay or gulf that stretches between the southernmost peninsulas of [[Altara]] and [[Illian]]. The gulf is famed for its extreme depth, with sailors reporting not being able to touch bottom with their longest sounding lines just a few miles offshore. The mouth of the gulf is reported to be over one hundred leagues wide, stretching between [[Arran Head]] and the city of [[Illian (city)|Illian]] itself.
The deep is particularly harshly affected by the *cemaros*, the storms that ravage the south coast of the [[Westlands]] during the winter.






https://wot.fandom.com/wiki/Kabal_Deep