---
tags: [Terangreal, ItemsofPower, AgeofLegends]
---
The **dreamspike** is a *ter'angreal* made during the [[Age of Legends]].

## Contents

1 Appearance
2 Use
3 Recent uses
4 Notes


## Appearance
A dreamspike is a large, spike-like piece of silvery metal that is topped with a large metal head and set with golden inlay. 

## Use
The *ter'angreal* seems to make a type of barrier both in *Tel'aran'rhiod* and in the waking world, though the purple dome it creates can only be seen in the world of dreams. The dome has an adjustable radius, presumably up to several leagues, when active, with the Dreamspike at its center. Touching the barrier in *Tel'aran'rhiod* drains the energy from a person and can likely kill them.
The barrier prevents instant transportation in or out of it in both worlds. In *Tel'aran'rhiod*, willing oneself to be on the opposite side of the barrier simply fails to work.  One quirk of this is that if a person holds the activated Dreamspike in *Tel'aran'rhiod*, he or she can still move beyond the dome with relative ease, by willing oneself just to the inner edge of the barrier, at which point the dome will instantly reorient to the Dreamspike's new location, freeing up travel to locations that were beyond the barrier's previous perimeter.
In the waking world, [[Traveling]] is useless except for those who are allowed by the user of the Dreamspike; gateways of all forms simply fail to form. This allows the Dreamspike to be used to protect oneself from hostile channelers, who will be unable to Travel to the user; it can also be used to trap a channeler in place by disabling the ability to Travel.  However, the Dreamspike does this not by making it absolutely impossible to open a gateway, but rather by imposing a huge amount of resistance; [[Androl Genhald]], a channeler with an exceptional [[Talent]] for gateways, was capable of opening a pinhole-sized gateway within a Dreamspike's area of influence, through which his cry for help was heard.
The dreamspike is also indicated to have the ability to protect the owner's dreams, though how this functions is never shown. It may protect the dreams of the one controlling the dreamspike specifically, or it may simply block interaction with the dreams of those who sleep within the protected area. In either case, however, it does not block those within the barrier from entering or using the World of Dreams.
A dreamspike's other unique property is its interaction with *Tel'aran'rhiod. *Though it is a physical object and is inside the waking world when inactive, when triggered it disappears from the waking world and plants itself in *Tel'aran'rhiod*.
Each dreamspike is associated with the specific "key", presumably a mental command code, that can be used to disable or counteract that specific dreamspike (e.g. to Travel from and to the protected area). It can be manually (a key is not necessary) disabled by twisting the top, then re-enabled by twisting again, twisting is used also to set the radius of the dome covered by the spike.

## Recent uses
[[Moridin]] is shown to own two dreamspikes. He lends one to [[Graendal]] in order to have [[Slayer]] use it to kill [[Perrin Aybara]], but Perrin eventually finds it in the Wolf Dream and destroys it.
Occurrences at the [[Black Tower]] suggest that the other dreamspike is posted there as no one in the area is able to create gateways. It is likely that Moridin gave the *ter'angreal* to [[Mazrim Taim]] to use. When Perrin hears of trouble in the Black Tower concerning [[Travelling]], he enters *Tel'aran'rhiod* and finds the *ter'angreal*. [[Cyndane]] shows him how to use the Dreamspike in alternative to destroying it. Perrin then uses the dreamspike to protect the Pit of Doom when [[Rand al'Thor|Rand]] is inside.

## Notes








https://wot.fandom.com/wiki/Dreamspike