---
tags: [Men, BandoftheRedHand, Soldiers, LivingasofKOD, ]
---


**Connl** is a soldier in the [[Band of the Red Hand]].

## Activities
While in [[Altara]], he is one of the Band members who engage a [[Seanchan]] unit in an ambush, wiping out the whole contingent with just about no casualties.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Connl