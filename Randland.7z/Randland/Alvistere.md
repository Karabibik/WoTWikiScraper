---
tags: [Women, Cairhien_people, Novices, LivingasofKOD, ElaidaaRoihansWhiteTower, Channelers]
---


**Alvistere** is a [[Novice|novice]] in the [[White Tower]].

## Appearance
She is short and slim with long dark hair. She has pale skin.

## History
She is from [[Cairhien]].

## Activities
She trips [[Egwene al'Vere]] up in the dining hall. Egwene rounds on her and embarrasses her.
She tries to emulate Egwene's behavior in classes, and after a string of beatings from [[Silviana Brehon]] cuts it out.






https://wot.fandom.com/wiki/Alvistere