---
tags: [Women, GrayAjah, AesSedai, LivingasofACOS, RandsAesSedai, MiddleRankingAesSedai, Unalignedsisters, Channelers]
---


**Niande Moorwyn** is an [[Aes Sedai]] of the [[Gray Ajah]].

## Contents

1 Appearance
2 Abilities
3 History
4 Activities
5 Notes


## Appearance
She is pale-haired and plump, with a sharp nose and inquisitive gray eyes.

## Abilities
Niande is not particularly strong in the [[One Power]]. Her level of strength is described by "The Wheel of Time Companion" as 27(15) which is a middle level in Aes Sedai hierarchy. With this level of strength she is unable to open alone a suitable [[Gateway|gateway]] to [[Travel]]. 

## History
Niande is 149 years old, she was born in 851 NE and went to the Tower in 867 NE. After thirteen years as [[Novice|novice]] and twelve as [[Accepted]] she was raised to the shawl in the year 892 NE. 
Niande has one [[Warder]].

## Activities
She was [[Aes Sedai advisors|advisor]] to King [[Galldrian]] of [[Cairhien]]. During this period she kept a low profile and was known to have visited the country estate of Lady [[Arilyn Dhulaine]] more than once.
She figured out that [[Thom Merrilin]] had killed Galldrian; while she understood why, as Galldrian had had Thom's apprentice [[Dena]] killed, she was displeased with him at all the suffering it had caused Cairhien. To everyone in Cairhien, she seemed to vanish after Galldrian's death. She was later coopted by Cadsuane. 
She is with [[Cadsuane Melaidhrin]] and [[Samitsu Tamagowa]] in the rebel camp outside [[Cairhien]] when a [[Bubble of evil|bubble of evil]] erupts forcing them to flee all the while protecting an unconsious [[Rand al'Thor]] who was stabbed by [[Padan Fain]] with the [[Shadar Logoth]] [[Ruby-hilted dagger|dagger]]. When Min told of three sisters being stilled by Rand at Dumai's Wells, Niande and Samitsu vomit over the sides of the carriage they are in.
After it Niande helped Cadsuane to bring Rand safely to the [[Sun Palace]]. She reads while watching over Rand. When Asha'man walk in, she becomes disconcerted and drops her book. 
When Cadsuane left Cairhien to [[Far Madding]], in search of Rand, she left behind Niande along [[Samitsu]] and other [[Unaligned sisters|unaligned sisters]].

## Notes






https://wot.fandom.com/wiki/Niande