---
tags: [Men, Shienar_people, Generals, LivingasofAMOL, Lords, FiveGreatCaptains, Nobility]
---


**Agelmar Jagad**, Lord of [[Fal Dara]], is the nephew of King [[Easar]] of [[Shienar]], brother to [[Amalisa Jagad]], and commander of Shienar's armies. He is one of the [[Five Great Captains]] of the [[Westlands]]. 


## Contents

1 Appearance
2 Activities

2.1 Meeting the Lord of Fal Dara
2.2 The Tarwin's Gap Battle-front


3 In the television series
4 Notes


## Appearance
He has a hard face with lines only at the corners of his eyes, which are like brown stone. He wears a topknot of pure white. His banner consists of three running red foxes on a field quartered blue and white.

## Activities
### Meeting the Lord of Fal Dara
On their way to the [[Eye of the World]], [[Moiraine Damodred]] and [[Lan Mandragoran]] lead [[Rand al'Thor]], [[Matrim Cauthon]], [[Perrin Aybara]], [[Egwene al'Vere]], and [[Nynaeve al'Meara]] to Fal Dara and meet with Agelmar. Moiraine advises him to send men to wall up the Fal Dara [[Waygate]]. [[Padan Fain]] is caught trying to sneak into Fal Dara and brought before Agelmar. He offers to advise Agelmar on how to defeat the [[Dark One]], but Agelmar refuses to listen.
After the party returns with the [[Horn of Valere]], Moiraine asks Agelmar for an escort to carry it to [[Illian]]. Agelmar gives the Horn to [[Siuan Sanche]] when she arrives in Fal Dara, but the city is attacked by [[Trolloc|Trollocs]], and Fain is released from his cell and steals the Horn. He sends a company of men, led by [[Ingtar Shinowa]], with Rand as his second-in-command, to retrieve the Horn. Once the Horn is retrieved, Rand proclaims himself the [[Dragon Reborn]] and most of the Shienarans pledge themselves to him, claiming that the Dragon Reborn has freed them from their old oaths. Only [[Hurin]] returns to Shienar.
He accompanies Easar to a meeting with the rest of the Borderland rulers.

### The Tarwin's Gap Battle-front
At the [[Field of Merrilor]], [[Elayne Trakand]] sets up an initial war council. There it is decided that Agelmar will lead the Borderlander armies at [[Tarwin's Gap]], lending Lan's forces aid. Agelmar informs Lan that due to the army starting to become too fatigued, they are going to have to pull out of the Gap, and slowly retreat back across Shienar. Lan is not impressed at leaving [[Malkier]] behind. Lan finally accepts the generals decision after having a duty as a commanding officer to his men thrown back in his face. Agelmar begins organizing the retreat from the Gap when [[Dreadlords]] join the fight and start pummeling the army with the [[One Power]]. Elayne sends a message to Lan's camp that they are to burn [[Fal Dara]] and every other city in Shienar as they slowly retreat back. Lan leads a quick hit and run skirmish on the following Trolloc army. When the starving Trollocs move to eat the wounded and dead, Agelmar gives the order to hit the Trollocs again while they are not ready. 
Lan confronts Agelmar when he is given some information from Lord [[Baldhere]]. Lan asks about the loss of [[Kayen Yokata]]'s entire squadron. Agelmar brushes it off as a mistake and tells him to either relieve him of duty or leave him alone. He and the other Great Captains were influenced by [[Graendal]]'s [[Compulsion]] during the course of the [[Last Battle]]. He refused to assume command again.

## In the television series
In the television series, Lord  
## Notes






https://wot.fandom.com/wiki/Lord_Agelmar