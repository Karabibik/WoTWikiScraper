---
tags: [Swordforms]
---




**Folding the Fan** is a [[Sword form|sword form]] used to sheathe a swordsman's weapon. It is typically used at the end of another form. After killing an unnamed woman and her companions in the [[Murandy|Murandian]] hills, [[Rand al'Thor]] started to sheathe his blade woven from *saidin* with Folding the Fan, forgetting he had neither scabbard nor steel.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Folding_the_Fan