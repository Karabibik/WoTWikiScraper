---
tags: [Women, Aiel_people, Goshien, FarDareisMai, LivingasofTOM, POVcharacter]
---




**Sulin** is a [[Maiden of the Spear]] of the [[Goshien]] [[Aiel]].

## Contents

1 Appearance
2 Activities

2.1 To Caemlyn
2.2 Made a maid
2.3 Malden
2.4 Encounter with the Whitecloaks


3 Correction


## Appearance
Sulin has sharp, pale blue eyes and white hair. She is wiry and leather faced, with a scar across one cheek.

## Activities
### To Caemlyn
Sulin leads the Maidens in protecting [[Rand al'Thor]] and sees him as a [[First-brother|first-brother]]. She serves as [[Roofmistress|roofmistress]] for the roof of the Maidens while in [[Rhuidean]], then relinquishes that position to lead the Maidens who accompany Rand. She continues to guard him during the battle with the [[Shaido]] outside [[Cairhien]] in which she receives an injury. Sulin confronts Rand about not allowing the Maidens to attack [[Caemlyn]] while all the other Aiel [[Aiel warrior societies|societies]] do. She tells him that Far Daries Mai no longer have [[Ji'e'toh|honor]]. Rand then agrees to take the Maidens into battle and Sulin goes with him on his attack of [[Rahvin]].

### Made a maid
After Rand takes over Caemlyn, [[Loial]]'s mother, [[Covril]], turns up with [[Elder Haman]] and [[Erith]] (a female [[Ogier]] who loves Loial); Rand takes them to [[Shadar Logoth]] (where they lose a Maiden called [[Liah]]) through a [[Gateway|gateway]] before taking them to the [[Two Rivers]] to find Loial.
First Sulin tells Rand that he needs an escort. Rand tells her to assemble that escort as quickly as possible. Sulin speaks to a *gai'shain* as she would a Maiden and in doing so she earns *toh*. To meet her *toh*, after her return to Caemlyn, Sulin becomes a maid in the [[Royal Palace of Andor|Royal Palace]]. She works as a maid for over a month and a half, but rejoins the Maidens when Rand is kidnapped by the [[White Tower]]. Sulin orders her *cadin'sor* back and organizes the Maidens for a rescuing mission. Both she and [[Nandera]] attempt to lead the Maidens, which culminates in a fight between the two. Although Sulin wins the power struggle, Nandera appears to continue leading the Maidens afterwards. Sulin participates in the [[Battle of Dumai's Wells]].
Sulin accompanies Rand into Cairhien's Throne Room when he confronts [[Colavaere Saighan]] about taking the [[Sun Throne]] for herself. She then goes with him to Caemlyn. Since Rand's capture she has become very protective of him.

*"The Aes Sedai have taken my first-brother!"*
   —*Lord of Chaos*, Chapter 53 
### Malden
Sulin Travels to [[Ghealdan]] with [[Perrin Aybara]] and his army to track down [[Masema Dagar]].
She tries to track [[Faile Bashere]], [[Chiad]], and [[Bain]] when they are captured by the Shaido.
Sulin is among the Maidens who meet Perrin when he sets out to view the Shaido camped in [[Malden]].
She is present when Perrin questions the Shaido being held prisoner, looking for answers about his missing wife.
Sulin comes back with a fresh slash on her face after killing the Shaido sentries around Malden, just before Perrin's combined attack with the [[Seanchan]].

### Encounter with the Whitecloaks
While traveling from Malden, Sulin scouts a village in the middle of Ghealden that seems to be affected by the [[Blight]]. She comes to Perrin with the news that there are [[Children of the Light]] camped up ahead. She is part of Perrin's group that meet with [[Galadedrid Damodred]] to discuss parley with the Whitecloaks.
Sulin is present during [[Seonid Traighan]]'s report to Perrin on current events that are happening within the continent. She confirms that Rand battled Rahvin in Andor, causing [[Morgase Trakand]] to drop her tray in shock. While she is in camp a [[Bubble of evil|bubble of evil]] erupts causing all the weapons to attack their owners. Sulin's own spears attack her and she manages to rend them inanimate again by throwing soil on them.
Perrin charges her and the other Maidens to scout the area around camp the day of Perrin's trial. After Perrin's army withdraws through a gateway, she is sent back through to check on the Whitecloak camp and see where they are. She arrives back to observe Perrin create *Mah'alleinir*. She is part of Perrin's procession when they meet with [[Elayne Trakand|Elayne]] in Caemlyn.

## Correction
In the first printing of *The Gathering Storm*, Sulin is listed as being one of the Maidens to scout ahead at [[Natrin's Barrow]] after Lord [[Ramshalan]] has gone through to deliver Rand's emissary to [[Graendal]]. However, this is incorrect as she remains with Perrin. The Maiden who should be said to scout out Natrin's Barrow is [[Nerilea]], as it now says in the e-book version.






https://wot.fandom.com/wiki/Sulin