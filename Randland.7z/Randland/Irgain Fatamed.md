---
tags: [Women, GreenAjah, AradDoman_people, AesSedai, LivingasofWH, RandsAesSedai, Cairhienexpedition, MiddleRankingAesSedai, Channelers]
---


**Irgain Fatamed** is an [[Aes Sedai]] of the [[Green Ajah]].

## Contents

1 Appearance
2 Abilities
3 History
4 Activities

4.1 The Last Battle


5 Notes


## Appearance
She has bright blue eyes.

## Abilities
Her strength in the [[One Power]] is unknown, but given the amount of time spent in training (12 years), it can be assumed that she is moderately strong and probably a middle-high ranking sister.

## History
Irgain was born in 931 NE and went to the [[White Tower]] in 946 NE. After spending six years as a [[Novice|novice]] and six years as [[Accepted]] she was raised to the shawl in 958 NE.

## Activities
She has remained loyal to the [[White Tower]] during the split.
Irgain was one of the [[Aes Sedai]] involved in kidnapping [[Rand]]. She was [[Shielding|shielding]] him along with [[Ronaille Vevanios]] and [[Sashalle Anderly]] when the Battle at [[Dumai's Wells]] occurred. They were all [[Stilled|stilled]] when [[Rand]] broke the [[Shield|shield]] . Irgain's two [[Warders]] were also killed during the battle. She was taken prisoner soon after by the [[Aiel]] [[Wise Ones]]. They used mild manners with her because for them her stilling was a sufficient punishment.
Irgain was [[Healed]] by [[Damer Flinn]], who was also able to Heal [[Ronaille Vevanios|Ronaille]] and [[Sashalle Anderly|Sashalle]], restoring them to full strength in the [[One Power]]. They have all since sworn fealty to [[Rand]].

### The [[Last Battle]]
It can be assumed that Irgain, along with the other [[Dragonsworn]] Aes Sedai in Cairhien, fought in the Last Battle. Lacking other information, she is presumed alive. It is likely that she has resworn the Three Oaths and was officially reinstated as a sister since the Last Battle.

## Notes






https://wot.fandom.com/wiki/Irgain_Fatamed