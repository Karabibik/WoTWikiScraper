---
tags: [Men, Saldaea_people, Soldiers, Deceased, ]
---


**Adrin** was a [[Saldaean]] guard under [[Davram Bashere]].

## Appearance
Adrin was a large, handsome man who had fine hair.

## Activities
During [[Rand]]'s stay at the Domani manor house, while guarding the front of the manor house with another of [[Davram Bashere]]'s soldiers, [[Aviendha]] witnessed Adrin complain about the heat. His companion thought he must be joking, or feverish. Minutes later, he burst into molten tar and gave off an intense heat and things near him started to burst into flame, including the manor itself. Aviendha moved the other guard away from danger and began to redirect the nearby stream to quench the heat. The [[Asha'man]] [[Naeff]] used the one power to aid her diversion of the stream to quench the fire and the charred leftover of Adrin's body. Rand then appears and is angered that the Dark One seemed to be striking at Rand but missed, hitting a guard instead. Likely, this was not a direct attack at Rand or anyone, but rather a [[Bubble of evil|bubble of evil]].

## Notes






https://wot.fandom.com/wiki/Adrin