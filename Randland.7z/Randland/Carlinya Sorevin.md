---
tags: [Women, WhiteAjah, Kandor_people, AesSedai, Deceased, RebelAesSedai, HighRankingAesSedai, AjahHeads, Channelers]
---


**Carlinya Sorevin** was an [[Aes Sedai]] of the [[White Ajah]].

## Contents

1 Appearance and Abilities
2 History
3 Activities

3.1 Split from the Tower
3.2 The Tower reunited


4 Viewing
5 Notes


## Appearance and Abilities
Carlinya was 5'5 tall, pale, with cool, almost black eyes and a broad face. After most of her dark hair was fried off in a [[Tel'aran'rhiod|tel'aran'rhiod]] nightmare she wore it in a cap of dark curls. She was of moderate build, neither slender nor stout.
She was somewhat messy, her hair sometimes being unkempt and her dress edge muddy from forgetting to wear a cloak. She owned a pale embroidered skirt. 
She often dressed in white with white embroidery.
She had a cold manner.
Carlinya was strong in the [[One Power]] by Aes Sedai standard; she was strong more than enough to [[Travel]] and was described as being on the same level as [[Anaiya]], [[Myrelle Berengari]] and other women on the [[Salidar Six]] except [[Sheriam Bayanar|Sheriam]].
This is confirmed by "The Wheel of Time Companion" where her level of strength is described as 15(3).

## History
Carlinya was 46 years old. She was born in the year 954 NE in [[Kandor]] and went to the Tower in 969 NE. After spending five years as Novice and five as Accepted she was raised to the shawl in the year 979 NE.
She was rational to a fault, and disliked being disagreed with.
As a novice, Carlinya made sure to commit one minor infraction per month so that she would not be thought to be stuck up. She could not understand why the other novices and Accepted still thought of her as a prig. [[Siuan Sanche]] thought that she had "a great deal of logic and not much common sense: that was Carlinya."
She was an [[Accepted]] in the [[White Tower]] during the [[Aiel War]] when the [[Dragon]] was reborn.
She held as much sway as most [[Sitter|Sitters]] even before the [[White Tower Schism|White Tower schism]].
She had no [[Warder]], but she considered taking one towards the end of her life.

## Activities
### Split from the Tower
Carlinya was one of her Ajah representatives to escort the [[Amyrlin]] to [[Fal Dara]]. Carlinya was in the anteroom during Moiraine's audience with Siuan.
Carlinya returned to Tar Valon by way of [[Medo]] with the rest of the Amyrlin's entourage.
She allied herself with the [[Rebel Aes Sedai|rebel Aes Sedai]]; in fact, she was one of its earliest supporters and instigators, becoming one of its original six leaders, informally known as the [[Salidar Six]]. They began planning to select an Amyrlin and Sitters and then move against Elaida. When Gareth Bryne arrived they gave him Siuan and Leane as personal maids. He agreed to build them an army.
The Salidar Six met with Elayne and Nynaeve when they arrived in Salidar. They learned that Elaida already knows about Salidar.
Sheriam, Anaiya, Beonin, Carlinya, Morvrin and Myrelle kept Elayne and Nynaeve busy at night with trips to *Tel'aran'rhiod*.
Later, when searching the [[Amyrlin's Study]] in *Tel'aran'rhiod* for information on what [[Elaida do Avriny a'Roihan]] had received, the Salidar Six were attacked by a stray nightmare of [[Trolloc|Trollocs]]. They were saved when [[Elayne Trakand]] and Siuan had to remind them about the dream not being real, in which case the nightmare faded away leaving only injury. In particular Carlinya burned away a lot of her hair.
Nynaeve eavesdropped while Tarna Feir met with Sheriam, Anaiya, Beonin, Carlinya, Morvrin and Myrelle in the Little Tower. They told her they need more time to consider Elaida's offer.
Carlinya suggests to the Wise Ones that they are holding Egwene against her will. They put snakes in her dress for the insult. 
Nynaeve and Elayne told Sheriam, Carlinya and Morvrin about finding the Bowl of the Winds. The Aes Sedai told them in no uncertain terms that they will stay in Salidar and study. Nynaeve blew up earning them extended kitchen duty.
She brought Siuan and [[Leane Sharif]] into the [[Little Tower]] to be [[Healing|Healed]] from [[Stilling|stilling]] by [[Nynaeve al'Meara]].
She was with the rest of the Salidar Six in *Tel'aran'rhiod* when they summoned [[Egwene al'Vere]] to become Amyrlin Seat.
Sheriam and her circle prepared Egwene for the election ceremony. Sheriam, Morvrin and Myrelle accompanied Egwene to the Little Tower while Anaiya, Beonin and Carlinya waited outside.
Sheriam, Anaiya, Beonin, Carlinya, Morvrin and Myrelle kepy Egwene up half the night telling her what they think is important.
Carlinya, Sheriam, Lelaine and Romanda wanted Logain gentled again. Delana wants him killed.
Carlinya was one of Sheriam's group that sent ten sisters, two of each Ajah other than Blue, back to the White Tower as moles, without informing the Hall . For this reason she had to swore an oath of fealty to Egwene; later she became a member of [[Egwene's Council]].
Egwene sent Sheriam, Carlinya, Morvrin and Nisao to talk to the Sitters in preparation for the meeting with the Andoran nobles.
The sisters who swore fealty to Egwene were still unsettled by it. Carlinya started and looked embarrassed every time she saw Egwene.
She was with Egwene and [[Gareth Bryne]] when they surveyed the area around [[Tar Valon]]. Carlinya is annoyed when she heard that Saroiya supported negotiations.. Egwene and her party return to the rebel Aes Sedai camp. Her Council members went to report to their respective Ajahs.
Egwene's Council accompanied her to the meeting of the Hall. Carlinya gave advice on what the Sitters might do.

### The Tower reunited
She was in council with Egwene's other advisers over Egwene's disappearance when Siuan arrived with the news that Egwene was still alive but prisoner inside the White Tower.
After the Tower was reunified, she was part of a plot to catch the [[Black Ajah]] in *Tel'aran'riod*. The Black Ajah got a preemptive strike on the White Tower Aes Sedai and their allies. Carlinya was one of the sisters killed at the beginning of the battle.

## Viewing
In Salidar, Min saw a black raven tattoo floating by Carlinya's face. It has since been confirmed by Maria Simons that as the raven is a symbol of the Dark One, this viewing represents her being killed by his servants (*fulfilled *- her death in *Tel'aran'rhiod* at the hands of the Black Ajah).

## Notes






https://wot.fandom.com/wiki/Carlinya