---
tags: [Swordforms]
---






**The Wind Blows Over the Wall** is a [[Sword form|sword form]]. Other than the name, nothing is known about it. [[Rand al'Thor]] used this form to cut off a [[Gray Man]]'s hand before driving a *saidin*-wrought sword through his opponent's heart.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Wind_Blows_Over_the_Wall