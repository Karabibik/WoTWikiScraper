---
tags: [, Terangreal, Parallels, ItemsofPower, EbouDariStash]
---



The **blue woman** figurine is a *ter'angreal* recovered from the [[Kin's Store Room]] in [[Ebou Dar]].

## Contents

1 Appearance
2 Use
3 Parallels
4 Notes


## Appearance
The blue figurine is small enough to fit in the palm of a hand and is dressed in an oddly cut skirt and coat.

## Use
This *ter'angreal* can supposedly be used to speak to people over great distances, much like the [[Black and white bird|black and white bird]].

## Parallels
The blue woman is the parallel of several long-distance communication devices, but most foremostly of the telephone.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Blue_woman