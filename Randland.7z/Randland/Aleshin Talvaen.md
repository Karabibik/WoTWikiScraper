---
tags: [Men, Ghealdan_people, Lords, Generals, Nobility]
---


Lord **Aleshin Talvaen** was a [[Ghealdan|Ghealdanin]] general during the [[Aiel War]] and a member of the [[Crown High Council]]

## History
Lord Talvaen was the leader of the Ghealdanin contingent during the [[Battle of the Shining Walls]]

## Recent Activities
Lord Talvaen was flogged by [[Masema]] for having expressed contempt about some word from the Lord [[Dragon]].






https://wot.fandom.com/wiki/Aleshin_Talvaen