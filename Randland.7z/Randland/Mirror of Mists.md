---
tags: [Weaves]
---




The **Mirror of Mists**, called also **Illusion** and known as the **Mask of Mirrors** in [[Age of Legends]], has several functions, each performed by a variation of the weave. The effect of this [[Weave|weave]] is the ability to alter one's appearance.
It has been reported that according to an interview, this weave can also be used to alter one's voice.

## Occurrences
Sometimes called an illusion by [[Aes Sedai]], it was used by [[Moiraine Damodred]] to make herself appear tall enough to step over a defensive wall.
Moiraine uses a variation of this called [[Folded Light]], along with several [[Ward|wards]] to render her party invisible when they make camp in the [[Great Blight|Blight]]. 
The [[Forsaken]] often use this weave as part of their assumed identities to infiltrate the upper echelons of various world governments and institutions, usually impersonating their unfortunate victims.  The only Forsaken not known to regularly use the weave is [[Ishamael]].
[[Lanfear]] disguises herself as Selene, [[Else Grinwell]] and Keille Shaogi using this weave.
[[Asmodean]] teaches this to [[Rand al'Thor]] which the Aes Sedai embassy from the White Tower try to use when confronting him.  And it is possible that he turned [[Egwene al'Vere]] invisible by using this weave or a similar one.
[[Mesaana]] often uses this weave to mask her voice and to make her look like she is made of silver.
[[Sammael]] and [[Graendal]] disguise themselves with the Mask of Mirrors when they visit [[Sevanna]]. 
Rand disguises himself with the Mask of Mirrors when he and [[Elmindreda Farshaw|Min Farshaw]] go to [[Caemlyn]] to pick up [[Nynaeve al'Meara]]. 
[[Semirhage|Semirhage's]] disguise as the[[Daughter of the Nine Moons| Daughter of The Nine Moons]] is disrupted by [[Cadsuane|Cadsuane's]] set of [[Ter'angreal|ter'angreal]]. She was using the Mirror of Mists.
As part of [[Amyrlin Seat]] Egwene al'Vere's efforts to smoke out Mesaana, [[Seaine Herimon]] and [[Doesine Alwain]] worked out that the Mirror of Mists can be used to affect what a person is saying into making the listener hear something else entirely.
[[Elayne Trakand]] tries to get information from [[Chesmal Emry]] by disguising herself as one of the [[Forsaken]].
Throughout the series [[Moghedien]] also disguises herself, once as Gyldin, another time as [[Demandred]] and one last time before being caught as a worker she had strangled.
Early during the Last Battle, Rand uses it to disguise himself as [[Jur Grady]] so that he could take part in one of the battles without drawing the attention of the Forsaken, and so that Jur could rest.

## Notes






https://wot.fandom.com/wiki/Illusion