---
tags: [Women, BrownAjah, AesSedai, LivingasofKOD, RebelAesSedai, LowRankingAesSedai, Channelers]
---


**Phaedrine** is an [[Aes Sedai]] of the [[Brown Ajah]].

## Contents

1 Appearance
2 Abilities
3 Activities
4 Notes


## Appearance
She is lean and small-boned, with dark hair and brown eyes. Much like the Brown Ajah stereotype, she tends to allow her low quality clothing to fall into disrepair, with tears and stains. She might be considered pretty if not for how much she frowns.

## Abilities
Pahedrine is relatively weak in the [[One Power]]. Her level of strength is described by "The Wheel of Time Companion" as 35(23) which is a quite low level in Aes Sedai hierarchy.
Thus she is not strong enough to open alone a [[Gateway|gateway]] to [[Travel]]. She and [[Shemari]] linked together were just strong enough to make a barely usable gateway.

## Activities
She taught [[Egwene al'Vere]] as a [[Novice|novice]].
She is allied with the [[Salidar Aes Sedai]].
[[Elayne Trakand]] and [[Nynaeve al'Meara]] reported to her upon reaching [[Salidar]].
She is spotted by Egwene leaving the Traveling grounds with [[Shemari]]. They were only just pinning on their cloaks so they must have been somewhere warm or inside.
Phaedrine still seemed surprised that Egwene was [[Amyrlin]]; Egwene kept her face averted to prevent Phaedrine from wading out into the muck to ask if she needed assistance.
She and [[Ashmanaille]] spoke with [[Beonin Marinye]] about how to hunt down whoever murdered [[Anaiya Carel]] and [[Kairen Stang]]. Phaedrine thought that the murderer was a male [[Wilder|wilder]] working in their camp.

## Notes






https://wot.fandom.com/wiki/Phaedrine