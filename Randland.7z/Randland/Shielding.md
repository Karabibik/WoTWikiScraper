---
tags: [OnePower, Weaves]
---
 is the act of forming a weave that will block another channeler from accessing the [[One Power]], though the blocked channeler will still be able to sense it.  During the [[Age of Legends]], the weave was referred to as a *buffer*.  The act of shielding is an incredibly useful tactic when a channeling foe needs to be subdued.
While any person who channels can lay a shield on another, if the one being shielded is much stronger in the power than the other, the shield can be broken through.
A shield placed upon a person who can channel can be tied off and left, though such a weave can eventually be broken by someone with enough patience or pain tolerance. However, the more complex the weaves in the shield are, the harder it is for even another channeler to undo with the power. Shielding weaves can also be made semi-permanent if tied off expertly, but will still eventually break, so is not as final as [[Severing|severing]].
It is possible to be exceptionally talented with shielding. An individual with this talent is able to hold a shield that even a much stronger channeler cannot break through. Instead of breaking, the shield stretches and bends. [[Berowin]] is the only person with this talent that is mentioned in the books, and while her strength is comparable to that of the weakest [[Aes Sedai]], she successfully holds two shields on stronger channelers as [[Nynaeve]] and [[Elayne]], and both at the same time. Berowin claims she would be able to hold a shield even on one of the [[Forsaken]]. Such talent with shielding is either unique to Berowin or extremely uncommon, as it seems Nynaeve was not prepared for it despite her time studying as [[Accepted]]; she considers it impossible. It is unknown if this shield will break eventually.
Traditionally to overwhelm the power of the strongest male channelers (as the [[Dragon Reborn]] or some [[False Dragon]]) it is needed a shield sustained by the power of a full circle of thirteen Aes Sedai and later to hold such shield it is needed a circle of six Sisters.
To maintain a shield over the strongest female channelers usually it is enough a circle of two Aes Sedai. But in the case of the captured Semirhage, Cadsuane decided to use always a circle of three Sisters.

## Notes






https://wot.fandom.com/wiki/Shielding