---
tags: [Books]
---



*The Flame, the Blade and the Heart* is a book of romantic adventure stories. It tells the tales of [[Birgitte]] and [[Gaidal Cain]], [[Anselan]] and [[Barashelle]], and [[Rogosh]] and [[Dunsinin]] among others.
It seems to be a favorite among both young ladies and grown women who like the idea of romance and adventure. [[Aviendha]] lends a copy to [[Egwene]] and [[Romanda Cassin]] considers that her love of such novels would ruin her reputation as an [[Aes Sedai]] and a woman born in [[Far Madding]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Flame,_the_Blade_and_the_Heart