---
tags: [Malkier, Borderlands]
---




The **Seven Towers** refers to the seven towers on the walls of the capital of [[Malkier]], a [[Borderland]] nation lost to [[The Blight]]. The Seven Towers were located alongside some lakes near the [[Mountains of Dhoom]]. Today it's only a broken ruin.

According to [[The Wheel of Time Companion]] the Seven Towers were defining landmarks of Malkier and were broken by the [[Shadowspawn]] armies.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Seven_Towers