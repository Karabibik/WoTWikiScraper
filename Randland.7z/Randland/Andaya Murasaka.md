---
tags: [Women, Entertainers, LivingasofTFOH, ]
---




**Andaya Murasaka** is an acrobat.

## History
She is one of six sisters who are traveling acrobats called "The Murasaka Sisters" that was with [[Sillia Cerano]]'s show. The sisters look nothing alike, and are not actually related, with it being part of their act as performers.
Her surname, even if it is made up or adopted from another sister, suggests a [[Borderlander]] origin, but it is unconfirmed.

## Activities
She and her five "sisters", one of whom is [[Kuan Murasaka]], join [[Valan Luca's Traveling Show]] when the [[Masema Dagar|Prophet]] has Sillia Cerano flogged for not moving her show fast enough.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Andaya_Murasaka