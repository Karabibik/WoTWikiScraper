---
tags: [Altara, Titles]
---



**Guardian of the Sea of Storms** is a [[Title|title]] of the [[Altara|Altaran]] monarch. The title comes from the fact that Altara, and its capital city of [[Ebou Dar]] lay on the [[Sea of Storms]]. [[King]] [[Beslan Mitsobar]] gained this title when he gained the [[Throne of the Winds]]. His mother, [[Tylin Quintara Mitsobar]], held this title before her death.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Guardian_of_the_Sea_of_Storms