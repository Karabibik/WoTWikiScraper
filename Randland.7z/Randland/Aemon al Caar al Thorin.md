---
tags: [Men, Manetheren_people, Deceased, Historicalpeople, Kings, Rulers, Generals]
---


**Aemon al Caar al Thorin** (translated from the [[Old Tongue]] as Aemon, son of Caar, son of Thorin) was the husband of [[Eldrene ay Ellan ay Carlan]] and the last King of lost [[Manetheren]]. He was a warrior of exceptional ability and a revered ruler of his people. His father was [[Caar al Thorin al Toren]] and his grandfather was [[Thorin al Toren al Ban]].

## Contents

1 Appearance and Abilities
2 History

2.1 Early Years
2.2 The Trolloc Wars
2.3 The Fall of Manetheren
2.4 Aemon's Death


3 Legacy

3.1 Emond's Field
3.2 The Winespring
3.3 Two Rivers Inhabitants


4 Notes


## Appearance and Abilities
*"Aemon, a man so fearless that the greatest complement for courage any could give, even among his enemies, was to say a man had Aemon's heart."*
   —Moiraine Damodred Historians record that Aemon struck an imposing figure; standing more than 6 feet tall and powerful. He was well-known for being a shrewd gambler and a master military strategist possessing exceptional intuition. But most of all, Aemon was renowned throughout the [[Ten Nations]] for his unmatched courage. Like his fathers before him, Aemon had pledged that Manetheren would forever come to the defense of any nation struggling to fight against the [[Shadow|shadow]]. Aemon's greatest love - his wife Queen Eldrene - was a beloved figurehead of their people, who named her *Ellisande* which translates from the [[Old Tongue]] as "The Rose of the Sun". Together they represented *bravery and beauty and wisdom and a love that death could not sunder.* 
## History
### Early Years

Many of the histories of Aemon's era were destroyed in the upheavals brought about by the [[Trolloc Wars]]. As a result, several details of his life have been lost to time and legend. Historians know that Aemon was born in Manetheren circa 1155 AB when his grandfather [[Thorin al Toren al Ban]] sat that nation's throne. Aemon's father, [[Caar al Thorin al Toren]] died when Aemon was young. History records that Caar was murdered by his borderlander wife, a woman named Rhea. It is unknown if Caar ever ruled Manetheren himself, and histories are unclear as to if Rhea was Aemon's true mother.
What is known is that sometime circa 1175 AB Aemon became king of Manetheren and shortly afterwards married the most powerful channeler of the era; the [[Aes Sedai]] [[Eldrene ay Ellan ay Carlan]] who subsequently [[Bond|bonded]] Aemon as her [[Warder|warder]]. Together they ruled Manetheren from that nations wondrous capital city; high and secure in the cloud-capped peaks of the [[Mountains of Mist]].

### The Trolloc Wars
*"For nearly two centuries the Trolloc Wars had ravaged the length and breadth of the world, and wherever battles raged, the Red Eagle banner of Manetheren was in the forefront."*
   —Moiraine Damodred 
History records that Aemon was a military strategist equal in skill to the [[Five Great Captains]] of the [[New Era]]. Under his rulership, the forces of Manetheren continued their reputation as stalwart defenders of the [[Ten Nations|Compact of the Ten Nations]]. They marched far across the westlands, answering pleas from embattled countries and fighting the Shadow at every turn. Men flocked to serve under Aemon, the greatest of whom had the honor of serving in the [[Band of the Red Hand]]; an elite fighting unit that had protected generations of Manetheren nobility. Wherever men fought the forces of the [[Dark One]], the Red Eagle of Manetheren was always at the fore. For their perseverance and courage, the Army of Manetheren became known as *a thorn to the Dark one's foot, and a bramble to his hand* and Manetheren itself as *the sword that could not be broken*.


For nearly two-hundred years shadowspawn armies had fought the Ten Nations and had killed and displaced many thousands of people. However, in this time the shadow had failed to achieve a lasting success. As a result, a new command structure was beginning to form among the shadow's [[Dreadlord|dreadlord]] councils circa 1200 AB. These new generals quickly discerned that Manetheren - and its genius monarch King Aemon - was the shadow's greatest threat. They therefore crafted a plan to bring final destruction to Manetheren.
After a lifetime of war, King Aemon's final victory occurred many leagues from his national borders upon the [[Field of Bekkar]], known forever afterward as the Field of Blood. Unfortunately, the battle at Bekkar had been the culmination of a strategic feint orchestrated by dreadlord generals. Despite the one-sided slaughter that Aemon's soldiers had visited upon their enemy, he had overextended his military forces, providing an opportunity for Shadowspawn armies to assault the very heartland of Manetheren.

### The Fall of Manetheren
*"Carai an Ellisande!"*
   —Translated from the Old Tongue as "For the honor of the Rose of the Sun!" 
Aemon immediately saw the peril Manetheren faced when the Shadow's plans were made known to him. Without hesitation or thought for the distance they must travel, the king's army marched from Bekkar, still covered in dust and sweat and blood. Day and night they traveled and it is said that no man of them could sleep whilst danger threatened their homeland. Aemon sent forth his swiftest riders to plead for aid from those of the [[Ten Nations]] that remained, and sent a special plea to [[Tetsuan]], the [[Amyrlin Seat]] herself. His messengers returned declaring that reinforcements would be dispatched from various allies but his army would have to resist the forces of shadow for three days before aid could arrive. After learning that his enemy planned to invade from the east, Aemon marched his army to the major east-west road leading into the heart of Manetheren and, on the east banks of the [[River Tarendrelle|Tarendrelle River]], arrayed his force to block their path and prevent the invaders from accessing two strategically important bridges. Thus began the legendary [[Battle of the Tarendrelle River]].


On the first day of battle Aemon's army was outnumbered 10:1. But the knowledge that they were fighting on home soil coupled with a belief that aid was coming gave the Manetheren soldiers strength of body and will to persevere. Hour by hour, they held their ground against waves of Trollocs that should have destroyed them. For three days the men fought, and though the fields east of the Tarendrelle became a butcher's yard, no crossing of the river did they yield. By the fourth day of battle Aemon began to suspect that no aid was coming. Unbeknownst to the king, Manetheren had been betrayed by Tetsuan who, it has been said, harbored an old adolescent jealousy of Eldrene and so intervened to misdirect or delay the responses of allied nations. But even so, the men of Manetheren fought on. Four days became six, and six became eight, and by the end of the ninth day King Aemon knew he had been betrayed. His forces were diminished and he could hold the eastern riverbanks no longer. Thus Aemon sent forth riders with orders to evacuate civilians from his nation's heartland, and he ordered a retreat across the bridges. In the dark of morning on the tenth day the Army of Manetheren completed its withdrawal across the bridges before destroying them. Aemon then arranged his remaining troops on the west bank in a fashion where his flanks were defended by floodplain geography. For a day he rained arrows down upon the Shadowspawn attempting to cross and though many were killed, his army could not halt the ultimate advance of the enemy. History records that it was in this final desperate defense that civilians began to arrive on the battlefield. First in a trickle, and then in a flood thousands of people came to stand shoulder-to-shoulder with Aemon's infantry and pay the price of their homeland with their blood.

### Aemon's Death
*"No man or woman who had stood beneath the banner of the Red Eagle at that day's dawning still lived when night fell.  The sword that could not be broken was shattered."*
   —Moiraine Damodred 
Despite their heroic courage and unbelievable sacrifices, Aemon's army was greatly diminished and began to be pushed back into the heartland of Manetheren. This fighting retreat eventually ended at an intersection of roads now called the [[North Road]], the [[Old Road]], and the [[Quarry Road]]. It was at a field near these crossroads that Aemon rallied his forces and led a final stand. After a day of battle the king, the [[Band of the Red Hand]], and the remainder of his army combined with civilian volunteers, fell to overwhelming forces in a struggle that came to be known as the Battle of Aemon's Field. However, the result was a  for the forces of shadow, for when Queen Eldrene felt her husband perish via the bond they shared she became overwhelmed with grief and poured forth devastation and [[Balefire|balefire]] to consume what remained of the shadow's army. In a display reminiscent of the [[Breaking of the World]], all of the dreadlords died in flame and the few surviving shadowspawn were scattered. But in her final moments Eldrene had drawn to herself more of the One Power than any human could wield unaided and as the enemy generals died, so did she; the fires that consumed her consumed too the empty city of Manetheren,even the stones of it, down to the living rock of the mountains.

Legend asserts that following this cataclysmic event, the earth shuddered and [[Winespring|a spring]] burst forth upon the location where King Aemon and the Band of the Red Hand perished. It is said that the aquifer has flowed unceasingly since that day; forever marking their heroic sacrifice.


## Legacy
King Aemon is one of the many tragic heroes that emerged from the suffering brought about by the Trolloc Wars. Due to the complete destruction of Manetheren, knowledge of his reign and the adventures he had are mostly limited to sages and [[Brown Ajah|White Tower historians]], though there are two elements of geography that endure as a testament to his life.

### Emond's Field

In the [[Two Rivers]] district of [[Andor]], a quiet and peaceful village exists on the site of Aemon's final battle. [[Emond's Field]], as locals call it, was established during the [[Free Years]] as "*Aemon's Field*"; though the name eventually changed over time via the process of social evolution and language drift. Like all inhabitants of the Two Rivers, those that live in and near Emond's Field are hereditary descendants of Manetheren and possess a indomitable sense of independence.

### The Winespring
In the village of [[Emond's Field]] there is an aquifer known as the [[Winespring|winespring]] that flows from a low stone outcropping near the village [[Green|green]]. Legend asserts that when Queen Eldrene destroyed the Shadow's forces at the hour of Aemon's death, geologic upheavals caused by her channeling forced an underground spring to burst forth upon the site of the battlefield. It is further said that the water of this spring has flowed unceasingly since the day of the battle and marks the site of the final heroic sacrifice of Aemon and his men. 

### Two Rivers Inhabitants

Beyond geography, the people of the [[Two Rivers]] are known for an intense streak of stubbornness, a legacy of the hardships created by the Trolloc Wars and their fierce Manetheren blood. Outsiders to the region often remark that Two Rivers folk can "give mules lessons and teach stones". When the [[Dragon Reborn]] raised his banner 2000 years after Aemon's death, the king's ancient legacy continued to resonate. The Band of the Red Hand reformed in greater numbers around Matrim Cauthon, a young man who could call forth King Aemon's personal experiences from a vast mental library of battlefield memories. Inhabitants of the Two Rivers were eventually united by [[Perrin Aybara]] and [[Faile Bashere]] in a cultural turning-point that came to be known as the [[Battle of Emond's Field]] where the people invoked their Manetheren heritage and rallied to the ancient Red Eagle Banner.  Many would continue to follow Perrin and would ultimately fight in the Last Battle where they - like King Aemon before them - sought to bar the advance of Shadowspawn at the banks of a river.  As time marches on it appears that King Aemon's legacy will not be forgotten and that the astonishing sacrifices of the Manetheren people who followed him did not pass in vain.

## Notes






https://wot.fandom.com/wiki/Aemon_al_Caar_al_Thorin