---
tags: [Men, Andor_people, Lords, HighSeats, LivingasofKOD, Nobility]
---


**Branlet Gilyard** is the [[High Seat]] of [[House Gilyard]]. The sign of House Gilyard is the Red Leopard.

## Appearance
He is a very young Lord, 13 years old, with unruly black curls and big blue eyes.


## Activities
He is brought to [[Caemlyn]] by [[Reanne Corly]] and [[Dyelin Taravin]]. In a meeting with [[Elayne Trakand]], he pledges his House in support of [[House Trakand]] for the [[Lion Throne]].
He walks into a meeting with Elayne and Dyelin, who are discussing the fate of the five other Houses who are planning to stay neutral until a victor is decided.
When [[Birgitte Silverbow]] arrives with the news of Elayne's capture, he heads out with the strike force to retrieve her. A soldier arrives with the news that some hired mercenaries paid by Elayne are attacking the [[Far Madding Gate]]. The forces have to be split and he and his forces ride to defend the Far Madding Gate. [[Arymilla Marne]]'s army attack the gate but is hit behind by the recently rescued Elayne and her force. Arymilla's army soon surrenders.
He is present at the meeting with the neutral High Seats and Elayne. There, they throw their support behind Elayne giving her the required Houses she needs to obtain the Lion Throne.

## Notes






https://wot.fandom.com/wiki/Branlet_Gilyard