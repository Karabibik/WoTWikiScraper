---
tags: [Men, AthaanMiere_people, Swordmasters, LivingasofWH]
---


**Moad din Nopara Red Hawk** is an *Atha'an Miere*, and the [[Swordmaster]] to [[Harine din Togara Two Winds]].

## Contents

1 Appearance
2 History
3 Activities
4 Notes


## Appearance
He has gray hair and hard eyes. He is more white-haired than Harine. He is 5'10" or 178 cm tall. He has five rings in each ear.
In Far Madding, he wears a quilted blue coat that he uses to protect him while sailing the coldest seas.
He wears an sword in his belt and a dagger in his sash, both with an ivory hilt, as signs of his office as Swordmaster. Also a mark of rank, he uses a two-tiered red-fringed parasol. When Rand is on the [[White Spray]], he wears baggy trousers of green silk. 

## History
He is a widower.
[[Shalon din Togara Morning Tide]] is surprised that he knows how to ride a horse, an uncommon skill among the Atha'an Miere.
Harine gives him so much leeway as Swordmaster that anyone who didn't know would have thought them lovers.

## Activities
Mat spies Harine and Moad on the deck of their ship as it heads down the [[River Alguenya]] towards [[Cairhien (city)|Cairhien]].
He is present when Harine receives Rand as the [[Coramoor]] aboard the [[White Spray]] in Cairhien, although he is not present during the Bargain.
He accompanies [[Cadsuane Melaidhrin]] and Harine to [[Far Madding]] to find [[Rand al'Thor]]. On entering the city, he is hesitant to hand over his sword to be peace-bonded as it is a sign of his office. As a man, it is not considered appropriate that he enter the [[Hall of the Counsels]] and so he is left behind when Harine is received by the Counsels.
After leaving Far Madding, he stands guard over [[Min Farshaw]] and Harine during the [[Battle near Shadar Logoth]].

## Notes






https://wot.fandom.com/wiki/Moad