---
tags: [Terangreal, ItemsofPower]
---



The **golden swallow** is a *ter'angreal* in the possession of [[Cadsuane Melaidhrin]] as a part of her [[Paralis-net|paralis-net]].

## Appearance
The *ter'angreal* is made of gold and is shaped like a swallow. It hangs from a golden chain and appears to be flying.

## Use
The golden swallow requires no channeling of its user to activate. It is used to detect the direction from which the [[One Power]] is being used, whether it is *saidar* or *saidin*. When either is channeled, the swallow will turn and appear to fly in the direction that the channeler is. The swallow will point towards *saidin* over *saidar* if both are being channeled, and will also take priority to point to linked circles of channelers.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Golden_swallow