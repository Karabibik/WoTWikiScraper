---
tags: [Women, Andor_people, TwoRivers_people, Deceased]
---


**Neain** was [[Perrin]]'s aunt. She was married to [[Carlin]] before he passed away. She visits his grave everyday.

## Activities
She lives on the Aybara farm with the rest of Perrin's family. [[Padan Fain]] murders Perrin's entire family including Neain. There deaths are blamed on Trollocs.

## Notes






https://wot.fandom.com/wiki/Neain