---
tags: [Altara, Inns]
---
**Wayland's Forge** is an [[Inn|inn]] in [[Remen]] on the [[Ghealdan]]/[[Murandy]] border.

## Appearance
Wayland's Forge is three stories tall and made of gray stone with a purple tile roof. It has large windows and scroll-carved doors. The sign of the inn shows a man with a leather apron holding a hammer. The inn has an [[Ogier]] room with a sung wood bed. The [[Innkeeper|innkeeper]]'s name is [[Gainor Furlan]].

## Recent events
[[Moiraine Damodred]], [[Lan Mandragoran]], [[Perrin Aybara]], and [[Loial]] stop at Wayland's Forge on their way to [[Tear]] to search for [[Rand al'Thor]]. [[Faile Bashere]] was already at the inn, along with fellow [[Hunter of the Horn|Hunters of the Horn]] [[Orban]] and [[Gann]]. Moiraine and the rest do not stay the night, as Perrin killed some [[Whitecloaks]] to free [[Gaul]]. Faile leaves with them.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Wayland%27s_Forge