---
tags: [Buildings]
---
**Taverns** are places to go to drink, dice, play cards and so on. They are much like a common room of an inn.






https://wot.fandom.com/wiki/Tavern