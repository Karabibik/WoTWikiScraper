---
tags: [Women, RebelAesSedai, Maids, Deceased]
---






**Meri** was a maid in [[Salidar]]. 

## Appearance and personality
She had a pinched nose, down turned mouth, dark eyes and black hair.
Egwene thinks she was poorly named as she was not a bit "merry" and was as disapproving of faults in herself as others.

## Activities
[[Romanda Cassin]] provided her maid Meri to serve [[Egwene al'Vere]] and report back anything she could find out. She woke Egwene and helped her get ready for the day when Egwene was adorned the stole and staff.
Chesa, Egwene's other maid, brings her evening meal late one day and complains that Meri seems to have "wandered off".

She was actually murdered by [[Halima Saranov]], who disposed of the body by smuggling it out of the rebel camp.





https://wot.fandom.com/wiki/Meri