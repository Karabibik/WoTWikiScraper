---
tags: [Battles]
---
The **Battle of Maighande** was fought in 1301 AB and is counted as the single most decisive battle of the [[Trolloc Wars]]. This engagement broke the back of the [[Shadowspawn]] armies and began the slow process of driving their remnants from the [[Westlands]], which continued for the next fifty years.
The battle came approximately ten years after the fourth but most devastating attempt by the Shadowspawn to seize [[Tar Valon]]. The [[Amyrlin Seat]], [[Rashima Kerenmosa]], who served as both a military leader and general as well as a politician, is believed to be the architect of Maighande. The surviving remnants of the [[Ten Nations]] brought their armies, bolstered by new tactics, to bear against the Trolloc forces.
The location of the battlefield at Maighande is not known. The precise number of troops involved is also unknown, although tales and legends of the battle suggest it was the biggest battle of the wars and was epic in scope, suggesting hundreds of thousands of soldiers were present. The Ten Nations were badly bloodied by this time, as both [[Manetheren]] and [[Aridhol]] had fallen, and [[Aramaelle]], [[Almoren]] and [[Coremanda]] had either fallen or were on the verge of collapse by this point. We can only know then that troops from Tar Valon, [[Aelgar]], [[Eharon]], [[Essenia]], [[Jaramide]] and [[Safer]] (which all survived the wars, albeit not for long) fought at the battle. If this were the case, Tar Valon was completely surrounded by forces of the Shadow by the time of the battle.
The battle was a significant victory for the [[Light]], the greatest victory over the [[Shadow]] since the [[War of the Shadow]]. It was not matched until the [[Battle of Talidar]] a thousand years later, and maybe not until the Last Battle.
Rashima Kerenmosa died in the battle, along with her five [[Warder|Warders]]. According to legend, a vast pile of [[Trolloc]] and [[Myrddraal]] corpses surrounded their bodies, along with the bodies of nine [[Dreadlords]].






https://wot.fandom.com/wiki/Battle_of_Maighande