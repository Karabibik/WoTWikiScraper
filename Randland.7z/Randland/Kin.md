---
tags: [Articlestobeexpanded, Kinswomen, Organizations]
---
*"I think we've just found the Ancient Muckety-muck Sisterhood of Wise Women."*
   —[[Nynaeve al'Meara]] 



The **Kin** is a group of female [[Channel|channelers]] who help women put out of the [[White Tower]] and in some rare cases also runaways. When encountered by [[Nynaeve]] and [[Elayne Trakand|Elayne]], there were 1,783 members. The ruling body is called the [[Knitting Circle]], headed by the Eldest.

## Contents

1 Rules
2 Wise Women
3 History
4 Strength
5 Places
6 From Altara to Andor
7 White Tower Plans
8 Known Members

8.1 Former Knitting Circle
8.2 Others


9 Notes


## Rules
The Prime rules were: 
1) All Kinswomen, even the Eldest, are subject to the Rule. 
2) All Kinswomen obey any order of the Eldest and of the Knitting Circle. 
3) The existence of the Kin must be kept secret from all who are not Kinswomen. 
4) It was forbidden to claim to be Aes Sedai, or to do anything that, under any circumstances, would cause someone to believe that one was Aes Sedai. 
5) It was forbidden to attempt to learn more of the One Power, or to try to increase one's strength, skills and abilities beyond the level they were upon leaving the White Tower. 
6) It was forbidden to use the One Power outside of carefully defined circumstances, or at great need. Anyone violating this rule would be brought before a court and receive severe punishment if found guilty. 
7) It was forbidden for anyone except the Knitting Circle, or those named by the Knitting circle, to recruit other women put out of the White Tower or who had run away. Nobody could recruit any woman who could channel except those who had once been in the Tower. 
What kept the Eldest from changing the rules was the simple fact that it was forbidden to change the Rule. 
Most of the Kin's members were put out of the White Tower for one reason or another, the vast majority for being too weak to advance to superior levels, some for failing one of the many required tests, some for insuperable discipline problems and very, very few are runaways. The Kin did try to avoid women put out for being too disruptive or who were put out for crimes such as habitual theft.  
Women who are considered [[Wilder|wilders]] (i.e. no Tower training) are not admitted. Young girls with the [[Spark|spark]] are also not admitted but directed to the attention of Aes Sedai.  
The Kin had a few women in Tar Valon, called guides, who cautiously checked out women expelled from the Tower. They kept a low profile and were changed at regular intervals. The guides focused on finding runaways; they would turn in those who seemed to need more training, while helping others escape. Most successful runaways were aided by the Kin. Of women put out of the Tower, the Kin approached only when sure of acceptance; they would rather miss some recruits than draw attention from the Tower.   
There were other rules besides these. The Kin do not allow marriage, and relationships with men are forbidden while in training. Impatience and hotheadedness were punishable. It was forbidden to speak of returning to the Tower, or to speak of recruiting girls who could be taught to channel.  
These rules were crafted to prevent Aes Sedai from learning about the Kin; indeed, the Kin were unaware that the Aes Sedai already knew about their existence, though the Aes Sedai had severely underestimated their number, ages and organization. 
None of the Kin's women were [[Aes Sedai]], but having trained in the Tower for a while, they have some similar rules and are not exactly wilders. Rank among the Kin is determined by age, not strength in the Power. This is because the Kin tried to pattern their rules and heirarchy (except those related to keeping secret) after what they believed to be Aes Sedai rules; but because none of them had been Aes Sedai, their rules were similar to what Accepted and novices were held to. Punishments were often physical in nature, or involving labor. They were very strict about behavior.  
The thirteen oldest members residing in [[Ebou Dar]] comprise the [[Knitting Circle]] and are the ruling body of the Kin. The oldest of the Knitting Circle is known as the [[Eldest]]. In any case there are usually older members elsewhere. [[Reanne Corly]] has been the last Eldest until the Kin fled Ebou Dar. 
The Eldest and the members of the Knitting Circle have to be obeyed without objections. Punishments are harsh chores and based on the rules of [[Novice|Novices]] and [[Accepted]] in the White Tower. Any new recruit is cautiously observed and examinated before acceptance. Are avoided women who are too disruptive or that are put out from the Tower for some serious crime.
They are also not allowed to teach each other [[Weave|weaves]], to experiment with the One Power and are discouraged from trying to learn more. They avoid to use the [[One Power]] in public and to attract attention from Aes Sedai in any manner. They use the Power cautiously and rarely, only when truly necessary, but despite this rule usually every Kinswoman is able to reach her full potential and to increase her skills, because of so many decades of careful practice of *Saidar*. Therefore there are some Kinswomen, older than Aes Sedai, between three and five hundred years old, that showed great skills and capacities in some cases better than Aes Sedai themselves.
In fact it was recently discovered that because the Kin do not use the [[Oath Rod]], they live significantly longer lives than Aes Sedai. When the ages of The Kin were discovered, they were met with disbelief by many Aes Sedai.
Until revealed to them by [[Elayne]] after she was told by [[Vandene Namelle]], the Kin believed their existence was unknown by Aes Sedai that actually used them to locate runaways. This way, the capture rate of women who fled the White Tower was significantly improved, catching 90% of all runaways.
Any Kinswomen is allowed to stay in Ebou Dar (or any other place) for no more than ten years, so no one can notice that she doesn’t age. Then she is sent far away, employed in some craft or as a merchant; she can return to a previous place only after more than twenty years have passed, as it is assumed no one would easily recognize her any longer. As part of their need for discretion, they will often take many names, trades, and jobs over the course of their lives. 
The Kin does not allow its members in Ebou Dar to reach the number of two hundred, a number considered too much noticeable by the White Tower. So they are turned frequently to and from other places, using the Farm as a cover to pass through.

## Wise Women
Wise Women are Kinswomen resident in Ebou Dar who practice healing, herbs and cures. They wear a distinguishing red belt (the longer the belt, the better is considered the woman in her healing). 
Wise Women are reputed to have more knowledge of herbs and healing than anyone, in fact they rely more in medicines, herbal concoctions and natural remedies than the use of weaves of *saidar*. Indeed they [[Heal]] using the One Power in public only when strictly necessary.

## History
The Kin is around two thousand years old. It was formed by a group of sent away from the White Tower, that took refuge in the ancient city of [[Barashta]] (now the [[Rahad]], the oldest district of [[Ebou Dar]]), during the troubling times of the [[Trolloc Wars]]. It began quite by accident; the founders originally stuck together for safety.  
The Aes Sedai discovered the organization quite quickly, but their involvement in the Trolloc Wars stopped them to intervene immediately to disperse the Kin. Later for the Sisters became convenient that the Kin, so discreet, took care for the channelers that failed to become Aes Sedai. Also, as stated above, the Kin revealed to be very useful to catch runaways, so finally the White Tower decided to not intervene against it.
During the centuries the Kin became the refuge for many hundreds of female channelers, finally gathering more channelers than the Tower itself. In fact its discretion, its ability to hide the Kinswomen by organizing a rapid turn over of people from the same place, left the Aes Sedai completely unaware of its real dimension.
In A Crown of Swords/Chapter 31, [[Merilille Ceandevin]] Sedai asked Reanne Corly how many Kinswomen there are all together. Reanne answered that they are one thousand seven hundred and eighty-three (1,783) names on the roll. The Aes Sedai present were shocked for this large number, because the Kin is almost twice as many as their total number. Reanne mistook their silence and thought that it was too few a number.

## Strength
The average strength in the One Power among the Kinswomen is very low if confronted to that of the average Aes Sedai, in fact the Kin is formed in majority by ex-novices too weak to reach not only the Shawl, but even to be tested for Accepted.
It has been calculated that around a third of women who go for training in the Tower will be put out for not being strong enough, though actual figures may be higher, for instance [[Elayne]] stated that out of forty novices when [[Egwene]] arrived at the Tower, only about a quarter of them will be raised.
Anyway there are very few of the Kin that are strong as the most strong Sisters: this strong Kinswomen come mainly from some runaways and women that failed their tests to advance in Aes Sedai hierarchy.
After learning how to form a [[Circle|circle]] from Elayne and Nynaeve, the Kinswomen in group can now reach the same performances of any Aes Sedai or better, for instance it has been showed that three or four weak of them in circle can open suitable gateways for [[Traveling]] as a pair of average Aes Sedai or a strong Sister.

## Places
The [[Kin's Farm]] is several miles northeast of Ebou Dar that serves as a retreat for women and also serves as a cover for Kin coming and going from Ebou Dar
The [[Kin's Storeroom]] is a hidden stash in the Rahad where the Kin collected any item which they perceived as related to the One Power
## From Altara to Andor
After the [[Gholam|gholam]] attacked in the [[Rahad]] store all the Kinswomen in Ebou Dar fled to the [[Kin's Farm| Farm]], so most of them escaped to be captured as *Damane* by the [[Seanchan]] that conquered the city.
The day when Ebou Dar was conquered by the Seanchan and started the occupation of Altara, from the Farm, around 150 members of the Kin fled again with Elayne to [[Caemlyn]]. From Andor many other Kinswomen were contacted in other lands and advised about the Seanchan menace. Meanwhile some of them reached Caemlyn engrossing the Kin's numbers there.
Only half a dozen of the Kinswomen in Andor are able to open alone suitable Gateways, but the others showed the ability to link in circle an so overwhelm the lacking of strength.
After Elayne conquered the throne, a group of Kinswomen, led by [[Alise]], signed a contract with the Crown of Andor which agrees they will establish themselves there permanently as supporter of the Crown, granting healing and traveling to the Andorans. This contract was not considered well by the Amyrlin Seat and the Hall of the Tower, but the upcoming of the Last Battle stopped them to take a measure about it.

## White Tower Plans
[[Egwene al'Vere]], the [[Amyrlin Seat]], unveiled a plan while with the faction of [[Rebel Aes Sedai]]: that [[Aes Sedai]] who wish to retire could have the [[Three Oaths]] removed and be sent to the Kin. This would allow them to live out their greater remaining days in peace while tying The Kin to the [[White Tower]], although it does mean that those who lived with The Kin must accept their rules and customs. So far this plan has not come into action and has been met with strong opposition by some [[Sitters]] in the [[Hall]].
Egwene promised also to the Kinswomen with enough strength that, if they want, they can be tested again to become Aes Sedai. Among them Reanne was very glad of the offer. Instead the too week as Alise searched an agreement with the Crown of Andor, to stay in Caemlyn. As part of this agreement, Alise begins to take a less informal leadership role.

## Known Members
### Former Knitting Circle
Members of the Knitting Circle with their strength level and in order by **age** (when known). Also includes the reasons for being put out of the Tower (are indicated also those below the minimum level to test for Aes Sedai 45(33)).


### Others
List of known Kinswomen (with strength and age if known)

[[Alise Tenjile]] 46(34) **181** (too weak to test for Aes Sedai) the new *de facto* ruler of the Kin.
[[Aloisia Nemosni]] 17(5)<18(6) **600** the oldest known member of the Kin, living in Tear
[[Asra Zigane]] 54(42) **87** (too weak to test for Aes Sedai) great talent in Healing and Fast Learning
[[Berowin Doraisin]] 42(30) **242** (failed her test for Aes Sedai) unique Shielding talent
[[Caiden]] 51(39)
[[Callie]] (tried to steal a *ter'angreal*) killed by [[Ispan]] and [[Falion]]
[[Derys Nermala]] 41(29) **89** (put out for discipline problems, after three time she was caught with a man)
[[Jesamyn]] ≤ 46(34) a bit of Talent in Healing and with Fire
[[Jillien]]
[[Julanya Fote]] 16(4) quite old, due the white in her dark hair, able to Travel alone
[[Kara Defane]] >17(5) **>47** former [[Wilder]], former *Damane* freed by the [[Asha'man]] during [[Altara]] campaign, now in care of the Kin
[[Kema]]
[[Keraille Surtovni]] 49(37) (too weak to test for Aes Sedai)
[[Kumiko]] ≤ 46(34) (too weak to test for Aes Sedai) able to open Gateways when in a Circle
[[Lemore Genhal]] **19** noblewomen from Tarabon former *Damane* freed by the Asha'man during Altara campaign, now in care of the Kin
[[Mirane Larinen]] killed by [[Careane]]
[[Nashia]]
[[Sabeine Ocalin]] ≥ 21(9) able to open suitable Gateway on her own
[[Sarainya Vostovan]] 46(34) **76**, a noble woman, raised Accepted only for political reasons,
[[Sarasia]] ≤ 46(34)
[[Solain Morgeillin]] 40(28) **181** a lesbian kleptomaniac, after eleven years as Novice and eight as Accepted, she was sent away because unable to heal from her problem, the Kin was successful were the Tower failed
[[Zarya Alkaese]] (alias Garenia Rosoinde) 13(1) **92** (now again a [[Novice]]) (ran away from the Tower after five years as Novice)


## Notes

|||
|-|-|






https://wot.fandom.com/wiki/The_Kin