---
tags: [Legends, Gleemen]
---
**Stories** and [[Legends|legends]] are often told by [[Gleeman|gleemen]] which include legendary people.

## Stories
*Aptarigine Cycle*
*The Thousand Tales of Anla*
*Anla the Wise Counselor*
*How Susa Tamed Jain Farstrider*
*Mara and the Three Foolish Kings*
*The Siege of the Pillars of the Sky*
*How Goodwife Karil Cured Her Husband of Snoring*
*King Darith and the Fall of the House of (unknown)*
[[The Great Hunt of the Horn]]
*The Karaethon Cycle*
*The Bargain of Rogosh Eagle-eye[1]*
*Lian's Stand*
*The Fall of Aleth-Loriel*
*Gaidal Cain's Sword*
*The Last Ride of Buad of Albhain*
*The Nine Rings[2]*
*The Essanik Cycle[3]*
## People
[[Artur Paendrag Tanreall]]
[[Jaem the Giant-Slayer]]
[[Lenn]]
[[Mosk the Giant]]
[[Elsbet, the Queen of All]]
[[Materese the Healer]]
[[Salya]]
## Notes






https://wot.fandom.com/wiki/Stories