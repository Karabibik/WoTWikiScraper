---
tags: [Altara, Towns]
---
**Runnien Crossing** is a town in [[Altara]]

## Description
The Town is smaller than [[Jurador]] but with four three story inns, half a mile from a shallow river with a stone bridge crossing it. The town is surrounded by farms on the hills as far as the eye can see. Despite being only a few days from [[Ebou Dar]], the people there wear very different clothing and their belt knives are mostly straight, rather than curved.

## Notes






https://wot.fandom.com/wiki/Runnien_Crossing