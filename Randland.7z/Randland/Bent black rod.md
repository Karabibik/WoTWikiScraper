---
tags: [, Terangreal, ItemsofPower]
---



The **bent black rod** is a *ter'angreal* used by [[Asne Zeramene]] during the confrontation at the residence of the "Lady [[Shiaine Avarhin]]" in [[Caemlyn]]. .

## Contents

1 Description
2 Use
3 Activation
4 Current position
5 Notes


## Description
"... a small, bent black rod, perhaps an inch in diameter, that had a strangely dull look."

## Use
It is a weapon that can be used for stunning or killing someone from the distance of a hundred paces. Asne affirmed that the rod was a 'gift' from [[Moghedien]] but, from a comment given by another Black Sister, Asne found the rod searching in the Forsaken's bedroom in [[Samara]], after Moghedien was absent for a long time and never returned to them (because in fact she was captured by [[Nynaeve]] in [[Salidar]]). Later Asne used it in [[Caemlyn]] to stun [[Elayne]], [[Sareitha]], [[Careane]] and [[Vandene]] at the house on Full Moon Street.

## Activation
How this *ter'angreal* is activated is unclear. When it is in use it is not detected by channelers, Asne affirmed that the rod can kill a man surrounded by Aes Sedai without any of them able to feel from where the attack is coming.

## Current position
After Asne was killed in the failed kidnapping of Elayne, it could be guessed that the bent black rod was recovered and now it is in the custody of the Queen of Andor.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Bent_black_rod