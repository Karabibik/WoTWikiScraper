---
tags: [Men, Tear_people, Warders, LivingasofKOD]
---


**Furen Alharra** is [[Warder]] to [[Seonid Traighan]].

## Contents

1 Appearance
2 History
3 Activities
4 Notes


## Appearance
He has curly black hair streaked with gray. He is very dark, tall and lean with dark eyes.

## History
He is [[Tairen]].

## Activities
He travels with Seonid to [[Ghealdan]]. He is furious with the way the [[Aiel]] [[Wise Ones]] treat Seonid.
When [[Faile Bashere]] is captured by the [[Shaido]] Aiel, he travels with [[Elyas Machera]] to find her tracks.
He accompanies [[Perrin Aybara]] and Seonid to [[So Habor]], where he sticks close to her when the residents claim to be seeing ghosts.
He goes through the aqueduct to enter the town of [[Malden]] before Perrin begins his attack.

## Notes






https://wot.fandom.com/wiki/Furen_Alharra