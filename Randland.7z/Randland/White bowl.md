---
tags: [Terangreal, ItemsofPower, EbouDariStash]
---



The **white bowl** is a *ter'angreal* recovered from the [[Kin's Storeroom]] in [[Ebou Dar]].

## Apperance
The *ter'angreal* is flattish and white, about a pace across.

## Use
The bowl is said to be used for looking at things far away. It could have been meant as a communication device or an item for spying. Not much else is known about it.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/White_bowl