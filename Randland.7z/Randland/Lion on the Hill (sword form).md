---
tags: [Swordforms]
---




**Lion on the Hill** is a [[Sword form|sword form]]. Other than the name, nothing is known about it. [[Rand al'Thor]] flows through this form while sparring against five men in [[Caemlyn]].

## Background
This form is probably an allusion to the epigraph of [[Lord of Chaos]], and to the chapter in which this form appears, also entitled "Lion on the Hill." The imagery suggests Rand is the Lion on the Hill. In a related imagery, the [[Daughter of the Nine Moons]] described [[Matrim Cauthon]] as a lion taking his "ease on a hilltop."

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Lion_on_the_Hill_(sword_form)