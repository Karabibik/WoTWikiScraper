---
tags: [Women, UnknownAjah, BlackAjah, AesSedai, Deceased, Dreadlords, Channelers]
---


**Notori** was an [[Aes Sedai]] of unknown [[Ajah]], and secretly part of the [[Black Ajah]]. 

## Activities
She took part in the [[Battle in Tel'aran'rhiod]] and was killed by a blast of [[Fire]] created by [[Nynaeve al'Meara]]. Because she was killed in the World of Dreams, she also died in the waking world.
She was probably using a dream *ter'angreal*, otherwise her soul would be obliterated from the [[Pattern]].






https://wot.fandom.com/wiki/Notori