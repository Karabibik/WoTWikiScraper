---
tags: [Men, Warders, Deceased, Historicalpeople, Blademasters]
---


**Jearom** was a [[Warder|Gaidin]] and [[Blademaster]].

## Contents

1 History
2 Activities
3 External links
4 Notes


## History
He is considered to be the greatest [[Blademaster]] to have ever lived.
It is said he fought over 10,000 times in battle and single combat during his lifetime. He only lost once to a farmer with a [[Quarterstaff|quarterstaff]]. He once defeated ten men at the same time.

## Activities
After a Warder of the [[White Tower]] sees Lord [[Galad Damodred]] and Lord [[Gawyn Trakand]] defeated by [[Mat Cauthon]], he tells them that the greatest Blademaster of all time was defeated by a man with a quarterstaff, and they best well remember it.
Watching [[Rand al'Thor]] practice with the sword against five opponents, [[Nasin Caeren]] compares him to Jearom. [[Davram Bashere]] asks Rand if he thinks he will live long enough to equal the greatest swordsman in history.

## External links
 
  on  
## Notes






https://wot.fandom.com/wiki/Jearom