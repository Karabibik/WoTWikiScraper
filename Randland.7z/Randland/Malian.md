---
tags: [Women, Seanchan_people, Suldam, LivingasofTGS, EverVictoriousArmy, Channelers, Learners]
---


**Malian** is a *sul'dam* in the [[Seanchan]] army.

## Activities
She is present at the meeting between the [[Dragon Reborn]] and the [[Daughter of the Nine Moons]], when it is revealed that the latter is actually [[Semirhage]] in disguise. She ties bandages on the rest of her injured comrades.






https://wot.fandom.com/wiki/Malian