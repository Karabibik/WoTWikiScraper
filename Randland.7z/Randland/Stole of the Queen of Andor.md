---
tags: [Andor, CrownsandRegalia]
---
Along with the [[Rose Crown of Andor|Rose Crown]], the **stole of the Queen of Andor** is a symbol of her role and station.

## Description
It is a wide strip of crimson silk, embroidered with the White Lion of Andor down its length, and is typically worn over the queen's finery and gowns, hanging from behind her neck.






https://wot.fandom.com/wiki/Stole_of_the_Queen_of_Andor