---
tags: [Disambiguation]
---
**Marith** is the first name of two [[Aes Sedai]]:

[[Marith Jaen]] - the [[Amyrlin Seat]] from 994 to 988 NE and [[Siuan Sanche]]'s predecessor.
[[Marith Riven]] - an Aes Sedai who has sworn fealty to [[Rand al'Thor]].


https://wot.fandom.com/wiki/Marith