---
tags: [Channelers, Organizations]
---



The **Daughters of Silence** was a group formed in the year 794 NE by two former [[Accepted]] who were put out of the [[White Tower]]. They gathered twenty-three [[Wilder|wilders]] and organized, taught and trained them in the [[One Power|Power]]. When the [[Aes Sedai]] discovered them in the year 798 NE, they disbanded the group, enrolled the "students" in the Tower as [[Novice|novices]] and punished the two former Accepted who started the group. The punishment was severe and public to make sure that the lesson was carried to everyone who might entertain the thought of channelers outside of the Tower banding together.
Only one of the women enrolled as a novice ever became full Aes Sedai - [[Saerin Asnobar]].

## Notes






https://wot.fandom.com/wiki/Daughters_of_Silence