---
tags: [, Terangreal, ItemsofPower]
---
The **alabaster figurine** is a *ter'angreal* that was stolen from the [[White Tower]] by the [[Liandrin's Group of Black Sisters|Black Ajah]].

## Appearance
The *ter'angreal* is in the shape of a unclothed woman, is made of alabaster, and is one hand tall.

## Use
The use of the alabaster figurine is unknown. The evidence suggests it is a [[Sleepweaver|sleepweaver]] because of the circumstances of the theft and also because it was studied by [[Corianin Nedeal]] along the other stolen objects.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Alabaster_figurine