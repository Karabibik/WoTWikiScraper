---
tags: [Men, Andor_people, Deceased]
---


**Jowdry** was a man from [[Caemlyn]].

## Activities
When Jowdry was at [[The Farrier's Green]], his throat was ripped clean out and his body was drained of blood. [[Matrim Cauthon]] heard of this when he was in Caemlyn, indicating the *gholam* was very near.

## Notes






https://wot.fandom.com/wiki/Jowdry