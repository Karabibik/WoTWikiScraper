---
tags: [Men, Murandy_people, HuntersoftheHorn, Lords, LivingasofLOC, Nobility]
---


**Culen** is a nobleman and a [[Murandian]] [[Hunter of the Horn]]. 

## Appearance
Culen is tall and lean with a curled mustache.

## Activities
[[Matrim Cauthon]] orders him, [[Paers]] and their servant, [[Padry]], out of [[Maerone]] for manhandling [[Olver]], who was sitting on Paers' horse.

## Notes






https://wot.fandom.com/wiki/Culen