---
tags: [Men, Cairhien_people, ChaFaile, LivingasofKOD, Eyes-and-ears]
---


**Nerion** Torelvin is a member of [[Cha Faile]].

## Activities
He is sent with [[Haviar Agora|Haviar]] to [[Masema Dagar]]'s camp under the pretense that he is a [[Dragonsworn]]. While he is there he spies on Masema's activities.
He and Haviar learn that Masema had sent another rider to Amadicia; that there were Altarans among Masema's forces; and that [[Annoura Larisen|Annoura]] and [[Masuri Sokawa|Masuri]] were meeting with Masema secretly.
He and Haviar were pulled out before the attack on [[Malden]].

## Notes






https://wot.fandom.com/wiki/Nerion