---
tags: [AesSedai, CrownsandRegalia]
---

The **Stole of the Amyrlin Seat** is one of the symbolic items of regalia worn by the [[Amyrlin Seat]]. It is a long strip of silk, about "a hand wide" that the Amyrlin wears over her dress, that traditionally contains seven bands of color, one for each [[Ajah]]. Robert Jordan has confirmed the order of these colors:

[[Blue Ajah|Blue]]
[[Green Ajah|Green]]
[[Yellow Ajah|Yellow]]
[[Red Ajah|Red]]
[[White Ajah|White]]
[[Gray Ajah|Gray]]
[[Brown Ajah|Brown]]
These colors are also repeated on the hems of the dresses of [[Accepted]] in the [[White Tower]].
The size of the stole is a mystery. It is generally thought of as wide, especially since the [[Stole of the Keeper of the Chronicles|stole of the Keeper of the Chronicles]] is frequently referred to as narrow. [[Egwene al'Vere]] can store the stole in her belt pouch. [[Elaida do Avriny a'Roihan]]'s stole is "wide enough to cover her shoulders." Perhaps, like the width of the Keeper's stole, the width of the Amyrlin's is based at least partly on personal preference.


## Variants
Following the [[White Tower Schism]] on Amadaine 16, 999 NE, Elaida wears a stole with only six colors, with no blue stripe. During the schism the "rebel" Amyrlin's stole maintained all seven colors, even though there were no members of the Red Ajah among the rebel faction.

## Notes

*This page is a stub. You can help A Wheel of Time Wiki by expanding it. *





https://wot.fandom.com/wiki/Stole_of_the_Amyrlin_Seat