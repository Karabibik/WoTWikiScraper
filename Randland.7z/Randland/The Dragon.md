---
tags: [Inns, Tear]
---



**The Dragon** is an inn in the city of [[Tear]].
It is owned by [[Agardo Saranche]]. It is a tile-roofed inn with three stories. It is bade of dark gray stone. The sign of the inn is a rough approximation of the marks on [[Rand al'Thor]]'s arms, but stylized to look almost like a *raken*. The common room has a beam ceiling. 
[[Rand al'Thor]], [[Min Farshaw]], [[Nynaeve al'Meara]], [[Alivia]], [[Cadsuane Melaidhrin]] and a small company of [[Maiden of the Spear]] take a room at *The Dragon* in order to [[Travel]] into the [[Stone of Tear]].

## Notes






https://wot.fandom.com/wiki/The_Dragon