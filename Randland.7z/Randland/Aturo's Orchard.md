---
tags: [Villages, AlmothPlain, TomanHead]
---
**Aturo's Orchard** is a small village on the edge of [[Almoth Plain]] and [[Toman Head]].

## History and geography
The village lies on a crossroads between the Old Hills and the Bramblewood. Two weeks to the west lies the city of [[Falme]]. The village grew from a few farms, a smithy, and the orchard, providing apples, ciders, jams and the like. The crossroads brought a number of peddlers and merchants, enough to warrant an inn, and soon tradesmen took up residence. 
The village is self-sufficient and untroubled despite the recent hostilities between [[Arad Doman]], [[Tarabon]], and the [[Seanchan]]. It is self-governed by a mayor, the [[Village Council]], and the [[Wisdom]].
Aturo's Orchard was occupied by the [[Children of the Light]], who disguised themselves as soldiers from [[Tarabon]]. This was to intimidate the local populace at the time of increasing hostilities between Tarabon and [[Arad Doman]].

## Locations
[[Three Crowns Inn]]
## Notes






https://wot.fandom.com/wiki/Aturo%27s_Orchard