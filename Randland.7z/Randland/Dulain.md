---
tags: [Men, Murandy_people, Lords, Deceased, Nobility, ]
---


**Dulain** was a young border [[Lord|lord]] from [[Murandy]]. 

## History
The White Tower had identified him as a man who could one day truly unite the nation of Murandy, with the help of the White Tower. 
Out of fear that raids from [[Andor]] would cause Dulain's death, [[Siuan Sanche]] forced [[Morgase]] and [[Gareth Bryne]] to remove all troops from the Andoran-Murandian border. During this episode the Amyrlin Seat scolded the general for his opposition to remove the army.
About a month after Siuan left [[Caemlyn]], Dulain was killed by an arrow from an Andoran farmer during a sheep raid. This all happened some three years ago, around the year 996 NE.
Gareth Bryne never knew that Dulain was the reason he was forced to remove his troops from the border; when Siuan finally tells him, he says that he has never even heard of Dulain.






https://wot.fandom.com/wiki/Dulain