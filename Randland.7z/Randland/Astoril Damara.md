---
tags: [Men, Tear_people, Lords, HighNobilityofTear, Ladies, LivingasofKOD, Nobility]
---


**Astoril Damara** from [[House Damara]] is a [[Tairen]] High Lord. 

## Contents

1 Appearance
2 History
3 Activities
4 Notes


## Appearance
He has an oiled, pointed beard and thinning, shoulder-length, snow white hair. He is elderly and his face is creased with wrinkles, but he is still straight-backed and sharp-eyed. He has dark eyes.

## History
Astoril Damara was born in 935 NE. He married for the first time at the age of twenty-five; his wife was twenty. One son, the eldest of their marriage, died in the [[Aiel War]], and another son died of sickness; two daughters of the marriage survived. His first wife died in childbirth in 974 NE.
During the [[Aiel War]], he was one of the generals of the [[Grand Alliance]] and sixth in order of command. He was also, presumably, in charge of the Tairen troops in this conflict.
In 979 NE, he married his second wife. His daughter [[Medore Damara]] was born of his second marriage in 981 NE. He also had two more sons from this marriage. 
He is very civil towards [[Aes Sedai]], something that is rare in Tear where channeling was outlawed before Rand changed the law.
He has several daughters, one of which is [[Medore Damara]], a member of [[Cha Faile]]. 
He retired to his country estates years ago, but is still considered among the most powerful [[High Lord|High Lords]]. His eldest daughter inherited the title of High Lady and High Seat.
[[Estean Andiama]] says he will probably flip a coin to see which one of Astoril's daughters he will marry, or perhaps Medore as she "has two or three pretty maids".

## Activities
When Rand took control of Tear, Lord Astoril remained in the country, waiting the evolving of situation.
Finally Astoril came out of retirement to join [[Darlin Sisnera]] inside the [[Stone of Tear]], when Darlin returned in the city and was appointed [[Steward of the Dragon]] in Tear. 
The Stone was under siege by those who wanted the [[Dragon Reborn]] out of Tear. Lord Astoril was therefore a supporter of Rand and/or Darlin.
Rand arrived in the Stone of Tear, visiting High Lord Darlin, Lady [[Caraline]] and [[Alanna]]. Astoril, [[Anaiyella]] and [[Weiramon]] are with them. Rand ordered Darlin to raise an army to take to [[Arad Doman]]. Bera arrived with news that the rebels will settle if Darlin is made King of Tear. 
Astoril encountering Rand for the first time commented that his arrival was a 'very pleasant surprise' and that he had been looking forward to their first meeting for some time. He treated [[Nynaeve]] and [[Cadsuane Melaidhrin]] with respect.

## Notes






https://wot.fandom.com/wiki/Astoril