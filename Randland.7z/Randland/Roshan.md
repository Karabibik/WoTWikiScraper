---
tags: [Men, Warders, LivingasofCOT]
---


**Roshan** is a [[Warder]] to [[Samitsu Tamagowa]].

## History
He certainly did not want to become a Warder, not until Samitsu said she wanted him for one.

## Activities
Samitsu misses him when she visited the rebels' camp near Cairhien and she wishes he were present to make her feel safer during the [[Bubble of evil|bubble of evil]] that is hitting the camp. A far as we know, he has still not been reunited with his [[Aes Sedai]].






https://wot.fandom.com/wiki/Roshan