---
tags: [Holds]
---
**Sulara Hold** is an [[Aiel]] [[Hold|settlement]] in the [[Aiel Waste|Three-fold Land]]. [[Niella]], [[First-sister|first-sister]] to [[Aviendha]], is from Sulara Hold. She was taken *gai'shain* by *Far Dareis Mai* of the [[Chareen]] [[Clan|clan]] during a raid. It is unknown if the hold is held by the [[Taardad]] or if ownership changed during the raid.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Sulara_Hold