---
tags: [Kandor]
---
The **Kandori** people are part of the [[Borderlands]].






https://wot.fandom.com/wiki/Kandori