---
tags: [Swordforms]
---






**Thistledown Floats on the Whirlwind** is a [[Sword form|sword form]].

## Description
This form involves leaping and spinning, such that the blade cuts horizontally.

## In practice
[[Rand al'Thor]] used this form to decapitate an unnamed, unarmed female [[Darkfriend]] in the [[Murandy|Murandian]] hills while on his way to [[Tear]]. She was still mounted on her horse, so Rand would have had to leap fairly high to cut her neck.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Thistledown_Floats_on_the_Whirlwind