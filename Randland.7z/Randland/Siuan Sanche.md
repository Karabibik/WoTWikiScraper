---
tags: [Women, BlueAjah, Tear_people, Fishers, AesSedai, Deceased, AmyrlinSeats, RebelAesSedai, Eyes-and-ears, HighRankingAesSedai, LivingasofAMOL, LowRankingAesSedai, POVcharacter, Sparkers, Notesneeded, Channelers]
---


**Siuan Sanche** (pronounced: SWAHN SAHN-chay; /ˈsʲwɑn ˈsan.t͡ʃɛɪ/) was an [[Aes Sedai]] of the [[Blue Ajah]]. She was born in [[Tear]], and grew up a fisher girl. She was formerly the [[Amyrlin Seat]], but was deposed in a *coup d'etat* led by [[Elaida do Avriny a'Roihan]], [[Severing|stilled]], and briefly imprisoned. Her first [[Warder]], [[Alric]], was murdered during the [[White Tower]] coup.
She later ran away, joined the [[Rebel Aes Sedai|rebel Aes Sedai]] and then was [[Healed]] from stilling, regained her status (albeit as a low-ranking sister) and bonded [[Gareth Bryne]], former [[Captain-General]] of the [[Queen's Guards]] of [[Andor]], former lover of Queen [[Morgase]] and one of the [[Five Great Captains]], whom she also agreed to marry after the [[Last Battle]]. Unfortunately, neither of them survived to marry.
She has been known to use the aliases "Suki" and "Mara".

## Contents

1 Appearance
2 Abilities
3 Early life and Family
4 History
5 Activities

5.1 The Dragon Reborn
5.2 The Amyrlin Seat
5.3 Meeting the Dragon Reborn
5.4 Back at the Tower
5.5 Deposed
5.6 Joining Salidar
5.7 Serving Egwene
5.8 To rescue the Amyrlin
5.9 Back within the Tower
5.10 The Last Battle


6 Personal quotes
7 Viewings
8 In the television series
9 Notes


## Appearance
She was nearly a hand taller than [[Moiraine Damodred]] and was pretty, if not quite beautiful, with blue eyes and a delicate mouth. She was fair-skinned with dark glossy hair to her shoulders. After being stilled, and then Healed by [[Nynaeve al'Meara]], she had lost about twenty years from her appearance.
By Min's observation Siuan as the Amyrlin looked sturdy, handsome rather than beautiful. *"Her age was indeterminate, as with any Aes Sedai; not even a hint of gray showed in her dark hair. But her sharp blue eyes brooked no nonsense, and her firm jaw spoke of the determination of the youngest woman ever to be chosen Amyrlin Seat."* 


## Abilities
As novice and Accepted Siuan showed a considerable potential and was very skilled. She almost reached her full potential in around 6-7 years while an Aes Sedai of average strength spent around 20 years in training and need around 10 years to reach her full potential.
Once Siuan was a considerably strong sister in the [[One Power]] by Aes Sedai standard, at the same level as [[Romanda Cassin]], [[Lelaine Akashi]], Moiraine, and Elaida, so she was a very high-ranking Aes Sedai, among the most influential sisters in the last twenty years; but after being stilled, and then Healed by Nynaeve al'Meara, she lost around 2/3 of her strength, becoming a low-ranking Aes Sedai. Her original strength level in the power was 13(1), the top level in Aes Sedai hierarchy during the last twenty years, but after being stilled and Healed it was reduced to level 35(23).


Siuan was described among the most fast and dexterous Sisters in the White Tower in the [[Weave|weaving]] of the One Power, an ability that she has maintained fully when she regained the ability to channel.
Siuan possessed also the [[Talent]] of [[Healing]], a Talent that remained in full even after she lost around 2/3 of her strength when Healed from the stilling. Siuan thought that her skill in Healing was not the best but she anyway was able to Heal three soldiers and Bryne during the [[Seanchan]] raid against the White Tower and again later she saved many lives after the [[Sharan]] attack against the Aes Sedai camp in [[Kandor]].
Like [[Chesmal Emry]], Siuan also knew how to use the Healing [[Weave|weaves]] to kill directly, by using *saidar* to stop the heart.
She had also the minor [[Talent]] of seeing and recognizing a *ta'veren *, which means that she was able to see a more or less bright aura around such people. After her stilling was Healed this Talent returned to her too.
[[Moiraine]] in *New Spring* affirmed that Siuan was a natural born leader, able to take the lead in every occasion, and she was quite surprised by this being herself a great noblewoman while Siuan was only a poor fisherman's daughter.
Siuan was considered by other Aes Sedai as very smart, very good in the administration, clever and intelligent in resolving puzzles and to find clues. All this qualities were immediately put in service by her fellow Blue sisters employing Siuan in the Ajah [[Eyes-and-ears|eyes-and-ears]] system.
Siuan revealed also to be very manipulative and too secretive.

## Early life and Family
Siuan was born in Tear in 957 NE.  Of humble origin, she was the daughter of a fisherman and had more than one sister. Her mother died while she was still a child and her father sometime during her training period at the White Tower (972-978 NE). She had nine uncles. One, [[Huan (Tairen)|Huan]], died in a fire while rescuing children. Two other uncles are street robbers, thugs and drunkards whose names her father wouldn't even speak in the house. One of those was her father's brother. In childhood, she was a very mischievous girl who had a fondness for pranks.

## History
Siuan was born with the [[Spark|spark]], and was sent to [[Tar Valon]] the same day her ability was discovered. She and [[Moiraine Damodred|Moiraine]] arrived on the same day, which was rather unusual. They quickly became [[Pillow friends|pillow friends]]. Siuan quickly took the lead between the two of them, which surprised Moiraine at first until she realized Siuan had been born to lead.
During her early years as a [[Novice|novice]], Siuan was found to have an earthy way of speaking, to the point of almost being vulgar. The Aes Sedai worked to instil a modicum of decency. She could not read or write when she came to Tar Valon, but after much study and learning, she was able to teach novice classes on the [[Old Tongue]].
Elaida knew their potential and was very hard on both her and Moiraine, pushing them to meet her very high standards and not allowing a single slip.
Siuan was raised to [[Accepted]] after three years as a novice. As such she was present at [[Gitara Moroso]]'s [[Foretelling]] about the Dragon reborn. After three years as Accepted she was raised at the exact same time as her [[Pillow-friend|pillow-friend]] Moiraine Damodred.
Moiraine and Siuan played a last prank on Elaida the night before their raising. They were caught by her trying to sneak mice into her bed; she made sure they were punished severely.
Only six years in training was a record matched by very few Aes Sedai in the history of the Tower, and due to their level of power Moiraine and Siuan immediately reached the top of Aes Sedai hierarchy, even if not their full potential.
Once she was raised, it was revealed that she had a mind for puzzles and soon was put in charge of the Blue Ajah's [[Eyes-and-ears|eyes-and-ears]], after spending some years as the assistant of the former sister of this position, [[Cetalia Delarme]].

## Activities
### The Dragon Reborn
At the end of the [[Aiel War]], in the midst of the [[Battle of the Shining Walls]], Siuan and Moiraine were present during a Foretelling, spoken by the [[Keeper of the Chronicles]], Gitara Moroso, forewarning the imminent birth of the [[Dragon Reborn]]. As the Amyrlin Seat, [[Tamra Ospenya]] gathered [[Tamra Ospenya's Searchers|certain sisters]] to search for the child. She and her searchers were murdered by the [[Black Ajah]], leaving only Siuan and Moiraine to continue their charge. The duo agreed to work in secret and separately, with Moiraine going out in the world while Siuan managed affairs within the White Tower.
Shortly after being raised to the shawl, Siuan was recruited as the assistant of [[Cetalia Delarme]], who was head of the Blue Ajah's [[Eyes-and-ears|eyes-and-ears]] network after learning of Siuan's natural aptitude for logic, puzzles, and codes. Under the tutelage of Cetalia, Siuan soon rose to become a political prodigy in her Ajah.

### The Amyrlin Seat
In 988 NE, when the Amyrlin [[Marith Jaen]] died after just four years of service, the [[Hall of the Tower]] decided to break the long tradition of twenty to thirty year reigns and seek a long period of stability. The Hall thought the deaths of three Amyrlins to have been from natural causes, even if some Sitters might have suspected otherwise. The Hall was deadlocked between four sisters who had worn the shawl for less than fifty years as the next Amyrlin. [[Seaine Herimon]] suggested Siuan be raised, noting the deaths of three consecutive Amyrlins after just a few years of service, as well as Siuan's qualifications in administration. The Hall agreed, despite knowing this might give Siuan a two hundred and more year long reign, unless deposed or murdered. At the age of thirty, after wearing the shawl for just ten years, Siuan Sanche was raised to the Amyrlin Seat, becoming the youngest Amyrlin ever at the time.
During a dispute over [[Murandian]] raids into the Andoran border, [[Gareth Bryne]] was severely upbraided by Siuan when she was the Amyrlin Seat. Years later she explained why Bryne was not allowed to interfere: the White Tower had identified a young [[Murandy]] border lord named [[Dulain]] who could one day unify all of Murandy. She didn't want Bryne's soldiers to kill him. Unfortunately the young lord was killed a month later by an Andoran farmer during a sheep raid.

### Meeting the Dragon Reborn

In 998 NE Siuan traveled to [[Fal Dara]] with an escort of no less than fourteen Aes Sedai, including [[Anaiya]], [[Liandrin]], [[Carlinya]], [[Alanna Mosvani]], and [[Verin Mathwin]], and a fair amount of [[Warder|Warders]]. During her visit she had meetings with Moiraine to discuss their search for the Dragon Reborn. She met all three *ta'veren* and discussed Rand with Moiraine and Verin, whom they briefly considered killing due to her deducing one of the boys was the Dragon Reborn. Siuan and Moiraine decided to trust Verin and fill her in on the situation. They decided to guide Rand to fulfill his destiny. She sent all three on the quest to retrieve the [[Horn of Valere]]. Just before she left she talked to Rand. During this conversation an arrow was shot at them. It was unclear at the moment who the intended target was or who the shooter was. [[Ingtar Shinowa]] later admitted to Rand, just before sacrificing himself, that he let a [[Gray Man]] into Fal Dara:

*"A pale little man you didn't seem to really notice even when you were looking at him. Take him inside Fal Dara, I was told, inside the fortress. I did not want to, but I had to do it. You understand? I had to. I never knew what he intended until he shot that arrow. I still don't know if it was meant for the Amyrlin, or for you."*
   —Ingtar Shinowa 


### Back at the Tower
After her trip to Fal Dara, Siuan returned to the White Tower. Here she continued to orchestrate her plans to control the Dragon Reborn.
She led the [[Circle]] that [[Healing|Healed]] [[Mat]], using a [[Sa'angreal]] to augment their combined power.
After [[Liandrin]] and twelve other sisters of the Black Ajah left the tower, Siuan decided to set [[Egwene]] and [[Nynaeve]] on their trail. She decided they were among the few she could trust, and although Elayne was not specifically included, she expected it, and was able to deny knowledge of it. The result was the three girls heading to Tear to stop a trap meant for Rand.
She received a message from Moiriane from [[Tear (city)|Tear]] saying that Rand had exposed himself as the Dragon Reborn by pulling *Callandor* from the Heart of the Stone. After this she received no more messages which irritated her deeply. She kept all her important documents in a small chest and used a very faint ward on it that burned the contents if anyone but her tried to open the chest.
At the same time Siuan hid [[Min]] from the world as Elmindreda in the Tower. She had Leane disguise Min as a noblewoman on the run from a forced marriage. In exchange Siuan asked Min to help using her talent in reading the auras. She also wanted Min to keep [[Gawyn]] and [[Galad]] at bay and had her befriend [[Logain]], the gentled and depressed false Dragon who was being kept at the Tower, but whose aura foretells a great future.

### Deposed
Elaida had been Siuan and Moiraine's enemy since they were Accepted due her punishment by the Mistress of Novices for her bad involvement in instructing them on the test for the Shawl.
Once Elaida learned that Siuan had kept knowledge of the [[Dragon Reborn]] secret, Elaida decided that she must be the one to lead and control him or he would destroy the world. Elaida also took note of Siuan's involvement with the Two Rivers girls.
Using some clever politics she had Siuan legally deposed and stilled, killing her Warder [[Alric]] in the process, taking the law to its extreme. Among the sisters personally involved in capturing Siuan after deposition there were [[Elaida do Avriny a'Roihan|Elaida]], [[Danelle]], [[Joline Maza]], [[Alviarin Freidhen|Alviarin]] and [[Shemerin]].
Some time later, [[Laras]], Mistress of the Kitchens in the White Tower, with the aid of [[Min Farshaw]], helped Siuan and her former Keeper, [[Leane Sharif]], escape out of the cells. Siuan only made it out of Tar Valon by lying (an ability gained by being stilled) about the whereabouts of [[Elayne Trakand]] and [[Egwene al'Vere]] to [[Gawyn Trakand]], who let them pass through the gates. As they left the city, they found [[Logain Ablar]], who joined them after Siuan offered him revenge against the [[Red Ajah]].
Siuan used revenge to fill the void that was created by the loss of *saidar*. She searched for where all the other Aes Sedai fled to when she was stilled, along with Min, Logain, and Leane. While in the remote village of Kore Springs in Andor, she was captured by one of the villagers for damage to property. It is here that she encountered Gareth Bryne, the local Lord, who did not recognize her. He paid for the damage in exchange for the three women (Logain has escaped beforehand) to work on Bryne's property.
They swore one of the most binding oaths but Siuan did not specify *when* she would fulfill it, showing that she still tried to hold to the [[Three Oaths]]. Logain rescued the ladies later on and they escaped to carry on with their search. After coming across an agent for the Blue Ajah eyes-and-ears, the agent revealed that the [[Rebel Aes Sedai|rebel Aes Sedai]] were meeting in a location called Sallie Daera, which is code name for [[Salidar]]. The group arrived there and met with the [[Salidar Six]]. Siuan manipulated them into forming the "real Hall of the Tower" and to consider a new Amyrlin who would be young enough to be "guided" by the rest of the Aes Sedai. Siuan also fell back into her old role as the head of the Blue Ajah eyes-and-ears. Gareth arrived and Siuan was forced to honor her oath and become his servant. She seemed to hate him and always acted aggressively when talking about him or to him. This was a cover for the fact that she actually loved him, even if she didn't realize it yet.

She also pretended that she and Leane hated each other and didn't talk anymore, in an attempt to guide and manipulate the Sitters.


### Joining Salidar
Upon the arrival of [[Nynaeve al'Meara]] and [[Elayne Trakand]] to Salidar, she started being trained in the [[World of Dreams]]. During experimentation by Nynaeve, Siuan wore the a'dam bracelet that was linked to [[Moghedien]]'s neck; while she was able to sense Moghedien, she was not able to sense the true source, or cause Moghedien to feel anything.
Nynaeve al'Meara studied Siuan, Leane and Logain until she learned how to Heal stilling, but while she was able to completely Heal Logain, it only partially worked on Siuan and Leane, leaving their strength with the [[One Power]] severely reduced. Siuan rejoined the [[Blue Ajah]], although she had relatively low standing among Aes Sedai, and had to defer to those whom she once ruled. Her strength with the One Power was reduced to roughly a third of her former capacity. Although her pride was injured, she realized its usefulness as other Aes Sedai overlooked her and forgot her substantial political abilities. The Warder bond that broke when [[Alric]] died also returned after her healing, and Siuan went through a delayed grieving process. With Egwene's help, Siuan gave tea to the Aes Sedai holding Logain's shield, rendering them unconscious and allowing him to escape. While in [[Salidar]], Siuan ran the eyes-and-ears network for [[Egwene al'Vere]], the Amyrlin Seat of the rebel Aes Sedai, and was teaching Egwene about being Amyrlin.

### Serving Egwene
She was also devoted to serving Egwene and led her to where [[Myrelle Berengari]] and [[Nisao Dachen]] had been hiding [[Lan Mandragoran]]. The two Sisters swore an oath of fealty to Egwene and Egwene told them to obey Siuan as they would her. Siuan's estimation of Egwene had grown significantly since this and she even mentioned Egwene being a very dangerous woman.
Egwene finally uncovered the fact that Siuan was in love with Gareth Bryne. Siuan was mortified and wanted to keep the fact quiet. She traveled with Egwene to meet with various nobles along the border of Andor and [[Murandy]] and helped Egwene develop the plan that would eventually force all the Sitters in the Hall to respect and treat Egwene as a proper Amyrlin rather than just a figurehead. She also mentored Egwene on how to be a proper Amrylin, and grew to respect her. 
She began to work on her theory of the [[Too Young Sitters]] conspiracy bringing it foward for Egwene to dwell on.
When Egwene decided to take over from [[Bodewhin Cauthon]] in the plan to turn the harbor chains into *cuendillar*, Siuan was told by Egwene to keep quiet about it.
After being captured by [[Elaida's White Tower]] Aes Sedai, Egwene sought Siuan out in her dreams and told Siuan she was fine and not to come and rescue her. Siuan delivered this news to Egwene's other advisers. Lelaine then approached Siuan and told her in no uncertain terms that she was to support Lelaine for Amyrlin if Egwene did die. Siuan's experience as Amyrlin shows Lelaine that the old Amyrlin's support is important and her advice would benefit Lelaine in the Seat. Also, Siuan's role in advising Egwene is known among the Rebel Aes Sedai.

### To rescue the Amyrlin
Siuan became one of Lelaine's attendants, all the while manipulating her so that Lelaine remained at odds with Romanda. Siuan continued to meet with Egwene in *Tel'aran'rhiod*, where she gave her the news of Halima actually being one of the Forsaken and Lelaine's reach for power while pretending to be acting in Egwene's name. She overheard [[Ashmanaille]] reporting about [[Elaida a'Roihan's White Tower]] now being able to Travel. She then sent a message to Bryne to warn him about this news.


She was part of the group who questioned [[Shemerin]] about how she escaped the White Tower. She continued to meet with Egwene in *Tel'aran'rhiod* and pleaded with her to let her be rescued but to no avail. Egwene again met her in *Tel'aran'rhiod* and told her that both Sheriam and [[Moria Karentanis]] were Black Ajah and that they should be watched. Before Egwene could say more she suddenly disappeared from *Tel'aran'rhiod*. Siuan woke to find the Seanchan attacking the White Tower. She gathered Bryne and Gawyn and used the attack as an excuse to enter the White Tower to rescue Egwene. Before going Bryne agreed only to accompany Siuan if she bonded him as her Warder, which she did. After bonding, they both finally realized how much the other loved them. The group entered through the way Shemerin escaped.
During the [[Battle of Tar Valon]], [[Gareth Bryne]], by then Siuan's Warder, was able to prevent a Seanchan [[Bloodknife]] from killing her. The assassin stabbed Gareth with a poison needle that he did not notice, but Siuan did. She [[Healing|Healed]] him, saving his life. Siuan took this mutual lifesaving to be fulfilment of Min's viewing about them.
The group found an exhausted Egwene and took her back to their camp, in fact using Vora *sa'angreal* Siuan is able to open a suitable gateway for all of them. But the next morning Egwene is furious with Siuan because she did not obey her order to not rescue her. So her plans to gain the Tower are gone. Nevertheless Egwene start the purge of the Black Ajah in the rebel camp and immediately after she decided to take advantage of the White Tower vulnerability after the Seanchan Raid.
Siuan was beside Egwene just as she was about to give Bryne and his army the signal to attack the White Tower when [[Andaya Forae]] arrived and asked Egwene to become the new Amyrlin Seat. Siuan advised her to be cautious as it may have been a trap but Egwene ignored her and accepted the position. Once everyone was inside the White Tower Egwene told Siuan to get all the rebel Aes Sedai to line up in ranks in front of the [[Sunset Gate]] in order to give an apology to the new Amyrlin Seat.

### Back within the Tower
She was with [[Saerin Asnobar]], who she had come to like, when [[Jimar Chubain]] informed them that Rand had entered the White Tower. Rand greeted Siuan before entering the Hall and thanked her for taking the arrow for him all those months ago in Fal Dara. He also asked her to help him with Egwene after he met with her.
She walked in on Gawyn seeking advice from Bryne on his situation with Egwene. Bryne gave him a very ambiguous answer.
She met with Egwene and Nynaeve about how they would lure [[Mesaana]] out of hiding. They agreed on bringing some [[Windfinder|Windfinders]] and Wise Ones into *Tel'aran'rhiod* in the hope that some of Mesaana's lackeys would pass the information on.
She was standing guard when the Black Ajah attacked in *Tel'aran'rhiod* and teamed up with Leane in the [[Battle in Tel'aran'rhiod]].

### The Last Battle
Siuan is in attendance at Elayne's initial war-council, where it is decided that the army will fight on four fronts led by the four Great Generals. In the first phases of the [[Last Battle]] Siuan was in [[Kandor]], in the Aes Sedai command tent, when the [[Shara|Sharans]] attacked. Siuan, Bryne and [[Yukiri]] jump through the viewing Gateway that Yukiri had created. They fall out of the Gateway at a great height and manage to survive thanks to Yukiri creating a massive cushion of that they fall onto. After the attack Siuan and Yukiri Healed many survivors and started to worry about Egwene's fate.
Siuan is relieved when Egwene arrives back to camp. The Aes Sedai army managed to retreat back, beside a river on the Kandor-Arafel border. There Bryne decides to commit his forces, until losses become too unacceptable and they have to fall back again. Siuan calls out a question to Egwene, that only the both of them would know the answer to. She checks Egwene's eyes as she answers, concerned that she could have been Turned. Egwene answers true and her eyes are still her own. Egwene notices *raken* scouts in the air and it has been confirmed by Min that the Seanchan fight the shadow. Min saw the viewing that Siuan and Bryne had to stay close to each other or both would die. But Siuan assumed that she and Gareth fulfilled the prediction during the rescue of Egwene from the Tower; so when Egwene asked her to go to put an eye on the Seanchan Empress, Siuan separated from Bryne without too much worry.
But against Mat's command center, the [[Sharan|Sharans]] launched a surprise assault. Siuan arrived there just in time to save Min's life by stopping the heart of a Sharan who tried to kill her. Rather than be thankful, Min berated Siuan for not following her instructions. Siuan claims that she has a greater purpose, to make sure Mat does not fall in battle.

*"Siuan! You're not supposed to be here! I told you. Stay near Gareth Bryne!"
**"I did stay near him, almost near as his own smallclothes, I'll have you know. We saved one another's lives because of it, so I guess the viewing was right. Are they ever wrong?"
"No. I told you that. Never. Siuan... I saw an aura around Bryne that meant you had to stay together, or the two of you would die. It hangs above you, right now. Whatever you think you did, the viewing has not been accomplished yet. It's *still there*."*

   —Min and Siuan *on her viewing*
Siuan and Min entered the burning command post to see Mat battling with a group of Gray Men trying to assassinate him and Fortuona. Min killed the final Gray Man, and turned to find Siuan dead, her clothing burned from an explosion of fire that had taken her life and part of the command post.

## Personal quotes
"Some people just aren't worth a tear."
"It is easier to ask forgiveness than permission." 
"There are times when rules can be broken." 
## Viewings

Min saw her lying on the floor wearing nothing, and something odd about her at the same time (*fulfilled - she was stilled and demoted and thrown into the cells of the White Tower naked.*)
That she must also always be near Gareth otherwise one, or both may die (*fulfilled*)
## In the television series
In the [[The Wheel of Time (TV series)|television series]],   is played by actress  . As a child, she is played by  .
## Notes

|**Major Characters**|
|-|-|
|**Protagonists**|**Main:****Primary:**|
|**Antagonists**|**The Shadow:**|
|**Major Allies**|**Aes Sedai:****Asha'man:****Aiel:****Seanchan:****Westlands Rulers:****Other Allies:**|
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Siuan_Sanche