---
tags: [Goshien, Mosaada, Aielsepts]
---
The **Mosaada** is a sept of the [[Goshien]] [[Aiel]]. The sept hold is unknown.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Mosaada