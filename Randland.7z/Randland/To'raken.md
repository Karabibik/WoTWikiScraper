---
tags: [Seanchananimals, Animals]
---

*To'raken* are animals used by the [[Seanchan]].

*"To'raken are one of the Seanchan exotics, taken from worlds accessed via the Portal Stones to fight Shadowspawn. They are large flying animals, that resemble raken, except larger and brown rather than grey and herbivorous not omnivorous. They are not as agile or fast as raken, but are stronger and can fly for much greater distances without rest, or carry heavier loads. Their primary purpose is transportation of troops or cargo, transporting as much as a thousand pounds over distances of two hundred miles. They are ranked lower than raken and a morat'raken would not normally be ordered to fly a to'raken, though they would be capable.Morat capable of handling a to'raken are able to handle a raken as well. But morat'raken are considered superior to morat'to'raken. Ordering a morat'raken to fly a to'raken would 'lower the eyes' of the flier."*
   —[[The World of Robert Jordan's The Wheel of Time]], Chapter 18 
Like the *raken*, it is roughly equal to a horse in intelligence. *To'raken* are larger than raken, and are unable to simply throw themselves into flight, instead requiring a running start. The *to'raken* are also not particularly agile fliers. Their value instead comes from their strength and endurance. They have been known to fly up to a thousand miles with only a single *morat'to'raken* in the saddle.
*To'raken* are typically used to carry valuable cargo or people who need to be transported quickly. With only a single *morat* aboard, a *to'raken* is able to carry an additional thousand pounds up to two hundred [[Mile|miles]].
When injured, *to'raken* frequently refuse to fly farther than the safest landing area; however there is often a difference in opinion between the *to'raken* and the *morat* as to what constitutes a "safe landing area."

## Etymology
The Seanchan word *to'raken* is similar to the English word "dragon".

## Exotic animals of the Seanchan
*Raken*
*Grolm*
*Lopar*
*Corlm*
*Torm*
## Notes







https://wot.fandom.com/wiki/To%27raken