---
tags: [Ashaman, Titles]
---



*Tsorovan'm'hael* is a word in the [[Old Tongue]] meaning "Storm Leader." It is a title in the [[Asha'man]] military rank that was held by [[Charl Gedwyn]] before his death and is considered to be below only the *M'Hael*.

## Also see
*M'Hael*
*Baijan'm'hael*
[[Asha'man (Rank)|Asha'man]]
[[Dedicated]]
[[Soldier]]





https://wot.fandom.com/wiki/Tsorovan%27m%27hael