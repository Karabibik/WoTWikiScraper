---
tags: [Women, YellowAjah, AesSedai, LivingasofCOT, RebelAesSedai, MiddleRankingAesSedai, Channelers]
---


**Therva Maresis** is an [[Aes Sedai]] of the [[Yellow Ajah]] and has allied herself with the [[Salidar Aes Sedai]].  

## Contents

1 Appearance
2 Abilities
3 History
4 Activities
5 Notes


## Appearance
She has a long nose. She is slim, and has yellow-slashed riding skirts and a cloak edged in yellow. 
She is excitable by nature, and it was considered a bad sign if she ever looked calm and serene.

## Abilities
At a strength level of 34(22), she is relatively weak in the [[One Power]] for an Aes Sedai. This is nearly as strong as [[Siuan Sanche]] (after she was [[Stilled|stilled]] and [[Healed]]). Therva is an expert at reading residues.
As she is of the Yellow Ajah, she doubtless has the Talent of Healing.

## History
Therva is 138 years old. She was born in 862 NE and went to the [[White Tower]] in 879 NE. After spending eight years as a [[Novice|novice]] and seven years as [[Accepted]], she was raised to the shawl in 894 NE.

## Activities
She is present in the [[Little Tower]] when Nynaeve Heals both Siuan Sanche and [[Leane Sharif]] of stilling completely shocking everyone. Therva thinks that Fire could be useful in Healing problems of the heart.
Due to her skills at reading residues, she was one of the team chosen to investigate after the massive amount of the One Power was used for the [[Cleansing of saidin]].
Some time after they report that they found a large hole where Shadar Logoth used to be. Reading the residues of Power they discovered also that a huge amount of *saidin* was used along *saidar*.

## Notes






https://wot.fandom.com/wiki/Therva_Maresis