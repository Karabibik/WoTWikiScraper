---
tags: [Altara, Titles]
---



**Mistress of the Four Winds** is a [[Title|title]] of the [[Altara|Altaran]] monarch. The title most likely changes, based on the gender of the monarch. It can be surmised that the title came about due to the [[Cemaros|cemaros]] that plague the [[Sea of Storms]] and Altara's capital, [[Ebou Dar]]. The title was first introduced by [[Tylin Quintara Mitsobar]], [[Queen]] of Altara. Upon [[Beslan Mitsobar]]'s ascension to the [[Throne of the Winds]], the title most likely changed to "Master of the Four Winds."


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Master_of_the_Four_Winds