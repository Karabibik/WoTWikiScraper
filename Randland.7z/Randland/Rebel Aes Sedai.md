---
tags: [RebelAesSedai, AesSedaifactions]
---
The **Rebel Aes Sedai** were a group of [[Aes Sedai]] from the [[White Tower]] who sided with [[Siuan Sanche]] rather than [[Elaida do Avriny a'Roihan]] during the [[White Tower Schism]]. Their primary purpose was to continue the traditions of Aes Sedai and to take the White Tower back from Elaida.

## Contents

1 Organization
2 History

2.1 Consolidation in Salidar
2.2 Picking new leadership
2.3 Subsequent actions


3 Reunion with the White Tower
4 Sisters among the Rebels

4.1 Blue Ajah

4.1.1 Leadership
4.1.2 Other sisters


4.2 Green Ajah

4.2.1 Leadership
4.2.2 Other sisters


4.3 Gray Ajah

4.3.1 Leadership
4.3.2 Other sisters


4.4 Brown Ajah

4.4.1 Leadership
4.4.2 Other sisters


4.5 White Ajah

4.5.1 Leadership
4.5.2 Other sisters


4.6 Yellow Ajah

4.6.1 Leadership
4.6.2 Other sisters




5 Notes
6 See also


## Organization
[[Egwene al'Vere]] served as the [[Amyrlin Seat]] of the Rebel Aes Sedai. She was originally raised to be a puppet, but through her own dexterity and intelligence with the mentorship of Siuan Sanche, she came to rule the Rebels, instead of the other way around. The very women who - under the manipulation of Siuan - had seen her raised, instead eventually swore oaths of fealty to her.
Much of the bureaucratic system remains similar to the White Tower before the split, having a [[Keeper of the Chronicles]], [[Mistress of Novices]], and [[Sitters]]. However, due to the nature of the divide there are major differences, including no representation from the [[Red Ajah]] and the formation of a group known as [[Egwene al'Vere's Council|Egwene's Council]], informally called the [[Salidar Six]].
[[Novice|Novices]] of the Rebels are divided into Families of six or seven. This necessary organization was to account for the enormous number of them in their ranks (nearly one thousand) and has been successful in preventing run-aways.

## History
After a [[Red Ajah]] [[Sitter]] of the [[Hall of the Tower|Hall]], [[Elaida do Avriny a'Roihan]], usurped the [[Stole|stole]] and staff of the [[Amyrlin]], [[Siuan Sanche]], a split formed down all the ranks within the [[White Tower]], from the young trainee warriors led by [[Gawyn Trakand]] to the [[Warder|Warders]] set to defend their Aes Sedai, from Sitters in the Hall to the most recently initiated sisters. During this time, those who sided with Siuan managed to escape, and no [[Blue Ajah]] sister remained in the Tower. 
According to Min Farshaw, most Greens and about half of the Browns, Grays, Whites and Yellows also left, but truly the rebels were less (most of the other Ajah Aes Sedai became [[Unaligned sisters|unaligned sisters]]), even if a considerable number, in fact summing the Blue Ajah with other rebels in total around one third of the Aes Sedai (a little more than three hundreds) reached the small village of [[Salidar]] as their rally point.

### Consolidation in Salidar
Eventually grouping together at Salidar they waited and plotted to regain the White Tower and remove Elaida. Salidar was formerly known as *Sallie Daera* when part of the kingdom of [[Shiota]], the birthplace of the legendary Blue Amyrlin [[Deane Aryman]].
The original Rebel leadership consisted of a council of six, later on known as Egwene's Council, among the fandom called the [[Salidar Six]]. They organized the early days of the rebellion and had the sisters opposing Elaida a'Roihan gather at Salidar. The Salidar Six were the following:

[[Sheriam Bayanar]] of the Blue Ajah. Served as the leader of the Six.
[[Anaiya]], also of the Blue Ajah. Possibly served as [[First Selector]] for the Blue Ajah, and even if not, certainly someone whom many Blues - and for that part non-Blues - listened closely to.
[[Myrelle Berengari]] of the [[Green Ajah]]. Young, raised but a little more than 15 years ago, but influential, and was elected [[Captain-General]] of the Green.
[[Carlinya]] of the [[White Ajah]]. Held as much sway as most Sitters even before the separation.
[[Morvrin]] of the [[Brown Ajah]]. Almost certainly on the [[Brown Ajah Council]].
[[Beonin Marinye]] of the [[Gray Ajah]]. Although one of the rebellion's first organizers, she was secretly Elaida's agent and believed in Elaida as Amyrlin Seat.
[[Nisao Dachen]] of the [[Yellow Ajah]] later on took an informal place on the council, having sworn her oath of fealty to Egwene, informally replacing the murdered Anaiya. The other members did not until the very last days of rebellion accept her as a member of it.

### Picking new leadership
After Siuan, [[Leane Sharif]] and [[Min Farshaw]] arrived in the town and started to mobilize the women, Siuan indicated that they would have no real authority unless they had their own [[Rebel Hall of the Tower| Hall of the Tower]]. This also meant, by implication, that they would need an Amyrlin to oppose Elaida.
Siuan manipulated the [[Salidar]] [[Aes Sedai]] into summoning the young [[Egwene al'Vere]] from her training with the [[Aiel]] [[Wise Ones]] to become the [[Amyrlin Seat]]. She was elected unanimously by the full Hall on the second vote.

### Subsequent actions
The Rebels, due to their desperate nature and radical new leadership, have made several actions that go against the usually conservative nature of the [[White Tower]]. Here is a brief summary of some of those decisions:

Declaring war against Elaida as Amyrlin Seat.
Opening the [[Novice book|novice book]] to all ages.
Voting for an alliance with the [[Black Tower]].
Making a Bargain with the [[Atha'an Miere]].
Raising an army and besieging Tar Valon.
Sending [[Rebel Spies]] into the White Tower.
Raising Aes Sedai by decree, as opposed to being tested.
The decision to make war on Elaida was necessary after raising their own Amyrlin and Hall. [[Delana Mosalaine]] of the Gray Ajah, herself of the [[Black Ajah]], even demanded that Elaida be branded Black Ajah.
To open the novice book to all ages was Egwene's own construction. The Hall and many senior sisters despised the decision at first, but as the Rebels suddenly had more novices than the Tower had had in at least a thousand years, the decision became widely accepted, at least publicly.
The alliance with the Black Tower was voted for after a group of sisters specifically skilled in reading residues of *saidar* and *saidin* returned from the place that was formerly [[Shadar Logoth]]. The immense residues that surrounded the gigantic crater was clear evidence of an incredibly destructive weave, probably used by the [[Forsaken]]; the Rebel Aes Sedai were not aware that the crater was the remnant left after the [[Battle of Shadar Logoth]] and the [[Cleansing of saidin|cleansing of saidin]].
The [[Bargain]] with the Atha'an Miere was considered both unfair and utterly over demanding by the Aes Sedai, as it concerned the [[Bowl of the Winds]] in a matter that was important not only to the Aes Sedai but to everyone, and the Atha'an Miere were the only ones to receive anything else off the Bargain, whereas the Aes Sedai received nothing.
To send Rebel spies back to the Tower was a political move to undermine Elaida's reign. Unfortunately it failed, since Elaida's agent, Beonin, at that time had returned to the Tower and betrayed the spies. This action was undertaken by the Salidar Six, unbeknownst to the Hall.
The decision to raised Aes Sedai by decree was another of Egwene's ploys; it gave her friends [[Elayne Trakand]] and [[Nynaeve al'Meara]] political authority on their respective missions. It backfired on [[Faolain Orande]] and [[Theodrin Dabei]] who were treated better than [[Accepted]], but nowhere near as full sisters. In the end it worked out well, since Egwene's greatest political rivals, [[Lelaine Akashi]] and [[Romanda Cassin]], took one of these each under their wings, and they reported their activities back to Egwene.
For more detail on some of the votes concerning these decisions, see the [[Voting history]] article.

## Reunion with the White Tower
After the Rebel Amyrlin Seat was taken captive by the White Tower loyalists, she undermined the rule of Elaida a'Roihan from within. Despite her warnings that the [[Seanchan]] would attack the Tower, no precautions were taken, and Elaida was taken [[Damane|damane]]. Since then, Egwene has been raised the proper Amyrlin Seat, and has welcomed the Rebels back. The White Tower Schism is over.

## Sisters among the Rebels
The only Ajah to have all its sisters present among the Rebels is the Blue Ajah, and the only Ajah to have none among the Rebels is the Red Ajah. All other Ajahs are split, though Min suggested that the majority of Greens abandoned the White Tower. Here is a short (and incomplete) list of known sisters that went over to the Rebels:

### [[Blue Ajah]]

Sheriam Bayanar- [[Keeper of the Chronicles]] (also [[Black Ajah]] )
[[Lelaine Akashi]] - Sitter
[[Lyrelle]] - Sitter
[[Moria Karentanis]] - Sitter (also Black Ajah)

Anaiya
[[Siuan Sanche]]
[[Kairen Stang]]
[[Rafela Cindal]]
[[Aeldene Stonebridge]]
[[Adine Canford]]
[[Maigan]]
[[Reiko]]
[[Faolain Orande]]
### [[Green Ajah]]

Myrelle Berengari - [[Captain-General (Green Ajah)|Captain-General]]
[[Malind Nachenin]] - Sitter
[[Samalin]] - Sitter
[[Faiselle]] - Sitter

[[Careane Fransi]] (also Black Ajah)
[[Elayne Trakand]]
[[Kiruna Nachiman]]
[[Bera Harkin]]
[[Seonid Traighan]]
[[Faeldrin Harella]]
[[Nacelle]]
[[Vandene Namelle]]
[[Leane Sharif]] (Formerly of the [[Blue Ajah]]. Switched to the [[Green Ajah]] after being stilled and [[Nynaeve al'Meara]] [[Healing]] her.)
### [[Gray Ajah]]

[[Tiana Noselle]]- [[Mistress of Novices]]
[[Delana Mosalaine]] - Sitter (also Black Ajah)
[[Kwamesa]] - Sitter
[[Varilin]] - Sitter

Beonin Marinye
[[Merilille Ceandevin]]
[[Merana Ambrey]]
[[Ashmanaille]]
[[Meidani]]
[[Jennet]]
### [[Brown Ajah]]

[[Janya Frende]] - Sitter
[[Escaralde]] - Sitter
[[Takima]] - Sitter

Morvrin
[[Theodrin Dabei]]
[[Phaedrine]]
[[Adeleas Namelle]]
[[Sareitha Tomares]]
[[Masuri Sokawa]]
[[Demira Eriff]]
### [[White Ajah]]

[[Saroiya]] - Sitter
[[Berana]] - Sitter
[[Aledrin]] - Sitter

Carlinya
[[Valinde Nathenos]]
[[Brendas]]
[[Zerah Dacan]]
[[Bernaile Gelbarn]]
### [[Yellow Ajah]]

[[Romanda Cassin]] - Sitter and [[First Weaver]]
[[Magla Daronos]] - Sitter
[[Salita Toranes]] - Sitter

Nisao Dachen
[[Dagdara Finchey]] (also Black Ajah)
[[Zenare Ghodar]]
[[Edesina Azzedin]]
[[Berenicia Morsad]]
[[Larissa Lyndel]] (also Black Ajah)
[[Therva Maresis]]
[[Celestin]]
[[Annharid]]
## Notes

## See also
[[Elaida's White Tower]]
[[Unaligned Sisters]]





https://wot.fandom.com/wiki/Salidar_Aes_Sedai