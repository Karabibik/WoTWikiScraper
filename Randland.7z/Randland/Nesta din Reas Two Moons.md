---
tags: [Women, AthaanMiere_people, MistressesoftheShips, Deceased]
---







**Nesta din Reas Two Moons** was the [[Sea Folk]] [[Mistress of the Ships]]. She sailed aboard the *Windrunner*.

## Appearance
She had dark eyes, white hair and a thrusting jaw. She had started to put on a little weight, going from stocky to fat. She had six rings in each ear and numerous medallions on the chain connected to her nose.
She had an air of power; when she said "go", people went.

## Activities
Her Windfinder was [[Renaile din Calon Blue Star|Renaile]] and her Master of the Blades was [[Baroc|Baroc.]]
She met [[Nynaeve al'Meara]] and [[Elayne Trakand]] when they came aboard *Windrunner* while she was docked in [[Ebou Dar]]. She organized a successful bargain with [[Aes Sedai]] concerning the [[Bowl of the Winds]] that was greatly in favor of the Sea Folk.
She sent twenty Windfinders to the Tarasin Palace to assist with the Bowl of Winds.
When the [[Seanchan]] attacked Ebou Dar, Nesta's ship fought a delaying action to allow others to escape. She was taken and refused to accept their rule and was executed soon after; both she and Baroc were impaled. Neither screamed while on the stake. Their heads were placed on poles outside the gates for the crime of Rebellion.

## Notes






https://wot.fandom.com/wiki/Nesta_din_Reas_Two_Moons