---
tags: [Towns, Saldaea]
---
**Kayacun** is a town in [[Saldaea]].

## Locations and Notable Residents
Kayacun has an inn called [[The Queen's Lance]]. Residents include [[Weilin Aldragoran|Weilin]] and [[Alida Aldragoran]], a [[Malkieri]] and [[Saldaean]] couple, was well as [[Ruthan]], a clerk in the service of Weilin.

## Activities
After [[Traveling]] to [[World's End]] and leaving [[Lan Mandragoran]] there, [[Nynaeve al'Meara]] Travels to Kayacun. There, she enlists the help of Weilin Aldragoran, as well as every Malkieri she can find in the [[Borderlands]], to ride to [[Fal Moran]] for Lan.

## Notes






https://wot.fandom.com/wiki/Kayacun