---
tags: [Men, AlmothPlain_people, Farmers, Living, CharactersonlymentionedintheRPG]
---


**Fenton DaVoren** is a farmer from [[Aturo's Orchard]].

## History
Fenton is married to [[Annabelle DaVoren]]. They have two children, [[Tobias DaVoren|Tobias]] and [[Issa DaVoren|Issa]]. His brother, [[Hobbs DaVoren|Hobbs]] is the owner of the town's [[Three Crowns Inn]].
His town is attacked by [[Whitecloaks]], and the farm is left in ruin.


## Notes






https://wot.fandom.com/wiki/Fenton_DaVoren