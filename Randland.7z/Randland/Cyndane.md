---
tags: [Women, Forsaken, Deceased, LivingasofAMOL, Antagonists, Reincarnated, POVcharacter]
---


[[Lanfear]], after being reincarnated by the Dark One, became **Cyndane**, which in the [[Old Tongue]] means "last chance." She was mind-trapped by [[Moridin]] along with [[Moghedien]], and the two of them have been reduced to Moridin's servants.
Her mindtrap was presumably created due to her flouting the Dark One's order that Rand al'Thor was not to be harmed. She was stripped of the privilege of being Chosen for planning to help Rand al'Thor usurp the Dark One early in the series using the [[Choedan Kal]].

## Contents

1 Appearance
2 Activities

2.1 The puppet
2.2 Final plot


3 Notes


## Appearance
Whereas Lanfear was tall and beautiful with dark eyes and pitch black hair, Cyndane is short, if still pretty, with silver hair, blue eyes, and an impressive bosom. She is forced to wear the black and red colors of Moridin. During [[Tarmon Gai'don]], Cyndane begins to change her appearance in *Tel'aran'rhiod* to how she originally looked as Lanfear.

## Activities

Her mindtrap forces her to obey any command given to her by Moridin, who initially appeared to enjoy torturing her as punishment for her pride (though in truth he cared very little). It is also revealed that Cyndane's strength in the One Power was less than Lanfear's, a fact that led a number of the other Forsaken to believe that she was not Lanfear re-incarnated. This loss of strength was revealed to have been a result of the Eelfinn granting her wish to make her stronger than any Aes Sedai. However, in her ignorance, she failed to realize that she was already stronger than any Aes Sedai (or, at least, any Aes Sedai who still held to the title). As such, the Finn began to feed off of her ability to channel, considerably reducing the amount of saidar she could draw upon. Some time later, [[Moridin]], the re-incarnation of Ishamael, somehow discovered her location and went to retrieve her. As the Dark One was capable of resurrecting the dead, Moridin simply killed her rather than rescuing her, and the Dark One retrieved her soul and placed it in a new body. However, the Finn were known to have told Moiraine at one point that they had killed Lanfear by draining her of her channeling abilities too quickly, though Moiraine believed that this tale might have simply been a lie told for the purpose of frightening her.
Cyndane does little after she is re-incarnated, as Moridin keeps her on a proverbially short leash. However, she did participate in the [[Battle near Shadar Logoth]]. Intending to kill Rand for spurning her, she encountered Alivia and engaged her. Alivia, being phenomenally powerful on her own and possessing a number of *angreal* and *ter'angreal*, overwhelmed Cyndane and forced her to retreat, although she did sustain an injury to her arm in doing so.


She attends the meeting with the other Chosen in *Tel'aran'rhiod*, which is made to look like the [[Ansaline Gardens]]. There she is told that Rand is not to be harmed and that Mat and Perrin are to be killed if found.
Later, after Rand's epiphany and the reintegration of Lews Therin's memories into his own, he found Cyndane in a dream in considerable distress. She begged him for help and apologized for everything she put him through before being dragged out of the dream by her torturer (most likely Moridin, though, as was seen later, it may have simply been an act to gain sympathy from Rand).
While recuperating in [[Town]], Slayer is approached by Cyndane in disguise. She tasks him with killing Rand as directly and efficiently as possible, and loans him the use of two *Samma N'Sei* and several guards to assist him, if necessary.
The night before the commencement of the Last Battle, Rand found Cyndane in *Tel'aran'rhiod*, apparently being tortured by Moridin. She attempted to manipulate Rand into helping her but Rand, having integrated Lews Therin's memories into his own, recognized that she was faking her torment in order to engender his sympathy. Found out, she ceased her charade and the two conversed for a short time. During this conversation, Rand offered her one last chance for redemption, and prompted her to let him see inside her mind in order to examine her sincerity in accepting his offer. Though appearing to genuinely consider allowing Rand to see into her mind, she ultimately refused, citing her recent torments as having caused her to mistrust Rand's intentions. Rand however, understood that Cyndane could simply not let go of her desire for power, and showed her his own mind in order to make her understand that the only feeling he still had for her was pity; not affection for their past relationship, and not anger or bitterness over her betrayals. As he departed, Rand simply told her to make herself scarce during the Last Battle.
She wandered in the World of Dreams during the [[Last Battle]] helping Perrin. She showed him how to handle the [[Dreamspike]] and free the [[Black Tower]]. Cyndane watches Perrin defeat [[Hessalam]] and chides him for not killing her. She decides that he will make an adequate replacement for Lews Therin. Perrin asks if she will transport him out of Tel'aran'rhiod but she declines believing he has to work this out for himself. Cyndane reappears beside Perrin, after he has willed some *Samma N'Sei* to become idiots. She informs Perrin that they have been Turned. She Heals both Perrin and Gaul grudgingly from wounds they had sustained during battle and then disappears again.
Thought to have abandoned the [[The Shadow|Shadow]] as the Last Battle rages, she encountered Perrin a few times in *Tel'aran'rhiod* as he hunted for Slayer. She put on a show of helping him to try to gain his trust, but, due to time constraints, she ultimately is forced to place a [[Compulsion]] on Perrin after his defeat of Slayer. Hoping to come to the Dark One's rescue and earn his supreme favor (and all the power it supposedly entailed), she ordered him to kill [[Moiraine]] while she killed [[Nynaeve]]. However, Perrin's love for [[Faile]] allowed him to break free of the Compulsion and he ambushed Cyndane, breaking her neck from behind and killing her.

## Notes






https://wot.fandom.com/wiki/Cyndane