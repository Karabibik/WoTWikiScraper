---
tags: [Wolves]
---


**Burn** is a wolf that is a part of [[Dapple]]'s pack.

## Appearance and History
Burn received his name due to an old shoulder injury from a [[Trolloc]]. He thinks of little outside of hunting and killing [[Shadowspawn]]. He is impatient, angry, and large.

## Activities
Burn, along with Dapple, [[Hopper]] and [[Wind (wolf)|Wind]], speak with [[Elyas Machera]] and [[Perrin Aybara]] when Perrin is learning about being a [[Wolfbrother|wolfbrother]]. Burn becomes reluctant as Dapple wants to follow the humans.

## Notes






https://wot.fandom.com/wiki/Burn