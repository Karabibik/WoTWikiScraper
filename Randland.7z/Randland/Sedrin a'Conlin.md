---
tags: [Men, Murandy_people, LivingasofNS]
---




**Sedrin a'Conlin** is the son of the Lady [[Meri do Ahlan a'Conlin]]. He was born during the end of the [[Aiel War]] in 978 NE.

## History
Sedrin's mother claimed the bounty from the [[White Tower]] from [[Moiraine Damodred]]. Before Moiraine would take Sedrin's name, however, she demands to know of other women who have given birth. Lady Meri, though, is "not accustomed to keeping track of every brat born in the camp."

## Notes






https://wot.fandom.com/wiki/Sedrin_a%27Conlin