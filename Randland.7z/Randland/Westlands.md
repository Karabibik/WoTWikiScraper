---
tags: [Nations, Westlands, Continents]
---

The **Westlands** is one of several names given to the continent or subcontinent that stretches from the [[Aiel Waste]] to the [[Aryth Ocean]], and from the [[Great Blight]] to the [[Sea of Storms]]. It forms the westernmost part of one large landmass that also incorporates the Aiel Waste and the land of [[Shara]], as well as a number of offshore islands belonging to the [[Sea Folk]].

## Contents

1 Geography
2 History
3 Name
4 Size
5 Allegiances
6 External links


## Geography

The Westlands stretches for roughly 3,500 miles from the Aiel Waste to the Aryth Ocean and is mostly temperate, with hot summers in the southern regions and icy winters in the north. The continent consists of several large plains (notably [[Almoth Plain]], the [[Plains of Maredo]], [[Caralain Grass]], and the [[Plain of Lances]]) divided by extensive forests, marshes, and several major mountain ranges, most notably the [[Mountains of Mist]] which divide the western coastal regions from the continental interior.
The continent is dominated by two extensive river networks. The larger consists of the [[Manetherendrelle|River Manetherendrelle]] and its major tributary, the [[Arinelle]]. This network rises in the [[Mountains of Dhoom]] in the far north and is navigable almost from the Blight to the river mouth at [[Illian]]. The [[River Erinin]] flows out the [[Spine of the World]] just south of the [[Niamh Passes]] westwards before turning south for two thousand miles, eventually reaching the sea at [[Tear]]. Although not as extensive as the Arinelle-Mantherendrelle network, the Erinin is by far the longer single river and sees much more traffic, as it passes through two of the busiest cities on the continent.
There are currently fourteen nations in existence in the Westlands: [[Altara]], [[Amadicia]], [[Andor]], [[Arad Doman]], [[Arafel]], [[Cairhien]], [[Ghealdan]], [[Illian]], [[Kandor]], [[Murandy]], [[Saldaea]], [[Shienar]], [[Tarabon]], and [[Tear]], as well as four major city-states: [[Falme]], [[Far Madding]], [[Mayene]], and [[Tar Valon]]. In previous eras, every part of the land was claimed by one nation or another, but in the modern era there are vast stretches of the continent which are given over to wilderness and are rarely traveled. After the [[War of the Hundred Years]], there were twenty-four nations in the Westlands. The nations of [[Almoth]], [[Caralain]], [[Goaban]], [[Hardan]], [[Irenvelle]], [[Kintara]], [[Maredo]], [[Mar Haddon]] and [[Mosara]] all faded away due to lack of population, whereas [[Malkier]] was swallowed by the [[Great Blight]].


## History
For the history of the Westlands, please see the entries on the [[Timeline]] and [[Third Age]].

## Name
The main continent does not posses one single unified name, and is referred to by a variety of titles within the books and fandom. 'Randland' is a common fan term, but is not used in the books themselves. *The World of Robert Jordan's The Wheel of Time* uses the term 'The Land', but this is also not used in the books themselves. The term 'Westlands' originates from *The Wheel of Time Roleplaying Game* and was subsequently used by Robert Jordan in occasional interviews. It is also used in the [[The Wheel of Time (TV series)|television series]], although its continuity differs from that of the books. The only single name used frequently in the novels themselves is 'the wetlands', the [[Aiel]] term for the lands west of the Spine of the World as they are much more fertile than the Waste.

## Size
Although no scale appears on the maps in the books themselves, a scale did appear on the world map on page 146 of the guidebook accompanying the series, *The World of Robert Jordan's The Wheel of Time*. The scale on this map suggests that the distance from the Aryth Ocean to the Spine of the World exceeds 3,000 miles. This concurs with the designers who worked on *The Wheel of Time Roleplaying Game*, who suggested a scale of 1"=400 miles on the color endpaper maps in the hardback editions of the books. By their calculations, the Westlands therefore measures roughly 3,500 miles from the west coast to the Spine of the World, making it approximately the width of the  (but considerably wider north-to-south). In an interview, Robert Jordan seemed to concur, suggesting it was almost 4,000 miles from the Spine to the ocean.
There are around a dozen references to distances between known or approximate locations in the series that can be used to develop a [[Distances in the Westlands|more accurate estimate]] of the size of the Westlands. By these calculations, the Westlands is 3893 miles (6264 km) at its widest and 2877 miles (4628 km) at its narrowest. Similarly, it extends a minimum and maximum of 2571 miles (4136 km) and 3192 miles (2809 km) respectively. These numbers are accurate to within 1% (see full details).

It is important to note that the distances quoted in the books are using in-world [[Measurement|units of distance]], which are probably not the same as miles in real life. Leagues are defined as being four in-world miles, which again is different to real life leagues. It isn't clear which units are used in the secondary sources. This also explains why Jordan's own estimation is higher than the others, as he would use real-world miles in his answer (as he has done with other units of length and weight). 
When using the above-Mentioned distances for length conversion and calculating the area between the Aryth Ocean, the Blight and the Spine of the World via pixel counting on a high-resolution map, one can determine the Area of the Westlands to 24 mio. square kilometers (plusminus 1 mio. km², about 9.3 mio. miles squared) which is almost equal to the size of North America (incl. Greenland)

## Allegiances

By the end of the series, the southwest of the continent is held by the [[Seanchan]], while the northeast remain unconquered nations. This political state of affairs should hold for the immediate future under the terms of the [[Dragon's Peace]], although what the [[Fourth Age]] will bring is unknown. 
The islands of the [[Aile Somera]] and [[Aile Jafar]], plus the kingdoms of Tarabon, Amadicia, and Altara, are held by the Seanchan invaders. Their influence also extends into Almoth Plain and Ghealdan, and there has been fighting with the armies of Arad Doman. The Aiel Waste, Cairhien, Tear, and Illian are held by the Dragon Reborn, with a strong influence in eastern Andor.

## External links
  on  





https://wot.fandom.com/wiki/Westlands