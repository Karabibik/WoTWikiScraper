---
tags: [AesSedai, BlackAjah]
---
The **Black Oaths** are the oaths that are sworn on the [[Oath Rod]] by the [[Black Ajah]] after they use it to un-swear their original [[Three Oaths]] as [[Aes Sedai]]. The Oaths are as follows: 


These Oaths make it effectively impossible for someone to betray the Black Ajah. Even though [[Sheriam Bayanar]] only joined the Black Ajah hoping it would advance her political career, these oaths forced her to steal the dreamer *ter'angreal* after [[Mesaana]] ordered her to do so.
However, the [[Black Ajah Hunters]] were able to force [[Talene Minly]] into confessing by making her forswear all oaths that bound her on the Oath Rod, and then having her re-swear the [[Three Oaths]].
[[Verin Mathwin]] also found a loophole to circumvent the third Oath by poisoning herself and revealing the secrets of the Black Ajah to [[Egwene al'Vere]] as she was dying, as the Oath forbids her from betrayal until the hour of her death, rather than the very moment of death.
Re-swearing different Oaths also means that even though the Black Ajah are freed from the original oaths, they retain an ageless look and a shortened lifespan by still being bound to the Oath Rod; thus their appearances and lifespans never rouse suspicion from other Aes Sedai. Indeed, this is partly the reason why [[Ishamael]] devised the Black Oaths when he created the Black Ajah, other than wanting to permanently bind the Black Ajah to the [[Shadow]].

## Notes






https://wot.fandom.com/wiki/Black_Oaths