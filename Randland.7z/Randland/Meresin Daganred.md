---
tags: [Men, Cairhien_people, BandoftheRedHand, Soldiers, Lords, LivingasofLOC, Nobility]
---



Lieutenant **Meresin Daganred** is from the [[Cairhienin]] [[House Daganred]]. His *con* is all wavy vertical lines of red and white. 

## Appearance
He is a pale, slender man with a narrow face and long nose, and has the shaved head of a Cairhienin soldier.

## Activities

He is sent from Cairhien when it is attacked by the [[Shaido]] and finds [[Rand al'Thor]] and the rest of the [[Aiel]].
[[Matrim Cauthon]] mentions him being one of his captains in the [[Band of the Red Hand]].






https://wot.fandom.com/wiki/Meresin_Daganred