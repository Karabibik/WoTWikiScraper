---
tags: [Hills]
---
The **Rhannon Hills** are an extensive hill range located east of [[Ebou Dar]]. They run almost from the city for a hundred miles until they meet the [[Venir Mountains]]. The [[Farm|farm]] belonging to the [[Kin]] is located a few miles from the city to the northeast, close to the hills, and [[Rand al'Thor]] fought the [[Seanchan]] to a standstill north of the hills.






https://wot.fandom.com/wiki/Rhannon_Hills