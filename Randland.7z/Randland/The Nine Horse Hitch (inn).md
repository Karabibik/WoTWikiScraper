---
tags: [Murandy, Inns]
---
**The Nine Horse Hitch** is an [[Inn|inn]] in [[Lugard]]. 
[[Siuan Sanche]], [[Leane Sharif]], [[Min Farshaw]] and [[Logain Ablar]] stop there briefly while Siuan tries to find out where the Blue Ajah is located.

## Notes






https://wot.fandom.com/wiki/Nine_Horse_Hitch