---
tags: [Women, Altara_people, Innkeepers, LivingasofCOT]
---


Mistress **Vadere** is the innkeeper of the [[Golden Barge]], in [[So Habor]].

## Appearance
Mistress Vadere has a long nose. When she is met, she looks very dirty for an innkeeper.

## Activities
When [[Perrin Aybara]], [[Berelain sur Paendrag Paeron]] and their group go to So Habor to purchace grain, Mistress Vadere serves them wine.

## Notes






https://wot.fandom.com/wiki/Vadere