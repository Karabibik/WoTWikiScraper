---
tags: [, Historicalsettlements, Cities, Eharon]
---
**Barashta** was a major city of [[Eharon]] between the [[Breaking of the World]] and the [[Trolloc Wars]]. It was located in the [[Rahad]] section of [[Ebou Dar]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Barashta