---
tags: [ThePattern]
---




A **Mirror World** is an alternate reality/timeline that has been woven by the Wheel.
These alternate worlds represent "Ifs". What might have been if a decision was made differently, a battle swung the other way, a winner became a loser. Theoretically the Mirror world is created at that junction of decision/outcome. This allows for infinite variation and so infinite Mirror Worlds. The more likely the alternate decision/outcome the more 'real' the Mirror world associated with it seems/is. Those Mirror Worlds closest to the true World (separated by only the difference in a minor decision) are populated by 'relfections' of the people in the True World. 


Mirror worlds can be reached by a person who can channel through the use of [[Portal Stones]]. Time acts differently in Mirror Worlds: a day spent in one can find a traveler re-entering the True World a year later, conversely five years spent in a Mirror World may result in a traveler returning to the True World merely weeks after he left. Study of Mirror Worlds led to the creation of [[The Ways]].
*Tel'aran'rhiod *is a mirror world which connects and reflects every one of the myriad worlds within the Pattern.






https://wot.fandom.com/wiki/Mirror_World