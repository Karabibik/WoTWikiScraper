---
tags: [Talents]
---
**Reading ter'angreal** is a [[Talent]] regarding the ability to discern the purpose and characteristics of a *ter'angreal*.
This ability appears to require physical contact with the *ter'angreal*. [[Elayne Trakand]] first identifies this [[Talent]] in [[Aviendha]], who identified several *ter'angreal* recovered from [[Ebou Dar]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Reading_ter%27angreal