---
tags: [Women, AthaanMiere_people, Windfinders, LivingasofKOD, Channelers]
---


**Serile** is an *Atha'an Miere* [[Windfinder]].

## Appearance
She is of an average weight.

## Activities
She is on [[Turane]]'s craft when it is used by the *Atha'an Miere* [[First Twelve]] for their meeting with [[Rand al'Thor]]'s ambassador [[Logain Ablar]].






https://wot.fandom.com/wiki/Serile