---
tags: [Othernotablebuildings]
---
*"It must be a low place. What is called a hell."*
   —[[Tuon Athaem Kore Paendrag]] 
A **hell** is kind of low-life bar where the customers are rough, ragged and have no scruples. [[Matrim Cauthon]] describes a hell as follows:

*"Hells were the lowest of the low, dirty and dimly lit, where the ale and wine were cheap and still not worth half what you paid, the food was worse and any women who set on your lap was trying to pick your pocket or cut your purse or else had two men waiting upstairs to crack you over the head... At any time of the day you would find dice rolling in a dozen games... Few of the gamblers would have come by their coin by any means even halfway honest... Hells always had two or three strong arms with cudgels about to break up fights... They usually stopped the patrons from killing one another, but when they failed the corpses were dragged out the back...and left on a rubbish heap. And while they were dragging the drinking never slowed, or the gambling either."*
   —Mat's thoughts 
Mat brought [[Tuon Athaem Kore Paendrag|Tuon]] to a place called [[The White Ring]], claiming it was a hell. Although Tuon and [[Selucia]] were convinced that it was a hell, it was not.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Hell