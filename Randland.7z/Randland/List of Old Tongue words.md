---
tags: [OldTongue, Glossary, Listpages]
---
This page gives sortable lists of all known words in the [[Old Tongue]]. It is split into two sections, one of "atomic" words and one of "compound" words which are derived by combining words from the first list. Both lists are from the entry on the Old Tongue from  [[The Wheel of Time Companion]].

## Contents

1 List of Atomic Words
2 List of Compound Words and Short Phrases
3 Notes


## List of Atomic Words
The following table gives all "atomic" words known in the Old Tongue i.e. those that cannot be broken down further or which are conjugations or irregular past participles of verbs. The list of atomic words (and some of the compound ones) is likely based on the 950-ish words of Basic English that Jordan used as the base of his language. Jordan, however, does discard some of these that are not used in his world and expands it by having some unique to his own worldbuilding and multiple words for the same word in the Common Tongue.
If you wish to translate a word or phrase from English/Common Tongue to the Old Tongue, order the table using the second column. Sorting by part of speech will enable easier sentence construction.
Note that numbers are compound words as they are composed of a stem indicating the number and a suffix indicating whether it is a physical object or an abstract one. The numbers in the Old Tongue can be found on a [[Old Tongue numbers|separate page]].

|**Old Tongue**|**Common Tongue**|**Part of Speech**|
|-|-|
|a|plural|suffix|
|a|of|preposition|
|aada|dear|adjective|
|aagret|awake|adjective|
|aan|one (masculine)|noun; adjective|
|abakran|amount|noun|
|ae|passive voice|suffix|
|aend|ever|adverb|
|aes|all; everyone; the public body; civilization|noun|
|aethan|shield(s)|noun|
|afwadh|well|noun|
|agaroum|disgust|noun|
|agit|living organism|noun|
|ahenila|current|noun|
|ahf|wind (as an air current)|noun|
|aiel|dedicated|adjective|
|Aiel|the Dedicated|noun|
|ailen|before|conjunction; preposition; adjective|
|ain|is|verb|
|airach|living|noun; adjective|
|aird|tall|adjective|
|ajah|association created for a specific purpose|noun|
|Ajah|group of women in the White Tower organised towards a single goal|noun|
|akein|swallow (the bird)|noun|
|al|for the; of the|preposition|
|al|royal (added to the first name of a Malkieri king)|prefix|
|aldazar|eagle(s)|noun|
|alantin|brother (sometimes used to address Ogier, as an abbreviated form of “tia avende alantin”)|noun|
|alep|son|noun|
|alget|fight|verb|
|algode|cotton (plant fiber from the Aiel waste)|noun; adjective|
|allein|man|noun|
|allen|hill|noun|
|allende|pass (as passing through or by, not handing something over)|verb|
|allwair|key|noun|
|am|beauty, pertaining to|prefix|
|aman|dragon|noun|
|Aman|the Dragon i.e. [[Lews Therin Telamon]]|noun|
|amela|friend|noun|
|amotath|attraction|noun|
|an|of; of the; for the|preposition|
|an|plural|suffix|
|ande|rose|noun|
|andi|stone-like quality|suffix|
|andillar|stone|noun|
|ane|past tense indicator, like -ed in English|suffix|
|angreal|device that enhances the power to channel|noun|
|anouge|cough|verb|
|ara|possession|suffix|
|arahar|curtain|noun|
|aran|right-hand or right-side|adjective|
|aris|harmony (see "aridhol")|noun|
|arkati|school|noun|
|asa|concubine (in Seanchan)|noun|
|asa|you|pronoun; noun|
|ascar|blue|noun; adjective|
|ashan|guard|prefix|
|asmodean|musician (name of a Forsaken)|noun|
|asmodi|music|noun|
|aso|it|pronoun|
|astai|belief|noun|
|atha|person|noun|
|attik|smile|noun; verb|
|aven|call|verb|
|avende|tree(s)|noun|
|ayashiel|fowl|noun|
|ayend|dead, the; those who have passed, those who have released their mortal coil; a root word related to ayende and allende.|noun|
|ayende|release; free|verb|
|azafi|canvas|noun|
|bachri|bread|noun|
|badan|bath|noun|
|bah|box (pluralises to baha)|noun|
|baichan|sticky|adjective|
|baid|self|noun; adjective|
|baijan|attack|noun|
|bairnu|crack|verb|
|bajad|spawn|noun|
|bak|how|adverb|
|bal|circle|noun|
|balad|slow|adjective|
|balfone|musical instrument of the Age of Legends|noun|
|balt|essence; heart; root|noun|
|banta|seat|noun|
|baroc|hour|noun|
|basho|under|preposition; adjective; adverb|
|bat|against|preposition|
|batthien|hard|adjective|
|bazam|arm|noun|
|beatha|art|noun|
|bebak|quiet|adjective|
|begoud|bad|adjective|
|begrat|swear|verb|
|begratanae|sworn|adjective|
|belo|desire|verb|
|beratam|distance|noun|
|betakai|yesterday|noun; adverb|
|beulin|front|noun; adjective|
|bhadi|company|noun|
|bhan|eradication; annihilation|noun|
|bhardo|building|noun|
|bhashan|hearing|noun|
|bhoot|screw|verb|
|bhuk|doubt|noun|
|bideli|form|noun|
|bift|still|adjective|
|bighar|conscious|adjective|
|bijoun|flower|noun|
|binti|delicate|adjective|
|birok|beet|noun|
|blagh|book|noun|
|bloobh|stomach|noun|
|boan|beauty, female ideal of|noun|
|bodong|rhythm|noun|
|boesin|floor|noun|
|bokhen|ill; sick|adjective|
|boko|fat|adjective|
|bolar|special|adjective|
|bolga|talk|verb|
|bopo|baby|noun|
|borz|coal|noun|
|botay|beauty, male ideal of|noun|
|brett|letter|noun|
|breudon|suggestion|noun|
|brith|kiss|noun; verb|
|brynza|cheese|noun|
|budhvai|liquid|adjective|
|buggel|play|verb|
|buido|knot|noun; verb|
|bumma|moon|noun|
|bunok|act|verb|
|ca|do (used as an intensifier; e.g., "Ca'lyet ye" is  "I do come" with the stress on "do")|verb (auxiliary)|
|caba|horse|noun|
|cadi|cloth|noun|
|cafar|animals/creatures from the Age of Legends known for being vicious and living in a nest (mentioned by Sammael)|noun|
|caili|skirt|noun|
|cair|gold(en)|noun; adjective|
|caisen|old|adjective|
|cal|red|noun; adjective|
|calazar|harbor|noun|
|caledon|metal|noun|
|calichniye|welcome|interjection|
|canant|news|noun|
|cantheal|train|noun|
|capar|boar-like creature from the Aiel Waste|noun|
|car|chief|noun|
|carai|honor (can be used in the sense of “for the honor”)|noun|
|carentin|worth; equivalent value|noun|
|carn|chiefs|noun|
|casgard|ornament|noun|
|cassort|married|adjective|
|cavastu|angry|adjective|
|cemaros|storm, winter; tempest; (specifically, one from the Sea of Storms)|noun|
|cha|talon; claw|noun|
|chaki|bitter|adjective|
|chalin|sweet|adjective|
|chalot|claw|verb|
|chanda|soup|noun|
|chanukar|island|noun|
|chati|breath|noun|
|chatkar|prose|noun|
|chegham|rate|noun|
|cheghar|credit|noun|
|chekrut|violent|adjective|
|chelan|roof|noun|
|chenal|support|noun|
|cheta|face|noun|
|chicaba|engine|noun|
|chiema|winter|noun|
|chinje|wheel used in gambling, similar to roulette|noun|
|chinnar|body|noun|
|chinti|small|adjective|
|chitzi|sneeze|verb|
|choba|formal greeting to an Ogier|interjection|
|chora|tree construct from the Age of Legends|noun|
|choshih|formal greeting to the Ogier|interjection|
|choss|manure (excrement hauled away on farms; Sammael calls Rand a "choss-hauler that got lucky")|noun|
|choutsin|strange|adjective|
|chukhar|shut|verb; adjective|
|cierto|resolute; enduring; determined|adjective|
|ciyat|price|noun|
|claddin|tired|adjective|
|clomak|lock|noun|
|cloriol|scale|noun|
|con|banner, small (used by Cairhienin nobility)|noun|
|conagh|answer|noun|
|concion|summons|noun|
|conde|walker(s)|noun|
|conden|walk|verb|
|conje|needle, type of (mentioned by Sammael)|noun|
|cor|night|noun|
|corda|heart (as in, the heart of things)|noun|
|corea|musical instrument of the Age of Legends|noun|
|coreer|snake, type of poisonous (from the Age of Legends)|noun|
|corlm|animal used by the Seanchan in battle|noun|
|cosa|animal from the Age of Legends that scampers up trees for protection (mentioned by Graendal)|noun|
|cour|container; trap|noun|
|cova|owner|noun|
|covale|property;  owned; (Seanchan term for a slave)|noun; adjective|
|cuande|anxiety (stress-induced condition experienced as chest pains)|noun|
|cue(n)|heart, referring to the|prefix|
|cuendar|heart (changes form when combined with other words or word segments)|noun; adjective|
|cueran|building material (from Age of legends; mentioned in a Semirhage point of view segment)|noun|
|culieb|past|noun; adjective|
|cyn|last|noun; adjective|
|d|of; belonging to; (implied ownership or inferior position)|preposition|
|da|person; individual; (any gender)|noun|
|da|one (any gender)|noun; adjective|
|daarlot|crime|noun|
|dabor|picture|noun|
|dada|father|noun|
|dae|complex; intricate; great|adjective|
|daes|many people; (implications of diversity [source needed])|noun|
|daghain|fear|noun|
|dahid|note|noun|
|dai|battle; struggle; strive|noun; verb; adjective|
|daien|dancer from Age of Legends (mentioned by Aran'gar)|noun|
|dal|bowl; basin; vessel|noun|
|dale|pay|verb|
|dali|clock|noun|
|dam|leash|noun|
|dane|chance (variant spelling is "diane")|noun|
|dantor|theory|noun|
|dao|cord|noun|
|daori|hair cord (cut by Malkieri’s *carneira* and woven into a cord)|noun|
|dar|forward (direction)|adverb|
|dar|sister|noun|
|dar|feminine|suffix|
|darath|animal from the Age of legends known for ferocity (mentioned during a Moghedien point of view)|noun|
|dareis|spear (Aiel term; pluralises to darei)|noun|
|darm|serious|adjective|
|darshi|see|verb|
|de|negation|suffix|
|de|agent of an action|prefix|
|deebo|brown|noun; adjective|
|dekhar|political|adjective|
|dena|song|noun|
|der|from|preposition|
|der|master (Seanchan prefix to denote master of some craft)|prefix (for nouns)|
|dera|derived from|suffix|
|deshi|hundred (meaning one hundred)|noun; adjective|
|deshi|hundreds (denotes the quantitative place value, e.g., *dvo'deshi* means two hundred)|suffix|
|desta|stop|verb|
|desu|bed|noun|
|devor|ask|verb|
|deyeniye|majesty|noun|
|dha|agony; anguish|noun|
|dhai|battle-related; war-related|adjective|
|dhakdi|cloud(s)|noun|
|dhalen|money|noun|
|dhamel|shade|noun|
|dhjin|terror; horror|noun|
|dhol|land|noun|
|dhub|ball|noun|
|diane|chance (variation of "dane")|noun|
|diband|dependent|adjective|
|dibbuk|interest|noun|
|dieb|wind (as an air current)|noun|
|difrol|waste|noun|
|dillar|stone|suffix|
|din|brother(s)|noun|
|din|masculine|suffix|
|dinya|care|verb|
|diutic|tongue|noun|
|dival|light|noun|
|diy|sound|verb|
|djanzei|south|noun; adjective; adverb|
|do|over|preposition|
|doko|where|pronoun; adverb|
|domashita|warm(s)|verb|
|domorakoshi|language|noun|
|don|importance|suffix|
|donde|ride (or, riding-related)|verb|
|doon|black; very dark|noun; adjective|
|doorn|thick|adjective|
|doozhi|burst|verb|
|dor|red|noun; adjective|
|dore|mountain(s)|noun; adjective|
|dornat|animal in the Age of Legends used in hunting (thought of by Graendal)|noun|
|doti|nut|noun|
|dovie|lucky (or, related to luck; note the Companion does not use the word "lucky")|adjective|
|dovienya|luck|noun|
|dred|twist|verb|
|drelle|suffix denoting river or water(s) of|suffix|
|drenni|turn|verb|
|drin|man (singular & plural); soldier(s)|noun|
|drosin|green|noun; adjective|
|drova|hag; beldam; old woman|noun|
|druna|push|verb|
|duadhe|water|noun|
|dudhi|cow|noun|
|duente|hold; grip|verb|
|dumki|army|noun|
|dvoyn|second|noun; adjective|
|dyani|natural|adjective|
|dyu|by|adverb; preposition|
|dzigal|flat|adjective|
|e|and|conjunction|
|einto|addition|noun|
|el|royal (added to the  first name of a Malkieri queen)|prefix|
|ellis|sun|noun|
|en|plural|suffix|
|en|true (derived from "jenn")|suffix|
|era|blue (see "seiera")|suffix|
|es|many|suffix (for adjectives)|
|ethaantar|transport|verb|
|evierto|polish|verb|
|fada|sad|adjective|
|faerstin|adjustment|noun|
|faile|falcon|noun|
|fakha|sail|verb|
|far|of; mobility, indication of|preposition|
|farhota|brass|noun|
|fear|night|noun|
|feia|speaker|noun|
|feiro|exchange|verb|
|feist|question|verb|
|fel|our|pronoun (possessive)|
|fenter|verse|noun|
|feros|soil|noun|
|ferster|garden|noun|
|finin|nephew|noun|
|fintan|cup|noun|
|folyt|able|adjective|
|fonnai|place|noun|
|for|herd|noun|
|frait|strong|adjective|
|fringfran|cork|noun|
|furthadin|statement|noun|
|ga|is|verb|
|gadhat|thread|noun|
|gadou|change|verb|
|gaen|across|preposition|
|gai|battle|noun|
|galamok|shirt|noun|
|gar|dagger; lethal device|noun|
|gara|lizard (a specific, venomous creature from Aiel Waste)|noun|
|garan|solid|adjective|
|gashi|profit|verb|
|gavane|what|pronoun; adjective; adverb|
|gemarise|make|verb|
|ghael|brutes; beasts; monsters|suffix|
|ghal|curve|verb|
|ghani|purpose|noun|
|ghar|acid; venom|noun|
|ghazh|chin|noun|
|gheuth|cry|verb|
|gheym|measure|noun; verb|
|ghiro|thus|adverb|
|ghleb|limit|noun|
|ghraem|the mighty; the all-powerful|noun|
|ghoba|the soul|noun|
|ghow|hollow|adjective|
|ghul|pit; hole|noun|
|ghuni|smoke|noun; verb|
|gidhi|normal|adjective|
|glasti|even|adjective|
|glimp|minute|noun|
|gobhat|plant|noun|
|gomaen|attempt|noun; verb|
|gorista|use|verb|
|gouql|look|verb|
|gozai|chest|noun|
|graedo|please|verb|
|graen|pleasure|noun|
|greal|the power to channel|noun|
|griest|rail|noun|
|grolm|animal with three eyes and green-gray skin used by the Seanchan in battle|noun|
|gruget|stretch|verb|
|gubbel|feeble|adjective|
|gurupat|oath|noun|
|gwiltor|wire|noun|
|haar|opinion|noun|
|habish|ear|noun|
|hadori|headband, Malkieri|noun|
|hadzi|cause|verb|
|hael|lead|verb|
|hafi|part|noun|
|hakhel|nail|noun|
|hama|dancer(s) (implies stately grace and fluidity)|noun|
|hanol|wound|noun|
|har|hand|noun|
|harben|take|verb|
|harvo|pump|verb|
|hasta|paste|noun|
|hathi|muscle|noun|
|havokiz|invention|noun|
|hawali|wide|adjective|
|heatsu|join|verb|
|heesh|smooth|adjective|
|hei|always|adverb|
|heinst|send|verb|
|hessa|forgiveness|noun|
|hienisus|design|noun|
|hirato|space|noun|
|hoba|oil|noun|
|hochin|east|noun; adjective; adverb|
|hodifo|responsible|adjective|
|holubi|comfort|noun|
|homa|offer|verb|
|hoptah|week|noun|
|hosiya|till|verb|
|houghan|structure|noun|
|houma|sleep|verb|
|humat|existence|noun|
|hutsah|bucket|noun|
|ibalets|thumb|noun|
|ikaat|wax|noun|
|illar|stone, relating to|suffix|
|imsoen|truth (also see "soe")|noun|
|in|plural|suffix|
|inda|girl|noun|
|inde|no; not; (a  general negation)|noun; adverb|
|ing|of utmost importance|suffix|
|iqet|this|pronoun; adjective; adverb|
|iro|we|pronoun|
|isain|is (a form of “to be”)|verb|
|isham|betrayer|noun|
|ishar|betray|verb|
|ishavid|betrayal|noun|
|iska|that which was|suffix|
|istor|fiction|noun|
|izaad|wool|noun|
|ja|of; issued from|suffix|
|jaahni|reading|noun|
|jabro|tooth|noun|
|jalat|burn|noun; verb|
|jalbouk|kettle|noun|
|jalid|heat|noun|
|jalou|go|verb|
|jeade|finder|noun|
|jegal|animal with scales from Age of Legends (thought of by Sammael)|noun|
|jemena|farm|noun|
|jenn|true; only true (implying others are fake); truly|adjective;  adverb|
|jhabal|brush|noun|
|jheda|exquisite (name  of the royal palace of Ghealdan)|adjective|
|jhin|exaltation|noun|
|ji|honor|noun|
|jobei|apparatus|noun|
|juma|worm|noun|
|kaarash|discovery|noun|
|kaarto|tax|noun|
|kadu|lip|noun|
|kaf|coffee (caffeinated beverage from Seanchan)|noun|
|kakamo|quick|adjective|
|kanjo|emotion|noun|
|kar|punishment through the nervous system|suffix|
|karagaeth|punishment|noun|
|kardon|fruit with green skin from a leafless spiny plant in Aiel Waste|noun|
|kasaar|order|noun|
|kashen|fork|noun|
|kathana|kick|verb|
|katien|size|noun|
|kazath|say|verb|
|kazka|grain|noun|
|keesh|out|adverb; preposition|
|keisa|jewel|noun|
|kelet|rod|noun|
|kelindun|general (military rank)|noun|
|kesan|steel|noun; adjective|
|kesool|shoe|noun|
|ketvar|chain|noun|
|keymar|color|noun|
|khadi|bone|noun|
|khalig|history|noun|
|khamu|year|noun|
|khoop|blow|verb|
|khust|dry|adjective|
|kikola|list|noun|
|killo|pin|noun|
|kippat|ticket|noun|
|kiserai|glory; honor|noun|
|kjasic|obscenity spoken by Sammael (no direct translation)|adjective|
|kloye|bell|noun|
|knotai|devastation; ruin|noun|
|koanto|learning|noun|
|kodome|here|noun; adverb|
|koja|there|noun; adverb|
|komad|mixed|adjective|
|komalin|weak|adjective|
|komo|put|verb|
|kontar|board|noun|
|korero|discussion|noun|
|koudam|west|noun; adjective; adverb|
|koult|quite|adverb|
|kovist|tail|noun|
|kramayage|development|noun|
|kramtor|store|noun|
|kriko|bird|noun|
|kritam|tight|adjective|
|kuruta|cart|noun|
|kuthli|laugh|verb|
|kutya|feeling|noun|
|la|daughter|noun|
|laada|long|adjective|
|labani|reward|noun|
|laero|flag|noun|
|lagien|town|noun|
|lahdin|observation|noun|
|laido|summer|noun|
|lakevan|motion|noun|
|lal|have|verb|
|lam|lack of; being without|suffix|
|lamena|frame|noun|
|lan|prized; beloved|adjective|
|lashite|meeting|noun|
|lato|angle|noun|
|lavakh|wood|noun|
|leagh|page|noun|
|leffal|stage|noun|
|lendha|fall|verb|
|lennito|military|noun; adjective|
|liede|neck|noun|
|lindhi|monkey|noun|
|lishno|trouble|noun|
|loftan|material|noun|
|logoth|place of waiting (possibly compound word?)|noun|
|lorme|write|verb|
|los|forward (direction)|noun; adjective; adverb|
|loviyaga|memory|noun|
|lyet|come|verb|
|m|of|prefix|
|ma|stresses importance|prefix|
|ma|give, you (second person - "you" is the implied grammatical subject)|verb|
|maani|very|adverb|
|maast|necessary|adjective|
|machin|destruction|noun|
|mad|loud|adjective|
|mael|hope|noun|
|mafal|mouth; pass|noun|
|mageen|daisy|noun|
|mahdi|seeker (used for leader of Tuatha'an caravan)|noun|
|mahrba|paint|verb|
|mai|maiden(s)|noun|
|makitai|wheel|noun|
|mamai|future|noun; adjective|
|mamu|mother|noun|
|man|blade, related to; sword, related to|adjective|
|mandarb|blade (name of Lan’s stallion)|noun|
|manive|drive|verb|
|manivin|driving|noun; adjective|
|manshima|blade; sword|noun|
|mar|game|noun|
|maral|destined|adjective|
|marath|urgency or compulsion, suggestion of (Seanchan word)|prefix|
|marcador|hammer|noun|
|marna|swim|verb|
|maromi|crush|verb|
|mashi|love|noun; verb|
|masnad|trade|noun|
|maspil|butter|noun|
|mastri|fish|noun|
|mat|control|verb|
|matuet|important|adjective|
|mawaith|reaction|noun|
|medan|sugar|noun|
|melaz|inn|noun|
|melimo|apple|noun|
|mera|without; lacking|preposition|
|merwon|boiling|adjective|
|mestani|lessons (plural; singular unknown)|noun|
|mestrak|necessity|noun|
|mi|my|pronoun (possessive)|
|mia|me; myself|pronoun|
|miere|ocean; waves|noun|
|mikra|shame|noun|
|min|little|adjective|
|miou|cat|noun|
|mirhage|pain (or the promise or expectation of pain)|noun|
|mist|middle|noun; adjective|
|mitris|dirty|adjective|
|modan|approval|noun|
|moghedien|spider (a particular breed that's small, venomous, and reclusive; name of a Forsaken)|noun|
|mokol|milk|noun|
|mon|scythe, related to|adjective|
|moodi|frequent|adjective|
|mora|people, the; population, a|noun|
|morasu|morning|noun|
|morat|handler; controller; (i.e., one who handles or controls <something>)|prefix|
|mordero|death|adjective|
|moridin|grave; tomb; (name of a Forsaken, the word referring to death)|noun|
|moro|so|adverb; conjunction|
|mos|down (listed as "moro" in Tor OT dictionary, but likely a typo)|adjective; adverb; preposition|
|mosai|low|adjective|
|mosiel|lower|verb|
|mosiev|lowered; downcast|adjective|
|motai|grub from the Aiel Waste that can be eaten as a sweet, cruncky snack|noun|
|mourets|mushroom(s)|noun|
|mozhlit|possible|adjective|
|muad|foot (noun); on foot (adjective); afoot (adverb)|noun; adjective; adverb|
|muaghde|meat|noun|
|mukhrat|private|adjective|
|mund|high|adjective|
|mustiel|sock|noun|
|mystvo|office|noun|
|n|of; from|prefix|
|nabir|fire|noun|
|nachna|science|noun|
|nadula|force|noun|
|nag|day|noun|
|nagaru|snake|noun|
|nahobo|full|adjective|
|nahodil|cushion|noun|
|nai|knife; dagger; blade, small (knife-like)|noun|
|nais|smell|verb|
|naito|flame|noun|
|nak|who|pronoun|
|nakhino|month|noun|
|naparet|parallel|adjective|
|nardes|thought|noun|
|narfa|foolish|adjective|
|nasai|wrong|noun; verb; adjective|
|nausig|boat|noun|
|nayabo|prison|noun|
|neb|mist|noun|
|nedar|pig with tusks that lives in water (found in the Drowned Lands; possibly a warthog or hippopotamus, or another animal entirely)|noun|
|neidu|new|adjective|
|neisen|why|adverb|
|nemhage|distribution|noun|
|nen|one who or that which does, or those who cause (like adding ‘er’ to English verb)|suffix|
|nesodhin|through;  through this; through it|preposition|
|ni|for|preposition|
|niende|lost|adjective|
|nieya|step|verb|
|ninte|your (formal)|pronoun (possessive)|
|ninto|your (informal)|pronoun (possessive)|
|nirdayn|hate|noun|
|no|but|conjunction|
|no|me|pronoun|
|nob|cut|verb|
|nodavat|produce|noun|
|nolve|give|verb|
|nor|cutter; slicer|noun|
|norvenne|account|noun|
|nosane|speak|verb|
|nothru|nose|noun|
|noup|only|adjective;  adverb|
|nupar|base (as in bottom or support)|noun|
|nush|deep|adjective|
|nyala|country|noun|
|nye|again|adverb|
|Nym|construct from the Age of Legends|noun|
|o|a; an|adjective|
|ob|or|conjunction|
|obaen|musical  instrument of the Age of Legends|noun|
|obanda|door|noun|
|obidum|spade|noun|
|obiyar|position|noun|
|obrafad|view|noun|
|obram|impulse|noun|
|ocarn|toe|noun|
|odashi|weather|noun|
|odi|some|pronoun;  adjective|
|odik|secretary|noun|
|oghri|sky|noun|
|ohimat|comparison|noun|
|olcam|tin|noun|
|olesti|pants|noun|
|olghan|drawer|noun|
|olivem|pencil|noun|
|olma|poor|noun; adjective|
|ombrede|rain|noun; verb|
|on|plural|suffix|
|onadh|arch|noun|
|onguli|ring|noun|
|onir|star(s)|noun|
|oosquai|whiskey (defined in the Companion as a distilled spirit used by the Aiel)|noun|
|orcel|pig|noun|
|ordeith|wormwood (name taken by Padan Fain while with the Whitecloaks)|noun|
|orichu|plow|noun; verb|
|orobar|danger|noun|
|ortu|open|adjective|
|orvieda|print|verb|
|osan|left-hand or left-side|adjective|
|ospouin|hospital|noun|
|ost|on|preposition|
|otiel|sponge|noun|
|otou|top|noun; adjective|
|ounadh|wine|noun|
|ovage|window|noun|
|ozela|goat|noun|
|paathala|operation|noun|
|pad|up|adjective; adverb; preposition|
|padgi|lift|verb|
|pakita|twist|verb|
|palatu|word|noun|
|panati|wash|verb|
|panjami|society|noun|
|pantae|business|noun|
|papp|fact|noun|
|parano|coward; base or low (in pejorative sense)|noun; adjective|
|parikesh|leather|noun|
|pas|none|pronoun|
|pashren|scissors|noun|
|pastien|protest|verb|
|patomi|potato|noun|
|patra|then|noun; adverb|
|peast|payment|noun|
|pecara|tree having pale, wrinkled fruit in the Aiel Waste; type of nut|noun|
|pedalen|expansion|noun|
|pentor|mass|verb|
|pepa|paper|noun|
|perant|together|adverb|
|perit|equal|noun; adjective; verb|
|perol|pen|noun|
|pi|teen (e.g. in the word seventeen)|suffix|
|pierskoe|peach|nou|
|pinchota|stocking|noun|
|pinikar|line|noun|
|pistit|whistle|noun|
|pistita|whistle|verb|
|pizar|ant|noun|
|platip|present|noun; adjective|
|platto|detail|noun|
|plean|much|adjective;  adverb|
|ploushin|square|noun; adjective|
|po|because|conjunction|
|pochivat|start|verb|
|poldar|skinny|adjective|
|polov|shelf|noun|
|potadi|debt|noun|
|potsa|collar|noun|
|poulam|boot(s)|noun|
|pranent|tendency|noun|
|prashat|process|noun|
|prasta|idea|noun|
|prato|such|adjective|
|pravilam|regular|adjective|
|probita|drink|verb|
|procol|map|noun|
|profel|test|verb|
|proyago|experience|noun|
|ptash|effect|noun|
|punia|may|verb|
|punta|number|noun|
|purtah|enough|noun; adjective; adverb|
|purvene|horn|noun|
|pyast|throat|noun|
|qaato|cake|noun|
|qaiset|same|pronoun; adjective; adverb|
|qamir|silk|noun|
|qen|when|adverb; conjunction|
|qinar|niece|noun|
|rabat|manage|verb|
|rabdo|sudden|adjective|
|raf|fly|verb|
|ragha|near|adjective; adverb; preposition|
|raha|free(dom)|noun; adjective|
|rahien|dawn|noun|
|rahtsi|authority|noun|
|raia|air|noun|
|rainn|kennel|noun|
|raken|flying creature used by the Seanchan|noun|
|rakh|back|noun;  adjective; adverb|
|ramay|table|noun|
|ranell|mountain range(s)|noun|
|ranzak|guide|noun; verb|
|raqit|shake|verb|
|rastra|road|noun|
|ravad|street|noun|
|raya|mine; my own|pronoun (possessive)|
|remath|whip|noun; verb|
|rennen|cook|noun|
|renni|cook|verb|
|rensal|kitchen|noun|
|restar|medical|adjective|
|rhadiem|prepare (insistent)|verb|
|rhaul|rice|noun|
|rhiod|world, a; land, a|noun|
|rhub|piece, a small|noun|
|rieht|balance|noun|
|rimbai|berry|noun|
|risor|trick|verb|
|roban|oven|noun|
|rodinat|relation|noun|
|roedna|bite|verb|
|ronagh|slope|noun|
|roscher|separate|adjective|
|rouyte|mark|noun|
|rulli|round|adjective|
|rumpo|drop|verb|
|runyat|weight|noun|
|sa|in|adverb; preposition|
|sa|superlative|prefix|
|saa|True Power side-effect; begins as tiny black flecks in the eyes|noun|
|saana|teacher|noun|
|saantar|teaching|noun|
|safar|white|noun; adjective|
|sag|time|noun|
|sahlan|attention|noun|
|sai|referring to power (adjectival)|prefix|
|sain|is|verb|
|saizo|request|verb|
|salidien|humor|noun|
|samid|band|verb|
|samma|destroyer; blinder|noun|
|sanasant|knowledge|noun|
|santhal|industry|noun|
|sar|she|pronoun|
|sara|dance, type of (Saldaean dance performed by women)|noun|
|sast|almost|adverb|
|scrup|between|adverb; preposition|
|se|it(self); themselves|pronoun|
|sedai|servant(s)|noun|
|seel|amusement|noun|
|segade|cactus (described in the Companion as a spiny leathery plant with white blossoms in Aiel Waste)|noun|
|seia|eye(s)  (becomes sei when used in combined forms)|noun|
|sene|as; like|adverb|
|sene|like|verb|
|seren|stubborn; obstinate|adjective|
|sha|noise|noun|
|shaani|quality|noun|
|shadar|shadow|noun|
|shae|dog|noun|
|shaek|house|noun|
|shaendi|aunt|noun|
|shaff|condition|noun|
|shai|woman|noun|
|shaidar|dark (as in pitch-darkness; indication of evil or wrong)|noun; adjective|
|shain|peace|noun|
|shak|any|pronoun;  adjective; adverb|
|shama|musical instrument of the Age of Legends|noun|
|shan|lord|noun|
|shao|jump|verb|
|shar|blood;  bloodline; (meaning descent or heritage)|noun|
|shaval|linen|noun; adjective|
|shayol|doom|noun|
|sheen|bringers of; those who exemplify something|noun|
|sheikar|bright|adjective|
|shen|band; group; brotherhood|noun|
|shi|suffix denoting multiples of ten (apostrophe before)|suffix|
|shiatar|iron|noun; adjective|
|shin|journey|noun|
|shitak|different|adjective|
|shodet|comb|noun|
|shost|knee|noun|
|shoufa|veil, dust (used by Aiel)|noun|
|shuk|health|noun|
|shukri|healthy|adjective|
|sich|bag|noun|
|sidama|radiance|noun|
|sidhat|example|noun|
|simp|thin|adjective|
|sin|he; man|pronoun; noun|
|sind|never|adverb|
|siswai|spear|noun|
|slagh|bent|adjective|
|sleesh|dress|noun|
|smoog|steam|noun|
|so|thing; entity|noun|
|sob|if|conjunction|
|sobel|button|noun|
|soe|truth|noun|
|soende|carry|verb|
|soetam|rat found in the Drowned Lands. Very large.|noun|
|sofor|vehicle having steering planes|noun|
|soovri|behavior|noun|
|sor|work(ing)|noun; adjective|
|sora|life|noun|
|sorbe|run|verb|
|sorda|rat species found in the Aiel Waste|noun|
|sorei|runner(s) (derived from "sorbe," "to run")|noun|
|soudhov|cabbage|noun|
|souk|bee|noun|
|souvra|mind|noun|
|sovin|hands (if unmodified, "hands that are open and empty")|noun|
|sovya|another; any other|adjective|
|spashoi|taste|noun|
|spiat|help|verb|
|spillon|disease|noun|
|s'redit|elephant. Seems a compound word due to the apostrophe, but neither part can be directly translated.|noun|
|spondat|early|adjective|
|spotsu|bridge|noun|
|staba|copper|noun; adjective|
|staera|sweat tent scraping stick (made of copper, used by Aiel)|noun|
|stedding|Ogier homeland and place of sanctuary|noun|
|sterpan|sex|noun|
|stobur|stem|noun|
|straviant|insurance|noun|
|streith|textile from the Age of Legends that changes color according to the wearer's emotions|noun; adjective|
|stripo|wing|noun|
|suchan|growth|noun|
|sul|hold|verb|
|sulwed|substance|noun|
|sunatien|education|noun|
|suravye|peace|noun|
|sursa|chopsticks (used in Tanchico)|noun|
|suzain|false|adjective|
|svayor|soap|noun|
|swabel|glove|noun|
|syndon|birth|noun|
|sysyn|brain|noun|
|szere|lower|adjective|
|t'mat|fruit, type of red  (found in Aiel Waste; never made explicit, but most likely a tomato)|noun|
|ta|Pattern-related|noun|
|taak|yes|adverb|
|taal|stone|noun; adjective|
|taberan|digestion|noun|
|taer|forthright; level; steady; straight(forward)|adjective|
|tahni|clean|adjective|
|tai|true|adjective|
|taishite|favor|verb|
|tamu|stamp|noun|
|tan|sovereign|noun; adjective|
|tana|get|verb|
|tanilji|insect|noun|
|tar|tower|noun|
|tarbun|hat|noun|
|tarmon|final; last; ultimate|adjective|
|tashi|ready|adjective|
|taskel|reason|noun|
|tasu|make|verb|
|tati|voice|noun|
|tcheran|game played on a board in the Age of the Legends|noun|
|tebout|probable|adjective|
|tefara|record|noun|
|telio|transparent|adjective|
|ter|limited or specific application|prefix|
|terta|rub|verb|
|tezra|gray|adjective|
|thamel|young; youth-related|adjective|
|thaz|at|preposition|
|theini|trousers|noun|
|thorain|loss|noun|
|thorat|coat|noun|
|ti|to|preposition|
|tia|to; to the|preposition|
|tiel|about|adverb; preposition|
|tiest|head|noun|
|tiganza|dance traditional to the [[Tuatha'an]]|noun|
|timari|skin|noun|
|tinto|wall|noun|
|tipakati|selection|noun|
|tippat|plate|noun|
|tirast|pull|verb|
|toh|obligation; duty; (term used by the Aiel)|noun|
|tolin|stiff|adjective|
|tom|among|preposition|
|tongel|secret|noun; adjective|
|toopan|short|adjective|
|topito|direction|noun|
|torian|silver|noun; adjective|
|torkat|touch|verb|
|torm|animal used by the Seanchan in battle|noun|
|torreale|north|noun; adjective; adverb|
|totah|far|adjective; adverb|
|toulat|copy|noun|
|tovya|roll|verb|
|trefon|system|noun|
|tsag|bollocks (obscenity uttered by Sammael)|interjection|
|tsang|despised|adjective|
|tsatsi|bottle|noun|
|tsinas|brake|noun; verb|
|tsingu|honor|noun; verb|
|tsorovan|storm (sometimes meaning a smaller storm)|noun|
|tuatha|traveler (one going from one place to place; can be a vagabond)|noun|
|tuhat|thousand, one|adjective|
|tuhat|thousand(s) (as in, *tre’tuhat*, meaning 3,000)|suffix|
|tumasen|safe|adjective|
|tumerest|bulb|noun|
|tunga|point|noun|
|tyagani|respect|noun|
|tyaku|keep|verb|
|ubriva|surprise|noun|
|ubunto|animal|noun|
|udiya|clear|adjective|
|uglat|smash|verb|
|uiwa|good|adjective|
|uldatein|division|noun|
|umeil|seem|verb|
|undacar|plane|noun|
|ungost|finger|noun|
|unyat|late|adjective; adverb|
|upendar|net|noun|
|urkros|egg|noun|
|ursta|fix|verb|
|urstae|fixed|adjective|
|usont|tray|noun|
|uttat|slip|verb|
|uvaal|leg|noun|
|vaakaja|sense|noun|
|vadin|bar/barrier|noun|
|vaeku|station|verb|
|vaesht|while|noun; conjunction|
|vakar|move|verb|
|valdar|guard|noun|
|valon|guard|verb|
|varkol|sheep|noun|
|varma|ray|noun|
|vartan|glass|noun|
|vasen|arrow|noun|
|vastri|rule|noun; verb|
|vavaya|flight|noun|
|veel|ink|noun|
|velach|receipt|noun|
|velin|feather|noun|
|velu|end|verb|
|veren|catalyst/pawn in human form; described in the Companion as "those who cause or are bound to change"|noun|
|veshan|way|noun|
|vesna|spring|noun|
|vetan|seed|noun|
|vezo|chalk|noun|
|vhool|basket|noun|
|viboin|pocket|noun|
|vid|with|preposition|
|vidhel|law|noun|
|vidnu|sort|verb|
|viliso|fold|verb|
|vin|promise|noun|
|vlafael|government|noun|
|vlagh|field|noun|
|vodish|judge|noun; verb|
|vokosh|hair|noun|
|vol|father(s)/sire(s) (specific to a male who has used brutal means, i.e., a rapist)|noun|
|vovok|wolf|noun|
|vraak|drain|verb|
|vrang|cruel|adjective|
|vream|shock|noun|
|vron|watcher(s)|noun|
|vronne|watch|verb|
|vyashak|organization|noun|
|vyavi|writing|noun|
|vyen|fade|verb|
|vyropat|opposite|noun; adjective; preposition|
|wabunen|connection|noun|
|wadlian|simple|adjective|
|wafal|hanging|noun; adjective|
|wagg|nerve|noun|
|wahati|porter|noun|
|waji|now|noun; adverb|
|wakaput|ship|noun|
|wanda|match|verb|
|wansho|builders (Shienaran term for the Ogier)|noun|
|wapro|cover|verb|
|warat|branch|noun|
|washdor|wise|adjective|
|wastin|spoon|noun|
|watari|decision|noun|
|wek|off|preposition|
|weladhi|family|noun|
|welakai|tomorrow|noun; adverb|
|werstom|food|noun|
|whado|fertile|adjective|
|whakatu|increase|verb|
|whandin|event|noun|
|whudra|regret|noun; verb|
|widon|after|adverb; preposition; conjunction|
|wishti|sign|noun|
|witapa|meal|noun|
|wixi|pot|noun|
|worshi|machine|noun|
|wot|that|pronoun; adjective|
|woudem|loose|adjective|
|wuseta|card|noun|
|xazzi|rough|adjective|
|xelt|sharp|adjective|
|xentro|sand|noun|
|xeust|side|noun|
|xurzan|representative|noun|
|ya|my own|suffix|
|yaanaho|competition|noun|
|yaati|physical|adjective|
|yabbeth|common|adjective|
|yabedin|committee|noun|
|yak|than|conjunction|
|yalait|expert|noun; adjective|
|yalu|name|noun; verb|
|yamar|edge|noun|
|yappa|kind|adjective|
|yasipa|rest|verb|
|yaso|cheap|adjective|
|yatanel|story|noun|
|yazpa|snow|noun; verb|
|ye|I (sometimes used as an exclamatory fragment)|pronoun|
|yedcost|brick|noun|
|yeel|carriage|noun|
|yekko|dust|noun|
|yohini|damage|verb|
|youna|let|verb|
|youst|ice|noun|
|yugol|broken|adjective|
|yuntar|boy|noun|
|zafar|yellow|adjective|
|zaffi|complete|verb|
|zahert|elastic|adjective|
|zalabadh|pipe|noun|
|zaleen|soft|adjective|
|zamon|darkness, total|noun|
|zanda|cold|noun; adjective|
|zanzi|happy|adjective|
|zara|game played on a board with living pieces by followers of the Dark One|noun|
|zarin|degree|noun|
|zavilat|will|noun|
|zazit|though|conjunction|
|zela|salt|noun|
|zeltain|need|noun|
|zemai|corn; maize; (type of grain from Aiel Waste; an anagram of "maize")|noun|
|zemliat|parcel|noun|
|zemya|room|noun|
|zengar|narrow|adjective|
|zheshi|argument|noun|
|zhoh|hook|noun|
|zhoub|earth|noun|
|zialin|certain|adjective|
|zinik|stitch|noun|
|zintabar|poison|noun|
|zipan|powder|noun|
|zladtar|market|noun|
|zomara|zombie-like creations of Aginor (used as servants by the Forsaken)|noun|
|zoppen|wet|adjective|
|zurye|grass|noun|
|zyntam|error|noun|

## List of Compound Words and Short Phrases
The following is a list of compound words and short phrases derived from the list above. The short phrases are not sentences, but usually named entities (eg the names of the Forsaken or Aiel societies), plurals or fixed expressions or terms (such as sul'dam). 

|**Old Tongue**|**Common Tongue**|**Literal translation**|**Part of Speech**|**Notes**|
|-|-|
|a’dam|leash; used by the Seanchan|of leashing|noun|a + dam.|
|a’vron|watchers|of watching|noun|a + vron.|
|Aan’allein|One Man (Aiel name for Lan)|One Man|noun|aan + allein. Capitalisation indicates more than just "one man", but one man alone or one man who is an entire people.|
|Aes Sedai|Servants of All|all-servants|noun|aes + sedai. The preposition "of" or "a" is implied or absorbed into the "A" of "Aes". Note Capitalisation means more than without capitals.|
|Aesdaishar|Kandori palace in Chachin where the ruler resides; Glory of All|all-glory|noun|aes + dai + shar. Capitalisation indicates something more. Note this is a single word compared to Aes Sedai.|
|aethan|shields|plural of shield|noun|Singular possibly "aetha", but not specified|
|Aethan Dor|Aiel warrior society; Red Shields|red shields|noun|aethan + dor|
|aginor|name of one of the Forsaken; slicer of the living|living-slicer/cutter|noun|agit + nor|
|Ahf’frait|Trolloc band; strong wind|strong wind|noun|ahf + frait. Possibly the additional ' indicates the two fs should both be pronounced|
|Aiel|the Dedicated|dedicated|noun|Capitalisation indicates more than "dedicated" but that it defines those to whom it applies|
|al‘cair|the gold(en)|the gold(en)|adjective|the prefix "al" seems to indicate definite article in this case. See "cair".|
|al’cair'rahienallen|name for Cairhien used in ancient times.|hill of the golden dawn|noun|al + cair + rahien + allen. Companion translates as Gold(en) Dawn Hill, but this conflicts with other entries for al and cair.|
|Al’ghol|Trolloc band; soulless||noun|ghol is soul; gholam also described as soulless. Use of "al" unknown.|
|Al'Cair Dal|place in the Aiel Waste; the Golden Bowl|golden bowl|noun|al + cair + dal. Capitalized as a proper noun|
|aldieb|name of the west wind (the wind that brings the spring rains); also the name of Moiraine's horse|name of Moiraine's horse|noun|wind is dieb. West is "koudam". The origin of the "al" part of the word is unknown.|
|algai|battle person, fighter|of battle|noun|al+gai = battler/warrior|
|algai’d'siswai|Aiel warriors|warriors of the spear|noun|algai + d' + siswai|
|anfear|night|of the night|noun|an+fear|
|angreal|device that enhances the power to channel|of the power to channel|noun|an+greal|
|ansoen|lies|anti-truths?|noun|"soe" means "truth" and "an" or "en" could signify plural, but the negation is not defined.|
|aran'gar|right-hand dagger used in deadly dueling in AoL; also the name of Balthamel reborn|right-hand dagger|noun|aran + gar|
|aridhol|Former name of Shadar Logoth; One of the Ten Nations for which this was the capital|harmony-land|noun|aris + dhol|
|asha’man|guardian/defender; having an implication of siding with justice and right|guard-blade|noun|ashan + man|
|ashandarei|name for Mat's sword used by Birgitte|guard-spear|noun|ashan + darei|
|atha’an|people/folk; strong implications at the least of nationhood|persons|noun|atha + an. Plural of atha.|
|Atha'an Miere|cultural group of the Westlands|people of the sea/waves|noun|atha'an + miere|
|Atha'an Shadar|Seanchan name for Darkfriends; People of the Shadow|people of the shadow|noun|atha'an + shadar|
|avende|trees|trees|noun|the singular form of this is unknown|
|Avendesora|tree found in Rhuidean; last living chora tree|life-tree|noun|avende + sora|
|Avendoraldera|an offshoot of Avendesora found outside the Waste|sapling?|noun|Avende is tree, dera is "derived from". The "lo" connector is not certain, but it is not the same as Avendesora|
|ayend’an|of the fallen or the dead|of the freed|preposition|ayend + an|
|Ba’alzamon|name used by Ishamael during the Trolloc Wars and afterwards; Heart of the Dark|heart of complete darkness|noun|ba + al + zamon. Ba is not defined but also present in words like baid (self), balt (essence), bal (circle) and bajad (spawn) indicating something central or original.|
|ba’asa|your heart|heart-you|noun|ba + asa. Asa only given as "you". Ninto is given as "your".|
|Baijan’m’hael|title of command given to asha'man.|attack leader|noun|baijan + m'/ma + hael|
|balthamel|name of one of the Forsaken; essence of youth|essence-young|noun|balt + thamel|
|be'lal|name of one of the Forsaken; also known as the Envious and Netweaver|desire to have|noun|belo + lal|
|Bhan'sheen|Trolloc band; bringers of annihilation|annihilation-bringers|noun|bhan + sheen|
|caba'donde|horse to ride|riding horse|noun|caba + donde. Donde is related to riding. As opposed to horses for eating or those that are wild?|
|caba'drin|cavalry/horsemen|horse men/soldiers|noun|caba + drin|
|caballein|horseman; also used to indicate a free man||noun|caba + allein. Similar to the word "chevalier" in that a man rich enough to own their own horse was independent.|
|cadin|clothes|cloths|noun|plural of cloth.|
|cadin'sor|working clothes|working clothes|noun|cadin + sor|
|caldazar|red eagle|red eagle|noun|cal + aldazar|
|calhar|red hand||noun|cal + har|
|ca'lyet|do come|do come|verb|ca + lyet|
|car'a'carn|chief of chiefs; capitalized|chief of chiefs|noun||
|Cha Faile|name taken by Faile's followers. The Falcon's Talon.|Talon Falcon|noun|cha + faile. Neither a compound word nor containing any obvious possessive modifier|
|chalinda|an Old Tongue name given to Min by Siuan|sweet one|noun|the suffix da is gender neutral, appropriate for Min and perhaps deliberate by Siuan when dar would be "sweet girl"|
|choryat|five (material)||noun; adjective|chor + yat|
|chorye|five (abstract)||noun; adjective|chor + ye|
|Cor Darei|Aiel warrior society; Night Spears|night spears|noun|cor + darei. Distinction between "cor" and "fear" unknown.|
|Cordamora|name of the palace in Maradon; Heart of the People||noun|corda + mora|
|Corenne|Seanchan term for the reconquest of the Westlands|the return|noun|Derivation uncertain. No other known word for the verb/noun "return". This may or may not be "corenne".|
|cour'souvra|device used to coerce Forsaken|mind-trap|noun|cour + souvra|
|cuebiyar|my heart; capitalized it means your true love|heart of mine?|noun|cuen + biyar?. The meaning of the second part is not known.|
|cuendillar|indestructible material made with the One Power|heart-stone|noun|cuendar + dillar|
|cyndane|name given to reincarnated Lanfear|last chance|noun|cyn + dane|
|Da'concion|Seanchan term for the Forsaken|summoned ones|noun|concion means summoned, but perhaps could be added as Chosen. Sunmoned to the Great Lord seems appropriate though.|
|da'covale|slave|person-property|noun|da + covale|
|dadaranell|name of large range of mountains inherited by modern day Shienar.|father of ranges|noun|dada + ranell|
|dae'mar|an intricate or complex game|complex/intricate game|noun|dae + mar. puzzle/brainteaser?|
|daes|many people; multitudes; implications of diversity|many persons|noun|da + es suffix|
|Daes Dae'mar|the Great Game; also known as the Game of Houses|complex game of people|noun|The sense of Daes is not just people but a diverse selection of people from all sectors in essence, politics, which has a similar etymology|
|dae'vin|treaty|complex/intricate promise|noun|dae + vin|
|Dai Shan|title for Lan used by Shienarans|battle lord|noun|The capitalisation may elevate this beyond merely descriptive. Greater than a lord or greater than a normal battle, for example.|
|daishar|glory literally: “battle blood ”or “blood of battles”|battle-blood|noun|dai + shar.|
|dalae|is paid|paid|past partciple|dale + ae|
|damane|Seanchan slave who can channel|leashed|noun|dam + ane|
|dantor|theory||noun||
|darei|spears plural of dareis; used by Aiel||noun|dareis --> darei|
|Da'shain Aiel|name of a group of pacifists in the Age of Legends. Sometimes shortened to “Da’shain” (pacifists).|dedicated peace-people|noun|dae+shain+ Aiel|
|da'tsang|Aiel term for a pariah|despised-one|noun|da + tsang|
|demandred|name of one of the Forsaken; one who twists the blade|agent of blade-twist|noun|de + man + dred|
|desyat|ten; a quantifier of material objects|a quantifier of material objects|adjective|des + yat|
|desye|ten; descriptive of the immaterial|descriptive of the immaterial|adjective|das + ye|
|devoriska|request; that which was asked|that which was asked|noun|devor + iska|
|Dhai'mon|Trolloc band; scythes of war|scythes of war|noun|dhai + mon|
|Dha'vol|Trolloc band; sires of agony|sires of agony|noun|dha + vol|
|Dhjin'nen|Trolloc band; those who cause terror|terroriser|noun|dhjin + nen|
|diynen|sounder|sounder|noun|diy + nen|
|Do Miere A'vron|Watchers Over the Waves|over the waves watchers of|noun|do + miere + a + vron|
|dore|mountains|mountains|noun|No singular form given|
|dovie'andi|dice|lucky stones|noun|dovie + andi|
|drovja|hag; beldam; old woman; (possessive)|of / issued from a hag / beldam / old woman|adjective|drova + ja|
|Duadhe Mahdi'in|Aiel warrior society; Water Seekers|water seekers|noun|duadhe + mahdi + 'n|
|dvoyat|two (material)||adjective|dvo + yat|
|dvoye|two (abstract)||adjective|dvo + ye|
|Ellisande|name given to last Queen of Manetheren; Rose of the Sun|sun rose|noun|ellis + ande|
|Far Aldazar Din|Aiel warrior society; Brothers of the Eagle|(of the) eagle-brothers|noun|far + aldazar + din|
|Far Dareis Mai|Aiel warrior society; Maidens of the Spear|(of the) spear-maidens|noun|far + dareis + mai|
|gaidin|brother to/of battle; Aes Sedai use this word for Warders|battle-brother|noun|gai + din|
|gai'don|battle|battle of importance|noun|gai + don. Don indicates significance, so refers to one that is key to victory/defeat, not just any battle.|
|gai'shain|Aiel word given to a captive|peace of battle|noun|gai + shain|
|gemarisae|is made|is made|verb|gemarise + ae|
|Ghar'ghael|Trolloc band; brutes of venom|brutish-venom|noun|ghar + ghael|
|Ghob'hlin|Trolloc band; harvesters of souls|soul-harvesters|noun|ghoba + blin|
|Gho'hlem|Trolloc band; takers of souls|soul-takers|noun|ghoba + hlem|
|gholam|Shadowspawn; means “soulless”|soulless|noun|ghol + lam|
|Ghraem'lan|Trolloc band; prized of the mighty|prized of the mighty|noun|ghraem + lan|
|graendal|name of a Forsaken; vessel of pleasure|pleasure-bowl/vessel|noun|graen + dal|
|Hailene|Seanchan term referring to the original force sent to the Westlands; Forerunners|forerunners|noun|h + ailen + ne. The prefix and suffix are unknown.|
|hama|dancers; implies particular grace and fluidity||noun||
|Hama N'dore|Aiel warrior society; Mountain Dancers|dancers of the mountain|noun|hama + n' + dore|
|haran|hand of the|hand of the|noun|har + an. eg Shaidar Haran is "hand of the shadow"|
|hessalam|name of one of the Forsaken. Graendal's reincarnation.|without forgiveness|noun; adjective|hessa + lam|
|hlem|takers||suffix|Both "hlin" and "hlem" uniquely start with "hl".|
|hlin|harvesters||suffix|Both "hlin" and "hlem" uniquely start with "hl".|
|hou'dabor|dream|sleep-picture|noun|houma + dabor|
|indemela|enemy|not-friend|noun|inde + amela|
|isainde|negative form of isain; is no/is not/am no/am not insistent; emphatic|is not|verb|isain + inde|
|ishamael|name of a Forsaken; betrayer of hope|betrayer of hope|noun|ishama + el|
|jeade'en|name of Jain Farstrider's and Rand’s horse|finder that is true|noun|jaede + en|
|ji'e'toh|Aiel philosophy of life|honor and obligation|noun|ji + e + toh|
|kesiera|jewelry worn on the forehead||noun|Possibly some derivative of keisa.|
|Kiseran|title Siuan used to address Loial|honourable one|noun|kiserai + n|
|Ko'bal|Trolloc band; circle of one; Brotherhood|circle of one|noun|ko + bal|
|ko'di|concentration technique; Oneness|one-ness|noun|ko + odi?|
|koyat|one (material)||adjective|ko + yat|
|koye|one (abstract)||adjective|ko + ye|
|koyn|first||adjective|ko + yn|
|kozat|unit||noun|ko + zat. Meaning of "zat" is not known|
|lanfear|name of a Forsaken; daughter of the night|daughter of the night|noun|la + an + fear|
|lormae|is written||verb|lorme + ae|
|loviyagae|memories||noun|loviyaga + e|
|Machin Shin|creatures of the Ways; also known as the Black Wind.|journey of destruction|noun|machin + shin|
|Mafal Dadaranell|name for Fal Dara in ancient times|pass at the father of ranges|noun|mafal + dada + ranell|
|magami|little uncle; what Amalisa called King Easar in private||noun|maga + min? "min" is "little" which would imply that "maga" is "uncle".|
|mah'alleinir|name Perrin gave to his Power-wrought hammer; he who soars|seeking man of the stars|noun|mahdi + allein + onir|
|mahdi'in|seekers||noun|mahdi + in|
|Manetheren|name of one of the Ten Nations|mountain home|noun|etymology of the word is unknown|
|manetherendrelle|name of the White River (one of the Two Rivers) in ancient times|waters of the mountain home|noun|manetheren + drelle|
|manshimaya|my own sword|my sword|noun|manshima + ya|
|marath'damane|Seanchan term for Aes Sedai and Wilders.|must-leashed|noun|marath + dam + ane|
|mashiara|my love; but a hopeless love|love-possession|noun|mashi + ara|
|ma'vron|Watchers (with capital W for importance)|watchers|noun|ma + vron|
|Mera'din|Aiel term for those without society; Brotherless|without-brother|noun|mera + din. Capitalisation defines who they are and indicates importance.|
|mesaana|name of one of the Forsaken; teacher of lessons|lesson-teacher|noun|mestani + saana|
|mestani|lessons|lessons|noun|singular form unknown|
|m'hael|leader; capitalized implies “Supreme Leader"; title Taim gave himself|Leader|noun|m' or ma + hael.|
|Mia'cova|term used by Moghedien after she is endlaved by the mind-trap|owner of me|noun|mia + cova|
|minyat|eight (material)||adjective|min + yat|
|minye|eight (abstract)||adjective|min + ye|
|misain|be, but with an insistent/emphatic tone||verb|m + isain. "to be" (isain)  but moreso|
|mosai|low||adjective|mos + ai|
|mosiel|lower||verb|mos  + iel|
|mosiev|lowered or downcast||adjective|mos + iev|
|m'taal|stone||adjective|m' + taal|
|muad'drin|infantry/footmen|men on foot|noun|muad + drin|
|n'am|beautiful|of/from beauty|adjective|n + am|
|nar'baha|traveling boxes given to Shaido by Sammael|fool boxes|noun|narfa + baha|
|navyat|nine (material)||adjective|nav + yat|
|navye|nine (abstract)||adjective|nav + ye|
|n'baid|automatic|of/from itself|adjective|n' + baid.|
|n'dore|mountain|of/from the mountains|adjective|n' + dore|
|nolvae|is given||verb|nolve + ae|
|no'ri|stones (the game)||noun|Word construction/contraction unknown|
|osan'gar|name of a Forsaken (Aginor reborn); left-hand dagger|left-hand dagger|noun||
|otyat|four (material)||adjective|ot + yat|
|otye|four (abstract)||adjective|ot + ye|
|o'vin|an agreement; a promise (with definite article)||noun|o + vin|
|panyat|six (material)||adjective|pan + yat|
|panye|six (abstract)||adjective|pan + ye|
|Rahien Sorei|Aiel warrior society; Dawn runners|dawn runners|noun|rahien + sorbe|
|rahvin|name of a Forsaken; promise of freedom|promise of freedom|noun|raha + vin|
|rema'kar|weapon from the Age of Legends that inflicts pain on the nervous system|nerve-pain whip|noun|remath+kar. Translated as "energy whip", but perhaps more similar to a taser?|
|Rhyagelle|Seanchan migration to the Westlands|Those Who Come Home|noun|Precise breakdown of word unknown|
|roedane|bit (past tense)|bite + (past tense)|verb|roedna + ane|
|sa'angreal|a device, stronger than an angreal, that enhances the power to channel|superlative object of the ability to channel|noun|sa + an + greal|
|sa'blagh|library|superlative book|noun|sa + blagh|
|sagain|it is time|time is|noun|sag + ain|
|saidar|female side of the Power|feminine power|noun|sai + dar|
|saidin|male side of the Power|masculine power|noun|sai + din|
|Samma N'Sei|Aiel warriors who have been turned to the Shadow|eye -blinders|noun|samma + n' + sei|
|sammael|name of a Forsaken; destroyer of hope|destroyer of hope|noun|samma + el|
|sedai|servants||noun|seda + i|
|Seia Doon|Aiel warrior society; Black Eyes|black/dark eyes|noun||
|Sei'cair|Aiel title for Perrin|golden eyes|noun|seia + cair|
|Seiera|name of a flower known in Baerlon as “blue-eye”; name of Min's mare|blue eye|noun|seia + iera|
|sei'mosiev|Seanchan word for shame|eyes lowered|adjective|seia + mosiev|
|sei'taer|Seanchan word for prestige or redemption|eyes straight|adjective|seia +  taer|
|semirhage|name of a Forsaken; promise of pain itself|pain itself|noun|se + mirhage. Companion translates as "promise of pain itself", but "promise" is "vin" and is not a component. Capitalisation may change meaning.|
|serenda|stubborn person; also the name of the King's palace in Amadicia|stubborn one|noun|seren + da|
|serenla|name given to Min by Siuan|stubborn daughter|noun|seren + la|
|Shadar Logoth|name for ancient city of Aridhol|place of waiting shadow|noun|shadar + logoth|
|Shadar Nor|name given to Latra Posae, an Aes Sedai in the Age of Legends|shadow-cutter/slicer|noun|shadar + nor|
|shae'en|dogs||noun|shae + en|
|Shae'en M'taal|Aiel warrior society; Stone Dogs|dogs of stone|noun|shae + en + m' + taal|
|Shaidar Haran|avatar of the Dark One in the form of a tall myrdraal|hand of the dark|noun|shaidar + har + an|
|shaiel|dedicated woman; Tigraine's Aiel name|dedicated woman/she|noun|shai + aiel|
|Shai'tan|name of the Dark One|dark sovereign OR female soveriegn|noun|shaidar + tan OR shai + tan.  Jordan's little joke?|
|sha'je|duel fought in ancient Qal; mentioned by Semirhage||noun|possibly related to "conje" and "needle" which would conjure up an image of fencing.|
|sha'mad|thunder|loud-noise|noun|sha + mad|
|Sha'mad Conde|Aiel warrior society; Thunder Walkers|loud-noise walkers|noun|sha + mad + conde|
|shambayan|Borderlands term for man in charge of securing provisions and supplies||noun|shan + ??. The word has clear similarities with shatayan, but not fully translatable.|
|sha'rah|game of strategy played by Moridin. From the Age of Legends.||noun|possibly shar + raha (blood freed) referring to the Fisher King being a free entity or his open wounds.|
|shari|plural of shar|bloods|noun|shar + i|
|shatayan|Borderlands term for female in charge of ordering servants and running the household||noun|shan + ??. The word has clear similarities with shambayan, but not fully translatable.|
|Shayol Ghul|place where the Dark One's prison is weakest.|doom pit|noun||
|Sh'boan|empress; Sharan term for alternating absolute ruler|one who is the ideal of female beauty|noun|sh? + boan. Contraction of the first part is unknown. Could be "shar", "shan", "shaari", "shain".|
|Sh'botay|emperor; Sharan term  for alternating absolute ruler|one who is the ideal of male beauty|noun|sh? + botay. Contraction of the first part is unknown. Could be "shar", "shan", "shaari", "shain".|
|sheen|bringers of|bringers of|noun|shee? + an. We don't have a word for "bring", but "an" suffix can be "of" or pluralisation.|
|Shen an Calhar|name of Mat's military force and historical force of Manetheren; The Band of the Red Hand|band of the red hand|noun|shen + al + cal + har|
|siswai'aman|spears of the dragon; term used by the Aiel|dragon-spear|noun|siswai + aman|
|Soe'feia|Seanchan Truthspeaker|truth-speaker|noun|soe + foe|
|so'jhin|Seanchan hereditary upper servants of the blood|exalted thing|noun|so + jhin. Implies someone that has been raised up from the lower classes/property caste.|
|souvraya|my own mind|my own mind|noun|souvra + ya|
|Sovin Nai|Aiel warrior society; Knife Hands|knife hands|noun|sovin + nai|
|sukyat|seven (material)||adjective|suk+yat|
|sukye|seven (abstract)||adjective|suk+ye|
|sul'dam|leash holder|holder-leash|noun|sul + dam|
|Tai'daishar|title more esteemed than tai'shar; name of Rand's horse|true glory|noun|tai + dai + shar|
|tain|true (plural)|true|adjective|tai + n|
|Tain Shari|Aiel warrior society|true bloods|noun|tai + n + shar + i. Note the pluralisation of both true and blood compared to tai'shar|
|tai'shar|true blood; used as an honorific|true blood|noun|tai + shar|
|ta'maral'ailen|web of destiny around those who are ta’veren|pre-destined of the pattern|noun|ta + maral + ailen. "maral'ailen" is "destined before".|
|Tar Valon|name of the city of the Aes Sedai|tower guard|noun|tar + valon|
|tarasin|name of palace in Ebou Dar|tower of man|noun|tar + a + sin|
|Tarmon Gai'don|last battle|final battle|noun|tarmon + gai + don|
|tatatoun|instrument|voice-copier/imitator?|noun|tati + ??. Closest to "toun" is "toulat" which means "copy".|
|ta'veren|those who cause the fabric of the Pattern to bend around them|pattern-changers|noun|ta + veren|
|Tel'aran'rhiod|The Unseen World, the World of Dreams|Unseen solid world?|noun|possibly tel + garan + rhiod. "telio" is "transparent" and "garan" is "solid".  A world that is both unseen and yet solid/real.|
|ter'angreal|tool made to perform a specific function using the One Power|tool of the ability to channel|noun|ter + an + greal|
|t'ingshen|treebrother; a compound word that is used in a formal address to an Ogier||noun|the construction of this word is unknown|
|to'raken|Seanchan exotic animal; huge flying creature|huge flier/raken?|noun|to + raken. The meaning of the "to" prefix is unknown|
|treyat|three (material)||adjective|tre + yat|
|treye|three (abstract)||adjective|tre + ye|
|Tsorovan'm'hael|name of additional military rank given to asha'man by Taim|storm leader|noun|tsorovan + m'/ma + hael|
|Tuatha'an|Tinkers; the travelling people|travelers|noun|tuatha + an|
|Valdar Cuebeyari|name of royal guard of Manetheren; the Heart Guard|Guard of the Heart|noun|Valdar + cuebiyar + i.  In this sense, heart is meant as "heartland"|
|vasen'cierto|arrow of time; idiomatic phrase which literally means “arrow enduring”|resolute arrow|noun|vasen + cierto. Cierto is defined as "resolute" but the Companion defines in this context as "enduring".  Possibly read as the irreversible/constant nature of causality/time.|
|wansho|builders; Shienaran term for the Ogier||noun|pluralisation and root form unknown|



## Notes
















https://wot.fandom.com/wiki/List_of_Old_Tongue_words