---
tags: [Women, BrownAjah, KeepersoftheChronicles, AesSedai, Charactersoriginaltothevideogame, AmyrlinSeats]
---


**Elayna** was an [[Aes Sedai]] of the [[Brown Ajah]] in a [[Mirror World]], where she served as [[Keeper of the Chronicles]], and briefly as [[Amyrlin Seat]] around 850 NE.

## History
As a child, Elayna was once trapped in a cave. She remembered this experience during her test to be raised [[Accepted]] at the [[White Tower]]. 
Elayna was eventually raised to the shawl and chose the [[Brown Ajah]], although she was very weak for an Aes Sedai. She was a student of *ter'angreal* and used them to raise her abilities in the [[One Power]] to the extent that it raised her standing within the White Tower.
Elayna was essential in her Mirror World thwarting a plan of [[Ishamael]] to weaken the seals on the [[Dark One]]'s prison before the [[Last Battle]] could take place.

## Notes






https://wot.fandom.com/wiki/Elayna