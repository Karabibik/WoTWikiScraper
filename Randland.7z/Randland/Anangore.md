---
tags: [, Seanchancontinent]
---
**Anangore** is the ninth largest city in [[Seanchan]].
The city is located in the west of the [[Seanchan (continent)|continent]], about one to two hundred miles south of the equator.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Anangore