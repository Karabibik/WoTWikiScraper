---
tags: [Otherfeatures, Shienar, Malkier]
---
**Tarwin's Gap** is a mountain pass marking the boundary between the [[Mountains of Dhoom]] and the [[Spine of the World]].
Tarwin's Gap can be seen as the location of [[Rand]]'s first appearance as the [[Dragon Reborn]] when he destroyed the [[Trolloc]] Army there after [[Channel|channeling]] the pool of pure *saidin* at the [[Eye of the World]].
Tarwin's Gap was also used extensively during the [[Trolloc Wars]] to transport Trolloc troops from the [[Blight]] into the [[Westlands]].

## External links
 





https://wot.fandom.com/wiki/Tarwin%27s_Gap