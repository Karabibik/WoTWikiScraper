---
tags: [Women, YellowAjah, Seanchan_people, Damane, AesSedai, LivingasofWH, MiddleRankingAesSedai, Slaves, Channelers]
---


**Ryma Galfrey** was an [[Aes Sedai]] of the [[Yellow Ajah]] who is now a *damane*. 

## Contents

1 Appearance
2 Strength
3 History
4 Activities
5 Notes


## Appearance
She is slim and elegant, with dark hair and blue eyes.

## Strength
Ryma's strength level is described by "The Wheel of Time Companion" as 29(17). She is not strong enough alone to open a [[Gateway|gateway]] to [[Travel]].

## History
Ryma was born in 902 NE and went to the [[White Tower]] in 917 NE. After spending eight years as a [[Novice|novice]] and seven years as [[Accepted]], she was raised to the shawl in 932 NE. 
She is the one to announce to the other Aes Sedai that [[Tamra Ospenya]] had "died in her sleep".

## Activities
When the Seanchan landed at [[Falme]], she and [[Sheraine Caminelle]] were captured and made *damane*. Ryma was renamed **Pura** and trained harshly.  When [[Egwene al'Vere]] was collared she met Ryma, who asked her to remember her real name. [[Bayle Domon]] witnessed the capture of Sheraine Caminelle, who screamed for Ryma to help her.
After Falme fell she was taken to [[Cantorin]] where the *sul'dam* [[Taisa]] holds her leash. [[Suroth]] questions her on how the White Tower controls the [[Dragon Reborn]]. Suroth does not believe that Pura does not know. Later she was brought back to the [[Westlands]] after [[Amadicia]] was taken. She is now completely broken.

## Notes






https://wot.fandom.com/wiki/Pura