---
tags: [Nations, Altara, Parallels]
---

**EWoT:** 


**Altara** (al-TAH-rah; /æɫˈtɑːɹɑ/) is a country located in the south-central part of the [[Westlands]].
The sign of Altara is two golden leopards on a field checked four-by-four in red and blue.

## Contents

1 Geography
2 History
3 Government
4 Culture
5 Military
6 Economy
7 Towns/cities
8 Parallels
9 External links
10 Notes


## Geography
The [[River Eldar]] forms its western border with [[Amadicia]], and is adjacent to [[Illian]] in the east.  


## History
The capital of Ebou Dar is situated on the old site of the ancient city of [[Barashta]], a city in [[Eharon]], one of the [[Ten Nations]]. Although the [[Trolloc Wars]] left the nation relatively untouched for many years (primarily due to distance from the [[Great Blight]]), by the time they ended, the city had been completely destroyed with barely a stone standing. The site of the old city is approximately located in what is now the [[Rahad]]. 
During the [[Free Years]], what is modern-day Altara included the nation of [[Shiota]], but also parts of [[Kharendor]]. Numerous attempts to reestablish the pre-Hawkwing era nation of Shiota were attempted, but ultimately failed, with the longest lasting fifty years and being ruled over by three different monarchs.
Concluding that the old nations would never return, Altara was founded c. [[FY 1112]] during the War of the Hundred Years by Lord [[Maddin Todande]]. He claimed to be a descendent of the last Queen of [[Shiota]] and may well have been. House Todande ruled from a strong and respected position under four different rulers over a country that was itself becoming increasingly strong and wealthy, especially after the War of a Hundred Years ended five years into his reign.
The dissolution of Altara began in the reign of [[Anarina Todande]] around 82 NE. Anarina was a capricious, some say incompetent, ruler who impoverished her own House and the nation as a whole. She was deposed and assassinated and the power struggles that followed resulted in a legacy of almost 800 years of what has been described as "near anarchy" across the whole nation. Similar to [[Murandy]], power is concentrated locally rather than centrally under an unifying monarch. Since the fall of Anarina, no House has held the [[Throne of the Winds]] for more than two generations and no monarch has been from House Todande. The only thing that unifies the disparate set of nobles that classify themselves as Altaran is the fear that another nation may encroach upon their territory.
In 957 NE, the [[Children of the Light]] made an attempt to do just this. They were opposed by Altara, [[Murandy]] and [[Illian]]. Eventually they were pushed back, and the war became known as the [[Whitecloak War]]. In subsequent years, [[Pedron Niall]] reconsidered making another such move, using the excuse of the presence of [[Rebel Aes Sedai|large numbers of Aes Sedai]] on Altaran soil to increase influence in the region. [[Jaichim Carridin]] was sent to increase favour with Queen Tylin.
Recently the Seanchan conquered Ebou Dar and the southern part of Altara. They allowed Queen Tylin to remain on the Throne of the Winds, however, Tylin was found bound and dismembered underneath her bed. Her son Beslan has taken the throne with the blessing of the Seanchan occupying force.

## Government
The ruling body of Altara is a monarch, with the seat of power called the [[Throne of the Winds]]. The throne is currently held by [[Beslan Mitsobar]]. The throne is located in the [[Tarasin Palace]] in the capital, [[Ebou Dar]]. Shortly before Beslan became king, Ebou Dar and the southern part of Altara were conquered by the [[Seanchan]]. They allowed the then-current queen, Beslan's mother [[Tylin Mitsobar|Tylin]], to remain on the Throne of the Winds. However, Tylin was killed by a *gholam*.
Before Beslan's coronation, he secretly opposed the Seanchan occupation. After the death of Empress [[Radhanan]] and the deposing of [[High Lady]] [[Suroth]], Beslan is offered clemency for his rebellion by [[Tuon]], the [[Daughter of the Nine Moons]], who believes that, although misguided, Beslan had the best interests of his people at heart. Beslan accepts her offer, re-swears his oaths, and is raised to the High [[The Blood|Blood]].
Outside Ebou Dar, the country's inhabitants tend to associate themselves with a particular town or lord rather than the nation as a whole, and only one House has ever ruled the country for four generations. After Beslan is raised to the High Blood, however, Tuon promises to secure Altara for him, granting him absolute rule over the country.

## Culture
Women in Altara are dominant, especially in Ebou Dar. In many situations an Altaran woman has the right to kill a man unquestioned. Knives and swords are an important part of Altaran life. Both men and women fight duels over trivial disputes, often with fatal results. Altaran women carry marriage knives, which serve both as a formal way to broadcast marital status (its color and decorations describe marital and motherly status), and an easy method of disciplining their men.
Seemingly a retreat for women, there was a farm located several miles northeast of Ebou Dar and north of the Rhannon Hills. In actuality, it was run by and was a refuge for the [[Kin]], a group of runaways and novices cast out of the [[White Tower]]. This farm was destroyed when an unsuccessful attempt to [[Talent|unweave]] a [[Gateway|gateway]] caused an explosion wiping out everything in its surroundings.

## Military
Given the political situation in Altara, one cannot say that there is any sort of national army. When the army is raised, it consists of the levies of various nobles, who usually squabble over command and are known to take their soldiers away from the army due to such quarrels, even in dire circumstances. Altara never had a standing force similar to the [[Queen's Guards]] or [[Defenders of the Stone]], as any ruler who attempted to form such a group would have been pulled down immediately by the nobles jealous of their new power.

## Economy
Around Ebou Dar, certain crafts, trades, and property rights belong to men and others to women, while others are open. Wine and ale can be made or sold by both men and women, but only men can own ships (but both can act as broker for the cargo) and women can own land, keep inns, weave cloth, sell fish or fowl to the public and butcher anything smaller than cows. Men can keep alehouses and taverns that have no rooms to let, fish, weave rugs and butcher cows. Death, daggers, and the sea are considered female; ships, swords, and trade are considered male.
Altara produces fine lacquerwork and is famed for its lace. It also produces carpets and tapestries, although these were not considered the best. There are many olive orchards in Altara, providing oil for lamps and cooking. Salt is harvested from salt wells, and pearls, mother-of-pearl, and fish comes from the waters around Altara. Shipping and shipbuilding are big business in Ebou Dar, which is a major port, serving a considerable portion of what lays inland. They have a major portion of the trade coming out of Amadicia and Ghealdan, and a good deal from Tarabon as well.

## Towns/cities
[[Ebou Dar]] (capital)
[[Alkindar]]
[[Brytan]]
[[Coramen]]
[[Cormaed]]
[[Ionin Spring]]
[[Jurador]]
[[Maderin]]
[[Malden]]
[[Marella]]
[[Moisen]]
[[Mosra]]
[[Nor Chasen]]
[[Remen]]
[[Runnien Crossing]]
[[Salidar]]
[[Sehar]]
[[So Eban]]
[[So Habor]]
[[So Tehar]]
[[Soremaine]]
[[Weesin]]
## Parallels
Altara is thought to be based on  in the early modern period, as it is a confederation of semi-autonomous regions beneath a weak monarch. Like Rome, the capital city of Ebou Dar is founded on a very ancient site, and the diet consists heavily of cheeses and seafoods. The importance of canals and the power of guilds in Ebou Dar is also somewhat reminiscent of Venice.

## External links
  on  
## Notes

|**Westland Nations**|
|-|-|
|**New Era**|**Current:****Former:**|
|**Free Years**||
|**After the Breaking**||
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Altara