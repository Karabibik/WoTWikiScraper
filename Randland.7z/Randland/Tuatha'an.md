---
tags: [Tuathaan, Parallels]
---



*"I will find the song, or another will find the song, but the song will be sung this year or in a year to come. As it once was, so shall it be again, world without end."*
   —*Tuatha'an* farewell 

The *Tuatha'an*, (pronounced: too-AH-thah-AHN), are a nomadic people who live in brightly painted wagons and live by a pacifist philosophy known as the [[Way of the Leaf]].  Outsiders sometimes call them "**Tinkers**" or refer to them as the "**Traveling People**".

## Contents

1 History
2 Culture
3 Appearance
4 References from Rand's visions in Rhuidean
5 The Song
6 Parallels
7 External links
8 Notes


## History
The *Tuatha'an* were originally [[Da'shain Aiel]] who followed the [[Way of the Leaf]]. After the Aiel were repeatedly attacked by bandits, [[Sulwin]] and several others of the Aiel defied [[Adan]], then leader of the [[Jenn Aiel]]. They abandoned the items of the [[One Power]] entrusted to them by the [[Aes Sedai]] and took their wagons in search of the "song" (may refer to the prologue of "The Eye of the World", in which the mad Lews Therin asks Ishamael if he has "the Voice" so as to participate in "the Singing"). This group became the *Tuatha'an*.
The *Tuatha'an* are one of the few peoples allowed passage through the [[Aiel Waste]], perhaps because the Aiel cannot bring themselves to interact with such a strange people, although it seems more likely that the [[Wise Ones]] and [[Clan chief|clan chiefs]] know of their mutual origins and refuse to allow the Aiel near the *Tuatha'an*.
The Tuatha'an continued to search in vain for their song, because the song they were looking for did not exist.

## Culture

The [[Way of the Leaf]] defines how the *Tuatha'an* interact with outsiders. *Tuatha'an* will never do any violence, be it in anger or self-defense, not even to save their own life or that of another. If they feel that violence or physical confrontation may ensue, they will simply hide or leave the area. 
This pacifism extends to other creatures. They are vegetarians and only consume fruits, nuts, berries and vegetables. It is not known whether they are vegan or not, but we do not observe them eating eggs or dairy and they appear to not rear any farm animals.
They also do not stay near areas where population is concentrated, as there is a greater propensity for violence in larger settlements. Their beliefs and actions frequently earn them repudiation by common folk. They are considered habitual thieves and, though they do not actively recruit new members, are often accused of trying to convert children to the Way of the Leaf.
Tinker Aes Sedai are also very rare as very few Tinker children wish to channel, as then they must become Aes Sedai and break from the Way of the Leaf.

## Appearance
Despite the fact that Aiel look today exactly as they looked in the AoL, wearing cadin'sor, having light skin color and the majority of them having hair in shades of red, from dark-red to golden-reddish-blond, even their haircut is exactly what they wear thousands of years ago, Tuatha'an people does not look much like Aiel at all. Which is unsurprising given that they've had many converts join them over the generations and thus have interbred with other peoples.

## References from Rand's visions in Rhuidean
Aiel followed the Way of the Leaf and only the Tuaha'an stayed loyal to that.
Solinda sedai tells to Jonai:

*"Keep moving, always moving, until you find a place of safety, where no one can harm you. [4]"* 
Tuatha'an people never stay long in one place. They keep moving although their reason for that is changed during the time.

## The Song

The search for their lost song was the primary goal of the *Tuatha'an* by the time of the events in the series. It has been theorized that the song might have been known to *Lews Therin Telamon* and thereby to *Rand Al'Thor*, and it has likewise been suggested that the *Aiel* could have learned the song through the use of the pillars ter'angreal at Rhuidean. While this could potentially be true, co-author Brandon Sanderson responded on his personal Facebook page to the question of whether the *Tuatha'an* ever discovered their lost song. He responded, "[Robert Jordan] said specifically this was something that did not happen, at least not in the scope of the novels." (February 4th, 2013)

Rand doesn’t know the Song and the Tinkers wouldn’t accept anything he taught them anyhow.
Robert Jordan specifically noted that the Tinkers would not find their Song by the end of the series and that the Ogier song of growing is not the Tinkers’ Song. The Song is *"a much more deep and philosophical concept, perhaps unattainable."*
Source:  , 


From Loial's memory:

*"The Traveling People live for their songs. For all songs, for that matter. For the search for them, at least. I met some Tuatha'an a few years back, and they wanted to learn the songs we sing to trees. Actually, the trees won't listen to very many anymore, and so not many Ogier learn the songs.  [...] I taught the Tuatha'an what they could learn, but the trees never listen to humans. For the Traveling People they were only songs, and just as well received for that, since none was the song they seek.[5]"* 
## Parallels
The name *Tuatha'an* comes from the  in Irish legend, who were a race of people who settled in Ireland. This reflects their wandering status in the Wheel of Time. The name of the only known *Tuatha'an* Aes Sedai, [[Aisling Noon]], strongly resembles the Old Irish *Aislinge Óenguso*, the *Dream of Angus*, one of many myths in a series known as the .
Their culture and reputation is also strongly reminiscent of what, in Ireland, are also referred to as . This, like in the books, is a slang term used for Irish Travellers. The name *Tuatha'an* translates from the Old Tongue as the Travelling People.
Their belief in pacifism is similar, at a basic level, to the beliefs shown in  or .
The Song seems to be a part of Tuatha'an religion originating in the Songs of Growing (the songs used in Treesinging) which the Tuatha'an's progenitors the Da'shain Aiel once sang with the Ogier and Nym in the Age of Legends. However while Rand's trip through Rhuidean shows the Song's clear origin in the Songs of Growing, RJ and Brandon have confirmed the Tuatha'an would never accept the Songs of Growing as the Song, as the Song is something far more based in ideals, spirituality, and religion having evolved over the previous 3,000 plus years through retellings of stories and legends. Indeed in The Eye of the World Loial even mentions teaching the Songs of Growing to the Tuatha'an before he ever met Rand and the Tuatha'an had already decided the Songs of Growing were not the Song.
The Tuatha'an are very similar to the real life Roma in both persecution with a reputation for being thieves and in that they live in wagons.

## External links
  on  
## Notes






https://wot.fandom.com/wiki/Traveling_People