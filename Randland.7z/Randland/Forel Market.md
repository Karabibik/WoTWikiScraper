---
tags: [Andor, Villages]
---
**Forel Market** is a village in [[Andor]].
When [[Elayne Trakand]] and her group are making their way to [[Caemlyn]] after [[Traveling]] from [[Altara]], they stop in Forel Market. They are forced to stay in The White Swan due to heavy rains. While there, Elyane hears three different rumors. The first is that the [[Rand al'Thor|Dragon Reborn]] is bringing Elayne to Caemlyn. The second is that Rand has sword fealty to [[Elaida do Avriny a'Roihan]]. The third, and the only one that is true, is that Rand has been crowned king of [[Illian]].

## Notes






https://wot.fandom.com/wiki/Forel_Market