---
tags: [Holds, Shaarad]
---



**Hot Springs Hold** is an [[Aiel]] [[Hold|settlement]] in the [[Aiel Waste|Three-fold Land]]. It is owned by the [[Shaarad]] [[Clan|clan]]. [[Colinda]] is the [[Wise One]] of the hold and [[Gaul]] is from the hold.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Hot_Springs_Hold