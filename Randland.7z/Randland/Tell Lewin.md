---
tags: [Men, Andor_people, TwoRivers_people, Soldiers, LivingasofKOD]
---







**Tell Lewin** is a man of the [[Two Rivers]], the nephew of [[Flann Lewin|Flann]] and the brother of [[Dannil Lewin|Dannil]].

## Appearance
He is lanky.

## Activities
He goes with [[Perrin Aybara]] to rescue the prisoners taken by the [[Children of the Light]] when they are in the Two Rivers.
He is made one of the two captains of the Two River men. He participates in the [[Battle of Emond's Field]].
He is in the [[Battle of Dumai's Wells]]. He carries the Red Eagle banner when they Travel back to [[Cairhien]].
He accompanies Perrin to [[Ghealdan]] when they search for [[Masema Dagar]].
He goes with Perrin to the meeting with the [[Seanchan]]. He keeps the Two Rivers men hidden in the bushes around the meeting to keep an eye out on the larger Seanchan force.

## Notes






https://wot.fandom.com/wiki/Tell_Lewin