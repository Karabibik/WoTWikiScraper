---
tags: [Terangreal, ItemsofPower]
---



The **red crystal chair** is a *ter'angreal* that was found in [[Rhuidean]].

## Appearance
The *ter'angreal* is a chair, undecorated but made completely of red crystal.

## Use
The use of the *ter'angreal* is unknown.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Red_crystal_chair