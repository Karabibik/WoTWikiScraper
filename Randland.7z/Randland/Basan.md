---
tags: [Men, Warders, Deceased, ]
---


**Basan** was [[Warder]] to [[Merana Ambrey]]. 

## History
He died before the [[Aiel War]] and she has not bonded another Warder.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Basan