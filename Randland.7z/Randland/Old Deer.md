---
tags: [Wolves]
---






**Old Deer** is a [[Wolf|wolf]].

## Activities
Old Deer, along with [[Two Moons]], [[Wildfire]], [[Half Tail]], [[Rabbit Nose]], [[Morning Clouds]] and many more are known to [[Perrin Aybara]]. They scout for Perrin when [[Rand al'Thor]] was captured by Aes Sedai.

## Notes






https://wot.fandom.com/wiki/Old_Deer