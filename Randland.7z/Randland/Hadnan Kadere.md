---
tags: [Men, Saldaea_people, Darkfriends, Peddlers, Deceased, POVcharacter]
---






**Hadnan Kadere** was a [[Darkfriend]] from [[Saldaea]], who was part of a party of [[Peddler|peddlers]] in the [[Aiel Waste]].

## Appearance
He was very heavy, but it was all muscle. He had a hooked beak of a nose and dark, tilted eyes.

## Activities
[[Matrim Cauthon]]'s wide-brimmed hat was purchased from Kadere. He meets up with Rand in the Waste shortly after Rand leaves Rhuidean.
While traveling from [[Imre Stand]] to [[Cold Rocks Hold]], Kadere tries make an agreement with [[Rand al'Thor]] to provide information in return for protection. Rand does not accept the offer.
While crossing the [[Spine of the World]] with Rand and the [[Aiel]], Hadnan strangled [[Isendre]] and hid her corpse. When he killed Isendre, it was suggested that every time Hadnan kills a woman, he saw his sister Teodora, whom he had killed when she found out he was a Darkfriend. [[Melindhra|An Aiel woman]] left him a letter saying that he was not alone.
Hadnan was skinned alive at the quay in [[Cairhien]] by [[Lanfear]] when he reported to her that [[Aviendha]] had slept with Rand. 

## Notes






https://wot.fandom.com/wiki/Kadere