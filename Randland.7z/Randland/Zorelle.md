---
tags: [Women, AesSedai_AgeofLegends, Deceased, AgeofLegends_people, Historicalpeople, Channelers]
---


**Zorelle** was an [[Aes Sedai]] who lived during the [[Age of Legends]].

## History
Zorelle Sedai is from [[M'Jinn]]. She had one of the [[Da'shain]] [[Aiel]] named [[Nalla]] in her service. When Nalla proposed to [[Charn]], he thinks of accepting, knowing he will have to change his service from [[Mierin]] to Zorelle.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Zorelle