---
tags: [Oceans]
---




The **Sea of Storms** is the large ocean that lies to the south of the [[Westlands]], [[Termool]] and [[Shara]], and to the north of the [[Land of the Madmen]]. The [[Atha'an Miere]] are the only people known to sail this sea. It is named because of its constant storming, and in the winter, tempests called "cemaros" roll across the Sea of Storms.
[[Mayene]], [[Tear]], [[Illian]] and [[Ebou Dar]] are the largest ports on the Sea of Storms.
The Sea Folk islands of [[Tremalking]], [[Qaim]] and [[Cindaking]] lie in the Sea of Storms. There are also larger Sea Folk island groupings known to exist much further to the south, where mainlanders do not travel.
The Sea of Storms washes against the northern shores of the island continent known as the Land of the Madmen, the existence of which is virtually unknown to people other than the Sea Folk. The Sea Folk have declared this landmass off-limits, due to dangerous volcanic activity and also the instability and violence of the inhabitants, who fell into savagery during the [[Breaking of the World]] and have never recovered.






https://wot.fandom.com/wiki/Sea_of_Storms