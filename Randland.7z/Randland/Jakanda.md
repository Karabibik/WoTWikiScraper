---
tags: [Towns, Arafel, Borderlands]
---
**Jakanda** is a town in [[Arafel]].
Not much is known about this town other than there is a metal worker there. [[Samitsu Tamagowa]] has bells in her hair that were made in Jakanda.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Jakanda