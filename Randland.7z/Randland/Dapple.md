---
tags: [Wolves, ]
---


**Dapple** is the leader of the pack of wolves affiliated with [[Elyas Machera]].

## Appearance
Dapple is a she-wolf whose fur is a dozen shades of gray.

## Activities
When [[Perrin Aybara]] is first learning about being a [[Wolfbrother|wolfbrother]], Dapple, [[Burn]], [[Hopper]], and [[Wind (wolf)|Wind]] speak with him. Dapple and her pack continue to follow Perrin, [[Egwene al'Vere]], and Elyas. When the humans see several flocks of ravens, Elyas asks Dapple to check their backtrail. Dapple tells Perrin that help is coming when he is captured by the [[Whitecloaks]].

## Notes

*This page is a stub. You can help A Wheel of Time Wiki by expanding it. *





https://wot.fandom.com/wiki/Dapple