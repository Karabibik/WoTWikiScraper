---
tags: [Men, Warders, Deceased, ]
---


**Balinor** was [[Warder]] to [[Verin Mathwin]]. 

## History
It took ten years for Verin to get over his death and bond another Warder, [[Tomas]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Balinor