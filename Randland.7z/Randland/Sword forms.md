---
tags: [Swordforms]
---




**Sword forms** are named forms - or "styles" - in which swordsmen are trained to use the sword. [[Blademaster|Blademasters]] and [[Gaidin]] have a wider knowledge and mastery of the forms. Like real-world parallels, they are not always meant to be used exactly as choreographed in the middle of combat and instead convey a named concept or tactic for the swordsman.
While training, one may use a [[Practice sword|practice sword]] instead of a real sword to move through these forms. A practice sword may be sword-shaped piece of wood, or a bundle of thin, loosely bound staves or lathes in place of a blade.
Some, if not all, sword forms are taught in the [[Seanchan]] Empire. When [[Rand al'Thor]] battles [[Turak Aladon]], Rand recognizes the forms that the High Lord used. They were different from what Rand was taught, but similar enough. It is possible the names might be different as well.

## Contents

1 Concepts
2 List of known forms
3 Gallery
4 Notes


## Concepts
[[Void|The Flame and the Void]]
[[Sheathing the Sword]]****
## List of known forms
|[[Apple Blossoms in the Wind]][[Arc of the Moon]][[Black Lance's Last Strike]][[Black Pebbles on Snow]][[The Boar Rushed Downhill]][[The Boar Rushes Down the Mountain]][[Bundling Straw]][[Cat Crosses the Courtyard]][[Cat Dances on the Wall]][[Cat on Hot Sand]][[The Courtier Taps His Fan]][[The Creeper Embraces the Oak]][[Cutting the Clouds]][[The Cyclone Rages]][[Dandelion in the Wind]][[The Dove Takes Flight]][[Eel Among the Lily Pads]][[The Falcon Stoops]][[The Falling Leaf]][[Folding the Air]][[Folding the Fan]][[The Grapevine Twines]][[The Heron Spreads Its Wings]][[Heron Wading in the Rushes]][[Hummingbird Kisses the Honeyrose]]|[[Kingfisher Circles the Pond]][[The Kingfisher Takes a Silverback]][[Kissing the Adder]][[Leaf on the Breeze]][[Leopard in High Grass]][[Leopard in the Tree]][[Leopard's Caress]][[Lightning of Three Prongs]][[Lion on the Hill (sword form)|Lion on the Hill]][[The Lion Springs]][[Lizard in the Thornbush]][[Lotus Closes Its Blossom]][[Low Wind Rising]][[Moon on the Water]][[The Moon Rises Over the Lakes]][[The Moon Rises Over Water]][[Oak Shakes Its Branches]][[Parting the Silk]][[Plucking the Low-Hanging Apple]][[Rain in High Wind]][[Rat Gnawing the Grain]][[Reaping the Barley]][[Red Hawk Takes a Dove]][[Ribbon in the Air]]|[[River of Light]][[The River Undercuts the Bank]][[The Rose Unfolds]][[Shake Dew from the Branch]][[Soft Rain at Sunset]][[Stone Falls From the Mountain]][[Stones Falling Down the Mountain]][[Stones Falling from the Cliff]][[Striking the Spark]][[The Swallow Rides the Air]][[The Swallow Takes Flight]][[Thistledown Floats on the Whirlwind]][[Threading the Needle]][[Tower of Morning]][[Twisting the Wind]][[Two Hares Leaping]][[Unfolding the Fan]][[The Viper Flicks Its Tongue]][[Water Flows Downhill]][[Watered Silk]][[Whirlwind on the Mountain]][[Wind and Rain]][[The Wind Blows Over the Wall]][[The Wood Grouse Dances]]|
|-|-|

## Gallery



## Notes






https://wot.fandom.com/wiki/Sword_form