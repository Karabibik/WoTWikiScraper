---
tags: [Battles]
---

*"Kneel and swear to the Lord Dragon, or you will be knelt."*
   —[[Mazrim Taim]], to the [[Salidar]] [[Aes Sedai]] after the battle. 




The **Battle of Dumai's Wells** occurs at the beginning of 1000 NE. An extremely bloody battle, the [[One Power]] was used to devastating effect, and the world was changed forever in the end as the first [[Aes Sedai]] swore fealty to the [[Dragon Reborn]], prompted by both his *ta'veren* twisting of chance, and the threat of [[Mazrim Taim]] and the [[Asha'man]].
The battle began at Dumai's Wells, when the [[Shaido]] attacked the [[Tower Aes Sedai|loyalist Tower Aes Sedai's]] wagon train and escalated when Rand's forces, led by [[Perrin Aybara]], accompanied by the [[Rebel Aes Sedai|Salidar Aes Sedai]] from the Caemlyn Embassy, arrived to rescue him. [[Mazrim Taim]], acting independently of Perrin, arrived during the battle with the Asha'man via gateways; the Asha'man were responsible for breaking the ranks of Shaido attempting to reach Rand after their betrayal of the Tower Aes Sedai.

## Contents

1 Events precipitating the battle
2 Forces

2.1 Rand's kidnappers
2.2 Shaido Aiel
2.3 Rand's rescuers


3 The battle
4 Aftermath
5 Fate of the Aes Sedai

5.1 Aes Sedai that escaped
5.2 Aes Sedai that were captured by Rand's forces

5.2.1 Aes Sedai that were stilled and kept by the Wise Ones
5.2.2 Aes Sedai that were freed


5.3 Aes Sedai that were captured by the Shaido
5.4 Aes Sedai that were killed


6 Notes


## Events precipitating the battle
[[Elaida]], the [[Amyrlin Seat]], sent an emissary of Sisters to [[Rand al'Thor]] to convince him to go to the [[White Tower]] where he could be kept safe (and controlled by the Tower). When Rand proves uncooperative, the Tower Aes Sedai kidnapped him according to Elaida's secret orders. The Aes Sedai have also met and made a prior arrangement with the Shaido [[Aiel]] to escort their party to [[Tar Valon]] once Rand was in hand, but as the Aes Sedai traveled toward Tar Valon with their captive, the Shaido betrayed their agreement and instead attacked the Aes Sedai party to take Rand for themselves. It was [[Sevanna]]'s plan to marry Rand, keeping him shielded, and gain power for herself over the Aiel through him.
The Tower Aes Sedai did not depart immediately for the White Tower after the kidnapping, instead waiting several days before announcing they were fed up with Rand's delaying tactics. Not long after they left Cairhien, [[Berelain]] discovered Rand's sword and sword belt in his apartments, which he usually keeps close to him. After bringing them to [[Perrin]], they, along with [[Dobraine]] and others, realized that Rand has been kidnapped. Following this, Perrin, Dobraine, [[Rhuarc]], and [[Sorilea]] organize a small rescue party, for fear that revealing Rand's kidnapping would drive even more Aiel warriors to the [[Bleakness]].


## Forces
### Rand's kidnappers
39 [[White Tower|Tower]] [[Aes Sedai]] led by [[Galina Casban]]: 15 Reds, 12 Whites, 10 Greens, 1 Gray and 1 Brown (among them we know also the name of 4 Black Ajah sisters)
582 [[Younglings]] led by [[Gawyn Trakand]]
### Shaido Aiel
Approximately 40,000 Aiel warriors led by Sevanna
Included the Wise Ones of the Jumai Shaido who could channel (about 300).
### Rand's rescuers
About 1,000 [[Wolves|wolves]] led by [[Perrin Aybara]]
300 [[Two Rivers]] men led by [[Dannil Lewin]]
500 [[Cairhien|Cairhienin]] men led by [[Dobraine Taborwin]]
200 [[Winged Guards]] from [[Mayene]] led by [[Havien Nurelle]]
200 [[Asha'man]] led by [[Mazrim Taim]]
9 [[Salidar]] [[Aes Sedai]]
94 Aiel [[Wise Ones]] led by [[Sorilea]]
Approximately 6,000 [[Aiel]] led by [[Rhuarc]], clan chief of the [[Taardad]]
5,000 *siswai'aman*
1,000 *Far Dareis Mai*
[[Loial|Loial son of Arent son of Halan]]

## The battle
As the forces loyal to Rand caught up with the Tower Aes Sedai, they saw that the Shaido forces had surrounded the Tower Aes Sedai's wagons at Dumai's Wells and were in the process of assaulting it. An impromptu plan was devised whereby Perrin would lead the [[Two Rivers]] men, Cairhienin, Aiel spears and Winged Guards to charge down into the valley at the back of the Shaido forces coinciding with attack by wolves, their goal being to reach Rand by cutting through the Shaido despite being severely outnumbered. The rebel Aes Sedai and Wise Ones accompanying the rescue party were ordered by Perrin to stay on the ridge. But, the Aes Sedai, restricted by their Three Oaths, charged into the Shaido forces with their Warders, intentionally putting themselves in mortal peril. This allowed them to bring the One Power into use on the battlefield; additionally, they very likely wanted to reach Rand before Perrin could.
In the meantime, as the Shaido continued their assault on the Tower camp, four of the six Aes Sedai holding Rand's shield tied off their weavings so they could assist in the defense. This allowed Rand to open three of the four tied knots of his shield with the help of Lews Therin who talked to him in his mind. Despite that one sister returned, the shield was already thin enough for him to break it with brute force. Filled with the Power he stilled the three Aes Sedai with the fists of Spirit. Rand then rescued Min from the imminent danger of the fight and began to shield and incapacitate the Tower Aes Sedai one by one; as he was using *saidin* he was undetectable by the women. This confused the Tower Aes Sedai and made their situation more desperate as they struggled to hold back the Shaido from breaching their lines.


Just as Rand's rescuers are about to be overwhelmed by the Shaido forces, around two hundred Asha'man led by Mazrim Taim [[Travel]] to Dumai's Wells among the Shaido forces and immediately begin to destroy them using the One Power in an effort to reach Rand. As they did, they erected a dome of Air around the wagons to hold back the Shaido.
By this time, Perrin had also reached the wagons and appealed to Rand to lift the dome and let forces loyal to him trapped outside the dome to be let in. Instead, Rand ordered Taim to "send a message" to Sevanna. The Asha'man lifted the dome of Air and attacked using the One Power with a weave that exploded the attacking Shaido warriors' bodies by the thousands, to the horror of everyone watching, likening it to a meat grinder.

## Aftermath
After the battle, the nine Salidar Aes Sedai came over to congratulate Rand, who forced them to kneel and swear an oath of fealty to him. Though the Aes Sedai attempted to refuse, they capitulated under the influence of *ta'veren* and Taim's threat to force them to their knees, after just having seen two hundred Asha'man massacre thousands of Aiel in seconds.
The [[Younglings]], led by [[Gawyn Trakand]], regrouped some miles north of Dumai's Wells. Retreating units of Aiel engaged the Younglings as they cut their way out of the battlefield. The Younglings later rescued some surviving Tower Aes Sedai and escorted them back to the Tower.
As Rand kept counting their numbers and learning their names, it is known that exactly 151 Maidens died for Rand during the battle.

## Fate of the Aes Sedai
Only twelve Tower Aes Sedai escaped of their own accord and one was freed by outside forces. Of the remaining Aes Sedai, nineteen were captured by Rand's forces, three were killed, three were stilled by Rand's escape and kept alive by the Wise Ones, and one was captured by Shaido forces. Following are lists of the known names (with strength level).

### Aes Sedai that escaped

### Aes Sedai that were captured by Rand's forces
[[Beldeine Nyram]] (Green Ajah) 16(4)
[[Chisaine Nurbaya]] (Red Ajah)
[[Coiren Saeldain]] (Grey Ajah) 18(6)
[[Elza Penfell]] (Green/Black Ajah) 25(13)
[[Erian Boroleos]] (Green Ajah) 17(5)
[[Fera Sormen]] (White/Black Ajah) 32(21)
[[Innina Darenhold]] (Red Ajah)
[[Janine Pavlara]] (Red Ajah) 27(15)
[[Marith Riven]] (Brown Ajah) 19(7)
[[Nelavaire Demasiellin]] (Green Ajah) 28(16)
[[Nesune Bihara]] (Brown Ajah) 15(3)
[[Sarene Nemdahl]] (White Ajah) 18(6)
[[Nalaene Forrell]] (Yellow/Black Ajah)
[[Turanna Norill]] (White Ajah) 26(14)
[[Vayelle Kamsa]] (Red Ajah) 34(22)
[[Mayam Colona]] (White Ajah) 21(9)
[[Cairlyn Nesolle]] (Yellow Ajah mentioned only in TWoTC) 22(10)
[[Elaiva Walfor]] (Grey Ajah mentioned only in TWoTC) 19(7)
[[Razina Hazzan]] (Brown Ajah mentioned only in TWoTC) 28(16)

[[Irgain Fatamed]] (Green Ajah)
[[Ronaille Vevanios]] (White Ajah) 27(15)
[[Sashalle Anderly]] (Red Ajah) 14(2)

[[Katerine Alruddin]] (Red/Black Ajah) 15(3)
### Aes Sedai that were captured by the Shaido
[[Galina Casban]] (Red/Black Ajah) 14(2)
### Aes Sedai that were killed
[[Amira Moselle]] (Red Ajah) 27(15)?
[[Laigin Arnault]] (Red Ajah)
[[Mirlene Cornwell]] (Green Ajah mentioned only in TWoTC) 26(14)
## Notes






https://wot.fandom.com/wiki/Battle_of_Dumai%27s_Wells