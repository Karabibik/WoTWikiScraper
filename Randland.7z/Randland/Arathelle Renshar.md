---
tags: [Women, Andor_people, Ladies, HighSeats, LivingasofKOD, Nobility]
---


**Arathelle Renshar** is an [[Andoran]] noblewoman, and High Seat of [[House Renshar]]. The sign of House Renshar is the three Golden Hounds.

## Contents

1 Appearance
2 History
3 Activities
4 Notes


## Appearance
She has graying hair with a hard gaze. She has a creased face.

## History
Along with Lord [[Abelle Pendar]], Lord [[Pelivar Coelan]], Lady [[Ellorien Traemane]], Lady [[Aemlyn Carand]], and Lord [[Luan Norwelyn]], she supported [[Morgase Trakand]] for the [[Lion Throne]] during the Third Succession War.

## Activities
Despite her support for Morgase, she was exiled from [[Caemlyn]] along with many others major lords, while Morgase was under the influence of [[Lord Gaebril]]. As a result, Arathelle supported [[Dyelin Taravin]] for the [[Lion Throne]] for a time.
After the death of Rahvin she was invited by Rand in the Royal Palace and Lady Arathelle meets with the Dragon along many other major Lords. 
Pelivar, Arathelle and Aemlyn also led the Andorans who met with the [[Murandy|Murandian]] nobles and the [[Rebel Aes Sedai]], meeting the new [[Amyrlin Seat]].
She leaves the border of Murandy and heads near Caemlyn, where she sets up camp with Abelle, Luan, Ellorien, Aemlyn and Pelivar. There they sit to the side and stay neutral during [[Arymilla Marne]]'s siege on Caemlyn against Elayne. When Arymilla's force is defeated a message is sent to Elayne asking for safe passage in Caemlyn for the neutral High Seats. 
They meet with Elayne and Luan asks for a temporary alliance with Elayne's forces to fight against the [[Borderlands]] army in Andor. Elayne reveals she invoked her right as an Aes Sedai and allowed them safe passage across Andor into [[Murandy]] to keep looking for the [[Dragon Reborn]]. Luan and then Abelle throw their support behind House Trakand. Arathelle, Aemlyn and Pelivar also throw their support behind Elayne, but only for a speech in her favour by Dyelin. This gives Elayne the required amount of Houses to obtain the Lion Throne.

## Notes






https://wot.fandom.com/wiki/Arathelle_Renshar