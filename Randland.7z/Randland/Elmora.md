---
tags: [Towns, Tarabon]
---

**Elmora** is one of the major towns of [[Tarabon]]. It is halfway on the road between [[Tanchico]] and [[Amador]] and on a major trade route.

## Mentions
[[Rodel Ituralde]] took part in a raid at [[Serana]], a town halfway between Elmora and the border of [[Amadicia]] on the first day of his co-ordinated attack against the [[Seanchan]].






https://wot.fandom.com/wiki/Elmora