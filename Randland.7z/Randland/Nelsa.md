---
tags: [Women, Altara_people, LivingasofCOT]
---


**Nelsa** is a cloth shopkeeper's assistant, located in [[Jurador]].

## Appearance
Nelsa is a slim and pretty woman.

## Activities
When [[Matrim Cauthon]] is traveling with [[Valan Luca]]'s [[Valan Luca's Traveling Show|Traveling Show]] across [[Altara]], he takes [[Tuon Athaem Kore Paendrag]] and [[Selucia]] into Jurador to go shopping. To keep from being discovered as [[Seanchan]], Tuon and Selucia do not speak to any of the merchants in the town. When they loiter near the cloth shop too long, the owner almost sends Nelsa for the town guards before Mat steps in to appease the shop keeper.






https://wot.fandom.com/wiki/Nelsa