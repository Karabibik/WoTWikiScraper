---
tags: [Military, Andor, QueensGuards]
---

The **Queen's Guards** are responsible for the protection of the kingdom of [[Andor]], for the upholding of the queens' laws, and the keeping of the queens' peace.

## History
The Guard are commanded by the "Captain General of the Guard", however if Andor goes to war then the army and guard are led by the [[First Prince of the Sword]]. However it has been known for the queen to accompany her guards.


The uniform of the Guard includes a red undercoat, gleaming mail and plate armor, and a brilliant red cloak. Long white collars hang over the armor and white cuffs gleam at the waist. The helmet is conical with barred face guards.

### Under Elayne Trakand
[[Elayne Trakand]]'s personal bodyguard is made of almost all women, because she believes she can trust women more. The head of the Guard is currently [[Birgitte Silverbow]], Elayne's [[Warder]].

## Ranks

The ranks of the officers of the Queen's Guards are identified by the golden knots of rank on one or both shoulders of their garments and armor. The hierarchy is as follows:
**Captain-General** - Four golden knots


[[Aranvor Naldwinn]]
[[Gareth Bryne]]
[[Birgitte Silverbow]]
**Captain** - Three golden knots


[[Doilan Mellar]]
[[Captain Kindlin]]
[[Charlz Guybon]]
**Lieutenant** - Two golden knots, also referred to as "Guardsman-Lieutenant"


[[Doilan Mellar]] (promoted to Captain)
[[Charlz Guybon]] (promoted to Captain)
[[Caseille Raskovni]]
[[Martyn Tallanvor]]*
**Under-Lieutenant** - One golden knot


[[Tzigan Sokorin]]
[[Rasoria Domanche]]






https://wot.fandom.com/wiki/Queen%27s_Guard