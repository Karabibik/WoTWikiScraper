---
tags: [BlackHills, Hills, Geographicalregions]
---




The **Black Hills** is a region that lie between the [[Borderlands]] and the [[Caralain Grass]]. There is at least one village in this area, called [[Denhuir]].

## History
Three [[Ogier]] *stedding*, including [[Stedding Jentoine]], are in the Black Hills. [[Cadsuane Melaidhrin]], when she was newly raised to the [[Shawl|shawl]], went to the Black Hills. There, she received a lesson in endurance and humility from a [[Wilder|wilder]] named [[Norla]]. Cadsuane also won her various *angreal* and *ter'angreal* from Norla.

## Recent Activities
The rulers of [[Kandor]], [[Arafel]], [[Shienar]], and [[Saldaea]] met in the Black Hills to cope with [[Rand al'Thor|al'Thor]] and the chaos he is seemingly responsible for . According to [[Perrin Aybara]], a person could go for days and not see anyone else in the Black Hills and the Caralain Grass. [[Mazrim Taim]], a captured [[False Dragon]] at the time, escaped from the village of Denhuir. [[Siuan Sanche]] received a report to this effect soon after he escaped. [[Aginor]]'s persona of Corlan Dashiva is said to have grown up on a farm in the Black Hills. The Black Hills is a meeting place for the Borderlander rulers when they are on their way to "deal" with [[Rand al'Thor]].

## Notes






https://wot.fandom.com/wiki/Black_Hills