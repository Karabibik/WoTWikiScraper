---
tags: [Women, YellowAjah, AesSedai, LivingasofLOC, RebelAesSedai, HighRankingAesSedai, Channelers]
---


**Zenare Ghodar** is an [[Aes Sedai]] of the [[Yellow Ajah]].

## Contents

1 Appearance
2 Strength
3 Activities
4 Notes


## Appearance
She is plump and haughty.

## Strength
In The Wheel of Time Companion her strength is described at level 19(7), a quite high level, putting her among the influential Aes Sedai.

## Activities
She has allied herself with the [[Salidar Aes Sedai]].
She was not present when [[Nynaeve al'Meara]] [[Heal|Healed]] both [[Leane Sharif]] and [[Siuan Sanche]] from [[Stilling|stilling]] and insisted on her going through the whole process again step by step and even tries to give advice on how to improve it.

## Notes






https://wot.fandom.com/wiki/Zenare_Ghodar