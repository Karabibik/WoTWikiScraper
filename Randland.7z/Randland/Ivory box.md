---
tags: [Terangreal, ItemsofPower, EbouDariStash]
---
The **ivory box** is a *ter'angreal* that was found in the [[Kin's Storeroom]] in [[Ebou Dar]].

## Appearance
The box appears to be made of ivory and is decorated with rippling red and green stripes, with a hinged lid.

## Use
The box contains music, possibly thousands of songs, much like a music box. The method of playing the songs is still unknown.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Ivory_box