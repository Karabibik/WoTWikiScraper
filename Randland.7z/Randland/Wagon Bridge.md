---
tags: [Bridges, TwoRivers]
---
The **Wagon Bridge** is one of three bridges that span the [[Winespring Water]] in [[Emond's Field]]. Its name derives from the fact that it is the only bridge wide and stout enough to bear wagons. It crosses the stream on the east side of the village [[Green]] next to the [[Winespring Inn]].
The bridge marks the point where the [[North Road]], coming down from [[Taren Ferry]] and [[Watch Hill]], becomes the [[Old Road]] leading to [[Deven Ride]]. Although outsiders often find it odd that the continuous road through Emond's Field is named differently on either side of the Wagon Bridge, villagers accept the convention without question.

## Notes






https://wot.fandom.com/wiki/Wagon_Bridge