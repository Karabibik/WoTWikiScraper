---
tags: [Cities, Shienar]
---
**Fal Eisen** is a city-fortress in [[Shienar]].  [[Kayen Yokata]] is the [[Lord]] of Fal Eisen.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Fal_Eisen