---
tags: [Women, Cairhien_people, Bankers, LivingasofNS, TarValon_people]
---


**Ilain Dormaile** is a [[Banker|banker]] in [[Tar Valon]]. She is Cairhienin, as stated by [[Moiraine Damodred]], since the Dormaile banker family took care of her money already in Cairhien.

## Appearance
Mistress Dormaile is a slim woman with graying hair. She is [[Measurement|a hand]] shorter than Moiraine Damodred.

## History
When Moiraine Damodred is raised to the [[Shawl|shawl]], she visits Ilain Dormaile to deposit her stipend from the [[White Tower]]. Mistress Dormaile tells Moiraine of a man, [[Ries Gorthanes]], who tried prying into Moiraine's affairs. When Moiraine leaves the Tower, she goes to Ilain's bank and withdrawls gold and several letters-of-rights. One of these is then later cashed with [[Kamile Noallin]] in [[Chachin]].

## Notes






https://wot.fandom.com/wiki/Ilain_Dormaile