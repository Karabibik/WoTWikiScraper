---
tags: [Women, Andor_people, LivingasofTFOH]
---







**Maigan Nem** is a farmwife who lives in [[Kore Springs]]. She is married to [[Admer Nem|Admer]].

## Appearance
She is round-faced, but not soft.

## Activities
When [[Siuan Sanche]], [[Leane Sharif]], [[Elmindreda Farshaw|Min Farshaw]], and [[Logain Ablar]] are traveling from [[Tar Valon]] to [[Salidar]], they spend a night in the Nem barn. They are found before dawn by Admer, and in an unfortunate turn of events, the barn burns to the ground and some of the livestock are killed. Logain steals a purse and knocks Admer down before escaping, and the three women are brought to trial in town. After Admer gives his testimony—with some embellishments—Magain steps forward and heatedly tells the lord of Kore Springs, [[Gareth Bryne]], to whip the "hussies" and "ride them to [[Jornhill]] on a rail!"
When Bryne gives his decision regarding the women's punishment, he stops Admer from complaining by reminding him that Maigan has given him worse assaults than Logain had, simply for drinking too much. Both Admer and Maigan are disgruntled with the women's punishment, but accept it.
Later, when Bryne is discussing the women with his retainer, [[Caralin]], he explains that if he had made the women work for the Nems as punishment, instead of for himself, that Maigan and the other women in her family would have made the women's lives as bad as the [[Pit of Doom]]. He even implies that they would see to the women's "accidental" deaths.

## Notes






https://wot.fandom.com/wiki/Maigan_Nem