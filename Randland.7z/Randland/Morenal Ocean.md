---
tags: [Oceans]
---
The **Morenal Ocean** is the large body of water that lies to the east of [[Shara]] and to the west of [[Seanchan]]. It is smaller than the [[Aryth Ocean]], and it is unknown why the Seanchan take the considerably longer journey over the Aryth in their current attempt to conquer the [[Westlands|main landmass]]. It is also unknown if the [[Sea Folk]] have conducted explorations of this ocean.
The Morenal Ocean is depicted on the world maps in *The World of Robert Jordan's The Wheel of Time*.






https://wot.fandom.com/wiki/Morenal_Ocean