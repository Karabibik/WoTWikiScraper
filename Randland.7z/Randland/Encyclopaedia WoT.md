---
tags: [Reference]
---
The **Encyclopaedia WoT** (commonly abbreviated EWoT) is a comprehensive  to the [[The Wheel of Time|Wheel of Time]] series. It is primarily edited by Gary Kephart and Bob Kluttz. Characters, chapters, items, and places are extensively .
The last novel that was fully added to the site is [[Towers of Midnight]]. As early as 2013, a second version of the site, EWoT 2, was planned.  The books through [[The Shadow Rising]] were added to the new site that year, as were early chapters of [[The Fires of Heaven]].  During 2014 and 2015, a few early chapters of [[A Memory of Light]] were added to the original site, some of them incomplete, after which neither site was updated for over six years.
In September, 2021, work on EWoT 2 resumed; regular postings on EWoT's social media have announced progress on converting information from the old site to the new.


## External link







https://wot.fandom.com/wiki/Encyclopedia_Wheel_of_Time