---
tags: [Men, Andor_people, ChildrenoftheLight, Soldiers, LivingasofTOM, Nobility]
---


**Brandel Vordarian** is a [[Lord Captain]] in the [[Children of the Light]]. 

## Contents

1 Appearance
2 History
3 Activities
4 References


## Appearance
He is a blond hulk of a man. He is clean shaven with silver in his yellow hair.

## History
His family were minor nobles from [[Andor]].
He is the eldest of the Lords Captain that follows Galad.

## Activities
He is one of the Lord Captain's who stood against Galad. He then rises up against [[Rhadam Asunawa]] and his men. 
He later pledges his support and loyalty behind Galad, rescuing him from the hands of the Questioners.
While traveling through [[Ghealdan]], he debates with Galad about the merit of sending a letter to the White Tower to ask if the Children of the Light can become allies with the Aes Sedai.
When Galad says that monarchs distrust the Children of the Light because they follow no ruler or lord, he calls them all Darkfriends. Galad asks him if he thought Morgase (who he refers to as his mother) was a Darkfriend, to which Vordarian replies she was an exception.

## References






https://wot.fandom.com/wiki/Brandel_Vordarian