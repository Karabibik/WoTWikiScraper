---
tags: [Official]
---
**Tor.com** is the official website of the publisher of *The Wheel of Time.*

## External Links



This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Tor.com