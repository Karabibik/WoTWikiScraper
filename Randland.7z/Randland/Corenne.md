---
tags: [, OldTongue, Seanchanculture]
---
The *Corenne* (meaning "[[The Return|the Return]]" in the [[Old Tongue]]) is the name given by the [[Seanchan]] both to the fleet of thousands of ships and to hundreds of thousands of soldiers, craftsmen and others carried by those ships, who came behind the [[Forerunners]] to reclaim the lands stolen from [[Artur Hawkwing]]'s descendants. The *Corenne* is led by Captain-General [[Lunal Galgan]].
Soon after the *Hailene* came to the [[Westlands]], the nation of [[Tarabon]] was occupied. A new king swore loyalty to the Seanchan Empress in [[Seandar]]. After the conquest of Tarabon, [[Amador]] and the whole of [[Amadicia]] was occupied by the Seanchan invaders. King Ailron was killed in the [[Battle of Jeramel]].
At the same time a Seanchan invasion force landed in [[Ebou Dar]], the capital of [[Altara]]. Their march to the north was stopped by the [[Dragon Reborn]] and his [[Asha'man]] forces.

## See also
*Hailene*
*Rhyagelle*
## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Return