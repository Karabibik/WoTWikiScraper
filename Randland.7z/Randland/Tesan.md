---
tags: [Women, WhiteAjah, Tarabon_people, AesSedai, LivingasofTGS, ElaidaaRoihansWhiteTower, Channelers]
---


**Tesan** is an [[Aes Sedai]] of the [[White Ajah]]. She is an arithmetist who applies numbers to logic.

## Appearance
She has the typical beaded braids of a [[Taraboner]]. Her hair is dark and she has a narrow face.

## Activities
She has remained loyal to the [[White Tower]] during the [[White Tower Schism|Schism]].
In the White Tower, [[Alviarin Freidhen]] hears her discussing statistical methods relating to the failing of the [[Keeping|Keepings]] on the food storerooms in the Tower with [[Astrelle]].
Tesan is in [[Ferane Neheran]]'s quarters being served by [[Egwene al'Vere]] when Ferane asks her on how she would have approached the [[Dragon Reborn]]. Egwene in turn tries to encourage Ferane and Tesan to think logically and approach the other Ajahs to try and mend the cracks in the White Tower.
She escorts Egwene to the [[Hall of the Tower]] where Egwene is to be raised as the new [[Amyrlin Seat]], and brings [[Silviana Brehon]] to the Hall from the Tower dungeons.

## Notes






https://wot.fandom.com/wiki/Tesan