---
tags: [Men, Andor_people, Bouncers, LivingasofTOM, Charactersnamedafterfans]
---


**Berg** is a tavern bouncer.

## Contents

1 Appearance
2 Activities
3 Trivia
4 Notes


## Appearance
He is a man described as ugly enough "to make his own mother weep."

## Activities
Berg is the jealous bouncer at [[The Seven-Striped Lass]] tavern, and doesn't like [[Mat]] because he thinks Mat is flirtatiously eying the pretty tavernkeeper [[Melli Craeb]].

## Trivia
Berg is named for Martin Bergman, a fan of *The Wheel of Time*.
## Notes






https://wot.fandom.com/wiki/Berg