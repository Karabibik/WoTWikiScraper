---
tags: [FourthAge, Foreseenevents]
---
The **Pact of the Griffin** was an alliance of nations that existed in the [[Fourth Age]] as envisioned by [[Aviendha]]. It was comprised of [[Andor]], the [[Two Rivers]], [[Mayene]], [[Ghealdan]], and [[Saldaea]]. 
Its symbol was a creature with the head of a lion (Andor), the body of a wolf ([[Perrin Aybara]] and the Two Rivers), and the wings of a hawk (Mayene), with three stars above (Ghealdan) and three fish below (Saldaea).
Curiously in this symbol is not comprised the rising sun of [[Cairhien]] which is another kingdom expected to be part of this alliance.  This may portend that in the fourth age Cairhien is politically merged with Andor.

## Notes






https://wot.fandom.com/wiki/Pact_of_the_Griffin