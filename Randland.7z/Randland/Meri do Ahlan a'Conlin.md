---
tags: [Women, Murandy_people, Ladies, LivingasofNS, Nobility]
---






**Meri do Ahlan a'Conlin** is a [[Murandy|Murandian]] noblewoman. Her infant son's name is [[Sedrin a'Conlin|Sedrin]].

## Appearance
She is a rather plump noble woman.

## Activities
She is one of the women waiting in line when [[Moiraine]] and [[Siuan]] are taking information of people who have given birth around [[Dragonmount]] near the end of the [[Aiel War]]. Lady Meri claims she is the direct descendent of [[Katrine do Catalan a'Coralle]], the first queen of Murandy.

## Notes






https://wot.fandom.com/wiki/Meri_do_Ahlan_a%27Conlin