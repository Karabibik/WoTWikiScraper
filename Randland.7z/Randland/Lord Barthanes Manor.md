---
tags: [CairhienAcademy, Othernotablebuildings, Buildings, Cairhien]
---
This **Manor House** was a property of Lord [[Barthanes Damodred]]; it was built just outside the walls of Cairhien; inside of it took refuge [[Padan Fain]] after he stole the [[Horn of Valere]] from [[Rand]]'s Inn inside the city. There Rand, [[Perrin]], [[Mat]], [[Verin]] and others followed the track of Fain to a [[Waygate]].

After the death of Lord Barthanes the building was transformed by Rand to the seat of the [[School of Cairhien]], an academy open to innovations.

## Notes






https://wot.fandom.com/wiki/Lord_Barthanes_Manor