---
tags: [Kinswomen]
---
The **Knitting Circle** is the group of thirteen women who lead [[Kin|The Kin]], a group mostly formed by [[White Tower]] initiates who failed to achieve the rank of [[Aes Sedai]].

## Structure and function
Unlike [[Aes Sedai]], whose rank depends primarily, but not exclusively, on strength in *saidar*, the Kin choose their Knitting Circle based solely on age. The thirteen oldest Kinswomen in [[Ebou Dar]] comprise the Circle, which is led by the Eldest.
In order to maintain their secrecy, the Knitting Circle nears fanaticism in enforcing their rules. The women of The Kin lead *very* long lives as do Aes Sedai, and in many cases even longer than Aes Sedai, making the thirteen of the Knitting Circle some of the oldest women alive. They carefully rotate women out of [[Ebou Dar|Ebou Dari]] society on a strict schedule to avoid people noticing their longevity.
The leadership also makes sure there are enough women of "suitable age" (above three hundred) in Ebou Dar at all times. Women under three hundred were very rare in the Circle. 
If a woman older than a member of the Knitting Cirlce ever visited Ebou Dar, she would assume a seat during her visit. Even the Eldest could be displaced in this manner. 
The Eldest was, in many ways, absolute ruler; but she could also be called down for an offense. This is because of the Rule - all Kin must obey the Rule, and the Rule cannot be changed. 

## Recent activities
The discovery of the Kin and the advanced ages of some of them caused consternation and disbelief among the Aes Sedai. It is now known that the Aes Sedai tradition of swearing on the [[Oath Rod]] is the cause of their comparatively short lifespans.
[[Elayne]], [[Nynaeve al'Meara|Nynaeve]], [[Aviendha]], and [[Birgitte Silverbow|Birgitte]] ask the Knitting Circle to help them locate the [[Bowl of the Winds]], which will supposedly counteract the Dark One's touch on the world, reverting the seasons back to normal conditions. The Kinswomen agree.
After fleeing Ebou Dar and the Seanchan invasion, technically the Knitting Circle were no longer the Circle because they were outside Ebou Dar. However, because they were still the eldest Kin present, they would continue acting as the Kin's leadership.

## Members
Members of the Knitting Circle with their strength level and in order by **age** (when known). Also includes the reasons for being put out of the Tower (are indicated also those below the minimum level to test for Aes Sedai 45(33)).







https://wot.fandom.com/wiki/Eldest