---
tags: [Women, Andor_people, TwoRivers_people, Healers, Wisdom, Deceased, WomensCircle]
---




**Doral Barran** was the [[Wisdom]] of [[Emond's Field]] in 989 NE.

## Contents

1 Appearance and Abilities
2 History
3 Legacy
4 External links
5 Notes


## Appearance and Abilities
In 989 NE Doral was the oldest woman in Emond's Field, and possibly the oldest person living in the [[Two Rivers]] at that time. Her hair was white; certainly braided in the Two Rivers custom.  Though her body was quite frail from age she did not walk stooped. She was clear eyed with a sharp-tongue ready for anyone who deserved stern feedback.  It is probable that she was a [[Wilder]] who could [[Talent|Listen to the Wind]], and she once told [[El'Nynaeve ti al'Meara Mandragoran|Nynaeve al'Meara]] that she would be one of the best at it.  Her ability to know this indicates that she intuitively sensed Nynaeve's strength in the power; something that only a fellow [[Channeler]] could do.  It is also likely that her extremely long life was a result of her ability to channel.

## History
Knowledge of Doral's history was quite forgotten by the community living in Emond's Field in 989 NE, owning to the fact that she had outlived all villagers who remembered her youth.  To local residents, she had been the Wisdom of the village for as long as anyone could recall.
Before teaching Nynaeve, Doral had been training an earlier student.  This young woman died of [[Channeling sickness]] when Nynaeve was still playing with dolls.  In 988 NE, Nynaeve was orphaned at the age of fourteen, and Mistress Barran took her on as an apprentice.  Doral did this despite the fact that many people thought she should have sent Nynaeve to her relatives in the country and taken on someone older.  She taught Nynaeve everything she knew; from how to staunch a wound with a bread-poultice, to how to dispense discipline - such as when she once switched [[Matrim Cauthon|Mat Cauthon]] for peeling open an [[Illuminator|Illuminator's]] firework.  Doral often praised Nynaeve publicly for being a quick learner while displaying a critical atmosphere privately of her work.  She also taught Nynaeve herblore and how to sense the changing seasons.  Doral was known for taking quick action when odd ailments struck the village, such as when spotted fever struck Emond's Field and she told people to cover their mouths and noses with handkerchiefs soaked in brandy to stave off the disease.
Doral passed away sometime before 998 NE.  Her manner of death is unknown, though it is likely that she died of natural causes brought about by extreme old age.  Nynaeve al'Meara succeeded her as the Wisdom of the village.    

## Legacy
*"Mistress Barran taught me well."*
   —Nynaeve al'Meara 
Doral Barran was a highly influential member of the Emond's Field community for several decades.  She was well known for her sharp tongue and her unwillingness to suffer fools or foolish behavior.  Her stern outlook lives on most strongly in Nynaeve al'Meara's aggressive personality; a trait she picked up during her apprenticeship.  Doral's knowledge and experience has also been invaluable in strengthening the [[Women's Circle]] of Emond's Field.  

## External links
 
## Notes






https://wot.fandom.com/wiki/Doral_Barran