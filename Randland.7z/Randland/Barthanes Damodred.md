---
tags: [Men, Cairhien_people, Darkfriends, Lords, Deceased, HighSeats, Nobility]
---


**Barthanes Damodred** was [[High Seat]] of [[House Damodred]] and was cousin to [[Laman Damodred]].

## Appearance
He was slim and handsome and tall for a [[Cairhienin]]. He had black eyes and slightly greying hair.

## Activities
Barthanes invites Rand to one of his parties and tries to find out where Rand's loyalties lie and if he supports King [[Galldrian Riatin]] and his project of digging up the male [[Choedan Kal]]. He had a waygate within his estate. He was a [[Darkfriend]] and passes a message from [[Padan Fain]] to [[Rand]] about meeting each other on [[Toman Head]]. He was found torn to pieces in his bedroom after the party at his house, presumably by the then unnamed *gholam*.


## Notes






https://wot.fandom.com/wiki/Barthanes