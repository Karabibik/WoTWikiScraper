---
tags: [Men, Murandy_people, Mercenaries, Deceased]
---


**Rhys a'Balaman** was a [[Murandy|Murandian]] mercenary.

## Appearance
He had a lean face with gray-streaked mustaches waxed to spikes. His eyes were like stones and he had a thin-lipped smile that always seemed a leer.

## History
His name, a'Balaman, was that of a Murandian noble, yet [[Elayne Trakand]] thought that this was not his real name.
He fought alongside [[Aldin Miheres]], a mercenary employed by [[Arymilla Marne]] to attack the walls of Caemlyn, yet accounted him an acquaintance more than friend, having fought just as many times against him.
He adhered to a particular mercenary code of honor which meant that allowing another mercenary to flee the battlefield meant that he might return the favor another day. In his opinion, fleeing troops were out of the battle.

## Activities
He was employed by Elayne to defend [[Caemlyn]]. He said he would much rather earn gold defending a city than attacking it. 
He defended the city against mercenary forces led by Aldin Miheres, who was employed by Arymilla.
[[Reene Harfor]] reported that he had been approached by agents of Arymilla about switching sides. 
Later, he, [[Aldred Gomaisen]], and [[Evard Cordwyn]] turned coat and attacked the [[Far Madding]] gate. Elayne then signed his death warrant.







https://wot.fandom.com/wiki/Rhys_a%27Balaman