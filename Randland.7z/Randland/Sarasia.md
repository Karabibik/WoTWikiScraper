---
tags: [Women, Kinswomen, LivingasofTOM, FarmGroup, Channelers, Novices]
---


**Sarasia** is a [[Kin|Kinswoman]].

## Appearance
She is plump, with a grandmotherly air.

## Activities
Sarasia, with the assistance of three other Kinswomen, creates a [[Gateway|gateway]] into [[Cairhien]] for [[Elayne Trakand]].






https://wot.fandom.com/wiki/Sarasia