---
tags: [Andor, Villages]
---


**Comfrey** is a small village north of [[Baerlon]], in [[Andor]].
When [[Matrim Cauthon]] delivers [[Elayne Trakand]]'s letter to [[Morgase Trakand]], he does so under the alias of "Thom Grinwell," claiming to be from Comfrey.

## Notes






https://wot.fandom.com/wiki/Comfrey