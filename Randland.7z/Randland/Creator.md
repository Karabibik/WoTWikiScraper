---
tags: [Concepts, Extradimensionalentities]
---
*"The Creator had made the world and then left humankind to make of it what they would, a heaven or the Pit of Doom by their choosing, The Creator had made many worlds, watched each flower and die, and gone on to make endless worlds beyond. A gardener did not weep for each blossom that fell."* 

The **Creator** is the name given to the entity who created the universe, the [[Wheel of Time]] and reality itself. It is unclear if The Creator also created the [[Dark One]]; it is suggested that The Creator imprisoned the Dark One, its antithesis, at the moment of [[Creation]], very probably in order to give his creations free will without allowing the Dark One to directly influence anything in the Pattern.
Virtually nothing is known of The Creator. He is not worshiped as a god in the traditional sense, although his name and the term "the [[Light]]" appear to be interchangeable. By the [[Third Age]] it is common knowledge that The Creator will not directly intervene in the affairs of humankind. Consequently, there are no organized religious bodies that have anything to do with him, with the strange exception of the [[Children of the Light]].
Despite his lack of a presence in the Pattern, he may have spoken to Rand al"Thor twice in the series. The first time is after Rand has first learned to channel after killing Aginor at the Eye of the World. In this instance, the voice remarked that it would not interfere, and that only Rand could undertake the struggle to help humankind. The second occurred immediately before Rand went to confront the Dark One at the Last Battle, when Rand was doubting whether or not he had prepared carefully enough for his confrontation with the Dark One. As Rand is about to step into the Pit of Doom, the same voice (as confirmed by Rand's thoughts) spoke aloud that the time for Rand to confront the Dark One was ripe. 
Interestingly, Rand hypothesized at one point that if the Dark One did break free of its prison then only that one world would be affected, not all of time and space (in contradiction of other prophecies). He suggested that The Creator had created many worlds as a gardener had grown many grapes on a vine, and if one of the grapes shriveled and died, then the gardener would be regretful but would move on. [[Lews Therin Telamon]], or at least the voice representing his personality within Rand's mind, seemed to agree with this conclusion.

## Fan Theories:
A running joke among fans is the idea that [[Bela]] is The Creator in disguise. The reason is because Bela appears more than any character but the central ones, along with the fact that she has gone into several battles and other hostilities and always come back into the story.

## External links
 
## Notes






https://wot.fandom.com/wiki/Creator