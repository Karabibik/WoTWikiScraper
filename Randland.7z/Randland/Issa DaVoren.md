---
tags: [Women, AlmothPlain_people, Living, CharactersonlymentionedintheRPG]
---


**Issa DaVoren** is a girl from [[Aturo's Orchard]].

## History
Issa is the daughter of the farmer couple [[Fenton DaVoren|Fenton]] and [[Annabelle DaVoren]], and she has a brother named [[Tobias DaVoren|Tobias]].
His town is attacked by [[Whitecloaks]], and the farm is left in ruin. Issa is separated from her family, and is terrified of the attackers. She is eventually taken to her uncle [[Hobbs DaVoren|Hobbs]], the owner of the [[Three Crowns Inn]].


## Notes






https://wot.fandom.com/wiki/Issa_DaVoren