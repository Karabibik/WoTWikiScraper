---
tags: [, Seanchancontinent]
---
**Dalenshar** is an area on the [[Seanchan]] [[Seanchan (continent)|continent]].
[[Kennar Miraj]] has troops that come from Dalenshar. People from Dalenshar, including [[Gamel Loune]] have black skin and a distinctive accent.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Dalenshar