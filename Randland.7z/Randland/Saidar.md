---
tags: [OnePower]
---
*Saidar* (pronounced: sah-ih-DAHR) is the female half of the [[One Power]]. Unlike the more violent *saidin*, *saidar* is said to be a "river of Power" which must be surrendered to or "embraced" in order to gain control.

## Contents

1 Characteristics
2 Groups that channel saidar
3 Saidar Strength Ranking
4 See Also
5 Notes


## Characteristics

Female channelers can tell when other women are touching the Source; a white glowing  appears around their body, only visible to those trained to touch *saidar*. The ability can also be sensed in any woman capable of channeling, be they [[Wilder|wilders]] or [[Aes Sedai]]. In the testing to see if you can channel, a woman channels a simple weave and waits. Within five minutes if a woman has the [[Spark|spark]], the woman tries to channel the flow, and the test is confirmed. It takes longer for those who only can learn. However, a woman who has the spark can be detected by another female channeler without being tested.
*Saidar* is described as gentle, but infinitely powerful; a force which will do what you wish it to, but requires patience and submission to properly channel it. Surrender is necessary to gain it, and women universally speak of it as "embracing" the Power. Weaving for a female channeller is described as "guiding" the Power to perform the desired task. By contrast *saidin *is often described as a "raging torrent" that must be "seized" and controlled in order to force it to submit. Because of this fundamental difference in channeling the Power, a man can never teach a woman to channel, and vice versa.
There is almost no way for a woman to tell when a man is channeling, though the residues of his channeling can be detected using an appropriate weave. [[Lanfear]] shows the ability to sense male channeling up to the extent of knowing where the weaves go when fighting with [[Rand al'Thor]] by means remaining unknown. Recently an active method was discovered to discern whether or not a man was channeling or holding *saidin*, but this is not widely known.
A woman repeatedly channeling *saidar* over a longer time starts to "slow," meaning that she does not age in the same way as a woman without the ability. This also gives the woman a longer life and some have been known to live over four hundred years.
An exception from slowing are the Aes Sedai, who bind themselves using the [[Oath Rod]], which gives them an ageless face instead of slowing the aging. The Oath Rod is also suspected to shorten an Aes Sedai's life by hundreds of years, though after being [[Severing|stilled]], the former Aes Sedai returns to the same young appearance as she would have if she never had taken the oaths.
Another blessing received by channeling *saidar* is that a pregnant woman will not be sick due to her pregnancy. However, her ability to channel will be harder to control over time and the woman will feel as if her weavings are slippery and oily – fading away as she tries to make a weave.

## Groups that channel *saidar*
[[Aes Sedai]]
Some Aiel [[Wise One|Wise Ones]]
The [[Kin]]
Sea Folk [[Windfinder|Windfinders]]
Seanchan *damane*
The [[Shara|Sharan]] [[Ayyad]]
Female [[Forsaken]]
## *Saidar* Strength Ranking
Initially Robert Jordan said that he knows the relative strength of every female channeller in the books imposed on a 21 level scale.
*I have said that in my notes I have such a scale that I use to keep track of everyone, but its main use is for the lesser characters, in particular Aes Sedai, so that I can check on who should defer to whom, who should only listen a little more attentively to whom, and so forth.*
Later this scale was expanded two times. The first was a new scale of levels between 1 and 60. Later again he added 12 levels above the former 60 levels scale.
In his notes Jordan explained that on the 60 level scale the Aes Sedai were comprised between level 1 (the level of [[Elaida]], [[Romanda]] [[Lelaine]], [[Moiraine]], [[Siuan]], the strongest living Aes Sedai at that moment, because Cadsuane was believed dead) and 33 (that of [[Daigian]], the weakest living Aes Sedai); between 33 and 60 were comprised the female channellers too weak to be tested for the shawl. The arriving in the Tower of Nynaeve, Elayne, Egwene, and the return of Cadsuane needed a scale to classify better the stronger channellers above the level 1. So the 60 levels became 72, and the former level 1 became the level 13(1). The new first level, the level of [[Lanfear]], was indicate as 1(+12). For instance that of Cyndane 2(+11), Nynaeve 3(+10), Moghedien 4(+9), Elayne 8(+5), Nicola 9(+4), Meilyn 11(+2). This is the classification that we can find in the "The Wheel of Time Companion".
But the levels of strength given by "The Wheel of Time Companion" have to be taken very cautiously. In too many cases they are completely in contradiction to the descriptions of strength that we can find in the main WoT books. For instance the positions of [[Cadsuane]], [[Aviendha]], [[Graendal]], [[Semirhage]], [[Mesaana]], [[Viendre]], [[Kwamesa]], and others are totally wrong; also too many Sitters in the Hall are classified in low levels, among Aes Sedai described in the books having an average strength.
*Saidar* Strenght Ranking Table (this is the first 21 table used by the author that later was expanded to a scale of 60 level and again to one with 72 levels, but the last one is with some contradictions and in need of clarification. In **bold** it is signed the position of every channeler that we are sure about their strength when compared to others or we have a very good approximation).

|**Rank**|**Aes Sedai, Accepted, Novices**|**Forsaken**|**Wise Ones**|**Windfinders**|**Kinswomen**|**Damane**|
|-|-|
|1|-|**Lanfear**|-|-|-|[[Alivia]] (maximum)|
|2|-|**Cyndane**|-|-|-|[[Alivia]] (min.)|
|3|**Sharina**|**Graendal**|-|-|-|-|
|4|**Nynaeve**|**Semirhage**|[[Someryn]]|**Talaan**|-|-|
|5|-|[[Mesaana]] (min.), **Moghedien**|**Tamela**, **Viendre**|-|-|-|
|6|**Egwene**, **Elayne**|-|**Aviendha**|**Metarra**|-|-|
|7|**Cadsuane**, **Bode**, **Nicola**|-|[[Therava]]|-|-|-|
|8|**Kerene, Meilyn,** [[Nissa]]|-|-|-|-|-|
|9|**Elaida**, [[Elle]], [[Jancy Torfinn|Jancy]], **Lelaine, Moiraine** (old), **Romanda, Siuan** (old)|-|[[Amys]] (max.)|**Rainyn**|**Garenia/Zarya**|[[Sera]]|
|10|[[Aisha Raveneos|Aisha]], **Cetalia**, [[Katerine]], **Larelle, Leane** (old), [[Ludice Daneen|Ludice]], **Merean**, [[Merise]], **Pevara, Saerin, Sheriam, Theodrin**, [[Valera Gorovni|Valera]], [[Yukiri]]|-|[[Amys]] (min.), [[Edarra]], [[Mora (Wise One)|Mora]]|-|**Kirstian, Reanne**|[[Charral]]|
|11|**Anaiya, Bera, Beonin**, [[Berisha]], **Carlinya**, [[Coiren]], [[Desandre]], **Faolain**, [[Felaana Bevaine|Felaana]], [[Galina]], [[Joline]], [[Kiruna]], **Kwamesa**, [[Lemai]], **Maigan**, [[Marith]], **Morvrin, Myrelle**, **Nesune**, [[Nisao Dachen|Nisao]], [[Sierin Vayu|Sierin]], [[Silviana]], **Talene**, [[Tamra]], [[Tarna]], **Teslyn**|-|[[Leyn]], [[Melaine]], [[Surandha]]|**Caire, Tebreille**|-|[[Dali]], [[Dani]]|
|12|[[Adelorna]], [[Aledrin]], [[Alviarin]], [[Amira Moselle|Amira]], [[Andaya]], [[Anlee]], [[Barasine]], [[Berana]], [[Danelle]], [[Delana]], **Doesine**, [[Duhara]], [[Eadyth]], [[Erian]], [[Escaralde]], [[Evanellein]], [[Faiselle]], [[Farnah]], **Faeldrin**, [[Ferane]], **Gabrelle**, [[Gitara]], [[Juilaine Madome|Juilaine]], [[Javindhra]], [[Janya]], [[Jesse Bilal|Jesse]], **Liandrin**, [[Lirene Doirellin|Lirene]], [[Lyrelle]], [[Magla]], [[Malind]], **Masuri**, [[Moria]], [[Naorisa Cambral|Naorisa]], [[Raechin Connoral|Raechin]], **Rafela**, [[Rina]], [[Rosil]], [[Rubinde]], [[Salita]], [[Samalin]], **Sarene**, [[Saroiya]], [[Sashalle]], **Seaine**, [[Sedore]], [[Serancha Colvine|Serancha]], [[Shemerin]], [[Shevan]], [[Suana Dragand|Suana]], [[Takima]], [[Tiana]], **Toveine**, [[Tsutama Rath|Tsutama]], [[Varilin]], [[Velina]], [[Viria Connoral|Viria]]|-|[[Alarys]], [[Belinde]], [[Dorailla]], [[Meira]], [[Modarra]], [[Rhiale]], [[Tion]] (minimum for all of them)|**Shalon**|[[Sumeko]]|[[Lidya]]|
|13|**Alanna**, [[Annoura]] (min.), [[Covarla]], **Eldrith**, **Falion, Ispan**, [[Meidani]] (min.), [[Merana]], [[Narenwin Barda|Narenwin]], [[Nesita]] (min.), [[Nimri]] (min.), **Seonid**, [[Serinia]], **Verin**|-|-|[[Chanelle]], [[Dorile din Eiran Long Feather|Dorile]], [[Kurin]], [[Renaile din Calon Blue Star|Renaile]], [[Senine]], [[Shielyn din Sabura Night Waters|Shielyn]] (min. for all of them)|[[Julanya Fote|Julanya]], [[Keraille Surtovni|Keraille]], [[Sabeine Ocalin|Sabeine]], two between [[Kema]], [[Nashia]] and [[Sarasia]] (minimum)|[[Mika]] (minimum)|
|14|[[Aeldene]], **Asne**, **Chesmal**, [[Demira Eriff|Demira]], [[Edesina Azzedin|Edesina]], [[Elza]], [[Lusonia Cole|Lusonia]], **Marillin**, **Merilille**|-|[[Tialin]]|-|-|[[Mylen]], [[Pura]]|
|15|**Adeleas**, [[Akarrin]], **Kairen, Sareitha**, [[Temaile]], **Therva**, [[Turanna]], [[Valinde Nathenos|Valinde]], **Vandene**, [[Vasha]] (minimum), [[Zerah Dacan|Zerah]]|-|[[Micara]]|-|-|[[Guisin]]|
|16|[[Aiden]], **Berenicia, Cabriana, Careane, Kumira, Leane** (new), [[Hattori]] (maximum), [[Jamilila Norsish|Jamilila]], [[Nalasia Merhan|Nalasia]], **Nisain, **[[Phaedrine]], [[Shemari]], **Siuan** (new), [[Teramina]], [[Zemaille]]|-|-|-|[[Berowin]]|-|
|17|**Adine, Daigian, Elin, Reiko, Shana**|-|**Monaelle**|-|[[Derys Nermala|Derys]]|-|
|18|-|-|**Daviena, Losaine**|-|**Sarainya**|-|
|19|**Moiraine** (new)|-|**Sorilea**|-|**Asra, Jesamyn**|-|
|20|**Setsuko**|-|-|-|**Alise, Caiden, Kumiko**|-|
|21|**Morgase**|-|-|-|-|-|

## See Also
[[Channeler|Channelers]]
*saidin*
## Notes






https://wot.fandom.com/wiki/Saidar