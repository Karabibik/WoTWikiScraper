---
tags: [Concepts, Constructs, AgeofLegends]
---
During the [[Age of Legends]], many different types of life were created using the [[One Power|Power]] and technology. The creation of such **constructs** was overseen by a strict code of ethics, which made genetic alteration on living creatures above the level of plants illegal. For some unknown reason, most constructs are incapable of passing through gateways, making weaves such as [[Deathgates]] viable.

## Contents

1 Known constructs

1.1 Shadowspawn
1.2 Nym
1.3 Chora trees
1.4 Notes





## Shadowspawn

[[Shadowspawn]] were originally created in the [[Age of Legends]] by the Forsaken [[Aginor]]. A leading geneticist, Aginor went to the [[Shadow]] because he wished to experiment outside the code of ethics - though the promise of immortality was also part of the reason - and the resulting creatures were dubbed Shadowspawn. Those marked as [[Chosen]] were to be obeyed absolutely by all Shadowspawn.

## Nym
The [[Nym]] are constructs of Aes Sedai from the Age of Legends, with the ability to use the One Power for the benefit of agriculture. They looked like humanoid plant creatures with hazelnuts  for eyes and shoots for hair. They tended the massive farms and gardens of the Age of Legends and worked alongside the [[Ogier]] and the [[Da'shain Aiel]] during Seed Singing. Proportionally, they were as much taller to Ogier as Ogier were to men. 
It was said that a Nym would not die as long as plants grew and that “Where a Nym touched, all manner of green and growing things thrived”. Most of the Nym were killed during the War of the Shadow. [[Someshta]] was one of the last of the Nym, given the task to watch the [[Eye of the World]] by ancient Aes Sedai. When he died, he took [[Balthamel]] with him and made an oak tree growing from his grave.  
The head of a Nym remained alive in a cave in [[Shara]], but it was killed by [[Demandred]] when he was searching for the last piece of the[[Sakarnen| sa'angreal Sakarnen]]. 

## Chora trees

Chora trees lined the streets of the cities of the [[Age of Legends]]. They are distinguished by their tri-foil leaves and the feeling of contentment a person gets when under one's branches. All chora trees except one were destroyed during the Breaking of the World, and that one was planted in the center of [[Rhuidean]]. The tree was known to the rest of the world as *Avendesora*, and the [[Aiel]] seemingly knew how to tend it. [[Avendoraldera]] was a cutting from *Avendesora*, given to the [[Cairhien|Cairhienin]] as repayment for the gift of water to the [[Aiel]] clans. It represented the promise of free travel through the [[Aiel Waste]] to the lands of [[Shara]]. It was destroyed in the event known as [[Laman's Pride]], when he cut down the tree to make himself a throne (see the [[Aiel War]]).
There were rumors that the nation of [[Almoth Plain|Almoth]] also possessed a living sapling of Avendesora, or at least a branch, but have so far been unsubstantiated.
The keys to opening a [[Waygate]] are also in the shape of a chora leaf.


## Notes






https://wot.fandom.com/wiki/Nym