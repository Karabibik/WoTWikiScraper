---
tags: [Women, Amadicia_people, Innkeepers, LivingasofTFOH, ]
---



Mistress **Alfara** was the innkeeper of the [[Bellon Ford Inn]] in the town of [[Bellon]].

## Activities
When [[Elayne]] arrives with [[Nynaeve]] in the role of ladies maid, Mistress Alfara takes advantage by giving Nynaeve all the duties her staff might have performed.

## Notes






https://wot.fandom.com/wiki/Alfara