---
tags: [Inns, Kandor]
---
**The Ruffled Goose** is an inn located in the [[Kandor|Kandori]] capital of [[Chachin]]. It is located within the first ringwall of the city in a disreputable, run-down district.
[[Moiraine Damodred]] visited the inn in 979 NE, whilst trying to find [[Siuan Sanche]] for an arranged rendezvous. Her horse, Arrow, was almost stolen whilst she was inside.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Ruffled_Goose