---
tags: [Imagesbyartist]
---
Images created by Todd Lockwood, an artist for the ebooks.






https://wot.fandom.com/wiki/Todd_Lockwood