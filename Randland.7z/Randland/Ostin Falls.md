---
tags: [Towns, AlmothPlain]
---
**Ostin Falls** is a trading town on the border of [[Toman Head]] and [[Almoth Plain]]. It is a fairly large town, with a population of roughly five hundred people. Its mayor is [[Bretton Kilvar]].

## History and geography
Trading is the town's lifeblood, since it often serves as a way station for caravans heading to and from [[Falme]], [[Bandar Eban]], [[Tanchico]], and even [[Katar]].
The community suffered badly when the new outbreak of hostilities between [[Tarabon]] and [[Arad Doman]] greatly reduced the number of caravans heading north and south along the trade road, and merchants from [[Falme]] stopped coming in too after the [[Seanchan]] occupation of the city. The citizens of Ostin Falls began to hear rumors of other local villages being attacked and destroyed. 
The Kilvar family had ruled Ostin Falls since around 948 NE, and did not want the town to be destroyed, nor face the prospect of a failing economy, and thus arranged a marriage between their son [[Lorwyn Kilvar]] and Lady [[Meka Antos]] of Bandar Eban. As he did not desire the arranged marriage, Lorwyn instead left to see what events were transpiring on Toman Head.

## Locations
[[Sean's Tale]]
## Notes






https://wot.fandom.com/wiki/Ostin_Falls