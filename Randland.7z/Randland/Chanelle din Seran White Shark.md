---
tags: [Women, AthaanMiere_people, Windfinders, LivingasofKOD, FarmGroup, Channelers]
---







**Chanelle din Seran White Shark** is an *Atha'an Miere* [[Windfinder]].

## Appearance
She has an angular face and big, hard eyes. She is lean and dark.

## Strengths
Her Saidar strength is 19(7), which is equal to many high-ranking Aes Sedai. Her honor-chain carried nearly as many medallions as [[Zaida din Parede Blackwing|Zaida's]] did.
She was Windfinder to a Sailmistress who was one of the First Twelve.

## Activities
She is one of the Windfinders to accompany [[Elayne Trakand]] from [[Ebou Dar]] to [[Caemlyn]]. She is with [[Zaida din Parede Blackwing]], when she makes a new bargain with Elayne. When Zaida leaves for [[Illian]], following the bargain just signed she leaves Chanelle behind in Caemlyn to be in charge of the five remaining Sea Folk Windfinders: [[Kurin]], [[Rainyn]], [[Renaile]], [[Rysael]] and [[Senine]]. 
She begins to demand Elayne about finding [[Merilille Ceandevin]] and [[Talaan din Gelyn]]. Elayne gives her permission to search the [[Silver Swan]] where other [[Aes Sedai]] have been sighted at.
When Elayne is captured by the [[Black Ajah]], [[Birgitte Silverbow]] manages to convince Chanelle and the rest of the Sea Folk Windfinders that without Elayne there is no bargain. They [[Travel]] to the area where the Black Ajah are riding a wagon with Elayne inside. The strike force ride towards the wagon, but are decimated by [[Balefire]] from [[Asne Zeramene]]. Birgitte finally convinces the Windfinders to actively attack the Black Ajah. The Windfinders all link with Chanelle in control and attack the wagon with lightning, killing Asne in the process. They shield all the remaining Black Ajah members so they can be taken captive by Elayne's troops.






https://wot.fandom.com/wiki/Chanelle