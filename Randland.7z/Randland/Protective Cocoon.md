---
tags: [Weaves]
---
The **Protective Cocoon** is a weave in the [[One Power]]. It is formed using flows of Air Fire and Earth to protect the person inside the cocoon. It can repel any kind of harmful One Power attack apart the Balefire. But it has a disadvantage: inside the cocoon the fresh air is consumed very fast so it can be used only for a very short time.
Rand used this weave in the Sun Palace in Cairhien to protect himself after the attack from some renegade Asha'man.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Protective_Cocoon