---
tags: [Men, Tear_people, Innkeepers, LivingasofTDR, ]
---


**Cavan Lopar** is [[Innkeeper|innkeeper]] of [[The White Crescent]] in [[Tear]].

## Appearance
He is rotund. His girth made his long blue coat fit snugly below the waist as well as above. His baggy breeches, tied at the ankle above low shoes, were big enough for two ordinary men to fit inside, one in each leg. He has a fat forehead and multiple chins.

## Activites
He is happy to see [[Mat]]'s silver and even happier with [[Thom]]'s offer to perform for a small fee some nights. Mat and Thom stay at his inn whilst looking for [[Egwene]], [[Elayne]] and [[Nynaeve]] who are being chased by the [[Darkfriend]] [[Comar]].
Lopar gives Mat directions to the [[Wise Woman]] [[Ailhuin Guenna|Mother Guenna]] for Thom's cough.


## Notes






https://wot.fandom.com/wiki/Cavan_Lopar