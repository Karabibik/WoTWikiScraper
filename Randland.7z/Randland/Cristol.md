---
tags: [Men, Essenia_people, Lords, Deceased, Historicalpeople, Nobility]
---


**Cristol** was a First Lord of [[Essenia]].

## History
In [[209 AB]], First Lord Cristol signed the [[Compact of the Ten Nations]] on behalf of Essenia.

## Notes






https://wot.fandom.com/wiki/Cristol