---
tags: [, Titles, Seanchanculture]
---



**Daughter of the Nine Moons** is a title in the [[Seanchan]] empire. The title is held by the current heir to the [[Crystal Throne]]. The title was most held by [[Tuon Athaem Kore Paendrag]] and upon her ascension to [[Empress]], the title became vacant. It can be assumed that if a man was heir, the title would be changed to "Son of the Nine Moons." Matrim Cauthon is supposed to marry the Daughter of the Nine Moons, he finds out, visiting in the world of Eelfinn through the twisted red doorframe under the [[Stone of Tear]] (TSR 15)
After the mourning period that follows the death of an Empress, the Daughter of the Nine Moons must state "I am the Empress" to be recognized as the successor to the [[Crystal Throne]]. She is then crowned in the imperial capital, and is given the opportunity to execute any who she believes has barred her ascent to the throne with her own hand.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Daughter_of_the_Nine_Moons