---
tags: [Women, AthaanMiere_people, Windfinders, LivingasofCOT, Channelers]
---






**Dorile din Eiran Long Feather** is a [[Sea Folk]] [[Windfinder]] on *Windrunner*. 

## Appearance
She is slender and handsome. She has four rings in each ear, with one of them being connected to her nose and only a few medallions along this chain.

## Activities
She is present when [[Nynaeve al'Meara]] and [[Elayne Trakand]] come aboard *Windrunner* and when they bargain with [[Nesta din Reas Two Moons]] over the [[Bowl of the Winds]].






https://wot.fandom.com/wiki/Dorile_din_Eiran_Long_Feather