---
tags: [Women, BrownAjah, RebelAesSedai, AesSedai, Deceased, MiddleRankingAesSedai, FarmGroup, Borderlands_people, Channelers]
---


**Adeleas Namelle** was an [[Aes Sedai]] of the [[Brown Ajah]]. She was [[Vandene Namelle|Vandene's]] older sister.


## Contents

1 Appearance
2 Strength and Abilities
3 History
4 Activities
5 Errata
6 Notes


## Appearance
She was slender and white-haired. She wore her hair at the back of her neck.
Many people had difficulty telling Adeleas and Vandene apart, even though they were from different [[Ajahs]]. They did not understand how people could make this mistake. Mat thinks that two were so alike the may as well be twins.

## Strength and Abilities
She has a strength in the One Power of 23(11), the same as that of her sister. Vandene actually has a higher potential strength, but never reached it. Adeleas is not strong enough to [[Travel]].

## History
Adeleas was born in 735 NE, two years before her sister Vandene.
She went to the [[White Tower]] with her sister in 752 NE.
After spending five years as [[Novice|novice]] and five as [[Accepted]] she was raised to the shawl in the year 762 NE.  She progressed in near lockstep with her sister and they were raised within a month of each other in both instances.
In the year 930 NE, around seventy years prior to the split of the [[White Tower]], the sisters retired to [[Tifan's Well]] to write a history of events since the [[Breaking of the World|Breaking]]. Events surrounding the Dragon Reborn caused them to become active again.  Also see the errata section below.

## Activities
[[Moiraine Damodred]] visited the sisters when she was looking for information on the [[Seanchan]], [[Prophecies of the Dragon]], the [[Horn of Valere]], the [[Forsaken]], [[Shadar Logoth]], and other such things linked to the [[Dragon Reborn]].
After the uprising in the White Tower, Adeleas and Vandene travelled to [[Salidar]] and joined with the [[Rebel Aes Sedai|rebels]] there. They then journeyed to [[Ebou Dar]] with the group looking for the [[Bowl of the Winds]]. While in Ebou Dar they were also looking for runaway girls from the White Tower. While inside the [[Tarasin Palace]] in Ebou Dar, she faced off against the [[Elaida a'Roihan's White Tower|White Tower embassy]] as to whether [[Matrim Cauthon]] should be returned to the White Tower.
She [[Traveling|Traveled]] with the the rest of the group led by [[Nynaeve al'Meara]] and [[Elayne Trakand]] from Ebou Dar to the [[Kin]]'s [[Farm|farm]] with the Bowl of the Winds. She, alongside her sister, took charge of the [[Black Ajah]] sister [[Ispan Shefar]] and began to question her.
She found out that [[Garenia Rosoinde]] was actually Zarya Alkaese, a runaway from the White Tower. She put Garenia back in novice white which also brought forward the confession from [[Kirstian]] that she too was a White Tower runaway. 
On the journey to [[Caemlyn]], Adeleas was killed Ispan in the village of [[Cullen's Crossing]]. Both were first incapacitated with tea laced by poisonous crimsonthorn root and then violently murdered. Vandene deduced that since her sister would not accept tea from someone she didn't trust, the murderer must have been one of their Aes Sedai traveling companions, secretly Black Ajah.
Vandene devoted herself to avenging her sister's murder. Vandene discovered that [[Careane Fransi]] had murdered Adaleas and vindicated her just before her own death.

## Errata
In [[The Path of Daggers]], Adeleas says that Zarya ran away "just before Vandene and I decided to retire and write the history of the world". This is repeated in [[The Wheel of Time Companion]]. This happened around seventy years ago, yet it is stated elsewhere in the Companion that they retired in the year 970 NE. Moiraine thinks in [[The Great Hunt]] that the two sisters retired "so long ago that few even in the White Tower remembered they still lived". The date of 970 NE was, however, corrected in some later editions of the Companion to 930 NE. 

## Notes






https://wot.fandom.com/wiki/Adeleas_Namelle