---
tags: [Men, Andor_people, TwoRivers_people, LivingasofTSR]
---






**Natley Lewin** is a [[Two Rivers]] resident. He is married to [[Laila Lewin]].

## Appearance
He is very wide.

## Activities
He is present on the al'Seen farm when Perrin visits with Faile.

## Notes






https://wot.fandom.com/wiki/Natley_Lewin