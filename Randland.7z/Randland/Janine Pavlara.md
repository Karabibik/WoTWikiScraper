---
tags: [Women, RedAjah, Arafel_people, AesSedai, LivingasofWH, RandsAesSedai, ElaidaaRoihansWhiteTower, MiddleRankingAesSedai, Cairhienexpedition, Channelers]
---


**Janine Pavarla** is an [[Aes Sedai]] of the [[Red Ajah]]. 

## Contents

1 Appearance
2 Strength and Abilities
3 History
4 Activities
5 Notes


## Appearance
She is 5'3" and plump, with large dark eyes and luxuriant black hair, which she wears pulled into a bun on the back of her neck. 

## Strength and Abilities
Janine's level of strength is described by "The Wheel of Time Companion" as 27(15), which is a middle level in Aes Sedai hierarchy. Therefore, she is not strong enough to open a [[Gateway|gateway]] to [[Travel]].

## History
She was born in 963 NE and went to the [[White Tower]] in 978 NE. After spending eleven years as a [[Novice|novice]] and nine years as [[Accepted]], she was raised to the Red Ajah in 998 NE. Since she is new to the shawl, she has not yet achieved the ageless look. It was for this reason that she, along with [[Beldeine Nyram]] and [[Marith Riven]], was chosen to participate in [[Rand al'Thor]]'s kidnapping.

## Activities
She was on the White Tower secret expedition to kidnap [[Rand al'Thor]] in [[Cairhien]].
She was captured by the [[Asha'man]] at the [[Battle of Dumai's Wells]].
[[Chisaine Nurbaya]], Janine Pavlara, [[Innina Darenhold]] and [[Vayelle Kamsa]] are the last four of the prisoners to swear fealty to Rand. They did so under [[Verin]]'s [[Compulsion]].
As with many Aes Sedai sworn to Rand, Janine probably fought the [[Last Battle]] on the slopes of [[Thakan'dar]]. It is not stated whether she survived or not.

## Notes






https://wot.fandom.com/wiki/Janine_Pavlara