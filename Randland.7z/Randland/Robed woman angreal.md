---
tags: [Angreal, ItemsofPower]
---

The **robed woman angreal** is an *angreal* used many times by [[Moiraine Damodred]]. It seems to be made from a smooth, dark ivory. It is a little statue of a woman in flowing robes, with long hair that falls about her shoulders. 
It is described with an average strength, however if [[Cadsuane]]'s weak [[Shrike]] *angreal* enables her to reach the strength of the top male level, it can be assumed that this statuette enabled Moiraine to reach almost the top female levels. 
The first time Moiraine used it to heal [[Rand al'Thor]]'s father, [[Tam al'Thor]], from a wound inflicted by a [[Trolloc]] weapon, a wound that would have otherwise been fatal. It was seen used last time by Moiraine to heal [[Shienar|Shienaran]] soldiers in the [[Mountains of Mist]], but now it is no longer in Moraine's hand, probably she returned it to [[Siuan]] by [[Min]], who was sent to the [[White Tower]] with important informations for the [[Amyrlin Seat]].






https://wot.fandom.com/wiki/Robed_woman_angreal