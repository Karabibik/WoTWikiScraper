---
tags: [Men, Illian_people, CouncilofNine, Lords, LivingasofCCG, Nobility]
---


**Ballin Elamri** is one of the [[Council of Nine]] in [[Illian]].

## Note
Ballin Elamri is not mentioned in the books, but appears in *The Wheel of Time Collectible Card Game* and has his own entry in the Companion.






https://wot.fandom.com/wiki/Ballin_Elamri