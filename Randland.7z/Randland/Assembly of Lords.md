---
tags: [Tarabon, Rulingbodies]
---
The **Assembly of Lords** is the ruling council of the kingdom of [[Tarabon]] and is, in theory, one of three balanced forces which controls the kingdom, alongside the King and the [[Panarch]].
The Assembly is a hold-over from the nation of [[Balasun]], which controlled much of Tarabon's territory before the time of [[Artur Hawkwing]]. The Assembly was resurrected by [[Haren Maseed]] and [[Tazenia Nerenhald]], the first Panarch and Queen of the new nation, in [[FY 1006]]. Over the next five centuries the power of the monarch gradually outstripped that of the Panarch and Assembly, however.
By 500 NE it had become tradition that the monarch was always male and the Panarch always female. The Assembly had lost most of its temporal and law-making powers aside from the ability to elect a new Panarch.






https://wot.fandom.com/wiki/Assembly