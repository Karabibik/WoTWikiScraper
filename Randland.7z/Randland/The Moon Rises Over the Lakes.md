---
tags: [Swordforms]
---



*"There was no time to think. Instinct brought the sword out if its sheath in a flashing arc. The Moon Rises Over the Lakes."*
   —Rand's thoughts when using the form. 



**The Moon Rises Over the Lakes** is a [[Sword form|sword form]]. It is a way to unsheath the sword, but can also be used once the sword is out of its scabbard. When ambushed by [[Trolloc|Trollocs]] in [[Cairhien]], [[Rand al'Thor]] killed one of them with this form. [[Gawyn Trakand]] also used this form, as well as [[The Falcon Stoops]] and [[The Creeper Embraces the Oak]], when he fought [[Aiel]] after the [[Battle of Dumai's Wells]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Moon_Rises_Over_the_Lakes