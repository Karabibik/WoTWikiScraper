---
tags: [Women, GreenAjah, Cairhien_people, AesSedai, LivingasofTOM, RandsAesSedai, RebelAesSedai, CaemlynEmbassy, HighRankingAesSedai, Channelers]
---


**Seonid Traighan** is an [[Aes Sedai]] of the [[Green Ajah]].

## Contents

1 Appearance and Abilities
2 History
3 Activities

3.1 Embassy to the Dragon
3.2 Tracking the Prophet
3.3 Rescuing Faile
3.4 Meeting with the Whitecloaks
3.5 The Last battle


4 Trivia
5 Notes


## Appearance and Abilities
Seonid is a short (5'1 tall) and pale [[Cairhienin]] with dark hair that fell in waves to her shoulders with big, dark, bottomless eyes. While she is not particularly slender, neither is she stocky or stout. She is atypical for a Green in that she is cool and reserved, with an air of dignity and authority, with sometimes a determined smile. Her normal attitude is to be brisk, practical, businesslike and methodical.
She sometimes wears a *Kesiera* on her forehead, with a white fingernail-sized stone.
Seonid is a quite strong Aes Sedai; her strength in *saidar* is the same as [[Verin]] and [[Alanna]], so she is strong enough and able to open alone a [[Gateway|gateway]] to [[Travel]].
This is confirmed by "The Wheel of Time Companion" where her level of strength is described as 17(5).
Seonid is also quite good in the traditional Aes Sedai method of [[Healing]].

## History
Seonid is 72 years old. She was born in the year 928 NE and went to the [[White Tower]] in 946 NE. After spending thirteen years as [[Novice|novice]] and twelve as [[Accepted]] she was raised to the shawl in the year 971 NE.
She chose the Green Ajah because it is the Battle Ajah but, as mentioned above, Seonid is atypical for a Green. She is a lesbian, but she does not hate men, she just does not want to bed them.
She has two [[Warder|Warders]], [[Furen Alharra]] and [[Teryl Wynter]]. Seonid's attitude toward her Warders is very businesslike, brisk, practical and methodical. That is in fact her general attitude.

## Activities
### Embassy to the Dragon
She is allied with the [[Salidar Aes Sedai]] and is a member of the [[Salidar Embassy to the Dragon Reborn|embassy]] sent from Salidar to [[Rand al'Thor]] in [[Caemlyn]]. Min reported that Seonid mulled over every rumor from her native Cairhien, and kept her own counsel as to her opinion of Rand.
The embassy arrives in Caemlyn. Seonid visits the Dragon Reborn, along with [[Merana]] and [[Masuri]] - the first three to do so. She is also one of the seven who confront Rand with the Mask of Mirrors after [[Demira Eriff|Demira]] is injured. Later, the embassy members connect with [[Verin]] and [[Alanna]], deciding to form an alliance with them.
After the delegation dissolves she accompanies [[Bera Harkin]] and [[Kiruna Nachiman]] to meet Rand in [[Cairhien]] after he flees [[Andor]].
Seonid fights with [[Perrin Aybara]]'s forces at the Battle of [[Dumai's Wells]] to rescue Rand, although she is forced to swear fealty to Rand afterwards.
Seonid and [[Masuri Sokawa]] of the [[Brown Ajah]] accompany Perrin into [[Ghealdan]] to track down [[Masema Dagar]]. Masuri and Seonid were sent by Rand under the order to obey Perrin as they would to the Dragon, something that left room for interpretation, as she, Perrin and Masuri are all aware. In Seonid's mind, she was determined to fulfill her Oaths to Rand; and one of the best ways to do that was to suppress the Dragonsworn in whatever way possible.
She considered Rand as arrogant as any king, and had the typical Cairhenin attitude towards the Aiel.

### Tracking the Prophet
In Perrin's camp, Annoura stays with Berelain but Masuri and Seonid stay with Edarra and the other Wise Ones. She becomes an apprentice to the [[Aiel]] [[Wise Ones]] and even has to suffer beatings from them.
Seonid helps Perrin to rescue [[Morgase]]'s group from a band of [[Dragonsworn]].
After it Seonid and the Wise Ones meet with Masuri and the others to discuss the Prophet. Seonid, along with the Wise Ones, advises Perrin to kill Masema.
She goes with Perrin to his meeting with Masema in [[Abila]].

### Rescuing Faile
Perrin and the others leave Abila and return to their camp to discover that Faile and others are captured by the Shaido.
Seonid, Masuri, Carelle and Edarra join Delora, Janina, Marline and Nevarin in the Wise Ones' tent to discuss the kidnapping.
Seonid, Masuri and the Wise Ones join the Two Rivers men as they all prepare to head south after Faile.
She goes with Perrin to [[So Habor]], where they collect grain for their troops. She wishes to investigate the ghosts in So Habor but Perrin forbids her from remaining behind.
She accompanies him back to camp and witnesses him cleave a Shaido prisoner's hand off when he is looking for answers on his missing wife. She [[Heal|Heals]] the hand, but as a stump, without the hand.
She assists Perrin in rescuing [[Faile]] from her captivity by the Aiel. She and her Warders go through the aqueduct to enter the town of [[Malden]] before Perrin begins his attack.
After the rescue, Seonid, Furen and Teryl join Perrin and Faile. Seonid Heals Perrin's and Faile's injuries.

### Meeting with the Whitecloaks
From Malden, Perrin and his followers travel slowly through Ghealdan to the Jehannah Road. A bubble of evil brings black snakes and the Aes Sedai are bitten. Healing does not work properly.
While Perrin's army travels they come across an area of land which is diseased as the [[Blight]]. Perrin orders Seonid, Masuri, and the Wise Ones to burn it. She then attends a meeting with Perrin to decide where the army should go.
Seonid advances enough in the Wise Ones opinions that she is allowed to speak without their permission. She decides to accompany a scouting force that will be sent to Cairhien to start looking for Rand.
She reports to Perrin on current events that are happening within the continent, including [[Darlin Sisnera]] being made king of [[Tear]] and the lack of a needed leader in Cairhien.
Perrin requests Seonid and the other Aes Sedai to meet with him just as his force is about to engage the [[Children of the Light|Whitecloaks]]. He charges the Aes Sedai to create a massive trench between the two forces but she declines as her oaths prevent her due to possible damage to the Whitecloaks who are close.
She attends the second parley between Perrin and the [[Lord Captain Commander]] [[Galadedrid Damodred]]. After the meeting, the Aes Sedai and Wise Ones accompany Perrin and others to his trial.
After the forging of [[Mah'alleinir]] Perrin decides to help the Whitecloacks that are to be attacked by a horde of [[Shadowspawn]]. Seonid and her Warders most probably participated at this battle.
The Asha'man, Aes Sedai and Wise Ones link and open a large gateway for Perrin's army to Travel to the Field of Merrilor.

### The Last battle
Seonid is not mentioned in the last book but as with many Aes Sedai sworn to Rand, she probably fought the [[Last Battle]] on the slopes of [[Thakan'dar]]. It is not stated whether she survived or not, so it is likely that she did.

## Trivia
She is one of the few confirmed lesbians throughout the series.

## Notes






https://wot.fandom.com/wiki/Seonid