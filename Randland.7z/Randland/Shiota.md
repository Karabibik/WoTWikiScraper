---
tags: [NationsoftheFreeYears, Historicalnations]
---
**Shiota** was a kingdom of the Free Years. It was founded after the [[Trolloc Wars]] out of the former territory of [[Eharon]]. During the [[War of the Hundred Years]], it splinted into the kingdom of [[Altara]], with a large chunk of its eastern territory becoming part of [[Illian]].

## Contents

1 Geography
2 Culture
3 History
4 Other mentions


## Geography

Shiota was one of the largest of the kingdoms of the Free Years, and the territory it controlled almost exactly matched that of the one of the Ten Nations it replaced, save some lands along the [[River Storn]] and [[River Cary]]. Its borders were the [[River Eldar]] to the west, the [[Sea of Storms]] to the south, and the [[Manetherendrelle|River Manetherendrelle]] to the east and north. Its neighbors were [[Kharendor]] to the west, [[Dhowlan]] to the northwest, [[Farashelle]] in the far north, [[Nerevan]] and [[Esandara]] to the northeast, and [[Fergansea]] to the east.
Shiota's capital city was [[Ebou Dar]], which had been built out of the ruins of [[Barashta]], which had been mostly destroyed in the Trolloc Wars. The city of [[Illian]], located on the border with Fergansea, was also a major port and trade center. Both cities survived the War of the Hundred Years. Another location of note was the village of [[Salidar]], where the famous [[Amyrlin Seat]] [[Deane Aryman]] was born c. [[FY 920]].

## Culture
Shiota was famed for its feather-dancers, which were common enough for it to be an idiom: "as easy as finding feather-dancers in Shiota". It is, perhaps, from this tradition that the [[Festival of Birds]] has its origin. 
Many statues of former Shiotan Queens also show them in considerably less clothing than is now deemed "proper."
Shiota may have had a matriarchy. All known references to the rulers of Shiota in the series mention the Shiotan warrior Queens. The toes of what remained of a two-hundred foot tall once-great warrior Queen is used by [[Careane Fransi]] as a pretence to strike a conversation with [[Elayne Trakand]] while on their journey to the [[Kin]]'s farm. Bashere observes that another statue in western Illian was of a Shiotan Queen. A statue with a sword signifies that she was a conqueror and the crown she wore meant that she expanded the borders. Although a different statue, it is possible that it may be of the same woman. If a matriarchy, it would explain the legacy of female dominance of many trades and the use of the marriage knife extant in Ebou Dar. Bashere makes an observation that the crown the statue wears is reminiscent of the [[Crown of Swords]], the crown of Illian which was once part of that nation. He also reflects that she may have been seen as the hope of Shiota in her day, as famous as Artur Hawkwing would be, and now not even the sisters of the [[Brown Ajah]] may know her name, a reflection reminiscent of the famous Shelley poem  and a running theme of the decay of nations in the series in general.

## History
As with many of the nations of the Free Years, little is known of Shiota's history. The kingdom arose out of the ruins of Eharon with the rebuilding of the capital as Ebou Dar a top priority during its earlier history. The nation appears to have had a possibly martial history, with large statues dating from the time of Shiota showing the rulers wearing crowns made of swords.
Around [[FY 500]] Shiota was invaded by both Nerevan and Esandara. The reason for the invasion is not known. A major battle was fought near the ruins of [[Londaren Cor]], the former capital of Eharon destroyed in the Trolloc Wars. Shiota appears to have proven victorious in the war, as it continued to survive after the war was concluded.
Shiota was conquered circa [[FY 940]] during the [[War of the Second Dragon]] by the [[False Dragon|false Dragon]] [[Guaire Amalasan]], and fell into disarray upon his death. It was then annexed by [[Artur Paendrag Tanreall|Artur Hawkwing]] some years later. After the [[War of the Hundred Years]] the rulers of Ebou Dar managed to establish control over much of the former territory of Shiota, naming it Altara, but were never able to decisively forge a unified kingdom. Instead, Altara became a patchwork of semi-autonomous fiefdoms paying lip service, if that, to the ruler in Ebou Dar.

## Other mentions
Another reference to the dead nation comes in the chapter *A Village in Shiota*, where [[Valan Luca's Traveling Show]] passes through a village that Mat recognises as having houses constructed in a style common in Shiota for around three hundred years. The village is a [[Bubble of evil]] and filled with ghosts who drag an unwary peddlar to his death as the entire village sinks into the ground.

||
|-|-|






https://wot.fandom.com/wiki/Shiota