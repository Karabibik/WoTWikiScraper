---
tags: [Prophecies, Seanchanculture, Foretellings]
---

The **Essanik Cycle** is a set of prophecies in [[Seanchan]] which originated from the [[Karaethon Cycle]]. It is unknown how similar or different these sets of prophecies are. Some believe this set to be highly corrupted for purposes of propaganda as a key tenet is that the [[Dragon Reborn]] must kneel before the [[Crystal Throne]] before [[Tarmon Gai'don]], or all is lost.

*"I am here.
At the end of time,
when the many become one,
the last storm shall gather its angry winds
to destroy a land already dying.
And its center, the blind man shall stand
upon his grave.
There he shall see again,
**and weep for what has been wrought."*

   —from The Prophecies of the Dragon, Essanik Cycle. Malhavish's official Translation, Imperial Record House of Seandar, Fourth Circle of Elevation 


*"The Last Battle would be between the Empire and the forces of the Dark One. Everybody knew that. The Prophecies clearly showed that the Empress would defeat those who served the Shadow, and then she would send the Dragon Reborn in to duel with Lighteater. How much had he fulfilled? He didn't seem blinded yet, so that had yet to happen. The Essanik Cycle said that he would stand on his own grave and weep. Or did that prophecy refer to the dead walking, as they did already? Certainly, some of those spirits had walked across their own graves. The writings were unclear, sometimes.[1]"* 
## Explanation
Rand was blind until he was weeping over his fate and the cyclical nature of history of mankind atop of [[Dragonmount]] – his own grave. (Dragonmount was created by him committing suicide by overdrawing the [[One Power]] in the AoL.). After that fight with the Shadow in himself, he gained the skill to recognise [[Darkfriends]] by looking them into the eye so they no longer can hide among his allies. E.g. Darkfriends like [[Weiramon Saniago|Weiramon]] and [[Anaiyella Narencelona|Anaiyella]] were not able to look at him or only with difficulties, eyes watering. They cover their face, their eyes in his presence. Rand explains to Min:

*"The Shadow does not need her to find me, Min, nor will it ever again. All its eyes are fixed directly upon me, and will be until I blind them. [...] The time when it could silence me quietly – and therefore win – has passed.
[...]

The time for hiding is past, Min. The Shadow made its play for me and lost. It is war, not subterfuge, that turns the day now.[3]"* 
While Rand alone attacks the [[Shadowspawn]] with the One Power on the battle field of [[Maradon]], inside one of the rooms of the Council Hall [[Vram Torkumen]] crawls his eyes out and going mad, crying: *"That light... That terrible light. I cannot watch it, I cannot! [...] That Light eats at my mind, like rats feasting on a corpse. It burns at my thoughts. It killed me. That light killed me."* [[Torkumen|Lady Torkumen]] jumps out the window, committing suicide. 
The Crystal Throne can be an object that the Empress sits on, or quite often Seanchan will say that the Empress is the Crystal Throne. So Rand literally kneels in-front of [[Fortuona Athaem Devi Paendrag]] (the Crystal Throne) in order for her to sign the [[Dragon's Peace]] and then get the Seanchan to fight in the Last Battle. Without the Seanchan, the forces of Light would probably have not won the Last Battle and the world would have been lost. 

## Notes






https://wot.fandom.com/wiki/Essanik_Cycle