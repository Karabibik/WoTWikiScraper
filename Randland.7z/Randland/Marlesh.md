---
tags: [Men, Warders, LivingasofTGS, ElaidaaRoihansWhiteTower, DorlanGroup, Cairhienexpedition]
---


**Marlesh** is a young [[Warder]], bonded to [[Vasha]]. They have a very casual relationship, almost like a brother and sister.

## Appearance
He is short and narrow.

## Activities
He is with the original group of eleven Aes Sedai who escape the [[Battle of Dumai's Wells]]. He accompanies Vasha to [[Dorlan]]. He spars with [[Gawyn Trakand]], alongside [[Sleete]]. Afterwards, he compliments Gawyn's swordsmanship and calls him a Blademaster.






https://wot.fandom.com/wiki/Marlesh