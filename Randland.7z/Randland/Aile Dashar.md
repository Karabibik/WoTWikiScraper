---
tags: [Islands, IslandsoftheAthaanMiere]
---


**Aile Dashar** is an archipelago that is controlled by the *Atha'an Miere* and [[Amayar]]. The islands are located northwest of [[Arad Doman]].

## External links
 





https://wot.fandom.com/wiki/Aile_Dashar