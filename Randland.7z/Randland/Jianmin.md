---
tags: [Seanchancontinent]
---
**Jianmin** is a location in [[Seanchan]]. [[Furyk Karede]] was there for the [[Jianmin Incident]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Jianmin