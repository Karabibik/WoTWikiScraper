---
tags: [Men, Amadicia_people, LivingasofKOD, Gaishain]
---


**Theril** is from [[Amadicia]]. His dad is [[Alvon]].

## Appearance
He is lanky and tall.

## Activities
He is made [[Gai'shain]] by the [[Shaido]]. He and his dad continue to try and escape from the Shaido, making it further each time. They tried three times.
He swears fealty to [[Faile Bashere]] and later on steals the [[Oath Rod]] from [[Therava]]'s tent. He then gives to Faile.
He witnesses [[Galina Casban]] topple a burnt down old house on top of Faile and the rest of her group. He runs back to the Shaido camp to get help from the rest of those who swore fealty to Faile.
He is sent by Faile to the fortress in [[Malden]] to escort those that traveled through the aqueduct before the [[Battle of Malden]] to where Faile and [[Perrin Aybara]] are.






https://wot.fandom.com/wiki/Theril