---
tags: [Villages, BlackHills]
---
**Denhuir** is a village located on the Maradon Road near the [[Black Hills]].
Denhuir is the village where [[Mazrim Taim]] escapes the custody of [[Aes Sedai]]. When [[Siuan Sanche]] learns of this, she sends a dozen Aes Sedai and one thousand guards to capture and gentle him.

## Notes






https://wot.fandom.com/wiki/Denhuir