---
tags: [CrownsandRegalia]
---
A **stole** is a vestment worn by various holders of certain of offices. In the series, it has been shown as primarily a symbol of offices held by women, such as the [[Amyrlin Seat]], the [[Panarch|Panarch of Tarabon]] and the [[Queen of Andor]]. The [[Keeper of the Chronicles]] also wears a stole as a trapping of her office.
Typically the stole is a wide, flat strip of silk, worn over a dress, hanging from the behind the wearer's neck to trail down the front of her torso. Thus far, all of the stoles mentioned have been worn by women.

## Stoles
[[Stole of the Amyrlin Seat]]
[[Stole of the Keeper of the Chronicles]]
[[Stole of the Panarch of Tarabon]]
[[Stole of the Queen of Andor]]





https://wot.fandom.com/wiki/Stole