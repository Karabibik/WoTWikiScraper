---
tags: [Men, Andor_people, TwoRivers_people, LivingasofTSR]
---







**Flann Lewin** is a [[Two Rivers]] farmer. He is married to [[Adine Lewin]], and [[Tell Lewin|Tell]] and [[Dannil Lewin|Dannil]] are his nephews.

## Appearance
He is gnarled and gray-haired and as thin as a beanpole.

## Activities
He is present on the al'Seen farm when Perrin visits with Faile.
He helps defend [[Emond's Field]] against the invading [[Trolloc]] army.

## Notes






https://wot.fandom.com/wiki/Flann_Lewin