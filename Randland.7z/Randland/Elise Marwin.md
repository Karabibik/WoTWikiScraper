---
tags: [Women, Andor_people, Novices, LivingasofTPOD, TwoRivers_people, RebelAesSedai]
---




**Elise Marwin** is a [[Novice|novice]] in the [[Rebel Aes Sedai|rebel Aes Sedai]] camp. She is from [[Emond's Field]].

## Activities
She is tested for channeling abilities by [[Verin Mathwin]] and [[Alanna Mosvani]], and is found suitable for training. She accompanies several other [[Two Rivers]] girls with channeling abilities to [[Caemlyn]], where they are all terrorized by [[Rand]]. She eventually joins the rebel Aes Sedai in [[Murandy]], becomes a novice and follow them to [[Tar Valon]].






https://wot.fandom.com/wiki/Elise_Marwin