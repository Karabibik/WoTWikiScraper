---
tags: [Men, ChildrenoftheLight, Soldiers, LivingasofTSR]
---






**Ivon** is a member of the [[Children of the Light]].

## Appearance
He is hard-faced. His armor shines as much as his snowy white cloak.

## Activities
He is one of the men that arrives in [[Taren Ferry]] with [[Dain Bornhald]] and who had been previously patrolling near [[Tar Valon]].
He carries a message from Hundredman [[Farran]] to Dain about the suspicious activities of [[Ordeith]] and the disappearance of three *Tuatha'an* he had been talking with.

## Notes






https://wot.fandom.com/wiki/Ivon