---
tags: [Items, WhiteTower, Novices, AesSedai]
---
The **novice book** is used in the [[White Tower]] to officially enroll those who wish to attempt to become [[Aes Sedai]]. Once enrolled in the novice book, a [[Novice|novice]] may not forsake Tower training until she is put out by the Tower or until she attains the rank of Aes Sedai. Though an instrument of administration, nevertheless it is held in great esteem by Aes Sedai.
An age restriction was once in place for those who wished to be written into the novice book, as it was believed that any girl over the age of eighteen was too old to adapt to the discipline. Consequently many times young women lied about their age to be enrolled in the Book, facing severe punishments when discovered. On the other hand in some exceptional cases the same Aes Sedai decided to not respect this rule, for instance when they discovered women with a very great potential, as in the case of [[Nynaeve]] who was enrolled and then tested immediately as [[Accepted]] at the age of 26, becoming the strongest initiated enrolled in the Novice Book since the time of [[Caraighan Maconar]], almost three thousand years earlier.
When [[Egwene al'Vere]] became [[Amyrlin Seat]] of the [[Rebel Aes Sedai|rebel Aes Sedai]], she removed this restriction and opened the novice book to women of all ages. Many Aes Sedai with an old mentality, as [[Romanda]], were not convinced about this opening of the Book, until some relatively old women were discovered with a potential even greater than Nynaeve, as [[Sharina Melloy]]. 
As Amyrlin of the reunified White Tower, Egwene has continued allowing older women to enroll, and currently the number of novices sits at close to one thousand. This is a number which many believe will continue to increase, providing the novice book remains open to all. The oldest novice in the White Tower is 67 years old. The ability to [[Travel]] also increases the possibility of finding more women to enroll.

## Notes






https://wot.fandom.com/wiki/Novice_book