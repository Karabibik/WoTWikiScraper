---
tags: [Women, GreenAjah, Andor_people, ElaidaaRoihansWhiteTower, AesSedai, Deceased, MiddleRankingAesSedai, Cairhienexpedition, Channelers]
---


**Mirlene Cornwell** was an [[Aes Sedai]] of the [[Green Ajah]]

## Contents

1 Appearance and Abilities
2 Activities
3 Particularity of this character
4 Notes


## Appearance and Abilities
Mirlene is not particularly strong in the [[One Power]]. Her level of strength is described by "The Wheel of Time Companion" as 26(14) which is a middle level in Aes Sedai hierarchy. With this level of strength she is unable to open alone a suitable gateway to [[Travel]].

## Activities
Mirlene was in the group of Aes Sedai that kidnapped [[Rand]] and she was killed during the Battle at [[Dumai's Wells]].

## Particularity of this character
Mirlene Cornwell is described only in "The Wheel of Time Companion", she is never mentioned in the main books of the Wheel of Time.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Mirlene_Cornwell