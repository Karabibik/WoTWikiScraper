---
tags: [Men, Cairhien_people, Rulers, Kings, Deceased, Historicalpeople]
---


**Matraine Colmcille** was the first King of [[Cairhien]] and is sometimes called the founder of that nation.

## History
Shortly after the death of the High King, [[Artur Hawkwing]], in [[FY 994]], an alliance of nobles descended from the pre-imperial nation of [[Tova]] attempted to restore that kingdom. During a ball held in the city of Cairhien to celebrate this occasion, there was a massacre and most of those present were killed. Months of fighting on the streets and in the back alleys followed, with battles and assassinations raging until every last descendant of the Tovan rulers were slain and one nobleman, Colmcille, had established a clear advantage over the others. Colmcille was thus crowned the first king of the new nation of Cairhien.
Colmcille led the nation through the early part of the [[War of the Hundred Years]] and some of the later traditions of the kingdom were established under his rule.






https://wot.fandom.com/wiki/Matraine_Colmcille