---
tags: [HerbsandMedicines]
---



**Silverleaf** is an [[Herb|herb]]. Nothing is known about it except that it is can be combined with [[Timsin root|timsin root]] in a tea to treat headaches. [[Matrim Cauthon]] once drank this tea.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Silverleaf