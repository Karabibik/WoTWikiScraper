---
tags: [Men, Seanchan_people, Generals, LivingasofKOD, EverVictoriousArmy]
---


**Mikhel Najirah** is a Banner-General in the [[Seanchan]] army and is a member of the low Blood.

## Appearance
He is lanky and graying.

## Activities
He greets [[Suroth Sabelle Meldarath]] and escorts her to the meeting with [[Lunal Galgan]] about the uprisings in [[Tarabon]].
He is present when [[Tuon Athaem Kore Paendrag]] warns King [[Beslan Mitsobar]] not to cause a revolt against the Seanchan.






https://wot.fandom.com/wiki/Mikhel_Najirah