---
tags: [Women, Legends, Parallels, FirstAge]
---


**Materese the Healer** is a character in one of the ancient [[Stories|stories]] in [[Thom Merrilin|Thom Merrilin's]] repertoire that date to the [[First Age]]. She is also known as the "Mother of the Wondrous Ind".  The story of Materese represents the legend of a real person that has gradually evolved away from the truth and faded into myth.  This is common for all stories that transcend multiple ages as the [[Wheel of Time]] turns.

## Parallels
Materese is a hidden reference to  and the Wondrous Ind is a reference to India, where she ministered.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Materese_the_Healer