---
tags: [Women, GreenAjah, AesSedai, Charactersoriginaltothevideogame]
---


**Cerist** was an [[Aes Sedai]] of the [[Green Ajah]] in a [[Mirror World]].

## History
Cerist was captured by the [[Children of the Light]], and was later rescued by [[Elayna]] Sedai.

## Notes






https://wot.fandom.com/wiki/Cerist