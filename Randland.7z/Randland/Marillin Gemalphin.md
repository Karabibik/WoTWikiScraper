---
tags: [Women, BrownAjah, Andor_people, BlackAjah, Dreadlords, AesSedai, Unknownstatus, LivingasofTOM, Eyes-and-ears, HighRankingAesSedai, Channelers]
---


**Marillin Gemalphin** is an [[Aes Sedai]] of the [[Brown Ajah]]. She is also [[Black Ajah]] and one of [[Liandrin's Group of Black Sisters|Liandrin's group of Black sisters]].

## Contents

1 Appearance, attitudes and abilities
2 History
3 Activities

3.1 Fleeing the White Tower
3.2 Elayne's kidnap
3.3 Unforeseen rescue
3.4 The Last Battle


4 Notes


## Appearance, attitudes and abilities
She is skinny, with dreamy blue eyes and lifeless brown hair. She has a narrow face.
Marillin's strength in the [[One Power]] is described by "The Wheel of Time Companion" as 15(3), which is a high level in the Aes Sedai hierarchy and enough to open a [[Gateway|gateway]] to [[Travel]] by herself. 
She loves cats and other animals, quite possibly more than she likes people, going out of her way to [[Healing|Heal]] stray cats.

## History
Marillin is from [[Caemlyn]] [[Andor]].
She is 152 years old. She was born in 848 NE and went to the [[White Tower]] in 863 NE. After spending six years as a [[Novice|novice]] and five years as [[Accepted]], she was raised to the [[Shawl|shawl]] in 874 NE.
She could be in the same heart as [[Careane Fransi]], for it is Marillin who reveals the [[Green Ajah|Green]]'s true identity as [[Black Ajah]].

## Activities
### Fleeing the White Tower
After fleeing the White Tower in Liandrin's group, she went to [[Tear]] and worked for the [[Forsaken]] [[Be'lal]]. They tried to trap [[Rand al'Thor]] just after he released *Callandor*. 
After this fails she fleed to [[Tanchico]] to try and steal the [[Domination Band|male a'dam]] from the [[Panarch]]'s [[Panarch's Palace|Palace]]. This plan was also foiled by [[Elayne Trakand]] and [[Nynaeve al'Meara]].
Some time after, in Amadicia [[Moghedien]] gave her a secret mission, that probably involved a travel to Caemlyn, where rumours have often spread of an Aes Sedai Healing cats.

### Elayne's kidnap
In [[Caemlyn]] she was put by forsaken under the leadership of [[Lady Shiaine]]. There Marillin met also [[Falion Bhoda]]  that was in punishment by Shiaine for her failures. Marillin was ordered by Shiaine to find a way to infiltrate the Royal Palace. Marillin tells Shiaine that she cannot do what she wants, because the Palace is full of female channellers, but that there is a woman already in the Royal Palace who can.
Fortuitously she was later involved in the unsuccessful kidnap attempt on Elayne and so she was captured. When in Caemlyn she had heard about a woman Warder, but told nothing to the others.

### Unforeseen rescue
In an attempt to interrogate a member of the Black Ajah, Elayne impersonates a Forsaken and in the process gets herself into a lot of trouble. [[Doilin Mellar]], whom she believes to be a Queen's man but is really a [[Darkfriend]], assaults her. Timely intervention by [[Matrim Cauthon]] and [[Birgitte Silverbow]] saves Elayne from further harm, but Mellar escapes.
During the fight between Elayne and Mellar, Marillin and Falion were probably freed from the dungeons by [[Jaq Lounalt]].

### The [[Last Battle]]
Technically, Marillin's fate is unknown, but it can be presumed that she fought in the Last Battle and was either killed or captured, or is on the run. 

## Notes






https://wot.fandom.com/wiki/Marillin_Gemalphin