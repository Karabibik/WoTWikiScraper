---
tags: [Women, AradDoman_people, Kinswomen, Healers, LivingasofTPOD, FarmGroup, Besthealers, Channelers, Novices]
---


**Asra** is a [[Arad Doman|Domani]] [[Wise Woman]] and a member of the [[Kin]] in [[Ebou Dar]].

## Contents

1 Appearance
2 History
3 Strength and Abilities
4 Activities
5 Notes


## Appearance
She looks just a little older than [[Nynaeve al'Meara]] but really she is 86 years old. She has coppery skin.

## History
Asra was born in the year 913 NE and went to the [[White Tower]] in the year 929 NE. After four months she was sent away because of her weakness in the [[One Power]].

## Strength and Abilities
Asra is very weak in the [[One Power]], in fact Elayne thought that she would probably never be allowed to test for [[Accepted]].
This is confirmed by "The Wheel of Time Companion" where her level of strength is classified 54(42), far below the minimum level of 45(33) to become Aes Sedai
Despite her lack of strength Asra is very [[Talent|talented]]. In fact like the strongest channelers (as [[Rand]] and [[Alivia]]) she is very quick in learning and doesn't need to see a weave more than once to be able to reproduce it perfectly.
Her second talent is [[Healing]]; when she was a simple Novice in the Tower, she was not instructed in the weaves used to heal, nevertheless she learned it, copying secretly the Aes Sedai performing it, and despite her weakness in the power in short time she reached a very high level of Healing.
Finally Asra has the very rare Talent that [[Aviendha]] does, of being able to tell what a weave she had never seen before would do before it is completed.

## Activities
In Ebou Dar she was seen by [[Nynaeve]] and [[Elayne]] when she tried to [[Heal]] a man named [[Masic]] after he was mortally wounded in a duel with [[Baris]].
Along other Kinswomen she [[Travel|Traveled]] from Ebou Dar to [[The Farm]] and after to Andor following the leadership of Elayne and Nynaeve.
She along with a number of other Kin were starting to develop a backbone and she had started to question [[Aes Sedai]] decisions.
When [[Zarya Alkaese|Garenia]] and [[Kirstian]] were identified as runaways and put back in Novice white, Asra and [[Sarainya Vostovan]] attempted a revolt, but they were punished for this boldness with a switching.
Asra found Lieutenant [[Charlz Guybon]] near Caemlyn and brought him and his army into the city via [[Gateway|gateway]] (Because Asra is surely not strong enough to Travel alone it can be supposed that she was leading a circle of Kinswomen).

## Notes






https://wot.fandom.com/wiki/Asra_Zigane