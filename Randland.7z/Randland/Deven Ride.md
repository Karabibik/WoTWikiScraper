---
tags: [Villages, TwoRivers]
---
**Deven Ride** is a community located near the southern boundary of the [[Two Rivers]] region.


## Geography
**Deven Ride** lies south of [[Emond's Field]] and serves as the southern endpoint of the [[Old Road]]. The [[Westwood]] stretches west of the village, with the [[Sand Hills]] and [[Mountains of Mist]] further beyond. To the east lie the [[Waterwood]] and [[The Mire]]. Deven Ride's primary feature is it's proximity to the northern banks of the [[River Manetherendrelle]], known locally as the White River. The river currents are considered to be extremely treacherous by villagers who never attempt to cross to the [[Forest of Shadows]] on the opposite bank. Because of this, Deven Ride is considered to be the most removed community in all of the Two Rivers, a region already known for its isolation. As a community, Deven Ride is very similar to its northern neighbors though smaller in size. The primary activities of villagers consist of [[Tabac]] farming and wool gathering. The village surrounds a [[Green]] where annual [[Bel Tine]] festivals are held. The local water source is a small spring-fed pond surrounded by a low stone wall. All buildings in Deven Ride are all thatch-roofed and the local inn is called the Goose and Pipe.

## History
When [[Manetheren]] was in its youth, a bridge was constructed over the Manetherendrelle River just south of the location of Deven Ride. Soon afterward, a town much larger than the present village emerged on the north side of the river and served as a gateway to the heart of the nation. After the [[Band of the Red Hand]] perished in Aemon's Field, the nation of Manetheren died and the town was abandoned along with the bridge. When farmers returned to the area many years later to begin a new community, the bridge over the river had collapsed. In time the powerful current of the White River washed away the ruins and no trace of the former structure remains. The name of the previous town is unknown, as is how Deven Ride acquired its name.

## Government
Like the other villages of the Two Rivers region, Deven Ride practices a form of gender-based  government. Governance is officially controlled by a [[Village Council]] consisting entirely of men who are elected to office by villagers via popular vote. The council is headed by a mayor who is elected in a similar fashion. Additionally, a second ruling body called the [[Women's Circle]] controls matters in Deven Ride as well. Members of the circle are always elder females within the village who are chosen by existing members. The Women's Circle is headed by a [[Wisdom]] who serves for life. The current Wisdom of Deven Ride is [[Elwinn Taron]] who has recently replaced [[Mavra Mallen]]. As in the villages of [[Watch Hill]] and Emond's Field, political control of Deven Ride exists as an ongoing willful struggle between the Village Council and the Women's Circle. Villagers are known for a strong streak of stubbornness, a trait shared with all inhabitants of the Two Rivers and a legacy of the blood of ancient Manetheren. From this emerges a sense of commitment to their neighbors evidenced when Deven Ride dispatched a group of archers to participate in the [[Battle of Emond's Field]]. Though Deven Ride continues to assert political independence, many villagers have begun to follow [[Perrin Aybara]].






https://wot.fandom.com/wiki/Deven_Ride