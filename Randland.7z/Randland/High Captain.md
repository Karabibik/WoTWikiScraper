---
tags: [Military, TarValon]
---
**High Captain** is the rank given to men who are in command of the [[Tower Guard]] of [[Tar Valon]].
The holder of this rank is responsible for the overall command of the defense of Tar Valon.
It has been speculated that [[Gareth Bryne]] may attain this rank, despite his preference for field command and the need for his skills in [[Tarmon Gai'don]].

## Known High Captains
[[Azil Mareed]]
[[Jimar Chubain]]





https://wot.fandom.com/wiki/High_Captain