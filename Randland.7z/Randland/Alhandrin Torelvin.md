---
tags: [Men, Cairhien_people, BandoftheRedHand, Soldiers, LivingasofLOC, ]
---


**Alhandrin Torelvin** is one of [[Matrim Cauthon]]'s officers in the [[Band of the Red Hand]]. He commanded the Third Banner of Horse.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Alhandrin