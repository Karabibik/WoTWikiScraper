---
tags: [Men, TarValon_people, Mayorsandgovernors, LivingasofCOT]
---


**Garon Burlow** is the mayor of [[Dorlan]], east of [[Tar Valon]]. He is married.

## History
He owns the biggest house in Dorlan. [[Covarla]] and [[Lusonia Cole]]  took his two spare rooms when they were sent to the village.
He is not present when [[Gawyn]] enters the house to find [[Katerine]], [[Narenwin Barda]] and [[Tarna]]. According to Gawyn, Burlow and his wife would have been offering hot drinks or food, unless they have been sent to bed to grant the [[Aes Sedai]] some privacy.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Garon_Burlow