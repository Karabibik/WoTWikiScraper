---
tags: [Men, Stablemen, LivingasofKOD, ]
---


**Bollin** is a horse handler in [[Valan Luca]]'s [[Valan Luca's Traveling Show|Traveling Show]].

## Appearance
Bollin is a big man with squinty eyes.

## Activities
Bollin is on guard at the entrance to the show when [[Murel]] and other [[Seanchan]] soldiers refuse to pay to enter.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Bollin