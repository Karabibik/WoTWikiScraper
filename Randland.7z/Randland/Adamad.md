---
tags: [Men, Borderlands_people, Farmers, LivingasofTGS, ]
---


**Adamad** is one of [[Renald Fanwar]]'s farmhands. 

## History
He goes north with Renald when they follow [[Thulin]].






https://wot.fandom.com/wiki/Adamad