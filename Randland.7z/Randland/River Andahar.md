---
tags: [Rivers, Tarabon]
---

The **River Andahar** rises in the [[Mountains of Mist]] and flows south and west through the kingdom of [[Tarabon]] into the [[Aryth Ocean]], flowing into the sea at the city of [[Tanchico]]. It is the major east-west trade artery of the country and has many tributaries, which help water the southern, warm kingdom and keep its fields fertile.

## Note on the maps
The legend 'River Andahar' is applied only to the lower course of the river and it is unclear which part of the upper course is the main river and which parts are the tributaries. It is therefore possible that the Andahar's source is [[Lake Somal]] instead of the mountains.






https://wot.fandom.com/wiki/Andahar