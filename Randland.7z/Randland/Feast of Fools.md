---
tags: [Holidays]
---
**Feast of Fools** is celebrated during the month of Tammaz (in [[Arad Doman]] and the [[Borderlands]]) and Shaldine (everywhere else), the exact day varying according to locality. A day in which all order of rank is flip-flopped: people of high status perform lowly tasks, while the low do no work and give orders to their usual superiors. In many villages and towns the most foolish person is given a lofty but foolish title, and for that one day everyone has to obey whatever orders the chosen one gives. Celebrations for this holiday can include wearing of masks, pranks, and the exchange of sweets and small pastries.
Alternate names for this holiday include:

Foolday - in [[Two Rivers]] and [[Baerlon]]
Festival of Unreason - in [[Saldaea]]
Festival of Fools - in [[Kandor]]
In [[Tear]], [[Illian]], and the southern half of [[Altara]], the time between the [[Feast of Abram]] and the Feast of Fools is considered the most propitious for a wedding.

## Notes






https://wot.fandom.com/wiki/Feast_of_Fools