---
tags: [Disambiguation, Chapterdisambiguations]
---
**Spear** can refer to the following:

## Chapter titles
*Maidens of the Spear* - the thirty-eighth chapter of *The Dragon Reborn*.
*The Road to the Spear* - the twenty-fifth chapter of *The Shadow Rising*.
*A Short Spear* - the thirty-second chapter of *The Fires of Heaven*.
*Spears* - the fortieth chapter of *A Crown of Swords*.
## Groups
*Cor Darei* - an Aiel warrior society, meaning "Night Spears" in the Old Tongue.
*Far Dareis Mai* - an [[Aiel]] [[Aiel warrior society|warrior society]], meaning "Maidens of the Spear" in the Old Tongue, whose members are all women.
*Siswai'aman* - "Spears of the Dragon" in the [[Old Tongue]].
## Weapons
*Ashandarei* - pole-arm weapons with a short blade at the end, whose name in the Old Tongue menas "sword spear."
The [[Dragon Scepter]] - a piece of a [[Seanchan]] spear that [[Rand al'Thor]] used as a scepter.
## Other
[[Siswai]] - a horse owned by [[Aviendha]].
*darei* - one of the words which means "spear" in the Old Tongue.
*siswai* - one of the words which means "spear" in the Old Tongue.
## See also
[[Blade]]
[[Dagger]]
[[Knife]]
[[Sword]]


https://wot.fandom.com/wiki/Spear