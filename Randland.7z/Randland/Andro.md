---
tags: [Men, Warders, Deceased, ]
---


**Andro** was the [[Warder]] of [[Meilyn Arganya]]. 

## Appearance
He was lean, dark and no taller than Meilyn. He appeared youthful and had an unblinking gaze.

## History
Andro was with Meilyn when she visited [[Moiraine Damodred]] and [[Siuan Sanche]], who were taking names of babies just born. It is assumed he died with Meilyn, either when she was killed by the [[Black Ajah]] or soon thereafter due to her death.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Andro