---
tags: [Men, Mayene_people, Soldiers, LivingasofWH, WingedGuard]
---


**Havien Nurelle** is the current Lord Captain of the [[Mayene]] [[Winged Guards]].

## Appearance
He has pink cheeks, is slender and a head shorter than [[Rand al'Thor]]. He is about the same age as [[Perrin Aybara]]. As Lord Lieutenant, his uniform was a red-painted breastplate and a single red plume. After the [[Battle of Dumai's Wells]], he wears a yellow cord tied high on the left arm.

## Activities
Nurelle was first seen in [[Cairhien]], having accompanied [[Berelain]], [[First of Mayene]], to the city when Rand summoned her for her assistance in governing the country.  He was in command of the soldiers she brought with her and held rank of Lord Lieutenant.
When Rand was kidnapped by [[Aes Sedai]] of the [[White Tower]] from the [[Sun Palace]] in Cairhien, Nurelle and his detachment of [[Winged Guards]] joined Perrin and the [[Aiel]] to rescue Rand. During the journey, Perrin notes that he is quite friendly with [[Dobraine Taborwin]], often sharing an evening meal with him, and spends time smoking a pipe with the Aiel,  especially [[Gaul]], a friendliness with the Aiel that is unusual in the Westlands.  From Gaul's conversations, he is very impressed with Perrin's campaign against the [[Trollocs]] in the [[Two Rivers]], a respec that bordered on hero-worship. He fought in the Battle of Dumai's Wells. For his efforts in that battle, he was named second to [[Bertain Gallenne]], Captain of the Winged Guards, and awarded the rank [[First Lieutenant]].
He accompanies Perrin and Berelain into [[Ghealdan]] to track down [[Masema Dagar]].
After the death of Bertain Gallenne, he becomes Lord Captain of the Winged Guards.

### References






https://wot.fandom.com/wiki/Havien_Nurelle