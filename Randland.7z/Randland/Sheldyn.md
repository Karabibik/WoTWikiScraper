---
tags: [Andor, Places]
---
**Sheldyn** is an estate in [[Andor]] held by the Lady [[Ellorien Traemane]].






https://wot.fandom.com/wiki/Sheldyn