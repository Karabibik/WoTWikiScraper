---
tags: [Inns]
---
**The Long Man** is an inn in [[Cairhien (city)|Cairhien]].

## Activites
The Long Man is located near Lady [[Arilyn Dhulaine]]'s palace. When [[Egwene al'Vere]] runs into [[Gawyn Trakand]] near the palace, he takes her to The Long Man so that they can talk. They spend the entire morning there and agree to meet there every morning. Before departing for [[Salidar]], Egwene sends [[Cowinde]], and [[Aiel]] *gai'shain* to The Long Man with a note for Gawyn.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Long_Man