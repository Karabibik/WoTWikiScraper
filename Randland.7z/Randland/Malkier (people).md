---
tags: [Malkier]
---
**Malkieri** are people from dead Malkier. Some still survive to the present day, though many have given up the ways of the Malkieri.






https://wot.fandom.com/wiki/Malkieri