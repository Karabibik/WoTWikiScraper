---
tags: [Women, Aiel_people, WiseOnes, Shaido, LivingasofACOS, Channelers]
---


**Micara** is a [[Wise One]] of the [[Shaido]] [[Aiel]]

## Appearance
She is pretty with red hair and a delicate mouth.

## Strength and Abilities
Micara can [[Channel|channel]] with a bit of strength. In TWoTC her strength level is described as 27(15), which is a middle ranking level among [[Aes Sedai]].
This strength is not enough to open alone a gateway for [[Travel|Traveling]].

## Activities
She is relatively weak in the [[One Power]]. She holds [[Galina Casban]] shielded after the [[Battle of Dumai's Wells]] as a reminder of how weak Galina has become.






https://wot.fandom.com/wiki/Micara