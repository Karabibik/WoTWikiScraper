---
tags: [Women, Amadicia_people, Seanchan_people, Seamstresses, LivingasofKOD, Eyes-and-ears]
---


**Ronde Macura** is a dressmaker in the village of [[Mardecin]], a small village in [[Amadicia]]. She also serves as an eyes-and-ears of the [[Yellow Ajah]], reporting to [[Narenwin Barda]]. 

## Appearance
She was middle aged, handsome, dark eyed, and had her dark hair worn in a neat array. She was about 5'4" tall. 

## Activities
When she encounters [[Nynaeve al'Meara]] and [[Elayne Trakand]] on their trip to [[Salidar]], she recognizes them instantly from her orders from [[Elaida a'Roihan's White Tower|Elaida's White Tower]]. In order to capture the two for transport back to the [[White Tower]] she drugs them with [[Forkroot|forkroot]] tea and hides them in her upstairs bedroom. The two girls are rescued by [[Thomdril Merrilin]] and [[Juilin Sandar]], who come looking for them after they fail to return to their camp. After Elayne and Nynaeve resume their trip to Salidar, Ronde sends a report to the Tower reporting her failure.
When [[Elaida do Avriny a'Roihan]] hears of this failure she orders that Ronde be severely punished for failing in her mission to capture the two runaways. For punishment, Ronde is strapped in the village square making her an example of what failure brings to someone who had markedly displeased Aes Sedai.
Because of her public humiliation and punishment by [[Aes Sedai]], Ronde now carries a passionate hatred for all Aes Sedai. This hate leads her to plead to serve the [[Seanchan]] and she is taken into [[Tuon Athaem Kore Paendrag]]'s service. She then gives the Seanchan the secret of forkroot, which allows for them to effectively capture both [[Wilder|wilders]] and Aes Sedai that are within their territory, she is richly rewarded. Ronde becomes part of [[Tuon]]'s entourage, but she behaves awkwardly, not being fully conversant with the proper protokols. 

## Notes






https://wot.fandom.com/wiki/Ronde_Macura