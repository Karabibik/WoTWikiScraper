---
tags: [Weaves]
---
The **Shield of Air** is a weave in the [[One Power]]; it is a specific kind of the [[Hardened Air]] weave, and it is used as protection against enemy attacks.
The shield can take any shape and dimension, from a simple wall to a great dome over a large portion of the ground. Depending on its hardness it can repel totally a projectile from an adversary or more simply slow the run of some arrows, to make them drop on the ground before they can touch their objective harmfully.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Shield_of_Air