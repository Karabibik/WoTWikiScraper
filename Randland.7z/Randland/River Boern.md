---
tags: [Rivers, Ghealdan]
---

The **River Boern** is a river that flows through [[Ghealdan]]. It flows out of the [[Mountains of Mist]] and passes through [[Jehannah]] on its way to [[Boannda]], where it joins the [[River Eldar]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/River_Boern