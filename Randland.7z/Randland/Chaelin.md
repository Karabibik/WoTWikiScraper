---
tags: [Women, Aiel_people, WiseOnes, Miagoma, SmokeWater, LivingasofTPOD, Channelers]
---


**Chaelin** is an [[Aiel]] [[Wise One]] of the [[Smoke Water]] [[Miagoma]] clan.

## Appearance
She has touches of gray in her hair.

## Strength and Abilities
Chaelin can [[Channel|channel]] quite strongly. In TWoTC her strength level is described as 19(7), the same level of [[Tamra]] and [[Gitara]], which is a high ranking level among [[Aes Sedai]].
This strength is more than enough to open alone a gateway for [[Travel|Traveling]].

## Activities
She is one of the many Wise Ones who settle into [[Cairhien]] after the battle with the [[Shaido]].
It can be assumed that during the [[Last Battle]] she fights in [[Thakan'dar]] Valley along the other Wise Ones.






https://wot.fandom.com/wiki/Chaelin