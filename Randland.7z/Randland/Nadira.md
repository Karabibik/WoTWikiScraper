---
tags: [Women, BlueAjah, AesSedai, CharactersonlymentionedintheRPG, Channelers]
---


**Nadira** is an [[Aes Sedai]] of the [[Blue Ajah]]. Her [[Warder]] is [[Gable]].

## History
Nadira was communicating with [[Megda]] of the [[Green Ajah]] via *ter'angreal* when the other woman went to [[Toman Head]] to investigate claims of women harming others with the [[One Power]]. Communication stopped after Megda was taken *damane* by the [[Seanchan]], which worried Nadira, who went to the village of [[Aturo's Orchard]] on the border of [[Almoth Plain]] and Toman Head.
Nadira later traveled to [[Tanchico]], where she began investigating the activities of [[Belyne]] Sedai, and learned that Megda had been able to escape [[Falme]] when the city was attacked by the [[Heroes of the Horn]].

## Notes






https://wot.fandom.com/wiki/Nadira