---
tags: [ItemsofPower, Terangreal]
---
The golden **shadowed moon** ornament is a *ter'angreal* in the possession of [[Cadsuane Melaidhrin]] as a part of her [[Paralis-net|paralis-net]].

## Appearance
It has the shape of a shadowed moon, pending from a golden hair needle. It is a full moon disc with a part chiseled leaving a brightly burnished crescent.

## Use
The use of this Cadsuane's ornament and two others is unknown. But from the fight against [[Semirhage]] we know also that Cadsuane has an unknown *ter'angreal* that disrupts weaves at close proximity, so the golden shadowed moon can be the one among the three with this abilities.






https://wot.fandom.com/wiki/Shadowed_moon