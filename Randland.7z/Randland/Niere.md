---
tags: [Women, YellowAjah, AesSedai, LivingasofTOM, Charactersnamedafterfans]
---


**Niere** is an [[Aes Sedai]] of the [[Yellow Ajah]].

## Activities
Niere is one of only three Yellow sisters who accepts [[Nynaeve al'Meara]] as a full sister before she is actually raised.

## Trivia
Niere is named for a fan of *The Wheel of Time* named Deborah, whose username was Niere al'Aman.
## Notes






https://wot.fandom.com/wiki/Niere