---
tags: [Men, Andor_people, TwoRivers_people, LivingasofTSR]
---






**Eward Congar** is a man from [[Emond's Field]].

## Activities
Eward, like some of [[The Congars and the Coplins|his family]], are somewhat arrogant. [[Matrim Cauthon]] once thought that a group of [[Whitecloaks]] reminded him of Eward. Later, when the Whitecloaks came to the [[Two Rivers]], Eward, along with [[Hari Coplin]] and [[Wit Congar]], fawn over them. This leads [[Marin al'Vere]] to warn [[Perrin Aybara]] that the group may alert the Whitecloaks that Perrin had returned to his home village.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Eward_Congar