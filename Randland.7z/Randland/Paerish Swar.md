---
tags: [Forests]
---

**Paedish Swar** or "The Darkwood" is a forbidding, large forest on the eastern edge of [[Almoth Plain]], and marks the edge of that territory. The Darkwood blocks easy access to [[Lake Somal]] to the east. It is unknown if the Darkwood is inhabited, but forces of [[Dragonsworn]] did operate in this region during their war with both [[Tarabon]] and [[Arad Doman]]. [[Katar]] is the nearest large city to this region.






https://wot.fandom.com/wiki/Paedish_Swar