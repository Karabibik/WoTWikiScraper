---
tags: [Rulers]
---
Women in positions of royal power over nations.






https://wot.fandom.com/wiki/Queen