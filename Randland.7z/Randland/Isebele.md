---
tags: [Women, DalCalain_people, Rulers, Queens, Deceased, Historicalpeople]
---


**Isebele** was once Queen of [[Dal Calain]].

## History
She was so powerful and willful she even summoned the then-[[Amyrlin Seat|Amyrlin]] [[Anghara]] to visit her for an audience. This is either evidence of Isebele's and Dal Calain's power having stretched further than the national borders, or of Anghara having been an extremely weak Amyrlin Seat (or maybe a combination of both circumstances: a relatively weak Amyrlin confronted by a powerful leader).






https://wot.fandom.com/wiki/Isebele