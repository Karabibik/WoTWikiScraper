---
tags: [Wolves, Deceased]
---


**Whisperer** was a female [[Wolf|wolf]].

## Activities
Whisperer is one of the wolves [[Perrin Aybara]] meets in *Tel'aran'rhiod* and joins him on his hunt of the white stag.
She is later shot and killed by [[Slayer]].

## Notes






https://wot.fandom.com/wiki/Whisperer