---
tags: [AesSedai, Ashaman]
---
The **concentration technique** (sometimes called "the trick") is used by [[Aes Sedai]] and [[Asha'man]]. This technique allows the person to not feel the surrounding temperature.

## Contents

1 Technique
2 Learning the "trick"
3 Parallels
4 Notes


## Technique
The concentration technique is done by breathing and focusing inwards. As explained by [[Natasia]] to [[Moiraine Damodred]], one's "mind must be as still as an unruffled pond throughout." She goes on the explain that one must focus on a point behind ones' navel and breathe at an unvaried pace, but not as normal breathing. Each inhalation, exhalation and the spaces between must take exactly the same length of time. This breath and focus causes the mind to become detached from the outer world, acknowledging neither heat nor cold. A person using this technique could travel through a blizzard or across a desert and not shiver or sweat. While the person would not feel the heat or cold, sunburns and frostbite would still occur after a time. As Natasia explained, "only the mind is truly distanced, the body much less so."

## Learning the "trick"
Upon gaining the [[Shawl|shawl]], new Aes Sedai are taught this technique. Asha'man are also taught the technique, originally by [[Mazrim Taim]], but it is unknown from where he learned it. Taim was the person who taught [[Rand al'Thor]] the technique.
[[Min Farshaw|Min]] tried to learn the trick, but was not able to. Supposedly, the trick is not related to channeling ability; but no known non-channeler can perform it. It is possible that the concentration required to channel helps channelers master it.

## Parallels
The technique's description is exactly the same as the real-world exercise called . The effect is of course rather different. 
The effect does bear some resemblance to the practice of , albeit at a lower intensity.

## Notes






https://wot.fandom.com/wiki/Concentration_technique