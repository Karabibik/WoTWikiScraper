---
tags: [Men, Cairhien_people, Lords, HighSeats, Deceased, Blademasters, Nobility]
---




Lord **Toram Riatin** was [[High Seat]] of [[House Riatin]]. His sister is [[Ailil Riatin]], and he is related to [[Galldrian Riatin]], the former king of [[Cairhien]].

## Contents

1 Background
2 Appearance
3 Activities

3.1 Rebellion
3.2 In the woods
3.3 Blinded by hate




## Background
Toram was tall for a Cairhienin, something he took great pride in. In fact, he took pride in everything, and was called arrogant and overbearing by many, including his sister. He was also jealous to a fault, taking great offense at perceived attempts to appropriate things (or people) he viewed as "his". He is also a Blademaster after having been judged by five Blademasters.

## Appearance
He was tall and slender, and considered extremely good-looking. He could be possessive and arrogant, however.

## Activities
### Rebellion
After [[Couladin]] and the [[Shaido]] assault [[Cairhien]], Toram and [[Caraline Damodred]] took up arms in the foothills of the [[Spine of the World]], opposing [[Rand al'Thor]]'s *de facto* leadership of the city (and country). They were unable to take action, however, until [[Colavaere Saighan]] laid claim to the [[Sun Throne]] following Rand's disappearance from the city. As House Riatin ruled until Galldrian's death, Toram did not support Colavaere's claim and prepared a siege of the city. Rand's sudden return following the [[Battle of Dumai's Wells]] caused the rebels to retreat to a wooded area south of the city. He acquired a new advisor there, [[Padan Fain|Jeraal Mordeth]], and an unrequited love interest in Caraline.

### In the woods
Despite the massing of both Cairhienin and [[Tear|Tairen]] rebels in the woods, Rand did nothing about them for several days. When he did go to investigate them, in disguise and secretly, Toram offered to spar with him, using [[Practice sword|practice swords]]. What was once considered a [[Bubble of evil|bubble of evil]], but now believed to be a manifestation of Padan Fain's [[Mashadar]] born power, interrupted their mock combat, and Toram used the distraction to strike a hard blow to Rand's side, before realizing the full extent of the danger they were all in. He allied himself with Rand's group (which also included [[Cadsuane Melaidhrin]] and several other [[Aes Sedai]] who were meeting with the rebels) until he discovered who Rand actually was, at which point he ran away through the fog.

### Blinded by hate
Miraculously, Toram survived the bubble of evil and reunited with his advisor, Jeraal Mordeth. He became even more obsessed with opposing Rand, and lie in wait for him at [[Far Madding]]. Despite the element of surprise and his skill with a sword, he was unsuccessful in his ambush attempt and was killed by [[Lan Mandragoran]].






https://wot.fandom.com/wiki/Toram_Riatin