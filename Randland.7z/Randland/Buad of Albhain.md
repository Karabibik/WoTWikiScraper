---
tags: [Women, HeroesoftheHorn, HuntersoftheHorn, BoundtotheWheel, Historicalpeople, Parallels]
---


**Buad of Albhain** is a historical character bound to the [[Wheel of Time]] as a [[Hero of the Horn]], who is part of the legendary saga of [[The Great Hunt of the Horn]] - specifically a tale called *The Last Ride of Buad of Albhain*.

## Contents

1 Occurrence as hero
2 Occurrence as story
3 Parallels
4 Male or female?
5 Notes


## Occurrence as hero
Buad is called back when [[Matrim Cauthon]] blows the [[Horn of Valere]] in [[Falme]] and when Olver blew the Horn of Valere at the [[Field of Merrilor]].

## Occurrence as story
[[Thom Merrilin]] tells this tale at the [[Stag and Lion]] in [[Baerlon]].

## Parallels
Buad of Albhain is a parallel to Queen Boadicea (who is now named ) who was a famous queen of the Britons who led a rebellion against the Roman Empire. Her husband had been king of the Iceni tribe, who had been voluntary allies of the Romans, and on his death they called in the debts he had owed them and/or annexed his kingdom by force. It is reported that Bodica herself was flogged and her daughters raped. Boudica then was chosen as a leader of a rebellion against the Romans. After an impressive campaign of defiance that left three cities destroyed and many thousands of Roman forces and allies dead, Boudica's army faced defeat at the . She rode into battle on a war chariot, accompanied by her daughters. This is an apt parallel to the *Last Ride of Buad*. 
This link comes from the similarity of the names of Baud and Boadicea and the fact that  is a common pseudonym for Great Britain, especially in reference to ancient Britain, and is similar to Albhain.

## Male or female?
For long it was speculated which gender Buad was, since it was not obvious to determine from her name, nor was it ever mentioned. However, as the Horn was sounded by [[Olver]] during the [[Last Battle]], Buad was described as being "as regal as any queen," once and for all solving the riddle.

## Notes






https://wot.fandom.com/wiki/Buad_of_Albhain