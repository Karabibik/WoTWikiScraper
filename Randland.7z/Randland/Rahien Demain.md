---
tags: [Men, Kandor_people, Lords, LivingasofNS, Nobility]
---






Lord **Rahien Demain** is the son of Lady [[Ines Demain]]. He was born at the end of the [[Aiel War]].

## History
Born two miles from [[Dragonmount]] in a farmhouse, Rahien's name in the [[Old Tongue]] means "dawn." He was on [[Moiraine Damodred]]'s list of possible boys who could be the [[Dragon Reborn]].
When Moiraine Damodred comes to [[Chachin]] in [[Kandor]], she tries to speak with Rahien's mother. She never gets the chance because Rahien's father had died recently and his mother was in seclusion in the [[Aesdaishar Palace]]. Because he was born the day after [[Gitara Moroso]]'s [[Foretelling]], Moiraine learns that he can't be the Dragon Reborn.

## Notes






https://wot.fandom.com/wiki/Rahien_Demain