---
tags: [ItemsofPower]
---

A **Traveling box**, or *nar'baha* ("fool box" in the [[Old Tongue]]), is a small box that supposedly uses *saidin* to enable [[Traveling]]. In reality, the box has no purpose.

## Appearance
A traveling box is a gray stone cube, smaller than a [[Callbox|callbox]], marked only with a red disk on one face.

## Usage
[[Sevanna]] obtains a callbox from [[Caddar]], a [[Wetlander|wetlander]] she met near [[Dumai's Wells]], and summon hims after the [[Battle of Dumai's Wells]]. However, Caddar is actually [[Sammael]]; he arrives accompanied by [[Graendal]] as [[Maisia]], both disguised using the [[One Power]]. When Sevanna asks that the [[Wise One|Wise Ones]] supporting her be taught to Travel by Maisia, he offers to provide traveling boxes instead.
Upon his return, Caddar shows Sevanna the traveling boxes. According to him, they will not work for several days if a woman touches them, which means he will have to hand them out himself. In addition, the gateway created by a traveling box will stay open for a fixed period of time and needs three days to recharge.
Sevanna divides the [[Shaido]] into groups. Each group receives a box and departs through its gateway. However, the gateways are actually made by Sammael; all the gateways but the last are tied off and allowed to close on their own.
[[Maeric]] leads one group through a gateway, about six thousand people total. It includes his sept (the [[Moshaine]]), their *gai'shain*, and a large group of the [[Mera'din|Brotherless]]. It closes prematurely, slicing through ten of the Brotherless and stranding Maeric's son [[Darin]], a [[Stone Dog]], and his daughter [[Suraile]], a [[Maiden]], with the rear guard. They are caught between three groups of armed men numbering at least thirty-five thousand. Maeric leads the *algai'd'siswai* to fight, leaving his wife [[Dyrele]] and a blacksmith in charge. Although he hopes to buy time for the rest of his people, he believes his warriors will all die and all the other Aiel will be made *gai'shain*.
Sevanna takes every Shaido Wise One who can channel with her through her gateway. After all the gateways have closed, Sammael tells Graendal that he scattered the Shaido.
To indicate to [[Sevanna]] how the Shaido dislike being gathered around the city of Maldan, [[Therava]] tells her, “Many of the sept chiefs press the red disc on their nar’baha every morning,” showing that the chiefs wish the boxes to work again allowing them to Travel, not realizing they never really worked at all.

## Notes






https://wot.fandom.com/wiki/Nar%27baha