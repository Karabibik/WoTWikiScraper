---
tags: [Men, Ghealdan_people, Innkeepers, LivingasofTDR]
---


Master **Harod** is the innkeeper of the [[Harilin's Leap]], in [[Jarra]], [[Ghealdan]].






https://wot.fandom.com/wiki/Harod