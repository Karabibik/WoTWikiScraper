---
tags: [Inns, Kandor]
---



**The Silver Penny** is an inn located in the [[Kandor|Kandori]] capital of [[Chachin]]. It is located within the first ringwall of the city in a disreputable, run-down district. Despite its unsavory surroundings, the inn itself was mostly clean and relatively hospitable compared to its neighbors.
[[Moiraine Damodred]] visited the inn in 979 NE, whilst trying to find [[Siuan Sanche]] for an arranged rendezvous. The innkeeper, [[Nedare Satarov]], attempted to drug Moiraine for unknown but presumably unsavory purposes, until Moiraine made her drink the drug instead.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Silver_Penny