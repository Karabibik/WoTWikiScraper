---
tags: [Men, Warders, Deceased]
---


**Karile** (pronounced: kah-REEL) was [[Warder]] to [[Kerene Nagashi]]. 

## Contents

1 Appearance
2 Activities
3 In the television series
4 Notes


## Appearance
He had golden hair and a beard and was a giant of a man.

## Activities
He left the [[White Tower]] with Kerene, when she was sent by [[Tamra Ospenya]] to find the newly born [[Dragon]]. It is assumed he died with Kerene, when she was murdered by the [[Black Ajah]].

## In the television series
Karile does not appear in the television series.  
## Notes







https://wot.fandom.com/wiki/Karile