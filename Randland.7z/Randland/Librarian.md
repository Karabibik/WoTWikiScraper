---
tags: [AesSedai, Librarians]
---

**Librarians** are those who work in a library. The biggest library known is the [[White Tower Library]] and as such, most known librarians are [[Aes Sedai]], specifically of the [[Brown Ajah]] as they are dedicated to the preservation of knowledge and history. Other major libraries include the [[Royal Library of Cairhien]], the Royal Palace Library in the [[Royal Palace of Andor|palace]] in [[Caemlyn]], and the [[Terhana Library]] in [[Bandar Eban]].

## Contents

1 Known Librarians

1.1 White Tower Library
1.2 Royal Palace Library in Caemlyn


2 Notes


## Known Librarians
### White Tower Library
[[Aiden]]
[[Namine Tasil]]
[[Nyein]]
[[Zemaille]]
[[Shemari]]
### Royal Palace Library in Caemlyn
[[Milam Harnder]]
## Notes






https://wot.fandom.com/wiki/Librarian