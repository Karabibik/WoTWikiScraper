---
tags: [Men, BandoftheRedHand, Soldiers, LivingasofKOD, ]
---


**Dongal** is a soldier in the [[Band of the Red Hand]].

## Activities
[[Mandevwin]] orders him to take his men up the south slope of the valley in preparation for the ambush on the [[Altaran]] conscripts.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Dongal