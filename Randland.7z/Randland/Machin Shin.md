---
tags: [Extradimensionalentities, Antagonists]
---
***"Flesh so fine, so fine to tear, to gnash the skin; skin to strip, to plait, so nice to plait the strips, so nice, so red the drops that fall; blood so red, so red, so sweet; sweet screams, pretty screams, singing screams, scream your song, sing your screams..."*
   —*Machin Shin*, The Black Wind  **
*Machin Shin* is an entity that resides in the [[Ways]], also known as the **Black Wind.** It kills, drains the victim's soul or drives insane, almost every living thing it comes in contact with, making it the reason why the Ways have now become unsafe to travel. The exact nature of *Machin Shin* is unknown, as are its origins.

## Contents

1 Early history
2 Description
3 Theories of Origin
4 External links
5 Notes


## Early history
Even some time after the [[Ways]] began to darken, travelers could still pass through them safely. It was not until the darkness began to deepen into blackness that individuals started to disappear. As the darkness increased, so did the rate of disappearances. Additionally, some who traveled the Ways arrived physically at their destination, but were mentally savaged. Some were seemingly dead, with no sign of mental function or a soul. Others were driven insane, terrified of the slightest breeze. Those capable of speech spoke of a "black wind" that now lived among the Ways.
Eventually, all the mysterious disappearances in the Ways, and the harm that befell other travelers, were attributed to this black wind, *Machin Shin*.

## Description
*Machin Shin* appears to be some sort of semi-sentient entity made up of darkness that flows like air. Survivors of encounters with *Machin Shin* tell of feeling a light breeze in the Ways preceding its arrival, easily noticed as there is normally no wind in the Ways. They also speak of hearing thousands of screaming voices, which might manifest as rambling monologue obsessed with blood, screams, violence and terror. Some seem to hear the screams separately from the monologue. [[Padan Fain]] is the only being yet that was released by the wind after it was caught and Fain speaks about some voices greeting and some even fearing him. It also can identify people, as when Rand first encountered it zeroed in on Rand's blue-gray eyes and the monologue began including begging or threatening to take his eyes for its own.
Exactly what occurs when *Machin Shin* fully envelopes someone is not known, except for some of its effects, insanity or a waking death. The soulless nature, and mental activity, of some survivors has been compared to that of victims of a [[Draghkar|draghkar]]'s kiss, leading some to believe that *Machin Shin* doesn't simply kill its victims, but steals their souls as well.

## Theories of Origin
There are many theories concerning the origin and nature of *Machin Shin*. All attribute its malevolent nature to the darkening of the Ways, and therefore to the taint on *saidin.* Also, most are somewhat incomplete and conjectural in nature, due to a lack of knowledge on the [[Ways]] themselves.

The first theory states that *Machin Shin* was somehow spawned from the corruption of the ways by *saidin.* It is assumed that the otherworldly nature of the Ways, along with the power of the taint, would be sufficient to create this new entity. Perhaps just as new Ways were able to be grown, so also were other aspects of that world. *Machin Shin* might simply be the twisted growth that sprang from it.
The second theory is that *Machin Shin* was originally a functional part of the Ways, before their darkening. As the impact of the taint spread, whatever purpose, or form, *Machin Shin* originally had was corrupted as well, twisting it into what it is today. Adherents to this theory point to the gradual increase in disappearances as the Ways darkened, almost as if the original *Machin Shin* became increasingly pulled off track as the blackening of the Ways increased.
A third, less known theory suggests that it was a remnant of the War of the Shadow that hid in the Ways and cannot find a way out.
Another possibility is that, since the Ways were alive and most living things have parasites, the wind was originally a parasite that became corrupted by the taint increasingly as the ways darkened.
It may also have been something like a transport device.  Since it would need to be tangible enough to engulf someone, it could have been stepped on or laid in and then used to fly to another Waygate to get around faster.
Machin Shin could also have spawned from the taint in Shadar Logoth.  This theory supports the mystery behind Padan Fain being able to control Machin Shin.
Machin Shin could have originally been a safety device used to prevent someone from falling forever or perhaps a cleaning device to remove any debris that had fallen off of the Ways, and was then corrupted by the taint.
Machin Shin, and the corruption of the Ways, could be the work of Ba'alzamon.  The corruption only began during the War of the Hundred Years, roughly during his third stint of freedom from the Bore, despite the Ways having been in existence for nearly two thousand years by this point.
## External links
 
## Notes






https://wot.fandom.com/wiki/Black_Wind