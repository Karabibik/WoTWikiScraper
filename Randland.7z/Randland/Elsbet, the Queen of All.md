---
tags: [Women, Rulers, Queens, Legends, Parallels, FirstAge]
---



*"Was Elsbet really queen of the whole world, and was Anla really her sister?"*
   —Thom Merrilin 
**Elsbet, Queen of All** is a character in several of the ancient [[Stories|stories]] in [[Thom Merrilin|Thom Merrilin's]] repertoire that date to the [[First Age]].  These tales assert that Elsbet was the queen of the entire world and a sister of [[Anla the Wise Counselor]].  Elsbet engaged in wars against [[Mosk the Giant]] who had a "lance of fire that could reach around the world".  The tales of Mosk and Elsbet are examples of historical accounts that over time evolved into legends which further changed and faded into myth.  This is common for all stories that transcend multiple ages as the [[Wheel of Time]] turns.  Eventually the myth of Elsbet will disappear from memory and will be long forgotten when the age that gave rise to the original story comes again.

## Parallels
Elsbet is a hidden reference to  of the United Kingdom.  Mosk is a hidden reference to  and his lance of fire refers to combat waged via the use of .  The wars between Elsbet and Mosk imply a series of conflicts between the United Kingdom and the U.S.S.R. who were adversaries during the cold war of the 20th century.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Elsbet,_the_Queen_of_All