---
tags: [HerbsandMedicines]
---
**Timsin root** is a root used in tea to alleviate a headache. It was once mixed with [[Silverleaf|silverleaf]] in a tea for [[Matrim Cauthon|Mat Cauthon]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Timsin_root