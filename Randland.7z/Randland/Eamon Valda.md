---
tags: [Men, ChildrenoftheLight, Soldiers, Deceased, LordCaptainCommanders, Blademasters, POVcharacter, LordCaptain]
---


**Eamon Valda** was a Lord Captain Commander of the [[Children of the Light]], succeeding [[Pedron Niall]] after his assassination.

## Contents

1 Appearance
2 History
3 Activities
4 In the television series
5 Notes


## Appearance
He was of average height with a hard, dark face.

## History
He was a member of the [[Council of the Anointed]], serving under Pedron Niall.
He had achieved [[Blademaster|blademaster]] status, being so judged unanimously by five other blademasters.

## Activities
Eamon Valda was sent by Pedron Niall to foment dissent in [[Caemlyn]] but stopped to follow [[Elayne Trakand]] when she began her journey to the [[White Tower]].
He encountered [[Galadedrid Damodred]], to whom he gave a copy of the book *The Way of the Light*, the basic treatise that defines the Children, and then proceeded to accept him into the Whitecloak ranks. Niall sent word to him that he was to go to [[Amador]] but Valda returned instead to the [[Fortress of the Light]] and began plotting with the [[High Inquisitor]] of the Children of the Light [[Rhadam Asunawa]] to kill Niall. After [[Abdel Omerna]] killed Niall with the encouragement of Valda, he barged into Niall's office and killed Omerna; it was this setup that allowed him to become the Lord Captain Commander. To further protect himself Valda staffed the Fortress with Whitecloaks loyal only to him. He then forced [[Morgase Trakand]] to submit to his authority on paper, as well as raping her before leaving to go north to deal with the Prophet of the Dragon, [[Masema Dagar]].
He engaged the [[Seanchan]] in the [[Battle of Jeramel]] and was forced to retreat without much loss to his forces. He later formed an alliance with the Seanchan and was given a new headquarters.
It was shortly after this event that Valda was confronted by Galad about his abuse and supposed murder of Morgase, Galad's mother by adoption. Galad challenged him to [[Trial Beneath the Light]], an archaic practice of single combat. In the ensuing sword fight Galad slew Valda, though Galad received numerous minor injuries.

## In the television series
In the [[The Wheel of Time (TV series)|TV series]],  
## Notes

|**Major Characters**|
|-|-|
|**Protagonists**|**Main:****Primary:**|
|**Antagonists**|**The Shadow:**|
|**Major Allies**|**Aes Sedai:****Asha'man:****Aiel:****Seanchan:****Westlands Rulers:****Other Allies:**|
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Valda