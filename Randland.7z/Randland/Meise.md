---
tags: [Women, Aiel_people, Unknownoccupation, Unknownclan, Foreseenpeople]
---


**Meise** is one of the Aiel [[Aviendha]] sees in her visions of the future in the [[Glass columns]] *ter'angreal* in [[Rhuidean]].
She is one of the children of [[Norlesh]] and [[Metalan]].
Meise is one of their two remaining children. She stopped talking after her older brother was lost due to exposure. She had also lost two other siblings before this. 
After her parents visit an outlander camp they are walking away and Meise sniffles, but her parents do not have the energy to carry her and her remaining sibling [[Garlvan]] dies in her mother's arms while walking.






https://wot.fandom.com/wiki/Meise