---
tags: [Women, Saldaea_people, LivingasofLOC]
---


**Teryane** is a [[Saldaean]] woman.

## History
She is the daughter of a merchant.
She is betrothed to [[Vilnar Barada]].

## Activities
Her betrothed thinks of her when he is on patrol on [[Caemlyn]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Teryane