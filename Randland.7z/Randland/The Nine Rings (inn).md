---
tags: [Inns, Cairhien]
---

**The Nine Rings** is an inn in [[Cairhien]] where [[Rand al'Thor]] stays with [[Selene]], [[Hurin]] and [[Loial]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/The_Nine_Rings_(inn)