---
tags: [Swordforms]
---


**Kingfisher Circles the Pond** is a [[Sword form|sword form]]. It was used in a fight between [[Galadedrid Damodred]] and [[Eamon Valda]]. Galad was barely able to use this form when Valda attacked with [[The Dove Takes Flight]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Kingfisher_Circles_the_Pond