---
tags: [Disambiguation]
---
The title **High Lady** can refer to the following:

[[High Nobility of Tear|High Lady of Tear]] - part of the former ruling body of [[Tear]].
[[The Blood|High Lady of Seanchan]] - a member of the High Blood of the [[Seanchan]].


https://wot.fandom.com/wiki/High_Lady