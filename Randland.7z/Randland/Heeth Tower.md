---
tags: [Kandor, Othernotablebuildings]
---



**Heeth Tower** is a [[Kandor|Kandori]] border tower that lies on the edge of the [[Blight]] border, under the command of [[Malenarin Rai]]. It is part of a chain of watchtowers to guard against the Blight. The chain uses a combination of mirrors to warn and communicate with other towers in the chain all the way to the capital of [[Chachin]].






https://wot.fandom.com/wiki/Heeth_Tower