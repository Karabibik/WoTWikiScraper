---
tags: [, Taardad, Aielsepts]
---



The **Bloody Water** is a sept of the [[Taardad]] [[Aiel]]. The sept hold is unknown. On their way to [[Alcair Dal]], [[Rand al'Thor]] and the [[Jindo]] are joined by other Taardad septs including the [[Nine Valleys]], [[Chumai]], [[Four Stones]], Bloody Water and [[Miadi]] septs.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Bloody_Water