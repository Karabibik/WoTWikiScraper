---
tags: [Men, Saldaea_people, Clerks, LivingasofKOD]
---


**Ruthan** is a [[Saldaea|Saldaean]] clerk, who works for [[Weilin Aldragoran]].

## Appearance
Ruthan has hard eyes.

## Activities
When Weilin Aldragoran concludes is gem deal with [[Jeorg Damentanis]] and [[Pavil Geraneos]], Weilin has Ruthan put the money in a strong box. Though he looks dangerous, he does not know one end of a sword from the other.






https://wot.fandom.com/wiki/Ruthan