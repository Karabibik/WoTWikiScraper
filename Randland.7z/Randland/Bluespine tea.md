---
tags: [, HerbsandMedicines]
---



**Bluespine** is an [[Herbs|herb]] found in the [[Aiel Waste]]. A [[Wise One]] will brew a tea of bluespine, which has an exceptionally bitter taste, and administer a dosage to someone she feels is being disagreeable. Bluespine tea "cures" sullenness, sulkiness, or foul-mouthed language.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Bluespine_tea