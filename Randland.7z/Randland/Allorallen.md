---
tags: [Cities, Ruins, Historicalsettlements, Jaramide]
---
**Allorallen** was a city of [[Jaramide]]. During the [[Trolloc Wars]], Allorallen was destroyed, and the entire country fell at the war's end. [[Arad Doman]]'s present-day capital [[Bandar Eban]] was built over the ruins of Allorallen.






https://wot.fandom.com/wiki/Allorallen