---
tags: [Malkier]
---
**Herot's Crossing** was a location within the [[Borderlands|Borderland]] nation of [[Malkier]]. It is unclear whether it was a town or merely a place where two roads crossed paths. It is famed as the site of the final Malkieri stand, when King [[Al'Akir Mandragoran|al'Akir Mandragoran]] and Queen [[El'Leanna Mandragoran|el'Leanna Mandragoran]] led the last remnants of the Malkieri army against the [[Shadowspawn]] invasion. Despite a valiant defense, the Malkieri host was slaughtered and al'Akir and el'Leanna were killed. The Shadowspawn swept on to  destroy the [[Seven Towers]] and menace the border of [[Shienar]] before the other Borderlands sent a unified army against them, which turned them back at the [[Stair of Jehaan]].
Shortly before the battle, al'Akir and el'Leanna sent their infant son [[Al'Lan Mandragoran|al'Lan Mandragoran]] south to [[Fal Moran]] to escape the massacre at Herot's Crossing.






https://wot.fandom.com/wiki/Herot%27s_Crossing