---
tags: [, Holds]
---
**Colrada Hold** is a settlement in the [[Aiel Waste]]. [[Mora (Wise One)|Mora]] of the [[Shaarad]] was the [[Wise One]] of the hold. It is unknown what [[Sept|sept]] or [[Clan|clan]] owns this hold.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Colrada_Hold