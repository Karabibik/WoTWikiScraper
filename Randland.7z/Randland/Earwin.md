---
tags: [Men, ChildrenoftheLight, Soldiers, LivingasofTGH, ]
---


**Earwin** is a member of the [[Children of the Light]].

## Appearance
He is large and has gray eyes and a long mustache.

## Activities
On arrival to the [[Almoth Plain]], [[Geofram Bornhald]] was forced to relinquish some of his men, including Child Earwin, to take orders from the [[Questioner|Questioners]].
Later, Earwin took part in the terrorizing of one of the villages on Almoth Plain, hanging around thirty men, women, and children while disguised as [[Taraboner|Taraboners]]. Bornhald rightly finds these actions disgusting and shocking.






https://wot.fandom.com/wiki/Earwin