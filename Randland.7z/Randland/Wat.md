---
tags: [Men, Andor_people, BandoftheRedHand, Soldiers, Redarms, Deceased]
---


**Wat** was an [[Andoran]] [[Redarm]] in the [[Band of the Red Hand]].

## Contents

1 Appearance
2 History
3 Activities
4 Notes


## Appearance
He was bald-headed and narrow-eyed.

## History
He was [[Andoran]].

## Activities
He was one of the dozen [[Redarm|Redarms]] who went with [[Mat]] to [[Ebou Dar]] in search of the [[Bowl of the Winds]].
He returned with [[Harnan]] as it was getting dark after Mat spent a day spying on a building used by the [[Kin]].
He was killed in the [[Rahad]] in the skirmish with [[Darkfriends]] and a [[Gholam]]. He may have been the wiry Andoran killed by [[Falion Bhoda]].

## Notes






https://wot.fandom.com/wiki/Wat