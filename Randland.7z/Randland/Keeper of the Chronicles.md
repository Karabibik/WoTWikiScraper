---
tags: [Titles, KeepersoftheChronicles]
---
The **Keeper of the Chronicles**, or more informally the **Keeper**, is a position among the sisters of the [[Aes Sedai]]. The Keeper is second to the [[Amyrlin Seat]], although the only real power gained with the title is that which the Amyrlin chooses to give her.

## Contents

1 History
2 Appointing and Removing a Keeper
3 Duties and Customs
4 Prestige and Limitations

4.1 Comparison with Sitters


5 Dress
6 List of Keepers
7 Trivia
8 External links
9 Notes


## History
In the early days of the White Tower, the role was no more than the Amyrlin's secretary and the official historian of the White Tower. Since five-hundred years before the Trolloc Wars, however, she became the de facto second-in-command to the Amyrlin.

## Appointing and Removing a Keeper
The Keeper is traditionally chosen by the Amyrlin, but her choice must be ratified by the Hall of the Tower. While acceptance of the Amyrlin's choice of appointee is strong custom, the Hall's ratification is the only legal requirement and in some cases an alternative Keeper has been imposed on an Amyrlin. This has happened in cases where the Hall has sought to rein in an Amyrlin that, despite having been raised, may be unreliable in some way or as quid pro quo in getting an Amyrlin elected. The latter was the case with Alviarin, who notes that Elaida would have been behind bars or had her head on a spike without the support of the White Sitters garnered by promising them the position of Keeper.
The Keeper is normally from the same Ajah as the Amyrlin, again custom rather than law. Like the Amyrlin, the Keeper formally leaves her Ajah when she takes on the role. She does, however, retain a traditionally thin stole of office in the colour of her former Ajah. On becoming Keeper, the woman is made aware of he existence of the secret histories of the Tower held in the [[Thirteenth Depository]], presumably by the librarians that are the gatekeepers of that knowledge.
Removing a Keeper requires the same process as the deposing of an Amyrlin, which is to say that it requires the greater consensus of Sitters and the Ajah from which the Keeper was raised is excluded from the voting process. The Amyrlin does not have the power to remove a Keeper by decree. This is one reason why Elaida could not simply have Alviarin removed and required the pretext of her being absent from the Tower when the armies of the Rebel Aes Sedai start their siege of Tar Valon.
Despite being officially not of her former Ajah, the removal of a woman from her role as Keeper adversely affects the prestige of her former Ajah. The sister is allowed to rejoin this Ajah, although the reception can be far from welcome.
If the Keeper of the Chronicles outlives the Amyrlin Seat, then her term comes to an end, and another woman is chosen to fill the position by the new Amyrlin. If a Keeper of the Chronicles dies in office, then the Amyrlin will choose another Sister for the office, usually of the same Ajah.

## Duties and Customs
 The Keeper is responsible for maintaining the records of the [[White Tower Library]] including secret files such as the [[Thirteenth Depository]]. In many ways she acts as an aide-de-camp to the Amyrlin. She parses through the thousands of files that come from below her and relays the important ones to the Amyrlin. She also oversees all official Tower business under the direction of the the Amyrlin. By strong tradition, the Ajahs are meant to pass on information from their networks of [[Eyes-and-ears]] to the Keeper, but rarely does this include *all* information as the Ajahs wish to retain some power through knowledge. Their willingness to share depends very much on the political situation in the Tower.
The Keeper is also responsible for announcing the Amyrlin before the latter enters a meeting of the [[Hall of the Tower]] with the phrase: "She comes. The Keeper of the Seals. The Flame of Tar Valon. The Amyrlin Seat. She comes." It is also her duty to call for consensus on any given vote. In the Hall of the Tower, her position is by the Amyrlin's side and to the Amyrlin's right as viewed from the Sitter's benches.
Although Moiraine says that the Amyrlin gave few audiences without the presence of the Keeper, we have seen this happening on several occasions throughout the series and this may be something more particular to Siuan Sanche than Amyrlins in general. This may be part of the reason that Leane was stilled along with Siuan, as people found it incredible that she was not also deeply involved.

## Prestige and Limitations
The power enjoyed by a Keeper over other Aes Sedai is dependent on how much the Amyrlin is willing to delegate to her.  In the case of Leane Sharif, it is mentioned that she is second only to the Amyrlin herself within the Tower and in general this can be assumed to be the case, especially when the sister is very strong in the One Power. Both [[Lelaine Akashi]] and [[Romanda Cassin]] attempt to position themselves as Keeper after the execution of [[Sheriam Bayanar]] and they would not be willing to give up their respected positions as the most senior Sitters if they did not see it as a way to gain additional power. The ability to control what information is seen by the Amyrlin falls under the maxim "knowledge is power" and is acutely demonstrated by Alviarin. What extra powers are afforded the Keeper by law other than access to privileged information is not explicitly stated, but it can be seen that the role brings its own unique prestige. Alviarin had considerable power over the Hall; nothing of real importance passed through the Hall without her approval and those matters she did not approve of were met with excuses and delay, even when pushed by Elaida. She also had more power in general than any Keeper in living memory.
The role of Keeper comes with the use of rooms with a balcony that opens over the Great Square in front of the White Tower. In the rebel camp, Sheriam is one of the few sisters that does not have to share a tent due to her role as Keeper. Leane is the only sister other than the Amyrlin to have her own tent on the journey from [[Fal Dara]] to Tar Valon. The Keeper also has the freedom to enter the quarters of any of the Ajahs.
Regardless of these benefits, there are clear strictures on the neutrality and limitations placed on the Keeper. The Keeper's role is to act as a mouthpiece for the Amyrlin. It is inappropriate to use the position to eschew views that are either personal or of the Keeper's former Ajah, or to make the accusation that any holder of this position would be biased as a representative of her former Ajah.
During a Sitting of the Hall of the Tower, the Keeper is not allowed to enter into discussion. She is merely there to accompany the Amyrlin Seat. Not only this, but she is not legally allowed to enter the Hall while it is in session. In this way, Sheriam was excluded from all Sittings after Egwene's capture by the loyalist Aes Sedai. Lastly, regular sisters are not even required to curtsy in respect towards the Keeper.

### Comparison with Sitters
The relative hierarchy between the Keeper and the Sitters seems unclear. On one hand, it is said that the Keeper is second only to the Amyrlin in the White Tower and that the White Tower is ruled over by a council consisting of the Sitters, the Amyrlin and the Keeper, which would imply that the Keeper is at least as significant as any Sitter. On the other hand Elaida notes that "even a Keeper with Alviarin's influence did not impede Sitters" and later Alviarin thinks that "a Keeper had no authority to order them (the Sitters attending Elaida) out", which implies that the Keeper should defer to a Sitter in the normal circumstances. Unlike other Aes Sedai, however, the Keeper is not required to stand when a Sitter enters the room.
In [[New Spring]], Gitara Moroso is described as being "certainly at least equal to the Sitters", but this may be referring to Gitara's personal reputation rather than the role of Keeper.. Of the two roles, Sitter seems to be the more revered in terms of the women that are chosen. Sitters usually have worn the shawl for at least 100 years, but there seems no such minimum norm for a Keeper. Several much younger women have filled the role in the series without comment on them being unsuitable for the job and it Duhara's position as a former Keeper does not seem to be worth mentionong.

## Dress
The Keeper of the Chronicles does not wear the [[Shawl|shawl]] she received when she chose her Ajah. Rather, she and the Amyrlin wear stoles of office. Unlike the broad [[Stole of the Amyrlin Seat|Amyrlin's stole]] which is striped in the seven Ajah colors, the [[Stole of the Keeper of the Chronicles|Keeper's stole]] is always simply the color of her Ajah. The width of the stole is dependent entirely on her own personal preference. Leane's stole was described as a hand's width. Tarna's is little more than a wide ribbon of brilliant scarlet.
She also carries a staff, which is described as being gilt-flamed or golden-flamed. It's official name is the "Amyrlin's Staff".

## List of Keepers
|**Keeper**|**Ajah**|**Amyrlin**|**Notes**|
|-|-|
|[[Gitara Moroso]]|[[Blue Ajah|Blue]]|[[Tamra Ospenya]] (Blue Ajah)|Died in office after [[Foretelling]] the birth of the [[Dragon Reborn]]|
|[[Aeldra Najaf]]|[[Blue Ajah|Blue]]|Raised after the death of Gitara|
|[[Duhara Basaheen]]|[[Red Ajah|Red]] ([[Black Ajah|Black]])|[[Sierin Vayu]] ([[Gray Ajah|Gray]])|Duhara was a nontraditional choice as Sierin was [[Gray Ajah]], although Sierin was very strongly pro-Red.|
|[[Angharad Juerissen]]|[[Gray Ajah|Gray]]|Nothing is known about this sister or her tenure as Keeper. Only mentioned in [[The Wheel of Time Companion]].|
|Unknown|Unknown|[[Marith Jaen]] (Blue Ajah)||
|[[Leane Sharif]]|[[Blue Ajah|Blue]]|[[Siuan Sanche]] (Blue Ajah)|[[Stilled]] and deposed along with Siuan. [[Healed]] by [[Nynaeve al'Meara]] and joined the [[Green Ajah]]|
|[[Alviarin Freidhen]]|[[White Ajah|White]] ([[Black Ajah|Black]])|[[Elaida a'Roihan]] (Red Ajah)|Untraditional choice as Elaida was [[Red Ajah]], but chosen for the position due to her support of Siuan's deposing. Was [[Ajah Heads|head]] of the Black Ajah while Keeper. Disappeared mysteriously from the [[White Tower]] while still in office|
|[[Tarna Feir]]|[[Red Ajah|Red]]|Raised after the disappearance of Alviarin. Left the [[White Tower]] on orders from the [[Highest]] without notice to [[Bond|bond]] an [[Asha'man]]|
|[[Sheriam Bayanar]]|[[Blue Ajah|Blue]] ([[Black Ajah|Black]])|[[Egwene al'Vere]] (No Ajah)|Was Keeper of the Chronicles under Egwene and the [[Rebel Aes Sedai|rebel Aes Sedai]], but has since been executed for being Black Ajah.|
|[[Silviana Brehon]]|[[Red Ajah|Red]]|Unconventional choice due to the history she has with Egwene, but chosen for the position because of her strength of character and to help mitigate Elaida's damage to the Tower|
|Unknown|Unknown (likely [[Green Ajah|Green]])|[[Cadsuane Melaidhrin]] (Green Ajah)|While this is unknown, a likely candidate would be [[Merise Haindehl]], a Green Ajah sister who is very strong on the One Power and who Cadsuane "trusted above any other sister".|



## Trivia
[[Beldeine Nyram]] appeared as Egwene's Keeper of the Chronicles during a potential future shown during Egwene's [[Accepted]] test.
The 1999 [[The Wheel of Time (video game)|video game]] focuses on the adventures of [[Elayna]] Sedai, a historical Keeper of the Chronicles from the Brown Ajah. The developers state that the game is set in a [[Mirror World]].
## External links
 
## Notes






https://wot.fandom.com/wiki/Keeper