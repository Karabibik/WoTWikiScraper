---
tags: [Women, BrownAjah, Andor_people, BlackAjah, AesSedai, Unknownstatus, LivingasofKOD, LowRankingAesSedai, ElaidaaRoihansWhiteTower, Channelers]
---


**Marris Thornhill** is an [[Aes Sedai]] of the [[Brown Ajah]] from [[Andor]]. She is also [[Black Ajah]] and is part of a [[Heart]] along with [[Atuan Larisett]] and [[Karale Sanghir]].

## Contents

1 Appearance
2 Strength
3 History
4 Activities


## Appearance
Marris is described as being plump. She usually seemed mild and absorbed in her studies.

## Strength
Marris is one of the weakest Aes Sedai, just a level above [[Daigian Moseneillin]] at 44(32).

## History
It is not described when Marris was born and when she was enrolled as Novice, but being so weak means that she most probably spent some decades in training as Novice and Accepted. Just a level below her Daigian was in training for forty eight years, above her at level 37(25) [[Bennae Nalsad]] stayed in training twenty four years, while [[Cariandre Temalien]] at level 35(23) was in training for twenty five years.

## Activities
She has no [[Warder]]. 
[[Faolain Orande]] is sent to Marris to be punished.
She was discovered and broken by the Black Ajah hunters, and then she was forced to swear on the [[Oath Rod]] obedience to Yukiri and the rest of the Black Ajah-hunting sisters. She is adamant that she now walks in the [[Light]] again.
After her interrogation, the [[Black Ajah Hunters]] reached a problematic stalemate in their task, since Marris' contact outside of her Heart was with the [[Rebel Aes Sedai]].
Her fate is undisclosed. There exists the possibility that she was one of the sisters that managed to escape the Tower, though her Oaths to the Black Ajah hunters may have prevented her flight. If that is the case, she would have been executed with the rest of the Black sisters unable to escape.






https://wot.fandom.com/wiki/Marris_Thornhill