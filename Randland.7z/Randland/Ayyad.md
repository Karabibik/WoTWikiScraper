---
tags: [Channelers, Shara]
---
The **Ayyad** are the people in [[Shara]] who can [[Channel|channel]] the [[One Power]]. They live in towns separate from the rest of the Sharan people; other Sharans intruding in these towns are killed. Permission must be granted for the Ayyad to leave these places, although anyone seeing one outside the village would just assume one had permission anyway. They tattoo their faces to allow identification; anyone bearing these tattoos are confined and isolated to Ayyad villages. All their lives they remain separate in the villages according to Jain Farsrider. Once in awhile a woman is seen on the outskirts of the village.

## Male Ayyad
Male Ayyad are not killed immediately; instead, they serve as breeding stock for female Ayyad. They can feed and dress themselves but are not allowed to read or write. Because they have always been known to go insane due the taint in the male side of the One Power, they are used to breed more female Ayyad, and as such their bloodlines are traced like horse breeding stock. Males are communally raised, called simply "the male," instead of "he." When they are of the age of sixteen they are taken from their original village and hooded and cloaked are transported to other villages, where they are matched with female Ayyad who desire children. Sometimes several. When one of them is twenty-one, or shows the first signs of channeling, he is taken from the place he is, as if again to go breed and is instead killed and cremated. 
In an effort to sow chaos in Shara, [[Demandred]] released them from bondage and taught them to channel, and they now call themselves "The Freed".

## Ties to Sharan rulers
The Sharans are ruled by monarchs who die after seven years in power, which the Sharan people simply accept this as the "will of the [[Pattern]]." At this point, the monarch's widow(er) remarries and becomes monarch; the new spouse will be widowed in an additional seven years and reign in turn. Unknown to most, the monarchs are actually killed by the female Ayyad, who are the true power in Shara.

## Notes






https://wot.fandom.com/wiki/Ayyad