---
tags: [Women, FarMadding_people, CounselsofFarMadding, LivingasofWH]
---


**Narvais Maslin** is one of the thirteen [[Counsel|Counsels]] of [[Far Madding]]. 

## Appearance
She is slim with gray hair.

## Activities
She is among the rest of the Counsels to greets [[Cadsuane Melaidhrin]], [[Harine din Togara Two Winds]] and the rest of their group to [[Far Madding]]. She escorts the group to their quarters.







https://wot.fandom.com/wiki/Narvais_Maslin