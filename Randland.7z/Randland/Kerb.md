---
tags: [Men, AradDoman_people, Apprentices, Deceased]
---


**Kerb** was a young chandler's apprentice.

## Appearance
Kerb was a spindly boy and had light hair. He had burns on his hands due to his occupation.

## Activities
He was heavily [[Compulsion|Compelled]] by [[Graendal]]. He was captured by [[Nynaeve al'Meara]] in [[Bandar Eban]] when she goes to search for [[Milisair Chadmar]]. Kerb was responsible for the poisoning of King [[Alsalam Saeed Almadar|Alsalam]]'s messenger and Lady Chadmar. [[Rand al'Thor]] ordered Nynaeve to dispel the Compulsion weave to find out Graendal's location. Once that was done, all that was left was a useless husk. Through sheer will power, Kerb managed to whisper out that Graendal was at [[Natrin's Barrow]]. He then collapsed and died.






https://wot.fandom.com/wiki/Kerb