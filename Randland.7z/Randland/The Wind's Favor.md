---
tags: [Inns, AradDoman]
---
**The Wind's Favor** is an inn located in [[Bandar Eban]]. The owner is [[Quillin Tasil]], an [[Andoran]]. Quillin is an agent for [[Cadsuane Melaidhrin]] and his daughter is [[Namine Tasil]], an [[Aes Sedai]] of the [[Brown Ajah]].

## Notes






https://wot.fandom.com/wiki/The_Wind%27s_Favor