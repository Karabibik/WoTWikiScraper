---
tags: [Women, Aiel_people, WiseOnes, Shaido, LivingasofCOT]
---


**Masalin** is a [[Wise One]] of the [[Shaido]] [[Aiel]]. 

## Appearance
She is gray-haired.

## History
She cannot [[Channel|channel]].

## Activities
She is one of the Wise Ones that [[Travel|Travels]] with [[Sevanna]]'s group of Shaido to [[Ghealdan]].
She talks to a man leading a horse. [[Zarine ni Bashere t'Aybara|Faile]] presumes it is about the animal's health. All the while, she is entirely oblivious to the [[Choedan Kal]] being used because she cannot channel.






https://wot.fandom.com/wiki/Masalin