---
tags: [Women, Aiel_people, DashainAiel, Deceased, Historicalpeople]
---


**Maigran** was a [[Da'shain]] [[Aiel]] who lived during the middle of the [[Breaking of the World]].

## History
Maigran was the sister of [[Lewin]] and the granddaughter of [[Adan]]. Her parents are [[Marind]] and [[Saralin]]. Her grandfather holds her when her father was killed by bandits.
During [[Rand]]'s third step through the [[Glass columns|glass columns]], he saw Maigran's rescue from bandits through Lewin's eyes. Due to Lewin's outcast as a follower of [[The Way of the Leaf]] because of Maigran's testimony, Maigran could be said to be the proximate cause of the Aiel abandoning the Way and separating from the Jenn.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Maigran