---
tags: [Women, BlueAjah, Tarabon_people, BlackAjah, AesSedai, Deceased, MiddleRankingAesSedai, FarmGroup, Channelers]
---


**Ispan Shefar** was an [[Aes Sedai]] of the [[Blue Ajah]], and secretly of the [[Black Ajah]].

## Contents

1 Appearance
2 Strength
3 History
4 Activities

4.1 From the White Tower to Ebou Dar
4.2 Capture, questioning and death


5 Notes


## Appearance
Ispan was a [[Taraboner]] with black hair in a multitude of braids with blue and green beads after the Taraboner fashion.

## Strength
"The Wheel of Time Companion" gives her *saidar* strength as 17(5), enough to [[Travel]] and a high level in Aes Sedai hierarchy.

## History
She was 109 years old when she died. She was born in 891 NE and went to the [[White Tower]] in 908 NE. After spending six years as a [[Novice|novice]] and eight years as [[Accepted]], she was raised to the [[Shawl|shawl]] in 922 NE.
Ispan was delicate and had very gentle senses. After she killed a beetle with the [[One Power]] "she wiped her hands on her skirts, as if she had done it herself".
When Ispan was a novice she ran away from the White Tower, and got as far as [[Ebou Dar]] before being caught by Aes Sedai and returned to the Tower.

## Activities
### From the White Tower to Ebou Dar
Ispan Shefar was part of [[Liandrin]]'s [[Liandrin's Group of Black Sisters|Group of Black Sisters]] who fled the White Tower. As they left, they took several *ter'angreal* with them, including several [[Sleepweaver|sleepweavers]]. While the group was in [[Amador]], [[Moghedien]] took control of the group and send Ispan and [[Falion Bhoda]] to [[Ebou Dar]] to search for the stash of *angreal*, *sa'angreal*, and *ter'angreal*. While in Ebou Dar, they question a [[Wise Woman]], [[Callie]], regarding the stash. Callie dies from their questioning, and they consider either kidnapping or killing [[Nynaeve al'Meara]] or [[Elayne Trakand]]. Shortly after Nynaeve and her group arrived at a six story building in the [[Rahad]], Ispan and Falion also arrived with two dozen men. Ispan shielded Nynaeve, but the tables were turned and Ispan herself was captured and shielded.

### Capture, questioning and death
Ispan was in the [[Tarasin Palace]] after her capture. [[Kin]] [[Elder|Elders]] kept her shielded and Nynaeve had her drugged to prevent any escape. When she was searched, Ispan had a [[Silver ring|silver ring]] sleepweaver *ter'angreal*, which was appropriated by Elayne. During their travel to the Farm of the Kin, [[Kirstian Chalwin]] kept Ispan shielded. [[Famelle Juarde]] and [[Eldase]] assist Kirstian with Ispan, something of which the Kin and the [[Aes Sedai]] are uncomfortable. Both [[Adeleas Namelle|Adeleas]] and [[Vandene Namelle]] questioned Ispan for information about the Black Ajah on their travels to [[Andor]]. After her first questioning session, Ispan was markedly meeker than she had been.
Two days before the group reached [[Caemlyn]], both Ispan and Adeleas were drugged with [[Crimsonthorn root|Crimsonthorn]] tea. Due to the nature of the murders, Elayne and Nynaeve suspect another Black sister. Later, it was revealed that [[Careane Fransi]] had killed them. Ispan might have known that Careane was Black Ajah, giving cause to Careane to murder her before she could be exposed.

## Notes






https://wot.fandom.com/wiki/Ispan_Shefar