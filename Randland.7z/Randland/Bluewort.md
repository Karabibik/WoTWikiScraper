---
tags: [, HerbsandMedicines]
---



**Bluewort** is an [[Herbs|herb]] that can be found in the [[Two Rivers]] region and in [[Tear]]. It can be brewed as a tea and administered to ease a queasy stomach. Bluewort also can be used as a dye, producing a purple-blue color.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Bluewort