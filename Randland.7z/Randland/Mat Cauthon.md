---
tags: [Wotwikifeaturedarticles, Men, Andor_people, BandoftheRedHand, Generals, LivingasofAMOL, TwoRivers_people, Taveren, Seanchan_people, TheBlood, Notesneeded, POVcharacter, Gamblers]
---





*"I am a free man, Aes Sedai. I am no Aes Sedai meat."*
   —Mat Cauthon, in the [[Old Tongue]], to the [[Amyrlin Seat]] 

**Matrim Cauthon**, usually called just **Mat**, is one of the main characters of the series. He is a powerful *ta'veren*, although not as powerful as [[Rand al'Thor]]. 

## Contents

1 Appearance
2 Personality
3 Family
4 Chronology
5 Titles
6 Prophecy references
7 Mat's fighting skills

7.1 Riding skills


8 Parallels
9 In the television series
10 Notes


## Appearance
Mat is 5'11" or 180 cm tall and weighs 170lb or 77kg. He is described as long-limbed and wiry. He has brown eyes, which often twinkle with mischief, and brown hair that is long enough to reach his coat collar.
Mat's appearance varies throughout the series as his sense of fashion changes. He wears clothes typical of the Two Rivers for the first few books, but gradually dresses more flamboyantly as the series progresses. After his encounter with the [[Eelfinn]] in [[Rhuidean]], he gains a hanging scar, which he hides by use of a kerchief. Shortly afterwards, he starts wearing his signature wide-brimmed black hat which he obtains from [[Hadnan Kadere]]. In [[Ebou Dar]], he finds many of his clothes replaced on the orders of [[Tylin Quintara Mitsobar|Queen Tylin]] with outfits suitable for a "pretty". Although he chafes at being dressed up like a fancy Lord, he also becomes accustomed to it and develops a taste for wearing "a little lace".
Later, after his last encounter with the [[Finn]], he is disfigured by the removal of his left eye.

## Personality
Mat is often described as lazy, roguish, immature, tactless, and brazen. He is not afraid to flout any and all authority figures around him, and typically tries whatever he can to shirk responsibility and work. For example, when he first discovered his *ta'veren* nature, he attempts as best he can to avoid his role in the Pattern, and only reluctantly accepts what he needs to do. However, he is also extremely steadfast and loyal, and has learned over time not to shirk from his duties, no matter how much he might grumble about it. He is also extremely pragmatic, shirking possessions or clothing that is not practical or useful. He enjoys gambling and drinking, as well as pursuing women, though he is careful never to pursue one who isn't open to his attentions. This love of gambling extends to a love of tactics, as Mat views battles as being the ultimate gamble. He is also extremely derisive of nobles or anyone with a "high-born" heritage, believing that, as a general rule, they all lack common sense.
Though he matures somewhat over the course of the story, Mat's core personality remains largely intact throughout his trials and challenges. By the time the Last Battle ends, he is still fond of virtually everything he was fond of when he first set out into the world (though, as a married man, he has reluctantly conceded to giving up his hobby of pursuing women). The only thing that appreciably changes about him is his attitude towards work and duty; he is still not fond of either, but will now typically accept both with a resigned attitude, particularly when it comes to commanding armies.
Mat's most obvious non-personality trait is his extraordinarily good luck. His *ta'veren* nature causes virtually every situation that depends on chance to work out in his favor, from dice to cards to avoiding random assassination attempts by inadvertently moving at the right time. This trait is so extreme that he was able to pick out directions for the seemingly impossible corridors and intersections of the [[Aelfinn]] and the [[Eelfinn]] realm by tossing dice or spinning in a circle and randomly stopping. An additional aspect of this trait is that he seemingly 'senses' the onset of important decisions or events soon to occur. This sense, referred by Mat as "the bloody dice rolling in my head," has frequently helped him to identify important aspects of his life and act accordingly, best demonstrated in his handling of Tuon.
Mat is a peerless tactician. Aided by memories collected by the Aelfinn and Eelfinn from generals that entered the lands of the Aelfinn and Eelfinn between the Trolloc Wars and the War of a Hundred Years, his tactical acumen is such that no army under his command has ever suffered a defeat, no matter what the odds seem to be. His greatest triumph on the battlefield was his defeat of the armies of the Shadow under Demandred's command during the Last Battle. Despite being almost hopelessly outnumbered by the Shadow and almost hopelessly overpowered by [[Demandred]] himself wielding [[Sakarnen]] in a full circle of seventy-two, he managed to rout the forces of the Shadow completely through brilliant planning, mental flexibility, and his trademark luck.

*"I'm no lord. I've more respect for myself than that."*
   —Mat 
## Family
Mat is the only son and eldest child of [[Abell Cauthon|Abell]] (born 955 NE) and [[Natti Cauthon]] (born 956 NE). He has two younger sisters, [[Bodewhin Cauthon]] (born 983 NE) and [[Eldrin Cauthon]] (born 984 NE).
At one point, Mat refers to having "four sisters" willing to tattle on him when he was up to any mischief. This can be regarded as an error, however, as he also refers only two sisters, Eldrin and Bodewhin, in the same context in the next book. Furthermore, no other sisters are ever mentioned in the series, even when other members of his family are kidnapped by Whitecloaks and the book Glossary and [[The Wheel of Time Companion]] seem consistent in this fact in the relevant entries.

## Chronology

## Titles
The Fox that makes the Ravens fly
The Trickster
Prince of the Ravens
Raven Lord
Lord of Luck
Marshal General
Son of Battles
Gambler
Lord Crimson
One-Eyed Fool
Battle Lord
Horn Sounder (formerly)
Horn Blower
Tylin's Toy
## Prophecy references
[[Prophecies of the Dragon|Prophecies of the Light]]

*"Fortune rides like the sun on high with the fox that makes the ravens fly. Luck his soul, the lightning his eye, He snatches the moons from out of the sky.."*
   — Quoted by [[Jain Charin]] aka Jain Farstrider alias Noal Charin 


*"When the Fox marries the raven, and the trumpets of battle are blown."*
   — Quoted by [[Tylee Khirgan]], Seanchan Banner-General 

[[Prophecies of the Shadow]]

*"In that day, when the One-Eyed Fool travels the halls of mourning, ..."*
   — origin unknown 
## Mat's fighting skills
Within the course of the books we see Mat in many fights and his skill with his [[Quarterstaff|quarterstaff]] is shown as exemplary, though it is rarely commented on. The fact that Mat, while exhausted and weak, simultaneously defeated [[Galad]] and [[Gawyn]], both considered exceptional swordfighters, and later [[Couladin]] of the Shaido clan (who is considered a fierce fighter, even among the Aiel) in single combat, shows that his skill in combat is above that of even the average blademaster, though he cannot be called a blademaster since he does not use a sword. The weapons he uses are the quarterstaff and later the *ashandarei*, the latter weapon being supplemented with knowledge from the Eelfinn memories on how to use it properly. Mat is also a very proficient knife fighter and can throw them with incredible accuracy, being able to fight off numerous assailants armed with swords and other mid-range weapons. A key facet of his fighting style, in addition to his natural luck, are his incredible reflexes, as seen best when he caught a knife thrown by the *gholam* out of the air.

### Riding skills
He is described as being an indifferent rider before he has visited the Eelfinn, but after that he rode as he was born on a horse's back. 

## Parallels

## In the television series
In the [[The Wheel of Time (TV series)|television series]],   is played by actor   in the first season, and   from the second season onward.
## Notes

|**Major Characters**|
|-|-|
|**Protagonists**|**Main:****Primary:**|
|**Antagonists**|**The Shadow:**|
|**Major Allies**|**Aes Sedai:****Asha'man:****Aiel:****Seanchan:****Westlands Rulers:****Other Allies:**|
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Matrim_Cauthon