---
tags: [Holidays, Parallels]
---


**Bel Tine**, also known as Festival, is the [[Westlands]] celebration of spring's arrival.
It is not set to a specific date, and comes later in northern lands than in the south. It's typically celebrated "when spring had well and truly arrived, the first lambs born and the first crop up."
The night preceding Bel Tine is known as [[Winternight]].

## Contents

1 Observance in the Two Rivers
2 Plot
3 Parallels
4 Trivia
5 Gallery
6 References


## Observance in the Two Rivers
Bel Tine is celebrated the whole day with singing and dancing and feasting.
As part of the celebration, huge bonfires are constructed in the center of town that are almost as big as houses. Bel Tine would be celebrated around the fires and on the village green.
The women of the village erect a [[Spring Pole]] the day before the festival, and even though the men walking by can see it happening, they pretend to be surprised by it when they wake up on the morning of the Festival. In the morning, unmarried women of marriageable age dance around the Spring Pole. At noon on the day of Bel Tine, unmarried women dance around the Spring Pole entwining it with ribbons while the unmarried men sing.
There are contests for many things throughout the day, including archery, the sling, the quarter staff, footraces, singing, dancing, fiddle playing, sheep-sheering, bowls, and darts. [[Tam al'Thor]] tends to win the archery competition annually.
If a woman is interested in a man and wants him to know it, she might put flowers in his hair at Bel Tine, or she makes a point of asking him and no one else to dance.

## Plot
On Winternight in 998 NE, the Two Rivers is preparing for Bel Tine the next day, with the bonfires being put up and the spring pole being erected. A [[Thomdril Merrilin|gleeman]] has arrived, and fireworks are planned. [[Tam al'Thor|Tam]] and [[Rand al'Thor]] bring apple brandy and apple cider to [[The Winespring Inn]] in [[Emond's Field]], as they do every year for Bel Tine.
Rand asks [[Egwene al'Vere]] to dance with him the next day at Bel Tine, she agrees to dance with him in the afternoon. She mentions that she'll be "busy in the morning", indicating that as she's now a woman of marriageable age, she'll be dancing with the other unmarried women around the spring pole in the morning, as was custom.
Bel Tine in 998 NE is disrupted by the Trolloc attack on the Two Rivers on Winternight the night before.

## Parallels
Bel Tine comes from the Celtic festival of Bealtaine taking place in spring. Bealtaine is also the Irish word for the month of May.

## Trivia
Every year at Bel Tine, Rand would put flowers on [[Kari al'Thor|his mother]]'s grave.
[[Cenn Buie]] considered it "an ill omen" that there were "no storks nesting on the rooftops at Bel Tine."
## Gallery
Bel Tine in [[Emond's Field]], unofficial fanart by ravenwing136.
## References






https://wot.fandom.com/wiki/Bel_Tine