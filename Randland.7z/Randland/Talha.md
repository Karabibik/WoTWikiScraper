---
tags: [Women, Seanchan_people, Suldam, LivingasofTGS, EverVictoriousArmy, Channelers, Learners]
---


**Talha** is a *sul'dam* in the [[Seanchan]] army.

## Activities
She is present at the meeting between the [[Dragon Reborn]] and the [[Daughter of the Nine Moons]], when it was revealed that the later was actually [[Semirhage]] in disguise.






https://wot.fandom.com/wiki/Talha