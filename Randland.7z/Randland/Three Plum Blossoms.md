---
tags: [Inns]
---
**Three Plum Blossoms Inn** is an [[Inn|inn]] in [[Falme]]. Before the Seanchan arrived, the word "Watcher" appeared in the name but this was hastily painted out.
[[Nynaeve]], [[Elayne]] and [[Min]] meet [[Bayle Domon]] there to discuss sailing away from Falme when they rescue [[Egwene]] from the *damane* quarters.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Three_Plum_Blossoms