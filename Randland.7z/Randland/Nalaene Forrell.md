---
tags: [Women, YellowAjah, Ghealdan_people, BlackAjah, AesSedai, Unknownstatus, LivingasofTGS, ElaidaaRoihansWhiteTower, RandsAesSedai, Cairhienexpedition, Female, Dreadlords, Channelers]
---


**Nalaene Forrell** is an [[Aes Sedai]] of the [[Yellow Ajah]] and secretly a member of the [[Black Ajah]].

## Activities
She has remained loyal to the [[White Tower]] during the split.
She was part of the White Tower secret expedition who were to kidnap [[Rand al'Thor]] in [[Cairhien]].
She is one of the Aes Sedai bound to [[Rand al'Thor]], and therefore one of the Aes Sedai who was captured after the [[Battle of Dumai's Wells]].
Along all the prisoner sisters in Cairhien she has sworn an oath of fealty to [[Rand al'Thor]].
She is revealed by [[Verin Mathwin]]'s book to [[Egwene al'Vere]] to be a [[Darkfriend]], though it is yet unknown to Rand. 

## Ajah
Nalaene's Ajah is never identified in the main books of the saga.
Of the thirty-nine sisters sent to kidnap Rand, 15 were described of the [[Red Ajah]]. According to [[Galina Casban]], the remaining sisters were 10 of the [[Green Ajah|Green]] and 12 [[White Ajah|White Ajahs]] (the last two were [[Nesune]] e [[Coiren]], a Brown and a Gray respectively).
But Nalaene's Ajah is identified as Yellow in "The Wheel of Time Companion", contradicting the description given by Galina in the Book, that never mentioned a Yellow in her party.

## Notes






https://wot.fandom.com/wiki/Nalaene_Forrell