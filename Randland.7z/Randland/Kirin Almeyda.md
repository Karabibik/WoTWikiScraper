---
tags: [Men, Ghealdan_people, Rulers, Kings, Deceased, Historicalpeople, Royalty]
---


**Kirin Almeyda** was the first King of [[Ghealdan]].

## History
Almeyda established the kingdom in [[FY 1109]] during the closing years of the [[War of the Hundred Years]], aided by several nobles, including [[Valera Prosnarin]], [[Cynric Talvaen]] and [[Iona Ashmar]], who founded the [[Crown High Council]] to advise him.






https://wot.fandom.com/wiki/Kirin_Almeyda