---
tags: [AesSedai]
---
After the [[Foretelling]] that [[Gitara Moroso]] had that the Dragon had been reborn on the slopes of [[Dragonmount]], [[Tamra Ospenya]] used the Accepted [[Moiraine Damodred]] and [[Siuan Sanche]] to deliver five messages to five sisters. These were to be **Tamra Ospenya's Searchers** for the [[Dragon Reborn]]. 

## Similarities
All five of these women were people that Tamra thought she could trust to keep her secret about the Dragon being reborn. All of them had been Aes Sedai for well over a hundred years - presumably she had known them all almost from the time she was training as novice or Accepted. All of them also had a reputation for adhering very strictly to the law. This is important because, as Amyrlin, she can have the information **Sealed to the Flame** and these women are likely to take their duties and orders very seriously and never betray the secret of the Dragon Reborn. It is also possible that, because of their strict adherence to the law, they would also take the Prophecies of the Dragon seriously and be more faithful in their duties.****

## The Searchers
The details of the searchers and their fates are as follows:

|**Name**|**Ajah**|**Supposed Fate**|
|-|-|
|[[Meilyn Arganya]]|[[White Ajah]]|Died in her sleep|
|[[Kerene Nagashi]]|[[Green Ajah]]|Drowned in the [[River Alguenya]]|
|[[Valera Gorovni]]|[[Brown Ajah]]|Cause of death unknown|
|[[Ludice Daneen]]|[[Yellow Ajah]]|Cause of death unknown|
|[[Aisha Raveneos]]|[[Gray Ajah]]|Killed by bandits in Murandy|

All of the **Searchers** were killed by the [[Black Ajah]]. Meilyn was supposed to have died in her sleep, yet Siuan Sanche was under her bed and Meilyn never came to her room that night. Her cause of death was announced by [[Chesmal Emry]], a known Black sister.
In "The Wheel of Time Companion" we discover that also [[Larelle Tarsi]] and [[Marya Somares]] (both Gray sisters) were among the Tamra's Searchers and that both were killed by the Black. [[Cetalia Delarme]], the head of the [[Blue Ajah]] eyes-and-ears, was also murdered by the Black to prevent her from finding the Dragon Reborn.
Her searchers were representative of all Ajahs except the Red. The [[Red Ajah]] would have been excluded simply because Tamra would not have trusted them with information on a male channeler, even if it were the Dragon Reborn. 
Though there is no confirmed member of the Blue Ajah among the Searchers (as Cetalia was not confirmed to have been included by Tamra), the entry on the Vileness in the Wheel of Time Companion says that Tamra spent a lot of time closeted with senior sisters (in age and strength) who were mostly from her former Ajah - the Blue. Thus, it is very probable that some searchers were Blue Ajah.






https://wot.fandom.com/wiki/Tamra_Ospenya%27s_Searchers