---
tags: [Women, Murandy_people, Rulers, Queens, Deceased, Historicalpeople]
---


**Katrine do Catalan a'Coralle** was the first Queen of [[Murandy]]. 

## History
In [[FY 1047]], she captured the city of [[Lugard]], which lay in much fought-over land, and founded the country. Katrine was killed only a year later.
She is known to have living descendants, such as [[Meri do Ahlan a'Conlin]].






https://wot.fandom.com/wiki/Katrine_do_Catalan_a%27Coralle