---
tags: [Men, Tear_people, Deceased]
---


**Melanril Asegora** is a noble from [[Tear]].

## Appearance
He has dark eyes and a sharp nose. He has a pointed beard.

## Activities
He is one of the Tairen nobles who is sent to [[Cairhien]]. He is in charge of the Tairen and Cairhienin soldiers during the [[Second Battle of Cairhien]]. He is warned by [[Matrim Cauthon]] that the [[Shaido]] [[Aiel]] are setting an ambush ahead. He is killed later in the battle.







https://wot.fandom.com/wiki/Melanril_Asegora