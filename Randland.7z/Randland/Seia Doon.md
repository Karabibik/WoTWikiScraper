---
tags: [Aielwarriorsocieties, SeiaDoon]
---




The *Seia Doon* is an [[Aiel]] [[Aiel warrior society|warrior society]]. The name means "Black Eyes" in the [[Old Tongue]].

## Roles
*Seia Doon* are often used in the questioning of prisoners, as well as *Far Dareis Mai*.. The Black Eyes are specialists in fighting during the twilight hours, and are excellent at finding their way in little to no light.

## Activities
Members of the *Seia Doon*, along with members of the *Aethan Dor*, *Far Aldazar Din*, *Duadhe Mahdi'in*, *Far Dareis Mai*, and *Sha'mad Conde*, helped [[Rand al'Thor]] find a [[Portal Stone]] outside [[Tear]]. As they are traveling through the [[Aiel Waste|Three-Fold Land]], members of the *Seia Doon* escort [[Hadnan Kadere]]'s wagons. When [[Couladin]] defies Aiel custom and tradition by claiming he is the *Car'a'carn*, the rest of his society, the *Seia Doon*, vow to kill him.. All of the societies, including the *Seia Doon*, accompanied Rand from the [[Sun Palace]] in [[Cairhien]] to [[Caemlyn]] in [[Andor]] to battle [[Rahvin]] and his forces. *Seia Doon* is one of the societies that guard the Sun Palace while Rand is there. *Seia Doon*, *Shae'en M'taal*, and *Far Dareis Mai* are all very touchy about *ji'e'toh*.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Seia_Doon