---
tags: [Women, Andor_people, Novices, LivingasofTPOD, TwoRivers_people, RebelAesSedai, Channelers]
---






**Susa al'Seen** is a [[Novice|novice]] in the [[Rebel Aes Sedai|rebel Aes Sedai]] camp. She is from [[Emond's Field]].

## Appearance
She is a slight, fluttery girl. She talks over other people, insisting on being able to get out what she wants to say. She is about 16.

## Activities
She is tested for channeling abilities by [[Verin Mathwin]] and [[Alanna Mosvani]], and is found suitable for training. She accompanies several other [[Two Rivers]] girls with channeling abilities to [[Caemlyn]], where they are all terrorized by [[Rand]]. She eventually joins the rebel Aes Sedai in [[Murandy]], and becomes a [[Novice]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Susa_al%27Seen