---
tags: [Women, YellowAjah, Ghealdan_people, BlackAjah, AesSedai, Deceased, Besthealers, HighRankingAesSedai, Channelers]
---


**Chesmal Emry** was an [[Aes Sedai]] of the [[Yellow Ajah]]. She is also [[Black Ajah]] and one of [[Liandrin's Group of Black Sisters]]

## Contents

1 Appearance
2 Strength and Abilities
3 History
4 Activities
5 Notes


## Appearance
She was from [[Ghealdan]]. Chesmal was stern but handsome with dark hair and eyes. She was tall for a woman and seemed even taller. She was 5'7 tall.
She was often described as cold and arrogant. 

## Strength and Abilities
Chesmal has a strength in the One Power of 18(6). This makes her significantly above average strength for an Aes Sedai.
She had a strong [[Talent]] in [[Healing]], prior to [[Nynaeve]], Chesmal was considered among the most talented and best [[Healer|Healers]] in Yellow Ajah anyone had seen in years, rivalling with [[Samitsu]] and [[Suana]]. Her speciality was that she had the ability to manipulate all the electrical activity of the body. 
In "The Wheel of Time Companion" it is stated that she might have rediscovered a part of healing using other flows than the standard, although this was never confirmed.
But Chesmal used her skills also to kill without leaving a sign on the corpses, in fact related to her Talent, she also possessed the rare ability to stop the heart of her victims.

## History
She was born in the year 863 NE and went to the Tower in 878 NE. After spending seven years as Novice and six as Accepted she was raised to the shawl in the year 891 NE. 
She was almost sent away twice as a novice and once as Accepted for severe infractions involving attacks on others.  
Chesmal, along with [[Galina Casban]] and [[Jarna Malari]], was involved in the torture and murder of [[Tamra Ospenya]]. She was also involved in the murder of [[Meilyn Arganya]], and she claimed to have manipulated the [[Red Ajah]] to murder [[Sierin Vayu]], because the Amyrlin was warned by [[Siuan]] about her activities. Chesmal often brags about her part in it to other Black sisters, and them thought that it would put her in danger.
Chesmal enjoys embroidery, concentrating intently upon her work. She assumes everyone else approaches it in the same manner.

## Activities
After fleeing the [[White Tower]] with the other Aes Sedai of [[Liandrin]]'s Group, she went to [[Tear]] and worked for the [[Forsaken]] [[Be'lal]]. They tried to trap [[Rand al'Thor]] just after he released *Callandor*.
When this failed, the group flees to [[Tanchico]] to try and steal the male *a'dam* from the [[Panarch]]'s Palace. This plan was foiled by [[Elayne Trakand]] and [[Nynaeve al'Meara]].
After Tanchico they went to [[Amadicia]]. There Liandrin tried to take advantage of a wounded [[Moghedien]], but the Forsaken was more able than her, leaving Liandrin severely punished, demoted and shielded permanently. [[Moghedien]] is shot with an arrow by [[Birgitte Silverbow]] in *Tel'aran'rhiod*, and it is Chesmal who heals her near-death injury. 
Upon leaving Liandrin's group, [[Moghedien]] placed Eldrith in charge, as the strongest in the [[One Power]] of the sisters remaining, ordering them to follow her to Ghealdan.
So Chesmal and some of the other sisters travel to [[Samara]]. When [[Eldrith Jhondar]]'s [[Warder]] [[Kennit]] arrives, they flee to [[Caemlyn]].
Though Moghedien has placed Eldrith in charge, Chesmal routinely disregards Eldrith's authority. After the Brown sister returns from an unexpected absence, Chesmal goes so far as to question her rudely about her activities. 
Chesmal is present with [[Asne Zeramene]] and Eldrith when [[Temaile Kinderode]] returns from spying on [[Elayne]], [[Egwene]], and Nynaeve in *Tel'aran'rhiod*. Temaile makes her nervous because of the Gray sister's breaking of Liandrin.

After that they go to Caemlyn. Meanwhile there [[Samwil Hark]] leads Elayne, Careane, Sareitha and [[Vandene Namelle]] to the house on Full Moon Street where they go to arrest [[Mili Skane]] and the Black Ajah sisters with her. [[Vandene]] discovers that [[Careane Fransi]] was the one who killed her sister, [[Adeleas]], along with Ispan. She kills Careane in revenge for this. Chesmal kills Vandene and [[Sareitha Tomares]] consequently.
After this Chesmal was involved in the unsuccessful kidnap attempt on Elayne and was subsequently held in the Royal Palace dungeon in [[Caemlyn]], along with [[Lady Shiaine]] and the other Black Ajah Sisters involved.
Some day after Elayne sneaks into her cell disguised as one of the [[Forsaken]] and questions Chesmal on her orders. Chesmal is deceived by the disguise, but she cannot reveal a lot because Eldrith and Temaile break in during her interrogation tipping Chesmal off. 
Elayne manages to shield all three women but is stabbed by [[Doilin Mellar]] releasing Chesmal from her shield. Mellar demands Chesmal to Heal Elayne, which she does. Elayne hands her one of the copies of [[Matrim Cauthon]]'s [[Foxhead medallion]] which cuts her off from the Source. Elayne then sets Chesmal's clothing on fire, incinerating her.

## Notes






https://wot.fandom.com/wiki/Chesmal