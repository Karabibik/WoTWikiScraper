---
tags: [Women, RedAjah, Tarabon_people, BlackAjah, Dacovale, AesSedai, Unknownstatus, LivingasofKOD, POVcharacter, Damane, HighRankingAesSedai, Sparkers, Slaves, Channelers]
---


**Liandrin Guirale** (pronounced: lee-AHN-drihn) is an [[Aes Sedai]] of the [[Red Ajah]], and secretly a member of the [[Black Ajah]].

## Contents

1 Appearance and Personality
2 Strength and Abilities
3 History
4 Activities

4.1 Search for Rand, Mat, and Perrin
4.2 Betraying Nynaeve and Egwene
4.3 Flight from the White Tower
4.4 The Stone of Tear
4.5 Tanchico

4.5.1 The Domination Band
4.5.2 The Panarch's Palace


4.6 Subjugation by Moghedien

4.6.1 Attempt to Escape and Stilling
4.6.2 The Black Sisters Disbanded


4.7 Enslaved by Suroth


5 In the television series
6 See also
7 Notes


## Appearance and Personality
Liandrin has dark brown eyes and honey-colored hair, which she wears in a multitude of thin beaded braids. She is pretty with a face bearing doll-like features and a rosebud mouth.
She is selfish and cunning, willing to use manipulation or intimidation tactics to get what she wants. Liandrin deliberately behaves and speaks like upper crust [[Tarabon|Taraboners]]. However, when angry she will sometimes lapse into the more vulgar dialect she spoke during her commoner upbringing.

## Strength and Abilities
Liandrin is well skilled in the [[One Power]] by Aes Sedai standards. Her ability on the Power Strength Scale is equivalent to 14(2). This level of strength once placed her in position of great political advantage in the [[White Tower]]. 
Liandrin has developed a minor [[Talent]] with [[Compulsion]] which she frequently uses to manipulate others to forward selfish personal agendas. She is very weak in [[Healing|healing]], and is frequently jealous of those who can kill directly with the power; a skill tightly linked with healing. Though she first learned to channel on her own as a girl, she does not consider herself a [[Wilder|wilder]] and loathes them.

## History

Liandrin was born in 964 NE in [[Tarabon]] to parents in poverty. Her father possessed no trade skills or special abilities and was reduced to selling fruit from a wheelbarrow to support his family. Liandrin grew up envious of anyone with power or rank and sought at an early age to escape her meager life and gain status for herself. 
She was born with the [[Spark]], and as a young girl she first learned she could channel when she unwittingly developed a [[Weave]] of Compulsion that forced others to do her bidding; a skill she referred to as "opening people" to her suggestions. Though useful, the weave was flawed and frequently hurt its target, causing victims to feel stabbing pains of agony in their minds if used too aggressively. Emboldened by her talent and driven by a greed for advancement she began to dream of a day she might become an [[Aes Sedai]] and join the ranks of the fabled [[Black Ajah]].
In 979 NE, at the age of sixteen and one year after she first learned to channel, her strength in the power became undeniable and so she traveled to [[Tar Valon]]. After spending five years as a [[Novice|novice]] and five more as [[Accepted]], she was raised to the shawl in 989 NE. She publicly joined the [[Red Ajah]] and soon after swearing the [[Three Oaths]] she covertly joined the Black Ajah, forswore those oaths, and passed through a secret black ceremony where she became bound to entirely new oaths to the cabal.

## Activities
### Search for Rand, Mat, and Perrin
In the summer of 998 NE, Liandrin was summoned to [[Shayol Ghul]] and there attended the [[Darkfriend Social]] where she was given public instructions to hunt for [[Rand al'Thor]], [[Matrim Cauthon]], and [[Perrin Aybara]] as well as secret directives to be carried out in the White Tower.
Soon afterwards, Liandrin traveled to [[Fal Dara]] as one of the Red Ajah representatives in the [[Amyrlin Seat|Amyrlin Seat's]] entourage. While there she became aware of the presence of [[Rand al'Thor]] and used her [[Compulsion]] [[Talent]] to force [[Amalisa Jagad]] to search for him. Later she discovered Rand in the Fal Dara dungeons and immediately attempted to compel Rand to obey her; an attack Rand was able to resist through sheer willpower and at great agony until Liandrin was interrupted by [[Moiraine Damodred]]. She subsequently lost track of Rand and was forced to resume her duties in the Amyrlin's entourage. 
On the journey back to Tar Valon she grudgingly gave a channeling lesson to [[El'Nynaeve ti al'Meara Mandragoran|Nynaeve al'Meara]] and [[Egwene al'Vere]]. However, she taught little and spent far more time trying to intimidate the two young women into answering questions about Rand, Mat, and Perrin.

### Betraying Nynaeve and Egwene
In the fall of 998 NE, Liandrin approached Nynaeve and Egwene with the claim that Rand was in grave danger and needed their help. After insisting on absolute secrecy she convinced the two young women to sneak out of the White Tower, but was overheard by [[Elayne Trakand|Elayne]] and [[Min Farshaw|Min]] through a hole in Egwene's chamber. After convincing Nynaeve and Egwene to let them join, the four girls traveled to the [[Tar Valon]] [[Ogier Grove|grove]] where they entered a [[Ways|Waygate]] and journeyed through the [[Ways]] to [[Toman Head]]. 
When they emerged, Liandrin betrayed all four to [[Suroth|The High Lady Suroth]]; leading to Nynaeve and Elayne fleeing for their lives, Egwene being made [[Damane]], and Min being beaten and nearly killed. After threatening Suroth in response to the High Lady's aggressive posture towards her, Liandrin returned to the Ways and journeyed back to Tar Valon. 

### Flight from the White Tower
Shortly after she returned to the White Tower it became clear that the four young women had escaped from the [[Seanchan]]. 
Liandrin was given new instructions and, with the help of [[Liandrin's group of Black Sisters|twelve other Black Ajah sisters]], carried out her orders by stealing several [[Ter'angreal|ter'angreal]] from Tower storerooms. Liandrin then fled [[Tar Valon]] with this group of women. In the process of doing so her group was responsible for killing twenty-one people, including three [[Aes Sedai]] and two [[Warder|warders]].

### The Stone of Tear
Unbeknownst to either Liandrin or her followers, their instructions were being issued to them by the [[Forsaken]], [[Ishamael]]. He ordered them to travel to [[Tear]] and swear loyalty to fellow Forsaken, [[Be'lal]], who was forming a trap to capture the [[Dragon Reborn]]. Liandrin and her followers took up residence in the [[Stone of Tear]] where they began to experiment with the *ter'angreal* they had stolen; the majority of which were intended to interface with [[Tel'aran'rhiod]]. Liandrin also awaited the arrival of Nynaeve, Elayne, and Egwene—who she knew were seeking to bring her to justice for her betrayal—and who she intended to capture as a part of Be'lal's schemes. 
While experimenting in Tel'aran'rhiod, Liandrin became aware of Egwene's presence at one point and smiled mockingly at her. Liandrin did not know the precise day when her pursuers arrived in Tear, but she eventually learned of a [[Thief-catcher]] named [[Juilin Sandar]] who was attempting to locate her and her followers. Liandrin captured Juilin and compelled him to lead her to the home of a local [[Wisdom|Wise Woman]]. It was there that Liandrin, [[Rianna Andomeran]], and [[Joiya Byir]] [[Shielding|shielded]] and bludgeoned Nynaeve, Elayne, and Egwene with weaves of air until they were totally subdued. 
Liandrin led the entire group back to the Stone of Tear where her victims were imprisoned as bait for Be'lal to use against Rand. Unfortunately for Liandrin, Be'lal was killed in a subsequent encounter with Rand and Moiraine. Then, two of her followers were captured by Egwene, and finally the Stone of Tear itself fell to a surprise assault by [[Aiel]]. 
With her plans in disarray, Liandrin and her ten remaining followers fled.

### Tanchico

Prior to fleeing Tear, Liandrin and fellow [[Liandrin's group of Black Sisters|black sister]], [[Temaile Kinderode]], discussed something that Liandrin had recently learned; specifically that somewhere in her former home [[Tanchico]] existed a [[Domination Band|device]] that could bind [[Rand al'Thor]] to their will. She did not know the exact specifics of what the artifact was, but she had learned enough to know that it was dangerous not just to a male channeler, but also to the person attempting to control him. Liandrin's conversation was overheard by [[Amico Nagoyin]] who later divulged it to Egwene, Nynaeve, and Elayne during an interrogation.
After the fall of the Stone of Tear, Liandrin and her ten remaining followers made haste to Tanchico where they were given instructions to locate the device for use in binding and controlling Rand. The object the women were seeking was in fact a male [[A'dam|a'dam]]—known more commonly as a [[Domination Band]]—though none of them knew this nor where it could be found. 
Upon arrival in Tanchico the group took up residence in the city's easternmost peninsula at the palatial estate of [[Darkfriend]] merchant sworn to the [[Dark One|Great Lord]]. Liandrin then started pressing [[Eldrith Jhondar]], a former [[Brown Ajah]] sister, to conduct research in the king's library to better understand what they were searching for. Much to Liandrin's frustration, Eldrith was only able to determine that their goal was somewhere in the [[Panarch's Palace]] and that it was likely a [[Ter'angreal|ter'angreal]].



Knowing she had to take control of the palace to achieve her goal, Liandrin sought out [[Jaichim Carridin]] who she knew to be a Darkfriend that had recently attended the [[Darkfriend Social]]. After pacifying Jaichim, she discerned that he believed her to be an assassin come to murder him for failing to carry out his own directive of killing the [[Rand al'Thor|Dragon Reborn]]. Using this revelation as leverage, Liandrin forced Jaichim to agree to use his force of [[Children of the Light]] to occupy and hold the Panarch's Palace long enough for her followers to search for the Domination Band.  
Liandrin subsequently moved into the palace where she captured the newly installed Panarch [[Amathera Aelfdene Casmir Lounault|Amathera Lounault]] and handed her over to [[Temaile Kinderode|Temaile]] to be used as a plaything for her sadism. However, unbeknownst to Liandrin, [[Elayne Trakand]] and [[Nynaeve al'Meara]] had also been seeking the Domination Band, and the time it had taken her to locate it had allowed them to catch up with her. Liandrin had also failed to realize that her activities were being monitored by the recently freed [[Forsaken]], [[Moghedien]], who was in disguise as the servant Gyldin and aiming to use Liandrin and the black sisters as pawns in her own mysterious goals.  
While all at Panarch's Palace, Moghedien and Nynaeve crossed paths and began a titanic channeling duel. Immediately sensed by Liandrin, she dispatched [[Jeaine Caide]] to deal with the threat. Jeaine attacked Nynaeve while wielding [[Fluted black rod|one of the stolen ter'angreal]] from the White Tower that was believed to produce uncontrollable [[Balefire]]. In the ensuing chaos, large portions of the palace came crashing down, a riot erupted in the streets of Tanchico, and Nynaeve escaped with the Domination Band. 
With her plans once again in disarray, Liandrin was forced to flee the palace in failure.

### Subjugation by Moghedien
Now adrift and without purpose, Liandrin determined that neither she nor her followers could safely remain in Tanchico and so fled the region. They traveled to the east and sheltered in [[Amador]] at the house of another [[Darkfriend]] merchant, [[Jorin Arene]]. Jorin initially objected to Liandrin's group occupying his home until Liandrin had Temaile torture him into submission. Afterwards Liandrin began the task of reaching out to the [[Supreme Council]] in the White Tower for new instructions.
In short order Liandrin learned that [[Siuan Sanche]] had been [[White Tower Coup|deposed]] and that [[Elaida do Avriny a'Roihan]] had become the [[Amyrlin Seat]]. She also quickly noted that since this change in power had occurred, no new instructions seemed to be coming from the tower. Even so, she continued to reach out to the White Tower daily until she returned one day to Jorin Arene's estate to find her followers bound by deep [[Compulsion]] with [[Moghedien]] directing them.
Initially mistaking the Forsaken for the servant, Gyldin, Liandrin's reaction was hostile. Moghedien quickly subjugated her however, expressing to Liandrin how weak and pathetic she was in comparison to her own vast knowledge and far greater strength. Moghedien then dared Liandrin to attack her, stating that she knew Liandrin would try on her own eventually and that she wanted Liandrin to learn immediately how truly weak she was. Liandrin stated that she would not attempt such a betrayal, but the moment she thought the Forsaken's guard was down she deviously tried to do exactly that. Moghedien effortlessly parried the attack before subjecting Liandrin to extreme anguish and temporally placed a weave of true Compulsion upon her before removing it again. Cowed into submission, Liandrin accepted her new status as a minion to Moghedien, though in secret she decided to wait until a time when the Forsaken might become weakened when she would strike again.


Liandrin's moment came two weeks later. Moghedien pursued and attacked [[El'Nynaeve ti al'Meara Mandragoran|Nynaeve al'Meara]] and [[Birgitte Silverbow]] in *Tel'aran'rhiod*. In the ensuing struggle, Moghedien was shot by Birgitte and grievously wounded through the chest; an injury which carried over into the real world upon waking. The Forsaken immediately forced herself upon [[Liandrin's group of Black Sisters|Liandrin's black sisters]] demanding healing from [[Chesmal Emry]]. 
Seeing the moment of weakness she had been waiting for, Liandrin chose the instant to attack the Forsaken. Embracing [[Saidar]] she channeled a Compulsion attack at Moghedien with every ounce of strength she had, coupled with the additional knowledge of compulsion she had puzzled out, and hurled the attack as strong as she possibly could. Even as she did, *saidar* seemed to fill Moghedien like a flood. Liandrin's assault died as the source was [[Shielding|shielded]] from her and she was subsequently slammed against a wall by flows of air. 
Moghedien decided at that point that Liandrin required severe punishment. She tied off Liandrin's shield with an inverted weave outlandishly complex; such that no female channeler of lesser skill could ever unravel it even if they could detect it through the inversion. Moghedien then forced Compulsion upon Liandrin with one simple directive—*to live.* Knowing that a Compulsion directive reinforcing what a victim already wants to do will hold for a lifetime, Moghedien allowed Liandrin to anticipate the anguish of knowing the inverted tied-off shield would never allow her to channel again; effectively [[Severing|stilling]] her. Broken and weeping, Moghedien gave Liandrin over to her former ally [[Temaile Kinderode|Temaile]] for further torture, then forced the remaining Black Ajah sisters to witness her suffering to demonstrate the price of failure.
Afterward, Liandrin stayed a the Arene estate to work as a scullery maid under the lady of the house, [[Amellia Arene]] and [[Evon]] the cook.


Moghedien departed the Arene estate, leaving behind instructions for the remaining black sisters to carry out. Obedient to the Foresaken's orders to await her return, the black sisters hid on the Arene estate in the midst of a series of riots and mob invasion by followers of [[Masema Dagar|The Prophet of the Dragon]]. Eventually driven by fear and a growing certainty that Moghedien had forgotten them, the black sisters fled the estate. Thus it came to pass that the group of Black Ajah sisters [[Liandrin's group of Black Sisters|who once implicitly obeyed Liandrin's commands without question]], abandoned her to an uncertain fate in a wartorn land.

### Enslaved by Suroth
Following the [[Seanchan]] invasion of [[Amadicia]], the region was conquered by the [[Ever Victorious Army]] and the Arene estate was occupied by soldiers. Due to the inverted shield placed upon her, Liandrin was not immediately identified as a [[Channeler]] to be made [[Damane|damane]]. Once she realized this, Liandrin attempted to betray her captors as [[Darkfriend|Darkfriends]] in the hope that she might escape.
This plan only succeeded in making her a Seanchan prisoner and she was subsequently presented to the High Lady [[Suroth Sabelle Meldarath|Suroth]]. Remembering her from their prior encounter on [[Toman Head]] and despite secretly knowing that Liandrin could channel, Suroth decided to acquire Liandrin as personal property, turning her into *da'covale,* and keeping her as a slave within Suroth's household. In this capacity, Liandrin was garbed in nearly transparent white robes with delicate slippers and made to follow Suroth while carrying the High Lady's personal effects. Liandrin was also required to obey the directives of [[Alwhin]], Suroth's *So'jhin* and Voice of the Blood.
During [[Rand al'Thor|Rand's]] campaign to reclaim Seanchan-conquered [[Altara]], Liandrin accompanied Suroth to a strategy meeting in the field with [[Captain-General (Seanchan)|Captain-General]] [[Kennar Miraj]], where she was forced to carry the High Lady's ornate writing desk. Liandrin's bitterness in her demeaning role was obvious to Captain Miraj, who noted her frequent scowls, glaring sulkiness, and open resistance to obeying commands from Alwhin. These things were known also to Suroth who took pleasure in them by intentionally stroking Liandrin's braided hair in front of Miraj as one might do with a favored pet.
Later, in an attempt to please Suroth, Liandrin tried to poison [[Alwhin]], who had only obtained her position because she knew too many of the High Lady's secrets. However, Suroth was not pleased at this, as it drew the attention of the [[Seekers for Truth]].
Still later, Liandrin informed Suroth that [[Lunal Galgan]] had arrived and wished to see her. Due to her bad behaviour, Suroth sent Liandrin away to [[Rosala]] to be beaten. Because Liandrin's presence was sparking rumours about a *marath'damane* circulating free in her household, Lady Suroth started to consider that the time had arrived for Liandrin to be collared.
With Lady Suroth's downfall, Liandrin's fate is unknown.

## In the television series
In the [[The Wheel of Time (TV series)|TV series]],   is played by actress  .
## See also
[[Liandrin's Group of Black Sisters]]
## Notes

|**Major Characters**|
|-|-|
|**Protagonists**|**Main:****Primary:**|
|**Antagonists**|**The Shadow:**|
|**Major Allies**|**Aes Sedai:****Asha'man:****Aiel:****Seanchan:****Westlands Rulers:****Other Allies:**|
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Liandrin_Guirale