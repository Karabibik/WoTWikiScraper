---
tags: [Men, ChildrenoftheLight, Soldiers, Deceased]
---


**Lathin** was a [[Child of the Light]] in service to [[Lord Captain]] [[Geofram Bornhald]].

## Activities
In 998 NE, Lathin and [[Yamwick]] were with a large group of the Children in an unknown, abandoned *stedding*. While there, they discover [[Perrin Aybara]] and [[Egwene al'Vere]]. After telling them to come out of their hiding place, [[Hopper]] attacks and kills Lathin. Perrin then attacks Yamwick after Hopper was killed by another Child.
Almost two years later, Child [[Oratar]] and Child [[Byar]] testify at a trial, held by [[Lord Captain Commander]] [[Galadedrid Damodred]] and judged by [[Morgase Trakand]], about the deaths. Byar insists that the killing of the Children makes Perrin a [[Darkfriend]].

## Notes






https://wot.fandom.com/wiki/Lathin