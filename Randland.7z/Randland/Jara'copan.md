---
tags: [Ruins, Historicalsettlements, Manetheren]
---

**Jara'copan** was an [[Ogier]]-built city of [[Manetheren]].
Jara'copan was located in a valley in the foothills of the [[Mountains of Mist]], six days south of the city of Manetheren itself, reachable by a road that wound along the feet of the mountains. The city itself spread across an area of about three square miles. Due to population pressures and the limitation of space in the city, it extended some way underground with elaborate subterrenean vaults and storage locations.
After the fall of Manetheren in the [[Trolloc Wars]], Jara'copan was abandoned and over the past two thousand years has fallen into ruin. The highway linking it to Manetheren is now a barely-discernable track leading off from the [[Quarry Road]] and most of the buildings have collapsed. Among the surface structures only the [[Waygate]] remains intact. The subterrenean levels remain relatively intact, however.

## Source
Jara'copan is mentioned in *The World of Robert Jordan's The Wheel of Time* as an Ogier-built city of Manetheren. Its precise location and geography are given in *The Prophecies of the Dragon*, an expansion to *The Wheel of Time Roleplaying Game* published by Wizards of the Coast. Although Robert Jordan approved the product, he later ruled one chapter of the book as non-canon. As a result, the canon status of the book's depiction of Jara'copan is unknown.






https://wot.fandom.com/wiki/Jara%27copan