---
tags: [Saldaea, Titles, Kandor]
---
**Shield of the North** is a title of the [[Kandor|Kandori]] and [[Saldaea|Saldaean]] monarchs. The title alludes to the fact that both nations are in the north and guard against invasion of [[Trolloc|Trollocs]] from the [[Great Blight]]. Currently, Queen [[Ethenielle Cosaru Noramaga]] and Queen [[Tenobia si Bashere Kazadi]] holds this title. Since the title is shared by two of the [[Borderlands|Borderland]] monarchs, is is logical to assume that all four monarchs would have this title. However, this cannot be confirmed, as King [[Paitar Nachiman]]'s and King [[Easar Togita]]'s full titles are not known.


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Shield_of_the_North