---
tags: [Men, Aiel_people, Unknownclan, Meradin, Deceased]
---


**Kinhuin** was one of the *Mera'din* [[Aiel]]. 

## Appearance
He had green eyes and full lips. He was a hand shorter than [[Rolan]].

## Activities
He [[Travel|Traveled]] to [[Ghealdan]] with [[Sevanna]] and all the other [[Wise Ones]].
He came to help rescue [[Faile Bashere]] when she was trapped in the burnt out old building in the town of [[Malden]]. When the [[Battle of Malden]] began, he fled with Faile and the rest of their group. They ran into [[Perrin Aybara]] who killed Rolan. While running to Rolan's aid he was stabbed in the back by Faile.






https://wot.fandom.com/wiki/Kinhuin