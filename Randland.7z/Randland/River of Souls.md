---
tags: [Seriesbooks]
---
*River of Souls* is a short story published in an anthology entitled *Unfettered*.

## History
*"Lacking health insurance and diagnosed with Hogdkin's lymphoma in 2011, Shawn [Speakman] quickly accrued a massive medical debt that he did not have the ability to pay. That's when New York Times best-selling author Terry Brooks offered to donate a short story Shawn could sell toward alleviating those bills—and suggested Shawn ask the same of his other friends."*
   —Release from Grim Oaks Press, the publisher of *Unfettered*. 
[[Brandon Sanderson]] confirmed that *River of Souls* will include several scenes that were written for *A Memory of Light*, but were cut for various reasons. A video and transcript can be found  These scenes are from the perspective of [[Demandred]] while in [[Shara]].
*Unfettered* was released in June, 2013, after *A Memory of Light*.

## External links


|**Books**|
|-|-|
|**Main Series**||
|**Other works**||
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/River_of_Souls