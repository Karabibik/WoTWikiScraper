---
tags: [Women, Saldaea_people, Darkfriends, Ladies, Deceased, Nobility]
---



Lady **Torkumen** was a [[Saldaea|Saldaean]] noble and a [[Darkfriend]]. Her husband is [[Vram Torkumen]].

## Activities
Her husband delayed aid to [[Rodel Ituralde]]'s army in defending [[Maradon]] against an invading [[Trolloc]] army. Eventually, Ituralde's forces were permitted into the city at the latest possible moment. Ituralde visits the pair with [[Yoeli]] and names them both Darkfriend. 
They were subsequently joined by [[Rand al'Thor]], who single-handily decimated the invading Trolloc Army. Upon Rand's channeling, Vram and Lady Torkumen were revealed to be Darkfriends. Lady Torkumen threw herself out the window while Vram clawed out his own eyes.

## Notes






https://wot.fandom.com/wiki/Lady_Torkumen