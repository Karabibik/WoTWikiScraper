---
tags: [BlueAjah]
---
The **Blue Ajah** of the [[Aes Sedai]] normally involve themselves with righteous causes and justice. They have the most extensive [[Eyes-and-ears|eyes-and-ears]] network, and enjoy the prestige of having the highest number of [[Amyrlin Seat|Amyrlin Seats]] raised from their [[Ajah]] in the last millennium.
The Blue has been at odds with the [[Red Ajah]] for a millennium and for a time were separate from the [[White Tower]] altogether. The head of the Blue Ajah is called the [[First Selector]].

## Contents

1 Characteristics
2 Size

2.1 Demographics


3 Quarters
4 Ajah loyalties

4.1 Red Ajah
4.2 Green Ajah
4.3 Brown Ajah
4.4 Yellow Ajah
4.5 White Ajah


5 Traditions
6 Exodus
7 Secret weaves
8 Leaders
9 List of Amyrlin Seats from the Blue Ajah
10 List of known Blue sisters
11 External links
12 Notes


## Characteristics

The Blue Ajah concerns itself with justice, noble causes, and in general "saving the world". In their tasks the Blues can be so passionate and focused that often other sisters see the Blues as "*so ready to save the world that they lose themselves*". [[Moiraine Damodred|Moiraine]] and [[Siuan Sanche|Siuan]] both chose the Blue because of their passion for justice; [[Verin Mathwin]] once called the Blues "Seekers for Causes", and the capital "C" in Causes was evident. It may be worthy to note that the justice they pursue is not the same as that of the Gray Ajah, but instead seems much more personal and perhaps more in the spirit rather than the letter of the law as might be the case with the legally minded Grays.
Another typical characteristic of the Blue Sisters is that they often become embroiled in intrigue. In the eyes of other Aes Sedai they are incorrigible schemers. At least in recent history, the Blue Ajah has been at the centre of the political landscape within the Tower, to a far greater degree than might be expected for their small size. This can be further seen by the fact they have the largest network of [[Eyes-and-ears]] of all the Ajahs. 
While they are not as fond of men as the Green Sisters, the Blue Sisters do not avoid males as some of the other Ajahs, notably the Red and White, seem to. [[Alanna Mosvani]] of the [[Green Ajah]] comments that a Blue sister likes men as long as they share her causes and do not get in her way.
[[Jesse Bilal]] thinks about the Blue Ajah characteristic of being driven to a single cause leading to single-mindedness: "*We never should have let Elaida disband the Blue Ajah... The Blues might have been willing to come back, had it not happened. But it was such a dishonour that they dug in. Light only knew how dangerous that was! The histories were filled with accounts of how dogged the Blues could be at getting their ways, particularly when they were forced into a corner*".
A final characteristic of the Blues is their relative worldliness compared with other Ajahs. With the exception of those embroiled in the White Tower's internal politics, they are often found out in the world finding and pursuing causes. This is a philosophy shared with the Green Ajah that may explain why they had been long-time allies (see later section).
Like in the majority of the other Ajah, Blue Aes Sedai only bond one [[Warder]] at a time.

## Size
The Blue is the sixth-largest Ajah, behind the [[Yellow Ajah|Yellow]] and before the [[White Ajah|White]]. Before the [[Schism]], they numbered roughly one hundred members.
It also contained twenty-two [[Black Ajah|Black]] sisters, though the reader has only learned the identity of five. 

### Demographics
The Blue Ajah breakdown by nationality for named Aes Sedai within the last 20 years:

Andor: 4
Cairhien, Tear: 3
Arad Doman, Illian, Saldaea, Tarabon: 2
Arafel, Kandor: 1
Amadicia, Far Madding, Mayene, Murandy, Sheinar: 0
## Quarters
The Blue Ajah section of the White Tower is not as flamboyant as that of the Green and Yellow Ajah, but is not quite as plain as the Brown's or White's.
The personal apartments for the sisters are located in side halls that branch off from the main hall. Each of them contains a spacious bedchamber, a large sitting room, a dressing room, and a study.

## Ajah loyalties
### Red Ajah
There is deep-seated animosity between the Blue and Red Ajahs. It began two thousand years ago when [[Tetsuan]] was [[Deposed|deposed]] and [[Stilled|stilled]] and replaced by an Amyrlin formerly of the Blue, and was reignited a thousand years later when [[Bonwhin Meraighdin]] was also deposed, stilled, and replaced by an Amyrlin raised from the Blue, the legendary [[Deane Aryman]].
For the next one thousand years the lack of any Amyrlin Seats raised from the Red Ajah infuriated the Reds, and culminated in the deposing and stilling of [[Siuan Sanche]] and the raising of [[Elaida do Avriny a'Roihan]]. The entire Blue Ajah deserted the White Tower, along with sisters from the [[Brown Ajah|Brown]], [[Gray Ajah|Gray]], [[Green Ajah|Green]], Yellow, and White Ajahs, and formed their own "[[Little Tower]]" in defiance of Siuan's treatment. With the raising of [[Egwene al'Vere]] to the Amyrlin Seat, the Blue Ajah has since returned to the Tower, but the relationship between the two Ajahs is still volatile.

### Green Ajah
The Blue Ajah is closely allied with the Green Ajah, which is a friendship that has continued for a millennium. On rare occasion, there is some struggle and tension between the two Ajahs, such as when the Green Sitters of the time suggested [[Moiraine Damodred]] be sentenced to farm work due to Siuan favoring her, but the friendship of the Blue and Green Ajahs is firm and assured. The Green Sitters at the time of this proposal were [[Talene Minly|Talene]], [[Faiselle Darone|Faiselle]] and [[Rubinde Acedone|Rubinde]]; Talene and Rubinde would later vote to depose Siuan and raise Elaida, so it is likely they were behind this proposition. Talene was secretly Black Ajah and probably under orders to foment dissent within the Hall of the Tower.

### Brown Ajah
The Brown Ajah will support the White over the Blue, but supports the Blue over the Yellow. It is telling that the Brown, along with the White, were the only Ajahs (except the Blue, of course) where only one Sitter ([[Saerin Asnobar|Saerin]]) voted to depose Siuan and raise Elaida. Of the Sitters who did not vote so, [[Janya Frende|Janya]] was the only one who joined the Rebels of her own volition.

### Yellow Ajah
There is some animosity between the Blue and Yellow Ajahs, due to interference between the two over something that happened more than one hundred years ago in [[Altara]]. In recent years, [[Lelaine Akashi]] (and to some extent, even if through no fault of her own, [[Tamra Ospenya]]) and [[Romanda Cassin]] made sure to deepen this conflict of interests.

### White Ajah
During the [[Aiel War]] the Blue Ajah's relationship with the White became strained, the reason for which was not known to the Blue Ajah. However, their shared animosity toward the Red Ajah has kept the Blue and White's relationship from deteriorating, and they have been on the same power axis as the Blue and the Green in the [[Hall of the Tower]] for the past millennium. Indeed, only one White Sitter ([[Velina Behar|Velina]], who was secretly Black Ajah) voted to depose Siuan and raise Elaida; and it was [[Seaine Herimon|Seaine]], a White, who proposed Siuan for Amyrlin in the first place.

## Traditions

Known traditions for members of the Blue Ajah:

never wearing red inside the Tower, though red gemstones are allowed
wearing all blue the first of each month
wearing blue stockings when leaving [[Tar Valon]]
refraining from marriage (except in some cases, such as Moiraine Damodred marrying [[Thomdril Merrilin]] and Siuan Sanche marrying [[Gareth Bryne]])
greeting the newest Blue sister with a kiss of welcome
requiring the newly-raised Blue sister to bake a pie for the sixth member of the Blue to kiss her
An ancient tradition involved all newly-raised sisters (not just Blue) to walk to the halls of her Ajah clad only in her [[Shawl|shawl]], but this was abandoned a long time ago. All that remains of this custom is that the hallways of the Tower must be kept clear until the new Aes Sedai reaches the quarters of her Ajah.

## Exodus
When [[Siuan Sanche]] was deposed and stilled, and replaced by [[Elaida do Avriny a'Roihan]] as [[Amyrlin Seat]], the entire Blue Ajah fled and secretly organized the [[Rebel Aes Sedai|rebel faction of the Aes Sedai]] at [[Salidar]] in Altara. No Blue remained in the Tower, though some did not join the rebels because of the distance. However, they were unanimous in believing that Siuan's deposition and Elaida's raising was illegal, and that Elaida deserved to be pulled down. This exodus was later sealed when Elaida disbanded the Blue Ajah entirely. With the eventual reunification of the White Tower, the Blue Ajah was restored after all the rebel sisters apologized to [[Egwene al'Vere]], the Amyrlin Seat they elected for themselves, for their actions.

## Secret weaves
All Ajahs have [[Weave|weaves]] known only to their members, and the Blue Ajah are no exception. There are two that are known so far. One controls insects, either repelling them, or making them gather and bite all at once. The other weave makes a person feel fear. It can be used to aid intimidation, as when pressing someone to answer questions, but unlike [[Compulsion]] it does not appear to actually force the subject to take any particular action.

## Leaders
The [[First Selector]] of the Blue Ajah is [[Lelaine Akashi]]. She is also a [[Sitter]] in the [[Hall of the Tower]], along with [[Lyrelle]]. As explained by Anaiya, Kairen and Cabriana, the Blues like using the abilities of their members to the fullest, and it seems to be common for the Blue Ajah Head to also be a Sitter in the Hall (as evidenced by both [[Eadyth]] and Lelaine).
A third Blue Sitter, who is yet to be identified, was killed during the fighting that broke out when Siuan was deposed, to be replaced by [[Moria Karentanis]] in Salidar, who was in fact Black. It is possible that this one Sitter was [[Eadyth]] or [[Anlee]], who were Sitters during the [[Aiel War]]. It is unclear who replaced Moria in the [[Hall of the Tower under Egwene al'Vere|newly united Hall]]. There is a theory that it is [[Elswell]], an Aes Sedai who only appeared after the Last Battle, but this is not confirmed.
The First Selector could be more or less autocratic, depending on the woman holding the post. She always has an advisory council with a variable number of members. Beyond that, there is no constant organizational structure, except possibly for the post of Head of the Eyes-and-Ears network.
During the Aiel War, [[Cetalia Delarme]] headed the eyes-and-ears. She tested [[Siuan Sanche]], who had a reputation for having a sharp mind, and took her on as an assistant. After Cetalia died, Siuan took over the post. After Siuan was raised Amyrlin, [[Aeldene Stonebridge]] held the post. When Siuan arrived in Salidar, she would take over the eyes-and-ears while Aeldene was absent; upon Aeldene's arrival, she retook the post.

## List of Amyrlin Seats from the Blue Ajah
One of the smallest Ajah in the White Tower, the Blue holds the highest number of Amyrlin Seats in the last millennium. Most Amyrlins raised from the Blue were strong or moderately strong, and many were quite successful. Although not identified, the Amyrlin that replaced Tetsuan was also raised from the Blue.

[[Deane Aryman]] (c. [[FY 992]] - c. [[FY 1084]])
[[Edarna Noregovna]] (64 NE - 115 NE)
[[Comarra Zepava]] (244 NE - 276 NE)
[[Suilin Escanda]] (355 NE - 396 NE)
[[Ishara Nawan]] (419 NE - 454 NE)
[[Eldaya Tolen]] (533 NE - 549 NE)
[[Feragaine Saralman]] (732 NE - 754 NE)
[[Noane Masadim]] (950 NE - 973 NE)
[[Tamra Ospenya]] 19(7) (973 NE - 979 NE)
[[Marith Jaen]] (984 NE - 988 NE)
[[Siuan Sanche]] 13(1) (988 NE - 999 NE)
## List of known Blue sisters
Beside each name is reported the double strength level and the sum of the *years* of training as described by "The Wheel of Time Companion"

[[Adine Canford]] 34(22) *12+11 (teacher in the Rebel camp)*
[[Aeldene Stonebridge]] 27(15) *10+9* (head of the Blue [[Eyes-and-ears|eyes-and-ears]] network)
[[Aeldra Najaf]] (former [[Keeper of the Chronicles]] under [[Tamra Ospenya]])
[[Anaiya Carel]] 15(3) *8+7* (suspected former [[First Selector]]; dead)
[[Anlee]] (former Sitter; possibly deceased or in retirement)
[[Berylla Naron]] 27(15) *7+5* (also [[Black Ajah]]; possibly dead or captured)
[[Cabriana Mecandes]] 34(22) *12+7* (dead)
[[Cetalia Delarme]] 14(2) (former head of the Blue Ajah's eyes-and-ears network; killed by the Black Ajah)
[[Eadyth]] (former Sitter and First Selector; possibly deceased or in retirement)
[[Faolain Orande]] 17(5) *8+5* (promoted to Aes Sedai by [[Egwene al'Vere]])
[[Gitara Moroso]] 19(7) *6+7* (Keeper of the Chronicles under Tamra Ospenya; dead)
[[Ispan Shefar]] 17(5) *6+8* (also Black Ajah; dead)
[[Kairen Stang]] 18(6) *8+8* (dead)
[[Lannis]] (historical scholar; dead)
[[Leane Sharif]] old 14(2), new 36(24) *5+4* (former Keeper of the Chronicles under Siuan Sanche; changed to the [[Green Ajah]])
[[Lelaine Akashi]] 13(1) *5+6* (Sitter and current First Selector)
[[Lyrelle Arienwin]] 24(12) *6+4* (Sitter)
[[Maigan]] 15(3) (Egwene's Blue Ajah advisor in Salidar)
[[Marith Jaen]] (former Amyrlin Seat; dead)
[[Merean Redhill]] 14(2) (former [[Mistress of Novices]] under [[Tamra Ospenya]]; also Black Ajah; dead)
[[Moiraine Damodred]] old 13(1), new 66(54) *3+3*
[[Moria Karentanis]] 25(13) *8+7* (also Black Ajah; Sitter; executed)
[[Nadira]]
[[Natasia]] (only appeared in [[New Spring]])
[[Rafela Cindal]] 16(4) *6+5* (sworn to [[Rand al'Thor]])
[[Reiko Kerevon]] 38(26)
[[Sheraine Caminelle]] (*damane*)
[[Sheriam Bayanar]] 14(2) *5+5* (former Mistress of Novices under [[Siuan Sanche]]; former [[Keeper of the Chronicles]] under [[Egwene al'Vere]]; [[Black Ajah]]; executed)
[[Siuan Sanche]] old 13(1), new 35(23) *3+3* (former head of the Blue [[Eyes-and-ears|eyes-and-ears]] network; former Amyrlin Seat; dead)
[[Tamra Ospenya]] 19(7) (former Amyrlin Seat; killed by the Black Ajah)
## External links
  on  
## Notes

||
|-|-|






https://wot.fandom.com/wiki/Blue_Ajah