---
tags: [Men, Illian_people, Bouncers, LivingasofTDR, ]
---




**Bili** is a [[Bouncer|bouncer]] at an inn called [[Easing the Badger]] in [[Illian]]. His aunt is named [[Nieda Sidoro]].

## Appearance
Bili is a very large man, bigger than [[Perrin Aybara]]. He can carry a man in either hand out of the inn.

## Activities
Bili sees [[Bayle Domon]] at the inn when the ship captain visits. When Gray Men attack the inn, Perrin, [[Lan Mandragoran]], [[Moiraine Damodred]], [[Faile Bashere]], and [[Loial]] kill them before Bili has time to react. Bili is told by his aunt to haul the bodies of the Gray Men out of the common room and lay down clean sawdust.

## Notes






https://wot.fandom.com/wiki/Bili_(bouncer)