---
tags: [Women, Seanchan_people, Deceased, Historicalpeople, Damane, Slaves, Channelers, Suldam, Inventors]
---


**Deain** was a [[Seanchan]] [[Aes Sedai]] inventor of the [[A'dam|a'dam]]. 

## History
Deaine was a female channeler who lived on the [[Seanchan]] continent at the time of [[Luthair Paendrag Mondwin]]'s invasion in [[FY 992]] where nations were mostly controlled by this channelers and no nation trusted the other. In fact at that time all female channelers in Seanchan proclaimed themselves to be Aes Sedai, but they were completely independent and unaware of the [[White Tower]]. Contrary to those grouped in the White Tower, these Seanchan Aes Sedai frequently fought each other, and they used the [[One Power]] as a weapon or to enslave people.
With Luthair's forces opposed by vast armies of natives led by Aes Sedai, Deain offered Luthair her invention, a *ter'angreal* she had created called an *a'dam* with which one female Aes Sedai can completely control another. It looked like a collar with a leash and a bracelet to the controller. It has created a link between the two channellers even against the will of the one who wore the collar.
Luthair agreed to pay an unknown price for the device and the secrets of its manufacture. In this way Deain became the first *Sul'dam*.
Later on Deain herself was also leashed with one of her own devices in the [[The Towers of Midnight]] in [[Imfaral]], becoming so also one of the first '**damane'**. It is said that her screams shook the Towers themselves. Her eventual fate is unknown, but her "gift" allowed Luthair and his descendants to take control of the entire Seanchan continent within three centuries.

## Death
Her exact fate is unknown.
*"When Luthair Paendrag Mondwin, son of the Hawkwing, first faced the Armies of the Night, he found many among them who called themselves Aes Sedai. They contended for power among themselves and used the One Power on the field of battle. One such a woman named Deain, who thought she could do better serving the Emperor – he was not Emperor then, of course – since he had no Aes Sedai in his armies, came to him with a device she had made, the first a'dam, fastened to the neck of one of her sisters. Though that woman did not want to serve Luthair, the a'dam required her to serve. Deain made wore a'dam, the first sul'dam were found, and women captured who called themselves Aes Sedai discovered that they were in fact only marath'damane, Those Who Must Be Leashed. It is said that when she herself was leashed, Deain's screams shook the Towers of Midnight, but of course she, too, was a marath'damane, and marath'damane cannot be allowed to run free." *
*– *[[Renna Emain|Renna]], the *sul'dam* to [[Egwene al'Vere|Egwene]] in [[Falme]]* *

## Notes






https://wot.fandom.com/wiki/Deain