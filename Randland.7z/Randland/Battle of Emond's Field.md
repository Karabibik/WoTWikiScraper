---
tags: [Battles, Andor, TwoRivers]
---

The **Battle of Emond's Field** consisted of a series of raids on the town of [[Emond's Field]] by [[Trolloc]] forces brought to the [[Two Rivers]] through the [[Ways]]. The attacks culminated in a final confrontation between the people of Emond’s Field and the Trolloc armies after [[Loial]] and [[Gaul]] succeeded in permanently locking the [[Manetheren]] Waygate, cutting off reinforcements. During the ensuing battle, the Emond’s Field defenders were nearly overrun by overwhelming numbers but were saved from annihilation by the timely arrival of unexpected reinforcements from both [[Deven Ride]] and [[Watch Hill]].

## Contents

1 Background
2 Preparations
3 Battle

3.1 First Day
3.2 Subsequent Attacks
3.3 Final Battle




## Background
By the events in [[The Shadow Rising]], [[Padan Fain]] who was now known as Ordeith, had managed to worm his way into an advisory position to [[Pedron Niall]], Lord Captain Commander of the [[Children of the Light]]. He persuaded the Lord Captain to allow him to accompany a group of the Children into the Two Rivers under the pretext of hunting [[Darkfriends|darkfriends]]. The commander of the Children was [[Dain Bornhald]], who was easily influenced due to his grudge against Perrin Aybara for his supposed betrayal of Dain’s father, [[Geofram Bornhald]]. Fain used his influence with the Children to arrest and prosecute the families of [[Mat Cauthon]], [[Rand al'Thor]], and [[Perrin Aybara]], in the hopes of luring Rand back to the Two Rivers to be killed.
At Fain’s behest, the Whitecloaks arrested the Cauthon girls and the Luhhan couple, and burned the Cauthon farm. [[Abell Cauthon]] managed to escape and go into hiding with [[Tam al'Thor]]. Fain personally killed the entire Aybara family for laughing at him when he accused Perrin of being a darkfriend. The Whitecloaks burned the al'Thor farm but not before Tam killed five of them with his bow. The two men, Tam and Abell, decided to go into hiding while trying to figure out how to rescue the Whitecloak's captives.
The creature known as [[Slayer]], meanwhile, also arrived in the Two Rivers in the guise of Lord Luc, to hunt down and kill the ever more dangerous Fain. He brought a number of Trollocs and [[Myrddraal]] through the Manetheren Waygate, but their numbers were initially insufficient to deal with Fain, who enjoyed the protection of the Whitecloaks. While waiting for Fain's death, he hunted down and killed all of the wolves in the Two rivers and paraded himself around as Lord Luc.
Perrin, upon hearing of Whitecloaks in the Two Rivers, decided to travel back by the Ways and give himself up to spare his family any harm. He was prepared to go to his death and wanted to bring only Loial with him. Despite his best efforts, he could not dissuade [[Faile]], who tricked Loial into bringing her. Although Rand was unwilling to accompany Perrin because his efforts to prepare for [[Tarmon Gai'don]] were too important, he asked several of the [[Aiel]] to aid Perrin. Only [[Gaul]], [[Bain]], and [[Chiad]] wanted to go with him and so the three Aiel, Perrin, Faile and Loial set out to journey to the Two Rivers.

## Preparations
After arriving in the Two Rivers and learning of the situation in his home village, Perrin set out to free the Luhhans and Cauthons from the Whitecloaks. Traveling northward from Emond's Field to the Whitecloak encampment, Perrin and his companions stopped at several farmsteads. Discovering that people were trying to hold out against the Trollocs by themselves (at Lord Luc's suggestion) and fearing for their safety, Perrin managed to convince several families to move to Emond's Field for better protection. After rescuing the Cauthons and Luhhans from the Whitecloaks and suffering a Trolloc ambush, Perrin arrived back at Emond's Field to discover the villagers ready to follow him and do what was necessary to defend their home
Trees around Emond's Field were cleared to approximately 500 paces toward the beginning of the siege, to make a clear killing field for the [[Two Rivers Longbow|longbowmen]]. Sharpened stakes were driven into the ground at an angle all around the village to fend off and slow down the enemy charges. Master [[Haral Luhhan|Luhhan]], with the help of [[Verin]] and [[Alanna]] and their respective Warders, constructed a dozen catapults used to hurl boulders which exploded into fire and stone upon impact. Polearms were constructed with converted farm equipment such as scythes and shovels, and were used by the majority of the defenders; some villagers also managed to find old swords and armor sets passed down for many generations. Most villagers were also armed with longbows and boys who had reached adolescence were either placed on rooftops to utilize their longbows, or placed with the defenders on the battle line. Younger boys were used to carry arrows or to deliver messages.


## Battle

The first attack consisted of approximately 500 Trollocs, herded by several Myrddraal. The attack was a test of the Emond's Fields' defenses, and had the Trollocs charging towards Emond's Field from the edges of the forest. The Half-men wanted to see how organized the men were in their defense and whether they would break ranks at the sight of a charge. However, the Trolloc numbers were too small, and the entire force was quickly cut down by disciplined Two Rivers longbowmen before they even reached the stakes that ringed the village.


In the seven days following the first attack, the Trolloc forces attacked with increasing numbers, and the defenders were forced to "fight at the stakes" at least three or four times. Little is told of these attacks short of the fact that by this time, all of the pole arms and swords have now been distributed to the defenders, and not a scythe or pitchfork remained that could be turned into a weapon.


The earlier sorties and attacks stopped when Loial and Gaul succeeded in sealing the Manetheren Waygate permanently. The Trolloc forces, cut off from further reinforcements, instead gathered for one final confrontation. On the day of their attack, the Trolloc forces assembled to the North and South of Emond's Field about an hour before midday. Their numbers have been estimated at several thousand, though no exact count was given.

The majority of the Emond's Field defenders were distributed to the North and South to face the Trolloc forces, with smaller groups distributed towards East and West to guard against possible Trolloc flanking attacks. Abell Cauthon was given charge of the defenders to the West, Tam al'Thor to the South, [[Jon Thane]] and [[Samel Crawe]] to the East, and [[Brandelwyn al'Vere|Bran al'Vere]] had nominal command to the North (on account of Perrin choosing to fight in the North). More than four hundred of the Whitecloaks under [[Dain Bornhald]] were assembled on the village Green, along with the women of Emond's Field, who were guarding the children and the *Tuatha'an*, to facilitate a last ditch effort to escape with the children should the defenders fall. Verin and Alanna were also stationed in the North and South respectively to work the catapults.
The Trollocs again charged the defenses and with their increased numbers, managed to make it past the stakes and engage in close combat. Fearing that their lines would break due to the vast number of Trollocs, the defenders quickly pulled back to fight between the houses. The Whitecloaks, under Bornhald, had decided against helping the villagers, and instead remained on the Green. Seeing this, the women of the village quickly left and fought alongside the men, reinforcing the lines. However, even with their help, the defenders were being pressed too hard and were on the cusp of defeat.
Unbeknownst to the Emond's Fielders, villagers from Deven Ride and Watch Hill had both marched to their aid, the latter led by Faile who returned after Perrin had tried to send her away from what he thought was a sure death. As the men of Deven Ride arrived in the South, quickly followed by those of Watch Hill to the North, they began raining arrows down upon the Trollocs' exposed flanks. The remaining Myrddraal tried to rally a charge against the new forces, but were quickly cut down in a hail of arrows from both sides.
In the aftermath of battle, the Whitecloaks attempted to arrest Perrin for being a darkfriend. They were summarily rebuffed and told to leave the Two Rivers for good. Although Perrin had tried to shy away from his responsibility and leadership, all of the villagers now respected and treated him as Perrin Goldeneyes, Lord of the Two Rivers.






https://wot.fandom.com/wiki/Battle_of_Emond%27s_Field