---
tags: [Women, Andor_people, Maids, LivingasofAMOL]
---



*"I think the woman was born in Far Madding in a thunderstorm. She probably told the thunder to be quiet. It probably did."*
   —[[Basel Gill]] 
*"At my age, if I make it up, it is still an old saying."*
   —Lini Eltring 
**Lini Eltring** (LIHN-nee; /ˈlɪ.nɪ ˈɛɫ.tɹɪŋ/) is an [[Andor|Andorwoman]] who has been nurse to three generations of Trakand women, including [[Maighdin Trakand|Maighdin]], [[Morgase Trakand|Morgase]] and [[Elayne Trakand]]. She is known for having a saying for almost every situation.

## Contents

1 Appearance
2 History
3 Lini's sayings
4 Activities

4.1 Leaving Andor
4.2 Service to Faile


5 Trivia
6 Notes


## Appearance
Lini is described as very thin with a back as straight as a rod despite her old age. Her hair is white, drawn in a bun. She has a narrow face with skin like thin parchment and has dark eyes. She is very strict and has a practical view of the world and those in it.

## History
She switched Elayne for stealing figs when she was little, and perhaps when she was "not so little".

## Lini's sayings
(*For a full list see Lini's sayings*)

"*Peel the apple in your hand, not the one on the tree*"
"*Tears are for after; they just waste time before.*"
"*When a woman plays the fool, look for the man.*"
"*You can do whatever you wish. So long as you're willing to pay the price.*"
## Activities
### Leaving Andor
As a nurse, she can afford to speak to both women in a way no noble lady of Andor could dare. For instance, she told Morgase that her affair with [[Gaebril]] was known to everybody.
She now lives in the Pensioners' Quarter of the Queen's palace in [[Caemlyn]], like many elderly former servants. 
When Morgase comes to Lini's apartment, Lini reveals the full extent of how things have deteriorated in Andor under Gaebril's rule. She brings in [[Martyn Tallanvor]] to confirm the story. She then flees Caemlyn with Morgase, Tallanvor, [[Basel Gill]], [[Lamgwin Dorn]], and [[Breane Taborwin]].
They arrive in [[Amadicia]] and are held captive in the [[Fortress of the Light]] by [[Pedron Niall]]. She still refers to Morgase as a child but remains very loyal to her and is disgusted with the way Breane talks to Morgase. She has also hinted several times that Tallanvor would be a good love interest for Morgase. She manages to escape with Morgase and the rest of her crew with the help of [[Sebban Balwer]].

### Service to Faile
While traveling in [[Ghealdan]], Lini and her group are saved by [[Perrin Aybara]] when they are attacked by the [[Masema Dagar|Prophet]]'s men. They then join with Perrin's army and become attendants under [[Faile Bashere]].
After Faile's capture by the [[Shaido]] [[Aiel]], she becomes a servant to Perrin. She believes the rumors of Perrin sleeping with [[Berelain sur Paendrag Paeron]], and has become very surly with him.
Perrin sends her north just before the attack on the Shaido in [[Malden]] with the intention of catching up with her afterwards. Her group is intercepted by the [[Children of the Light]], who keep them captive. She is returned to Perrin's army after Perrin's trial.
After watching enough of Morgase and Tallanvor fawn over each other, she hauls the both of them in front of Perrin, where he presides over a small and simple wedding ceremony. She then leaves Perrin's army to continue serving Morgase.

## Trivia
Lini's greatest treasure are six miniature portraits of [[Maighdin Trakand]], [[Morgase Trakand]] and [[Elayne Trakand]], with one as a child and one as a young woman.
## Notes

|**Major Characters**|
|-|-|
|**Protagonists**|**Main:****Primary:**|
|**Antagonists**|**The Shadow:**|
|**Major Allies**|**Aes Sedai:****Asha'man:****Aiel:****Seanchan:****Westlands Rulers:****Other Allies:**|
|Places | Items | Timeline | Concepts|






https://wot.fandom.com/wiki/Lini_Eltring