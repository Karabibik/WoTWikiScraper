---
tags: [Amadicia, Towns]
---
**Almizar** is a town in [[Amadicia]]. It lies in farming country a hundred miles southwest of [[Amador]] near the [[Tarabon]] border. It is a prosperous town with six watchtowers but no wall. The streets are paved with granite blocks, and lined with solid buildings of brick or stone, some gray, some black, many three or four stories high and most roofed in dark slate, the rest in thatch.






https://wot.fandom.com/wiki/Almizar