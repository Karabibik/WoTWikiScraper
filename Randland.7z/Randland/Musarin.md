---
tags: [Women, YellowAjah, AesSedai, LivingasofTGS, ElaidaaRoihansWhiteTower, Channelers]
---


**Musarin** is an [[Aes Sedai]] of the [[Yellow Ajah]]. 

## Appearance
She is tall and aging. She has white hair. Her hair color implies she is significantly more than two hundred years old.

## Activities
She is guarding [[Leane Sharif]] when [[Egwene al'Vere]] comes to visit her in the cells. A [[Bubble of evil|bubble of evil]] erupts and begins to melt Leane's cell. Leane is saved when [[Gelarna]] and Musarin pull her out of the cell with [[Weave|weaves]] of [[Air]].

## Notes






https://wot.fandom.com/wiki/Musarin