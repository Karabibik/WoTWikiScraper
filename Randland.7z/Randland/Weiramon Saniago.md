---
tags: [Men, Tear_people, Darkfriends, HighNobilityofTear, Ladies, Unknownstatus, LivingasofAMOL, Nobility]
---


**Weiramon Saniago** is a [[Tairen]] [[High Lord]] and a [[Darkfriend]].

## Contents

1 Appearance
2 Activities

2.1 To Cairhien
2.2 The Seanchan campaign


3 Notes


## Appearance
He is thin, with gray streaked hair and an oiled pointy beard. He is not short and there is something of a strutting rooster about him. He is balding.

## Activities
### To Cairhien
Despite being in service to Rand, Weiramon's noble prejudices and exaggerated opinion of his own abilities make him, if not untrustworthy, at least unsuitable to take charge of matters of great importance. For example, his views on military tactics begin and end with the charge, with no room for deviation.
He was sent to [[Cairhien]] as reinforcements when the city is attacked by the [[Shaido]] while gathering forces as he went.
Due to Weiramon's high rank but poor military tactics, he is sent from the battle of Cairhien to the [[Plains of Maredo]]. He is placed in charge of the massive force Rand gathered there for the attack on [[Illian]]. 
There he almost ruined that plan by attacking off with the cavalry and leaving the infantry behind, once the attack on Illian began.

### The Seanchan campaign
He goes with Rand when Rand tried to deal with the Illian rebels loyal to Lord Brend, who the forsaken Sammael was posing as.
He is placed under Rand's direct command when Rand's forces fight the invading [[Seanchan]] army just outside Illian. He broke position to charge a group of Seanchan, allowing another group of Seanchan through to hit Rand's position from behind. He convinced Rand to keep advancing toward [[Ebou Dar]]. He leads [[Charl Gedwyn]], [[Kiril Drapaneos]], [[Bertome Saighan]] and [[Doressin Chuliandred]] into the final assault against the Seanchan. 
Rand brings him back to Cairhien and gives him servants that are loyal to Rand and [[Dobraine Taborwin]].
He is later seen conversing with Bertome in Cairhien's corridors.
Again disobeying Rand's orders he travels to Tear and is in the [[Stone of Tear]] when Rand arrives to talk to [[Darlin Sisnera]]. He wishes to gather a sortie and send into the rebels who are laying siege to the Stone of Tear, his own countryman. The idea is squashed by Darlin. Rand sends Weiramon with the rest of the Tairen forces into [[Arad Doman]].
He greets Rand with King Darlin when Rand withdraws his forces from Arad Doman back into Tear.
After Rand's personal redemption, he seems to gain the ability to tell a Darkfriend by looking into their eyes. He orders all the High Lords and Ladies into a line and confirms Weiramon and [[Anaiyella Narencelona]] as Darkfriends and sends them away as a warning to any others.
His fate is undisclosed, but Moridin states later to Rand that Weiramon was shocked at the trick Rand had done to him to work out he was a darkfriend.

## Notes






https://wot.fandom.com/wiki/Weiramon