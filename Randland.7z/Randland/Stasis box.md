---
tags: [AgeofLegends, ItemsofPower, Specialobjects]
---
*"The world had changed, as it seemed, in the blink of an eye.  There had been a world of war and killing on a huge scale, with weapons that reached across miles, across thousands of miles, and then there was...this."*
   —From the thoughts of the [[Gholam|gholam]] A **stasis box** is a technological device crafted during the [[Age of Legends]]. Though little information of these artifacts has survived the [[Third Age]], it is known that items held inside a sealed stasis box will never age, and that time is suspended within the box for as long it remains sealed. Indeed, from the perception of a creature - or object - placed into a stasis box, as soon as the lid of the device closes it immediately re-opens. This bizarre time-defying effect is directly experienced by the [[Gholam|gholam]] which pursues [[Matrim Cauthon]]. It is probable that the creature was either placed or tricked into a stasis box during the height of the [[War of Power]], and released in 999 NE. Moreover, it is possible that the ornate container found at the [[Eye of the World]] containing the [[Horn of Valere]] and the [[Dragon Banner]] was a stasis box put into place by [[Solinda]], [[Oselle]] and [[Zorelle]] Sedai after the destruction of [[Paaran Disen]] in the hopes that its unaged contents would be recovered in the far future by the [[Dragon Reborn]].
Sometime prior to 998 NE, [[Ishamael]] located a stasis box that contained dozens of [[Zomara|zomara]], which later serve wine to [[Darkfriends]] at the [[Darkfriend Social]]. In 999 NE [[Graendal]] found a stasis box that contained [[Streith]] and [[Sammael]] found another which contained "lots of goodies, and something else," - a possible reference to the gholam.

## Notes






https://wot.fandom.com/wiki/Stasis_box