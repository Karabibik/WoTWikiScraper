---
tags: [Noblehouses, Andor, Cairhien]
---
**House Saighan** is one of the three major noble houses in [[Cairhien]]; along [[House Damodred]] and [[House Riatin]] this three houses struggle regularly for the throne. 
The colors of House Saighan are red, yellow and silver. The sign of House Saighan is a silver diamond on a red and yellow checked field. The High Seat of House Saighan was [[Colavaere Saighan]] who was crowned Queen of Cairhien after the death of King [[Galldrian Riatin]], but after nine days of her reign, she was deposed by [[Rand al'Thor]], who reduced her to the status of a commoner and sentenced her to live out the rest of her life on a farm. Colavaere committed suicide by hanging rather than face such a disgrace.  
Colavaere was succeeded by her cousin [[Bertome Saighan]] as High Seat. He eventually supported [[Elayne Trakand]] as Queen of Cairhien on the condition that he was offered a portion of the [[Andor|Andoran]] estates of [[Arymilla Marne]], [[Elenia Sarand]] and [[Naean Arawn]].
[[Dairaine Saighan]] is another member of House Saighan. She was taken as *gai'shain* by the [[Shaido]]. 


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/House_Saighan