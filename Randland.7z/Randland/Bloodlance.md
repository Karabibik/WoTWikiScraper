---
tags: [Horses]
---






**Bloodlance** is a tall bay horse that belongs to [[Harril]]. 

## Activities
When Harril returns to the [[White Tower]] from Southharbor after [[Aes Sedai]] capture [[Egwene al'Vere]], Harril rides Bloodlance and has him stabled.

## Notes






https://wot.fandom.com/wiki/Bloodlance