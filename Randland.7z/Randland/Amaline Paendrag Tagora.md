---
tags: [Women, Shandalle_people, Rulers, Queens, Deceased, Historicalpeople]
---


**Amaline Paendrag Tagora** was the first wife of [[Artur Paendrag Tanreall]] and was the Queen of [[Shandalle]] and later the High Queen of the [[Westlands]]. 

## History
She married Artur in [[FY 937]], when Tanreall was twenty-five and the Prince of Shandalle. Two years later the [[Black Fever]] swept across the continent and killed Tanreall's parents, making him King and Amaline Queen of Shandalle.
Within four years, Amaline's husband became known as "Artur Hawkwing," for the speed at which he could move his troops and had won a stunning victory over the [[False Dragon|false Dragon]] [[Guaire Amalasan]]. Hawkwing spent the next twenty years resisting attacks from other rulers until he had conquered the entire continent in a war known as the [[Consolidation]].
Hawkwing appears to have genuinely loved his wife and historians have uncovered several poems he wrote to his wife, apparently spanning the length of their marriage. In [[FY 942]] Amaline gave birth to twins, [[Amira Paendrag|Amira]] and [[Modair Paendrag|Modair]], and later to another son and daughter, whose names are not recorded.
Modair died in battle in [[FY 959]], devastating both his parents, but in [[FY 961]] Amaline and her three remaining children were all killed by poison. Hawkwing flew into a legendary rage, marking the beginning of the [[Black Years]] of his rule, and became bitter, ruthless and even cruel as he brought the war to a conclusion with the conquest of [[Aldeshar]]. In his fury, he launched an ill-considered invasion of the [[Aiel Waste]] and suffered his first major defeat. He was brought out of this time of rage by a woman named [[Tamika]], who became his second wife in [[FY 965]].
In [[FY 974]] Hawkwing turned violently against the [[Aes Sedai]] and the following year began a siege of [[Tar Valon]] that would last the rest of his life. Some historians have suggested that the reason for his violent turn against Tar Valon was that he uncovered evidence that it was the [[Amyrlin Seat]], [[Bonwhin Meraighdin]], who had his wife and children poisoned. Whether this is true or not remains unknown.






https://wot.fandom.com/wiki/Amaline_Tagora