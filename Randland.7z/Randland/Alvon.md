---
tags: [Men, Amadicia_people, Gaishain, LivingasofKOD, ]
---


**Alvon** is a woodcutter from [[Amadicia]]. His son is [[Theril]].

## Appearance
He is stocky.

## Activities
He is made *gai'shain* by the [[Shaido]] [[Aiel]]. He and his son continue to try and escape from the Shaido, taking longer to find each time.
He swears fealty to [[Faile Bashere]] and later on brings the [[Oath Rod]] to Faile, after his son steals it.






https://wot.fandom.com/wiki/Alvon