---
tags: [Men, Soldiers, Generals, Deceased, Authors, Historicalpeople]
---



*"It is always better to kill your enemies far off than close at hand."*
   —Madoc Comadrin 
**Madoc Comadrin** was a [[General|general]] who lived approximately six hundred years before the era of [[Artur Paendrag Tanreall|Artur Hawkwing]]. He was a genius of military strategy and authored a book entitled *Fog and Steel*.

## Referenced
Centuries later [[Matrim Cauthon]] often quotes Comadrin, from his book and from his own memories of actually meeting him. King [[Roedran Almaric do Arreloa a'Naloy]] was also very impressed with Comadrin's book and printed some copies of it. In respons to [[Musenge]]'s querry about Mat not donning armor and participating in battle, Mat quotes Comadrin, saying *"a general who draws his sword has put aside his baton and become a common soldier."*

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Madoc_Comadrin