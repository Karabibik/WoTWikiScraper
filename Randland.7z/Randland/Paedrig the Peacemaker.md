---
tags: [Men, HeroesoftheHorn, BoundtotheWheel, Parallels, Historicalpeople]
---


**Paedrig the Peacemaker** is one of the [[Heroes of the Horn]]. He is said to be a golden-tongued peacemaker.

## Summoned by the Horn
He appears at [[Falme]] when [[Matrim Cauthon]] blows the [[Horn of Valere]]. [[Rand al'Thor]] knows him as Patrick as well as Paedrig. Mat later remembers Paedrig when he is talking with [[Birgitte Silverbow]].

## Parallels
Paedrig is a parallel to . Pádraig is the Irish version of the English name Patrick. His reputation as a golden-tongued peacemaker may stem from the conversions of many pagans in Ireland to Christianity, including sons and daughters of Irish Kings, or from the reputation of the Irish having the *gift of the gab*.

## Notes






https://wot.fandom.com/wiki/Paedrig_the_Peacemaker