---
tags: [Men, Tuathaan_people, Seekers, LivingasofAMOL]
---


**Raen** is a [[Seeker|Mahdi]] of the *Tuatha'an*. He is married to [[Ila]].

## Contents

1 Appearance
2 Activities

2.1 Last Battle


3 In the television series
4 Notes


## Appearance
He is short, wiry and gray-haired.  

## Activities
He showed [[Perrin Aybara]], [[Egwene al'Vere]] and [[Elyas Machera]] hospitality when they approached his camp. 

After Perrin had returned to the Two Rivers; on the way back after their hunting party was attacked by Trollocs; they encountered a band of Tinkers. Odd it was for the chances of him to meet Raen again after so long. He offers them protection in the Two Rivers; when all other towns had deserted them. Raen says he will consider it; however that decision is taken away from him when Trollocs attack the wagons, killing many of his people. he takes Perrin's offer of protection and later with others help in the defense of the Two Rivers by protecting the children so that the women and girls could help drive back the hordes of Trollocs about pressing from all sides.

### Last Battle
Raen seeks the wounded along with his wife and wonders if he should fight, since the Trollocs would not care for the Way of the Leaf. Ila discourages him from picking up weapons stating that the fight is for the soldiers and that they could either flee or submit.

## In the television series
In the [[The Wheel of Time (TV series)|TV series]],  
## Notes

*This page is a stub. You can help A Wheel of Time Wiki by expanding it. *





https://wot.fandom.com/wiki/Raen