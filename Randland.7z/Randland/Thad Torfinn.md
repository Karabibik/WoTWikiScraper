---
tags: [Men, Andor_people, TwoRivers_people, Farmers, LivingasofKOD]
---






**Thad Torfinn** is a [[Two Rivers]] resident. He is a farmer.

## Appearance
He is skinny.

## Activities
He comes to [[Faile Bashere]] over a boundary dispute with [[Jon Ayellin]].
He [[Travel|Travels]] through [[Jur Grady]]'s [[Gateway]] to join the rest of the [[Two Rivers]] men taken by [[Perrin Aybara]]. He participates in the [[Battle of Malden]].






https://wot.fandom.com/wiki/Thad_Torfinn