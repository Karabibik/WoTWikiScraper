---
tags: [Militaryunits]
---
A **troop** is a military unit led by a [[Lieutenant|lieutenant]] consisting of fifty [[Cavalry|cavalry]].


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Troop