---
tags: [Terangreal, ItemsofPower]
---
The **fancloth ter'angreal** is a *ter'angreal* in the possession of the [[White Tower]].

## Appearance
The appearance of the *ter'angreal* is unknown, as it has only ever been mentioned and never shown.

## Use
The *ter'angreal* is used to make the color-shifting material known as [[Fancloth|fancloth]], which is used to make [[Warder]]' cloaks. In the Age of Legends, this was used to make clothing in the highest fashion.



This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Fancloth_ter%27angreal