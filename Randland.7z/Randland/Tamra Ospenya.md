---
tags: [Women, BlueAjah, AmyrlinSeats, AesSedai, Deceased, HighRankingAesSedai, Channelers]
---


**Tamra Ospenya** (pronounced: TAHM-rah oh-SPEHN-yah) was the [[Amyrlin Seat]] at the time of [[Rand al'Thor]]'s birth, raised from the [[Blue Ajah]] in 973 NE.

## Contents

1 Appearance
2 Strength
3 History
4 Activities
5 Notes


## Appearance
She was described as having long hair streaked with gray as well as a square face.

## Strength
In "The Wheel of Time Companion" her level of strength is described as 19(7) which is a bit low considering the rank and role assumed by Tamra in the main books. Most probably her real level is around 17(5) which can be also considered the minimum level to become an Amyrlin Seat.

## History
She was thought to be fair and always just. She also seemed to be a devious manipulator.
She was raised to Amyrlin Seat from the Blue Ajah in 973 NE. Her raising to the staff and stole was rumored to be the reason for the retirement of [[Romanda Cassin]] and [[Marith Jaen]].
She was [[Noane Masadim]]'s successor and [[Sierin Vayu]]'s predecessor. This makes her the first known Amyrlin Seat to be raised from the same Ajah as her predecessor. It has been speculated that as with the case of [[Marith Jaen]] and [[Siuan Sanche]], this consecutive pair of Blue Amyrlins was the work of the political skill of the Blue Ajah [[First Selector]] of the time, [[Eadyth]], who was also a [[Sitter]] at the time.


## Activities
On the last day of the [[Aiel War]], as the [[Battle of the Shining Walls]] ended, Tamra was one of three people to hear [[Gitara Moroso]]'s [[Foretelling]] of the rebirth of the [[Dragon]] immediately before Gitara died. At this point Tamra began her search for the child she knew must be born by appointing [[Tamra Ospenya's Searchers|searchers]]. The other two present, the then [[Accepted]] [[Moiraine Damodred]] and Siuan Sanche, were forbidden to reveal this secret to anyone. 
When the [[Black Ajah]] discovered what had happened, they—[[Galina Casban]] and [[Chesmal Emry]] in particular—tortured and murdered Tamra, along with the [[Aes Sedai]] that she had sent searching for the Dragon Reborn. Tamra's death in the tower was explained by an announcement that she had "died in her sleep." This left only Moiraine and Siuan outside of the Black who knew of the rebirth, so this began their search. 
[[Alviarin Freidhen|Alviarin Freidnen]] remembers that it was [[Jarna Malari]], the former head of the Balck Ajah, who ordered this quite unsuccessful interrogation.

## Notes






https://wot.fandom.com/wiki/Tamra