---
tags: [, HerbsandMedicines]
---
**Boneknit** is an [[Herb|herb]] known for its healing properties, specifically when used to heal broken bones. [[Nynaeve al'Meara]] references the herb in a discussion with [[Ailhuin Guenna]] in [[Tear]], though they each know it by a different name. This suggests that the plant is one that grows over a large portion of the continent.

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Boneknit