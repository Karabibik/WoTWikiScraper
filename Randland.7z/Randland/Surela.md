---
tags: [Women, Seanchan_people, Suldam, LivingasofTSR, Channelers, Learners]
---


**Surela** is a *der'sul'dam* from [[Seandar]] that is with [[Suroth Sabelle Meldarath]] on [[Cantorin]]. 

## Activities
When [[Taisa]] fails to control [[Pura]] properly during an interview with Suroth, [[Alwhin]] tells her to seek out Surela to learn how to be a better *sul'dam*.

## Notes






https://wot.fandom.com/wiki/Surela