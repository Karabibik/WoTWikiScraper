---
tags: [Men, Malkier_people, Lords, Deceased, Nobility]
---




**Lain Mandragoran** was the brother of [[Al'Akir Mandragoran|al'Akir Mandragoran]] of lost [[Malkier]]. His wife was [[Breyan Mandragoran]] and his nephew is [[Lan Mandragoran]].

## History
On a dare from his wife Breyan, he led a number of men into the [[Great Blight|Blight]] where they perished. He was a great man and it was a huge loss to Malkier, weakening it for a huge [[Trolloc]] invasion, which ultimately destroyed it. He was survived by his son Isam ([[Slayer]]).






https://wot.fandom.com/wiki/Lain_Mandragoran