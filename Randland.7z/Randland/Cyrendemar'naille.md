---
tags: [, Towns, Aridhol, Historicalsettlements]
---
**Cyrendemar'naille** was an Ogier-built city in [[Aridhol]], one of the [[Ten Nations]] after the [[Breaking of the World|Breaking]].

## Notes


This is a short page. All known information from the *Wheel of Time* universe has been added. Please **do not add** {{stub}}.







https://wot.fandom.com/wiki/Cyrendemar%27naille