---
tags: [Men, Cairhien_people, Warders, LivingasofTGS, ]
---


**Bassane** is [[Warder]] to [[Merise Haindehl]].

## Appearance
He is short and wide with quite a dark complexion.

## Activities
He [[Traveling|Travels]] with Merise to [[Far Madding]] and then to [[Shadar Logoth]] where he scouts the surrounding area during the [[Battle near Shadar Logoth]] and the [[Cleansing of saidin|cleansing of saidin]].
He accompanies [[Rand al'Thor]] and Merise to [[Algarin Pendaloan]]'s house in [[Tear]], where Rand recovers after cleansing *saidin*. He watches Lan and [[Jahar Narishma]] practice with their swords in the courtyard with the other Warders.
Bassane also accompanies Merise and [[Nethan]], Merise's other Warder, when they visit [[Salidar]] and the [[Rebel Aes Sedai]]. Later, he is part of the entourage that Rand takes to meet the Daughter of the Nine moons, who turns out to be [[Semirhage]]. Bassane also joins Merise and Nethan when Merise seeks an audience with Rand.

## Notes






https://wot.fandom.com/wiki/Bassane